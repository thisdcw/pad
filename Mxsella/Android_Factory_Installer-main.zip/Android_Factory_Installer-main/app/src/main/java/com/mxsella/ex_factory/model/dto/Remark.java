package com.mxsella.ex_factory.model.dto;

import java.util.List;

public class Remark {
    private List<String> localCachePath;
    private List<String> whiteList;
    private List<String> pluginList;

    public List<String> getPluginList() {
        return pluginList;
    }

    public void setPluginList(List<String> pluginList) {
        this.pluginList = pluginList;
    }

    public List<String> getLocalCachePath() {
        return localCachePath;
    }

    public void setLocalCachePath(List<String> localCachePath) {
        this.localCachePath = localCachePath;
    }

    public List<String> getWhiteList() {
        return whiteList;
    }

    public void setWhiteList(List<String> whiteList) {
        this.whiteList = whiteList;
    }

    @Override
    public String toString() {
        return "Remark{" +
                "localCachePath=" + localCachePath +
                ", whiteList=" + whiteList +
                ", pluginList=" + pluginList +
                '}';
    }
}
