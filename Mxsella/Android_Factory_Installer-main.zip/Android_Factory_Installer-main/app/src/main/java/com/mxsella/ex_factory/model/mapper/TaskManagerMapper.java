package com.mxsella.ex_factory.model.mapper;

public class TaskManagerMapper {

    public static final int IS_INSTALL = 1;
    public static final int NOT_INSTALL = 0;
    public static final int HAS_UPDATE = 1;
    public static final int HAS_NOT_UPDATE = 0;


}
