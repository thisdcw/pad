package com.mxsella.ex_factory.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

/**
 * apk 工具类
 */
public class ApkUtils {

    /**
     * 获取apk包名
     *
     * @param context 上下文
     * @param apkPath apk路径
     * @return apk包名
     */
    public static String getApkPackageName(Context context, String apkPath) {
        PackageManager packageManager = context.getPackageManager();
        PackageInfo packageInfo = packageManager.getPackageArchiveInfo(apkPath, 0);

        if (packageInfo != null) {
            return packageInfo.packageName;
        }
        return null;
    }



}
