package com.mxsella.ex_factory.ui.adapter;

import android.view.View;

import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.brv.BaseRVAdapter;
import com.mxsella.ex_factory.base.brv.DBHolder;
import com.mxsella.ex_factory.databinding.ItemApkBinding;
import com.mxsella.ex_factory.model.dto.ApkMenu;

public class ApkMenuAdapter extends BaseRVAdapter<ApkMenu, ItemApkBinding> {

    private OnSelectClick onSelectClick;

    @Override
    public void initView(DBHolder<ItemApkBinding> holder, int position, ApkMenu item) {
        binding.setItem(item);
        binding.select.setOnClickListener(v -> {
            if (onSelectClick != null) {
                onSelectClick.OnClick(item, v);
            }
        });
    }

    @Override
    public int layoutId() {
        return R.layout.item_apk;
    }

    public interface OnSelectClick {

        void OnClick(ApkMenu info, View view);
    }

    public void setOnSelectClick(OnSelectClick onSelectClick) {
        this.onSelectClick = onSelectClick;
    }
}
