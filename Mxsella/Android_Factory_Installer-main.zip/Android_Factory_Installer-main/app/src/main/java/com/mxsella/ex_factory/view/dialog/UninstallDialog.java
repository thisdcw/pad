package com.mxsella.ex_factory.view.dialog;

import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.view.BaseDialog;
import com.mxsella.ex_factory.databinding.DialogUninstallBinding;
import com.mxsella.ex_factory.inter.DialogClickListener;

public class UninstallDialog extends BaseDialog<DialogUninstallBinding> {

    private DialogClickListener dialogListener;

    public UninstallDialog() {

    }

    @Override
    public void initView() {
        super.initView();
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new Dialog(context, R.style.MyDialog);
    }

    @Override
    public void initEventAndData() {
        binding.cancel.setOnClickListener(v -> {
            if (dialogListener != null) {
                dialogListener.onCancel();
            }
            dismiss();
        });
        binding.confirm.setOnClickListener(v -> {
            if (dialogListener != null) {
                dialogListener.onConfirm();
            }
            dismiss();
        });

    }

    public void setDialogListener(DialogClickListener dialogListener) {
        this.dialogListener = dialogListener;
    }

    @Override
    public int getLayout() {
        return R.layout.dialog_uninstall;
    }

}
