package com.mxsella.ex_factory.util;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;

import com.mxsella.ex_factory.MyApplication;
import com.mxsella.ex_factory.base.Config;
import com.mxsella.ex_factory.manager.ActivityStackManager;
import com.mxsella.ex_factory.model.DiskInfo;
import com.mxsella.ex_factory.ui.ac.CheckActivity;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppUtils {

    private static final String TAG = "AppUtil";

    public static String getVersionName(Context context) {
        String versionName = "1.0";
        try {
            versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.i(TAG, "versionName:" + versionName);
        return versionName;
    }

    public static int getVersionCode(Context context) {
        int versionCode = 1;
        try {
            versionCode = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.i(TAG, "versionCode:" + versionCode);
        return versionCode;
    }

    /**
     * 重启APP
     */
    public static void reStartApp(final Context context, final long time, final boolean killFlag) {
        new Thread(() -> {
            try {
                Thread.sleep(time);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            ActivityStackManager.getInstance().finishAll();
            Intent bootIntent = new Intent(context, CheckActivity.class);
            bootIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(bootIntent);
            if (killFlag) System.exit(0);
        }).start();
    }

    /**
     * 获得当前屏幕亮度值
     *
     * @return 0--255
     */
    public static int getScreenBrightness() {
        int screenBrightness = -1;
        try {
            screenBrightness = Settings.System.getInt(MyApplication.getInstance().getContentResolver(),
                    Settings.System.SCREEN_BRIGHTNESS);
        } catch (Settings.SettingNotFoundException e) {
            e.printStackTrace();
        }
        return screenBrightness;
    }

    /**
     * 保存当前的屏幕亮度值，并使之生效
     *
     * @param paramInt 0-255
     */
    public static void setScreenBrightness(int paramInt) {
        Settings.System.putInt(MyApplication.getInstance().getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS, paramInt);
        Uri uri = Settings.System
                .getUriFor("screen_brightness");
        MyApplication.getInstance().getContentResolver().notifyChange(uri, null);
    }

    /**
     * 获取所有外部存储设备的路径。
     *
     * @param context 上下文
     * @return 外部存储设备的路径列表
     */
    public static Set<String> getExternalStoragePaths(Context context) {
        Set<String> paths = new HashSet<>();
        ContentResolver contentResolver = context.getContentResolver();

        // 查询 MediaStore 中的外部文件
        Uri externalUri = MediaStore.Files.getContentUri("external");
        String[] projection = {MediaStore.Files.FileColumns.DATA};

        try (Cursor cursor = contentResolver.query(
                externalUri,
                projection,
                null,
                null,
                null)) {

//            if (cursor != null) {
//                int dataIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);
//                while (cursor.moveToNext()) {
//                    String filePath = cursor.getString(dataIndex);
//                    if (filePath != null) {
//                        // 获取文件所在的目录作为外部存储路径
//                        String directoryPath = new java.io.File(filePath).getParent();
//                        if (directoryPath != null) {
//                            paths.add(directoryPath);
//                        }
//                    }
//                }
//            }
            if (cursor != null) {
                int dataIndex = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA);
                while (cursor.moveToNext()) {
                    String filePath = cursor.getString(dataIndex);
                    if (filePath != null) {
                        String[] split = filePath.split("/");
                        paths.add(split[split.length - 1]);  // 直接添加文件路径
                    }
                }
            }

        }

        return paths;
    }

    public static List<String> getAllFiles(ContentResolver contentResolver) {
        List<String> filePaths = new ArrayList<>();

        // 获取Download文件夹的路径
        File downloadDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);

        // 确保目录存在
        if (downloadDirectory.exists() && downloadDirectory.isDirectory()) {
            // 获取目录下的所有文件和子目录
            File[] files = downloadDirectory.listFiles();
            if (files != null) {
                for (File file : files) {
                    // 只添加文件，忽略目录
                    if (file.isFile()) {
                        filePaths.add(file.getAbsolutePath());
                    }
                }
            }
        }

        File documentDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        if (documentDirectory.exists() && documentDirectory.isDirectory()) {
            File[] files = documentDirectory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        filePaths.add(file.getAbsolutePath());
                    }
                }
            }
        }

        scanDirectory(new File("/storage/9223-4C51"), filePaths);

//        Map<String, DiskInfo> diskMap = Config.diskMap;
//        for (String s : diskMap.keySet()) {
//            File usbDirectory = new File(s);
//            if (usbDirectory.exists() && usbDirectory.isDirectory()) {
//                scanDirectory(usbDirectory, filePaths);
//            }
//        }


        return filePaths;
    }

    private static void scanDirectory(File directory, List<String> filePaths) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    scanDirectory(file, filePaths);  // 递归扫描子目录
                } else {
                    filePaths.add(file.getAbsolutePath());  // 添加文件路径到列表中
                }
            }
        }
    }
    public static long getFileSize(String filePath) {
        File file = new File(filePath);

        if (file.exists() && file.isFile()) {
            return file.length();  // 返回文件大小（以字节为单位）
        } else {
            throw new IllegalArgumentException("File does not exist or is not a file: " + filePath);
        }
    }
    public static boolean isWifiConnect(Context context) {
        ConnectivityManager connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mWifiInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        return mWifiInfo.isConnected();
    }

    public static int getWifiStrength(Context context) {
        int index = 3;
        if (isWifiConnect(context)) {
            WifiManager mWifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            WifiInfo mWifiInfo = mWifiManager.getConnectionInfo();
            int wifi = mWifiInfo.getRssi();//获取wifi信号强度
            if (wifi > -50 && wifi < 0) {//最强
                index = 4;
            } else if (wifi > -70 && wifi < -50) {//较强
                index = 3;
            } else if (wifi > -80 && wifi < -70) {//较弱
                index = 2;
            } else if (wifi > -100 && wifi < -80) {//微弱
                index = 1;
            }
        } else {
            //无连接
            index = 0;
        }
        return index;
    }
}
