package com.mxsella.ex_factory.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FileScanner {
    private final ExecutorService executorService;

    public FileScanner() {
        executorService = Executors.newSingleThreadExecutor();
    }

    public void scanUsbFiles(String usbPath, ScanCompleteListener listener) {
        executorService.execute(() -> {
            List<String> filePaths = new ArrayList<>();
            File usbDirectory = new File(usbPath);

            if (usbDirectory.exists() && usbDirectory.isDirectory()) {
                scanDirectory(usbDirectory, filePaths);
            }

            // 通过主线程回调结果
            listener.onScanComplete(filePaths);
        });
    }

    private void scanDirectory(File directory, List<String> filePaths) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    scanDirectory(file, filePaths);  // 递归扫描子目录
                } else {
                    filePaths.add(file.getAbsolutePath());  // 添加文件路径到列表中
                }
            }
        }
    }

    public interface ScanCompleteListener {
        void onScanComplete(List<String> filePaths);
    }
}
