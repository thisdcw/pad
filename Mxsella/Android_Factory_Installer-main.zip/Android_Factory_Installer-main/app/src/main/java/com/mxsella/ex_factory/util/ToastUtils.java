package com.mxsella.ex_factory.util;

import android.widget.Toast;

import com.mxsella.ex_factory.MyApplication;


public class ToastUtils {
    public static void showToast(String info) {
        showToast(info, Toast.LENGTH_SHORT);
    }

    public static void showLongToast(String info) {
        showToast(info, Toast.LENGTH_LONG);
    }

    public static void showToast(String info, int duration) {
        Toast.makeText(MyApplication.getInstance(), info, duration).show();
    }

}
