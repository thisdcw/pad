package com.mxsella.ex_factory.ui.adapter;

import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.brv.BaseRVAdapter;
import com.mxsella.ex_factory.base.brv.DBHolder;
import com.mxsella.ex_factory.databinding.ItemUsbContentBinding;
import com.mxsella.ex_factory.model.FileInfo;

public class UsbAdapter extends BaseRVAdapter<FileInfo, ItemUsbContentBinding> {
    @Override
    public void initView(DBHolder<ItemUsbContentBinding> holder, int position, FileInfo item) {
        binding.setItem(item);
    }

    @Override
    public int layoutId() {
        return R.layout.item_usb_content;
    }
}
