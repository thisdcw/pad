package com.mxsella.ex_factory.ui.adapter;

import android.view.View;

import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.brv.BaseRVAdapter;
import com.mxsella.ex_factory.base.brv.DBHolder;
import com.mxsella.ex_factory.databinding.ItemAppBinding;
import com.mxsella.ex_factory.model.AppInfo;

public class AppAdapter extends BaseRVAdapter<AppInfo,ItemAppBinding> {

    private OnSelectClick onSelectClick;

    @Override
    public void initView(DBHolder<ItemAppBinding> holder, int position, AppInfo item) {
        binding.setItem(item);
        binding.select.setOnClickListener(v -> {
            if (onSelectClick != null) {
                onSelectClick.OnClick(item, v);
            }
        });
    }

    @Override
    public int layoutId() {
        return R.layout.item_app;
    }

    public interface OnSelectClick {

        void OnClick(AppInfo info, View view);
    }
    public void setOnSelectClick(OnSelectClick onSelectClick) {
        this.onSelectClick = onSelectClick;
    }
}
