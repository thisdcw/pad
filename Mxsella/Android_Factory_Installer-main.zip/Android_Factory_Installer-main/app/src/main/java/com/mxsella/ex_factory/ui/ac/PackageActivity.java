package com.mxsella.ex_factory.ui.ac;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.gson.Gson;
import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.util.FileDownloadUtils;
import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.view.BaseActivity;
import com.mxsella.ex_factory.base.Config;
import com.mxsella.ex_factory.base.Constant;
import com.mxsella.ex_factory.databinding.ActivityPackageBinding;
import com.mxsella.ex_factory.db.PackageManager;
import com.mxsella.ex_factory.inter.DataChangeListener;
import com.mxsella.ex_factory.inter.DialogClickListener;
import com.mxsella.ex_factory.manager.TaskManager;
import com.mxsella.ex_factory.model.AppInfo;
import com.mxsella.ex_factory.db.domain.AppPackage;
import com.mxsella.ex_factory.model.dto.ApkInfo;
import com.mxsella.ex_factory.model.dto.ApkMenu;
import com.mxsella.ex_factory.model.dto.Remark;
import com.mxsella.ex_factory.model.dvo.TaskManagerModel;
import com.mxsella.ex_factory.model.mapper.TaskManagerMapper;
import com.mxsella.ex_factory.model.request.ApkListRequestBody;
import com.mxsella.ex_factory.model.response.ListResponse;
import com.mxsella.ex_factory.model.response.ResultType;
import com.mxsella.ex_factory.ui.adapter.ApkMenuAdapter;
import com.mxsella.ex_factory.ui.adapter.TaskAdapter;
import com.mxsella.ex_factory.util.DownloadUtil;
import com.mxsella.ex_factory.util.LogUtil;
import com.mxsella.ex_factory.util.ToastUtils;
import com.mxsella.ex_factory.view.dialog.UninstallDialog;
import com.mxsella.ex_factory.vm.ApkVM;
import com.scwang.smart.refresh.footer.ClassicsFooter;
import com.scwang.smart.refresh.header.ClassicsHeader;
import com.scwang.smart.refresh.layout.api.RefreshLayout;

import org.apache.commons.lang3.RandomUtils;
import org.litepal.LitePal;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PackageActivity extends BaseActivity<ActivityPackageBinding> implements DataChangeListener {
    private final ApkVM apkVM = new ApkVM();
    private int cur = 1;
    private int size = 20;
    private int total = 0;
    private RefreshLayout packageMenuRefreshLayout;

    private static final int REQUEST_INSTALL_PERMISSION = 1234;
    private TaskAdapter taskAdapter;

    private ApkMenuAdapter apkMenuAdapter;

    private String selectApkId;

    private TaskManagerModel selectApkModel;

    private UninstallDialog uninstallDialog;

    private List<AppPackage> isInstallPkg;
    private AppPackage handlerAppPackage = new AppPackage();

    private List<TaskManagerModel> pluginList = new ArrayList<>();
    private List<TaskManagerModel> modelList = new ArrayList<>();
    private List<TaskManagerModel> originlList = new ArrayList<>();
    String menuId = "";
    private BroadcastReceiver packageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            Uri uri = intent.getData();
            String packageName = uri != null ? uri.getSchemeSpecificPart() : null;

            if (Intent.ACTION_PACKAGE_ADDED.equals(action)) {
                LogUtil.d("应用已安装: " + packageName);
                handlerAppPackage.setType(Constant.APP_INSTALL);
                saveRecord();
//                if (taskAdapter != null) {
//                    taskAdapter.notifyDataSetChanged();
//                }
            } else if (Intent.ACTION_PACKAGE_REMOVED.equals(action)) {
                LogUtil.d("应用已卸载: " + packageName);
//                if (taskAdapter != null) {
//                    taskAdapter.notifyDataSetChanged();
//                }
            } else if (Intent.ACTION_PACKAGE_REPLACED.equals(action)) {
                LogUtil.d("应用已更新: " + packageName);
//                if (taskAdapter != null) {
//                    taskAdapter.notifyDataSetChanged();
//                }
            }
        }
    };

    public boolean deleteFileAtPath(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            if (file.delete()) {
                LogUtil.d("文件删除成功: " + filePath);
                return true;
            } else {
                LogUtil.d("文件删除失败: " + filePath);
                return false;
            }
        } else {
            LogUtil.d("文件不存在: " + filePath);
            return false;
        }
    }

    private void saveRecord() {
        AppPackage lastPackage = LitePal.findLast(AppPackage.class);
        if (lastPackage == null) {
            handlerAppPackage.setId(1);
        } else {
            handlerAppPackage.setId(lastPackage.getId() + 1);
        }
        handlerAppPackage.setApkId(selectApkModel.getApkId());
        handlerAppPackage.setItemId(selectApkModel.getItemId());
        handlerAppPackage.setPackageName(selectApkModel.getPackageName());
        handlerAppPackage.setVersionCode(selectApkModel.getVersionCode());
        handlerAppPackage.setRemark(selectApkModel.getRemark());
        new PackageManager.Singleton().getInstance().saveOrUpdate(handlerAppPackage);
        handlerAppPackage = new AppPackage();
        deleteFileAtPath(selectApkModel.getPath());

        getApkList();
    }

    @Override
    public int layoutId() {
        return R.layout.activity_package;
    }

    @Override
    public void initView() {

        registerPackageReceive();

        isInstallPkg = new PackageManager.Singleton().getInstance().getAll();
        LogUtil.d(isInstallPkg.toString());

        Bundle extras = getIntent().getExtras();
        String title = "";
        if (extras != null) {
            title = (String) extras.get("menuName");
            menuId = (String) extras.get("menuId");
        }
        binding.navBar.getTitleTextView().setText(title);
        initRefreshLayout();
        getApkList();
        initTask();
        initUsb();
    }

    private void registerPackageReceive() {
        // 创建 IntentFilter 监听应用安装、卸载、更新
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_PACKAGE_ADDED);
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        filter.addAction(Intent.ACTION_PACKAGE_REPLACED);
        filter.addDataScheme("package");  // 必须加上这一行
        // 注册广播接收器
        registerReceiver(packageReceiver, filter);
    }

    private void initRefreshLayout() {
        binding.packageInfo.setLayoutManager(new LinearLayoutManager(this));
        binding.packageInfo.setAdapter(taskAdapter = new TaskAdapter());

    }

    private void initTask() {
        TaskManager.getImpl().onCreate(new WeakReference<>(this));
        TaskManager.getImpl().setTaskUpdateListener(taskAdapter);
        initAdapterListener();
    }

    private void resetTask() {
        runOnUiThread(() -> {
            modelList = new ArrayList<>();
            for (TaskManagerModel model : originlList) {
                if (model.getApkId().equals(selectApkId)) {
                    modelList.add(model);
                }
            }
            TaskManager.getImpl().setModelList(modelList);
        });
    }

    private void initUsb() {
        packageMenuRefreshLayout = binding.rvPackageMenu.refreshLayout;
        packageMenuRefreshLayout.setRefreshHeader(new ClassicsHeader(this));
        packageMenuRefreshLayout.setRefreshFooter(new ClassicsFooter(this));
        binding.rvPackageMenu.rv.setLayoutManager(new LinearLayoutManager(this));
        binding.rvPackageMenu.rv.setAdapter(apkMenuAdapter = new ApkMenuAdapter());
    }


    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void postNotifyDataChanged() {
        if (taskAdapter != null) {
            runOnUiThread(() -> {
                if (taskAdapter != null) {
                    taskAdapter.notifyDataSetChanged();
                }
            });
        }
    }

    @Override
    public void initObserve() {
        apkVM.getAppList().observe(this, result -> {
            if (result.getResultCode().getCode() == ResultType.SUCCESS) {
                ListResponse<ApkMenu> data = result.getData();
                if (data != null) {
                    total = data.getTotal();
                    isInstallPkg = new PackageManager.Singleton().getInstance().getAll();
                    LogUtil.test(isInstallPkg.toString());
                    List<ApkMenu> records = data.getRecords();
                    if (records != null && !records.isEmpty()) {
                        binding.rvPackageMenu.empty.setVisibility(View.GONE);
                        binding.empty.setVisibility(View.GONE);
                        apkMenuAdapter.submitList(records);
                        modelList.clear();
                        originlList.clear();
                        handlerApk(records);
                    } else {
                        binding.rvPackageMenu.empty.setVisibility(View.VISIBLE);
                        binding.empty.setVisibility(View.VISIBLE);
                    }
                } else {
                    binding.rvPackageMenu.empty.setVisibility(View.VISIBLE);
                    binding.empty.setVisibility(View.VISIBLE);
                }
            } else {
                binding.rvPackageMenu.empty.setVisibility(View.VISIBLE);
            }
        });

        apkVM.getAppByNameList().observe(this, result -> {
            if (result.getResultCode().getCode() == ResultType.SUCCESS) {
                List<ApkMenu> data = result.getData();
                if (!data.isEmpty()) {
                    isInstallPkg = new PackageManager.Singleton().getInstance().getAll();
                    LogUtil.test(isInstallPkg.toString());
                    handlerPluginApk(data);
                    LogUtil.d(data.toString());
                }
            }
        });
    }

    private void handlerPluginApk(List<ApkMenu> data) {
        List<TaskManagerModel> models = new ArrayList<>();

        for (ApkMenu record : data) {
            List<ApkInfo> infoList = record.getInfoList();
            for (ApkInfo itemInfo : infoList) {

                TaskManagerModel model = createModel(record, itemInfo);

                models.add(model);
            }
        }
        pluginList = models;
        TaskManager.getImpl().setModelList(pluginList);
    }

    private TaskManagerModel createModel(ApkMenu record, ApkInfo itemInfo) {
        String apkName = record.getApkInfo() + "(" + itemInfo.getItemName() + ") " + itemInfo.getVersionName();
        String packageName = record.getPackageName();

        //遍历数据库数据,判断数据库中是否有下载记录
        int isExist = TaskManagerMapper.NOT_INSTALL;

        //todo
        LogUtil.d(isInstallPkg.toString());
        for (AppPackage appPackage : isInstallPkg) {
            if (appPackage.getApkId().equals(itemInfo.getApkId())) {
                //验证本地是否安装(防止用户在外部卸载)

                if (DownloadUtil.isAppInstalled(this, record.getPackageName())) {

                    isExist = TaskManagerMapper.IS_INSTALL;
                } else {

                    //如果数据库中有,而本地未找到,则删除数据库记录
                    new PackageManager.Singleton().getInstance().deleteByPackageName(record.getPackageName());
                }
                break;
            }
        }

        String path = DownloadUtil.createDownloadPath(DownloadUtil.createApkName());
        String url = itemInfo.getApkLink();
        TaskManagerModel taskManagerModel = new TaskManagerModel();
        taskManagerModel.setId(FileDownloadUtils.generateId(url, path));
        taskManagerModel.setCategoryId(record.getCategoryId());
        taskManagerModel.setName(apkName);
        taskManagerModel.setPackageName(packageName);
        taskManagerModel.setApkId(itemInfo.getApkId());
        taskManagerModel.setUrl(url);
        taskManagerModel.setPath(path);
        taskManagerModel.setMd5(itemInfo.getMd5());
        taskManagerModel.setIsExist(isExist);
        taskManagerModel.setItemId(itemInfo.getItemId());
        taskManagerModel.setRemark(record.getRemark());
        taskManagerModel.setVersionCode(itemInfo.getVersionCode());
        taskManagerModel.setNeedExFactory(record.isNeedExFactory());

        return taskManagerModel;
    }

    private void handlerApk(List<ApkMenu> records) {
        new Thread(() -> {
            for (ApkMenu record : records) {
                List<ApkInfo> infoList = record.getInfoList();
                for (ApkInfo itemInfo : infoList) {
                    TaskManagerModel model = createModel(record, itemInfo);

                    originlList.add(model);
                }
            }
            resetTask();
        }).start();


    }

    private void getApkList() {
        String search = binding.etSearch.getText().toString();
        apkVM.fetchAppList(cur, size, new ApkListRequestBody(menuId, search));
    }

    @Override
    public void initListener() {

        packageMenuRefreshLayout.setOnRefreshListener(refreshlayout -> {
            cur = 1;
            size = 10;
            getApkList();
            refreshlayout.finishRefresh(Constant.FRESH_DELAY);//传入false表示刷新失败
        });
        packageMenuRefreshLayout.setOnLoadMoreListener(refreshlayout -> {
            size += 10;
            if (cur * size > total) {
                packageMenuRefreshLayout.setNoMoreData(true);
            } else {
                getApkList();
                refreshlayout.finishLoadMore(Constant.LOAD_DELAY);//传入false表示加载失败
            }
        });
        apkMenuAdapter.setOnSelectClick((info, view) -> {
            //筛选
            selectApkId = info.getApkId();
            resetTask();
        });
        binding.ivSearch.setOnClickListener(v -> {
            getApkList();
        });


    }

    public void uninstallApp(String packageName) {
        Log.d("UninstallApp", packageName);
        Uri packageUri = Uri.parse("package:" + packageName);
//        Uri packageUri = Uri.fromParts("package", packageName, null);
        Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageUri);
        uninstallLauncher.launch(uninstallIntent);
    }

    private ActivityResultLauncher<Intent> uninstallLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                LogUtil.d(result.toString());
                // 无论 resultCode 是什么，检查应用是否还存在
            }
    );

    private void showUninstallDialog() {

        //TODO bug,点击确认卸载后,出厂按钮并没有变化状态
        uninstallDialog = new UninstallDialog();
        uninstallDialog.setDialogListener(new DialogClickListener() {
            @Override
            public void onConfirm() {
                uninstallApp(selectApkModel.getPackageName());
            }

            @Override
            public void onCancel() {

            }
        });
        uninstallDialog.show(getSupportFragmentManager(), "uninstall_dialog");
    }

    private void initAdapterListener() {
        taskAdapter.setInstallListener(path -> {
            //检查是否已有应用
            LogUtil.i("安装apk: " + path);
            for (TaskManagerModel model : modelList) {
                if (model.getPath().equals(path)) {
                    selectApkModel = model;
                }
            }
            for (TaskManagerModel model : pluginList) {
                if (model.getPath().equals(path)) {
                    selectApkModel = model;
                }
            }
            LogUtil.d(selectApkModel.toString());
            Map<String, AppInfo> installedApps = DownloadUtil.getInstalledApps("");
            if (installedApps.containsKey(selectApkModel.getPackageName())) {
                LogUtil.d("存在同名应用,选择是否卸载");
                showUninstallDialog();
                return;
            }
            //通过md5值再次获取安装包路径
            String apkPath = DownloadUtil.scanAndCheckApkPath(selectApkModel.getMd5());
            selectApkModel.setPath(apkPath);
            install(apkPath);
        });
        taskAdapter.setOnOpenClick(model -> {
            String json = model.getRemark();
            Remark remark = new Gson().fromJson(json, Remark.class);
            if (remark != null) {
                List<String> pluginList = remark.getPluginList();
                if (pluginList != null && !pluginList.isEmpty()) {
                    for (String s : pluginList) {
                        boolean appInstalled = DownloadUtil.isAppInstalled(this, s);
                        if (!appInstalled) {
                            ToastUtils.showToast("请先安装插件");
                            apkVM.getApkListByPkgName(s);
                            return;
                        }
                    }
                }
            }
            if (!model.isNeedExFactory()) {
                ToastUtils.showToast("该应用无需出厂");
                return;
            }
            AppPackage byName = new PackageManager.Singleton().getInstance().getByName(model.getPackageName());
            if (byName == null) {
                LogUtil.test("记录为空: " + model);
                List<AppPackage> all = new PackageManager.Singleton().getInstance().getAll();
                LogUtil.test("所有记录: " + all);
            }
            if (byName != null && byName.getApkId().equals(model.getApkId())) {
                //检查本地是否已安装该APP(用户在外部卸载)
                Map<String, AppInfo> installedApps = DownloadUtil.getInstalledApps(getPackageName());
                if (installedApps.containsKey(model.getPackageName())) {
                    if (Config.deviceId == null) {
                        ToastUtils.showToast("获取设备号失败");
                        return;
                    }
                    Bundle bundle = new Bundle();
                    bundle.putString("packageName", model.getPackageName());
                    bundle.putString("remark", model.getRemark());
                    navToWithParam(FactoryActivity.class, bundle);
                } else {
                    ToastUtils.showToast("本地未安装该应用");
                    new PackageManager.Singleton().getInstance().deleteByPackageName(model.getPackageName());
                    getApkList();
                }
            } else {
                ToastUtils.showToast("安装版本异常");
            }
        });
    }

    private void install(String apkFilePath) {
        LogUtil.d("安装路径: " + apkFilePath);
        File apkFile = new File(apkFilePath);

        if (apkFile.exists()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Android 8.0 及以上需要安装未知来源应用的权限
                boolean haveInstallPermission = getPackageManager().canRequestPackageInstalls();
                if (!haveInstallPermission) {
                    // 如果没有权限，请求安装未知来源应用的权限
                    Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES);
                    intent.setData(Uri.parse(String.format("package:%s", getPackageName())));
                    startActivityForResult(intent, REQUEST_INSTALL_PERMISSION);
                    return;
                }
            }
            // 如果已经有权限或版本低于 Android 8.0，直接安装 APK
            installApk(apkFile);
        } else {
            Toast.makeText(this, "安装包未找到", Toast.LENGTH_SHORT).show();
        }
    }

    private void installApk(File apkFile) {
        Uri apkUri;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // Android 7.0 及以上使用 FileProvider 共享文件
            apkUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", apkFile);
        } else {
            // Android 7.0 以下使用文件路径
            apkUri = Uri.fromFile(apkFile);
        }

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); // 授予读取权限
        startActivity(intent);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_INSTALL_PERMISSION) {
            if (resultCode == Activity.RESULT_OK) {
                // 用户授予了安装未知应用的权限，继续安装
            } else {
                // 用户拒绝了安装权限
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    public void initService() {

    }


    @Override
    public void onBackPressed() {
        TaskManager.getImpl().onDestroy();
        taskAdapter = null;
        FileDownloader.getImpl().pauseAll();
        modelList.clear();
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        TaskManager.getImpl().onDestroy();
        taskAdapter = null;
        modelList.clear();
        unregisterReceiver(packageReceiver);
        FileDownloader.getImpl().pauseAll();
        super.onDestroy();
    }
}