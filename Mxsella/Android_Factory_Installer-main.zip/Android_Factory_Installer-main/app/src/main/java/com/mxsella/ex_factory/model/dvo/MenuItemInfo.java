package com.mxsella.ex_factory.model.dvo;

public class MenuItemInfo {

    private String categoryName;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    @Override
    public String toString() {
        return "MenuItemInfo{" +
                "categoryName='" + categoryName + '\'' +
                '}';
    }
}
