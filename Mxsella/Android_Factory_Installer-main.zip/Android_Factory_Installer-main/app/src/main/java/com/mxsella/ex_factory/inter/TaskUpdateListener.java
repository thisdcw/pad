package com.mxsella.ex_factory.inter;

public interface TaskUpdateListener {
    void onTaskChange();
}
