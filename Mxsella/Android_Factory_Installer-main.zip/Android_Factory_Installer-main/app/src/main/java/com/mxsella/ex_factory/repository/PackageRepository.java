package com.mxsella.ex_factory.repository;

import com.mxsella.ex_factory.inter.HandlerLoading;
import com.mxsella.ex_factory.model.dto.ApkMenu;
import com.mxsella.ex_factory.model.dto.MenuInfo;
import com.mxsella.ex_factory.model.request.ApkListRequestBody;
import com.mxsella.ex_factory.model.response.BaseResponse;
import com.mxsella.ex_factory.model.response.ListResponse;
import com.mxsella.ex_factory.net.inter.ApiResponseHandler;

import java.util.List;

public class PackageRepository extends BaseRepository {
    public PackageRepository(HandlerLoading handlerLoading) {
        super(handlerLoading);
    }

    public void fetchCategory(ApiResponseHandler<BaseResponse<List<MenuInfo>>> handler) {
        subscribeWithHandler(apiService.fetchCategory(), handler);
    }

    public void fetchApkList(int cur, int size, ApkListRequestBody body, ApiResponseHandler<BaseResponse<ListResponse<ApkMenu>>> handler) {
        subscribeWithHandler(apiService.getApkList(cur, size, body), handler);
    }

    public void bindVersion(String apkId, String itemId, String deviceId, ApiResponseHandler<BaseResponse<String>> handler) {
        subscribeWithHandler(apiService.bindVersion(apkId, itemId, deviceId), handler);
    }

    public void production(String apkId, String deviceId, ApiResponseHandler<BaseResponse<String>> handler) {
        subscribeWithHandler(apiService.production(apkId, deviceId), handler);
    }

    public void fetchApkListByPackageName(String packageName, ApiResponseHandler<BaseResponse<List<ApkMenu>>> handler) {
        subscribeWithHandler(apiService.getApkListByPackageName(packageName), handler);
    }

}
