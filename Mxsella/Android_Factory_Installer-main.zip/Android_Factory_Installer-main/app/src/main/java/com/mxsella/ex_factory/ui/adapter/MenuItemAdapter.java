package com.mxsella.ex_factory.ui.adapter;

import android.view.View;

import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.brv.BaseRVAdapter;
import com.mxsella.ex_factory.base.brv.DBHolder;
import com.mxsella.ex_factory.databinding.ItemMenuInfoBinding;
import com.mxsella.ex_factory.model.dto.MenuInfo;

public class MenuItemAdapter extends BaseRVAdapter<MenuInfo, ItemMenuInfoBinding> {

    private OnSelectClick onSelectClick;

    public void setOnSelectClick(OnSelectClick onSelectClick) {
        this.onSelectClick = onSelectClick;
    }

    public interface OnSelectClick {

        void OnClick(MenuInfo info, View view);
    }

    @Override
    public void initView(DBHolder<ItemMenuInfoBinding> holder, int position, MenuInfo item) {
        binding.setItem(item);
        binding.select.setOnClickListener(v -> {
            if (onSelectClick != null) {
                onSelectClick.OnClick(item, v);
            }
        });
    }

    @Override
    public int layoutId() {
        return R.layout.item_menu_info;
    }
}
