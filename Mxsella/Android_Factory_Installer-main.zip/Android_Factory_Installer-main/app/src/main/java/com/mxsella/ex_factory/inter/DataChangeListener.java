package com.mxsella.ex_factory.inter;

public interface DataChangeListener {
    void postNotifyDataChanged();
}
