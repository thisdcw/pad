package com.mxsella.ex_factory.util;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import com.liulishuo.filedownloader.BaseDownloadTask;
import com.liulishuo.filedownloader.FileDownloader;
import com.mxsella.ex_factory.MyApplication;
import com.mxsella.ex_factory.base.Config;
import com.mxsella.ex_factory.model.AppInfo;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DownloadUtil {

    /**
     * 构建下载地址
     *
     * @param apkName 要下载的App名称
     * @return
     */
    public static String createDownloadPath(String apkName) {
        String str = RandomStringUtils.randomAlphanumeric(10);
        return new File(Config.FILE_SAVE_DIRECTORY, apkName + ".apk").getAbsolutePath();
    }

    public static String createDownloadPath() {
        String str = RandomStringUtils.randomAlphanumeric(10);
        return new File(Config.FILE_SAVE_DIRECTORY, str + ".apk").getAbsolutePath();
    }

    public static String createApkName() {
        return RandomStringUtils.randomAlphanumeric(6);
    }

    public static boolean scanAndCheckApkFiles(String md5) {
        File directory = Config.FILE_SAVE_DIRECTORY;
        if (!directory.exists() || !directory.isDirectory()) {
            return false;
        }

        // 获取目录下所有文件
        File[] files = directory.listFiles();
        if (files == null || files.length == 0) {
            return false;
        }

        // 遍历文件
        for (File file : files) {
            // 只处理 .apk 文件
            if (file.isFile() && file.getName().endsWith(".apk")) {
                String filePath = file.getAbsolutePath();
                String fileMd5 = MD5Util.calculateFileMD5(filePath);
                // 比较MD5值
                if (md5.equals(fileMd5)) {
                    return true;
                }
            }
        }
        return false;
    }
    public static boolean isAppInstalled(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;  // 已安装
        } catch (PackageManager.NameNotFoundException e) {
            return false;  // 未安装
        }
    }

    public static String scanAndCheckApkPath(String md5) {
        File directory = Config.FILE_SAVE_DIRECTORY;
        String path = "";
        if (!directory.exists() || !directory.isDirectory()) {
            LogUtil.i("目录不存在");
            return path;
        }

        // 获取目录下所有文件
        File[] files = directory.listFiles();
        if (files == null || files.length == 0) {
            LogUtil.i("文件不存在");
            return path;
        }

        // 遍历文件
        for (File file : files) {
            // 只处理 .apk 文件
            if (file.isFile() && file.getName().endsWith(".apk")) {
                String filePath = file.getAbsolutePath();
                String fileMd5 = MD5Util.calculateFileMD5(filePath);
                // 比较MD5值
                if (md5.equals(fileMd5)) {
                    return filePath;
                }
            }
        }
        return path;
    }

    /**
     * 获取所有已安装的App的版本信息
     *
     * @param ignore 要忽略的包名
     * @return 包名对应版本号的map
     */
    public static Map<String, Integer> getInstalledPackages(String ignore) {
        Map<String, Integer> packageMap = new HashMap<>();

        PackageManager packageManager = MyApplication.getInstance().getPackageManager();
        List<PackageInfo> packages = packageManager.getInstalledPackages(0);
        for (PackageInfo packageInfo : packages) {
            // 过滤掉系统应用
            if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                if (!packageInfo.packageName.equals(ignore)) {
                    packageMap.put(packageInfo.packageName, packageInfo.versionCode);
                }
            }
        }

        return packageMap;
    }

    /**
     * 获取已安装的App的信息
     *
     * @param ignore 要忽略的App包名
     * @return 包名对应AppInfo的map
     */
    public static Map<String, AppInfo> getInstalledApps(String ignore) {
        Map<String, AppInfo> appMap = new HashMap<>();

        PackageManager packageManager = MyApplication.getInstance().getPackageManager();
        List<PackageInfo> packages = packageManager.getInstalledPackages(0);
        for (PackageInfo packageInfo : packages) {
            // 过滤掉系统应用
            if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                if (!packageInfo.packageName.equals(ignore)) {
                    AppInfo appInfo = new AppInfo();

                    appInfo.setAppName(packageManager.getApplicationLabel(packageInfo.applicationInfo).toString());
                    appInfo.setPackageName(packageInfo.packageName);
                    appInfo.setVersionName(packageInfo.versionName);
                    appInfo.setVersionCode(packageInfo.versionCode);

                    appMap.put(packageInfo.packageName, appInfo);
                }
            }
        }

        return appMap;
    }
}
