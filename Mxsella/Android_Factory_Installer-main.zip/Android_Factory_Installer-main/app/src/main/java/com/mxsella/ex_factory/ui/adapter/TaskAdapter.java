package com.mxsella.ex_factory.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.liulishuo.filedownloader.BaseDownloadTask;
import com.liulishuo.filedownloader.FileDownloadListener;
import com.liulishuo.filedownloader.FileDownloadSampleListener;
import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.model.FileDownloadStatus;
import com.liulishuo.filedownloader.util.FileDownloadUtils;
import com.mxsella.ex_factory.MyApplication;
import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.db.PackageManager;
import com.mxsella.ex_factory.inter.TaskUpdateListener;
import com.mxsella.ex_factory.manager.TaskManager;
import com.mxsella.ex_factory.model.AppInfo;
import com.mxsella.ex_factory.model.dvo.TaskManagerModel;
import com.mxsella.ex_factory.ui.adapter.holder.TaskHolder;
import com.mxsella.ex_factory.util.DownloadUtil;
import com.mxsella.ex_factory.util.LogUtil;

import java.io.File;
import java.util.Map;

public class TaskAdapter extends RecyclerView.Adapter<TaskHolder> implements TaskUpdateListener {

    private InstallListener installListener;

    @Override
    public void onTaskChange() {
        notifyDataSetChanged();
    }

    public interface InstallListener {
        void OnInstall(String apkName);
    }

    public interface OnOpenClick {
        void nav(TaskManagerModel model);
    }

    public interface OnExistInstallClickListener {
        void onExist();
    }

    private OnExistInstallClickListener onExistInstallClickListener;
    private OnOpenClick onOpenClick;

    public void setOnExistAppClickListener(OnExistInstallClickListener onExistInstallClickListener) {
        this.onExistInstallClickListener = onExistInstallClickListener;
    }

    public void setOnOpenClick(OnOpenClick onOpenClick) {
        this.onOpenClick = onOpenClick;
    }

    public void setInstallListener(InstallListener installListener) {
        this.installListener = installListener;
    }


    private FileDownloadListener taskListener = new FileDownloadSampleListener() {

        private TaskHolder checkCurrentHolder(final BaseDownloadTask task) {
            final TaskHolder tag = (TaskHolder) task.getTag();
            if (tag.id != task.getId()) {
                return null;
            }

            return tag;
        }

        @Override
        protected void pending(BaseDownloadTask task, int soFarBytes, int totalBytes) {
            super.pending(task, soFarBytes, totalBytes);
            final TaskHolder tag = checkCurrentHolder(task);
            if (tag == null) {
                return;
            }

            tag.updateDownloading(FileDownloadStatus.pending, soFarBytes
                    , totalBytes);
            tag.taskStatusTv.setText(R.string.tasks_manager_demo_status_pending);
        }

        @Override
        protected void started(BaseDownloadTask task) {
            super.started(task);
            final TaskHolder tag = checkCurrentHolder(task);
            if (tag == null) {
                return;
            }

            tag.taskStatusTv.setText(R.string.tasks_manager_demo_status_started);
        }

        @Override
        protected void connected(BaseDownloadTask task, String etag, boolean isContinue, int soFarBytes, int totalBytes) {
            super.connected(task, etag, isContinue, soFarBytes, totalBytes);
            final TaskHolder tag = checkCurrentHolder(task);
            if (tag == null) {
                return;
            }

            tag.updateDownloading(FileDownloadStatus.connected, soFarBytes
                    , totalBytes);
            tag.taskStatusTv.setText(R.string.tasks_manager_demo_status_connected);
        }

        @Override
        protected void progress(BaseDownloadTask task, int soFarBytes, int totalBytes) {
            super.progress(task, soFarBytes, totalBytes);
            final TaskHolder tag = checkCurrentHolder(task);
            if (tag == null) {
                return;
            }

            tag.updateDownloading(FileDownloadStatus.progress, soFarBytes
                    , totalBytes);
        }

        @Override
        protected void error(BaseDownloadTask task, Throwable e) {
            super.error(task, e);
            final TaskHolder tag = checkCurrentHolder(task);
            if (tag == null) {
                return;
            }
            LogUtil.e(e.toString());
            tag.updateNotDownloaded(FileDownloadStatus.error, task.getLargeFileSoFarBytes()
                    , task.getLargeFileTotalBytes());
            TaskManager.getImpl().removeTaskForViewHolder(task.getId());
        }

        @Override
        protected void paused(BaseDownloadTask task, int soFarBytes, int totalBytes) {
            super.paused(task, soFarBytes, totalBytes);
            final TaskHolder tag = checkCurrentHolder(task);
            if (tag == null) {
                return;
            }

            tag.updateNotDownloaded(FileDownloadStatus.paused, soFarBytes, totalBytes);
            tag.taskStatusTv.setText(R.string.tasks_manager_demo_status_paused);
            TaskManager.getImpl().removeTaskForViewHolder(task.getId());
        }

        @Override
        protected void completed(BaseDownloadTask task) {
            super.completed(task);
            final TaskHolder tag = checkCurrentHolder(task);
            if (tag == null) {
                return;
            }

            tag.updateDownloaded();
            TaskManager.getImpl().removeTaskForViewHolder(task.getId());
        }
    };
    private View.OnClickListener taskActionOnClickListener = v -> {
        if (v.getTag() == null) {
            return;
        }

        TaskHolder holder = (TaskHolder) v.getTag();

        CharSequence action = ((TextView) v).getText();
        LogUtil.d("点击了: " + action);
        if (action.equals(v.getResources().getString(R.string.pause))) {
            FileDownloader.getImpl().pause(holder.id);
        } else if (action.equals(v.getResources().getString(R.string.start))) {

            final TaskManagerModel model = TaskManager.getImpl().get(holder.getPosition());

            final BaseDownloadTask task = FileDownloader.getImpl().create(model.getUrl())
                    .setPath(model.getPath())
                    .setCallbackProgressTimes(100)
                    .setListener(taskListener);

            TaskManager.getImpl()
                    .addTaskForViewHolder(task);

            TaskManager.getImpl()
                    .updateViewHolder(holder.id, holder);

            task.start();
        } else if (action.equals(v.getResources().getString(R.string.delete))) {
            // to delete
            LogUtil.d("路径" + TaskManager.getImpl().get(holder.getPosition()).getPath());
            new File(TaskManager.getImpl().get(holder.getPosition()).getPath()).delete();
            holder.taskActionBtn.setEnabled(true);
            holder.updateNotDownloaded(FileDownloadStatus.INVALID_STATUS, 0, 0);
        } else if (action.equals(v.getResources().getString(R.string.tasks_manager_demo_status_open))) {
            final TaskManagerModel model = TaskManager.getImpl().get(holder.getPosition());
            LogUtil.test("打开");
        } else if (action.equals(v.getResources().getString(R.string.tasks_manager_demo_status_ex))) {
            final TaskManagerModel model = TaskManager.getImpl().get(holder.getPosition());
            LogUtil.test("出厂");
            if (onOpenClick != null) {
                onOpenClick.nav(model);
            }
        }
    };


    @Override
    public void onBindViewHolder(TaskHolder holder, int i) {
        final TaskManagerModel model = TaskManager.getImpl().get(i);
        holder.update(model.getId(), i);
        holder.taskActionBtn.setTag(holder);
        holder.taskNameTv.setText(model.getName());
        holder.taskActionBtn.setText(model.getIsExist() == 0 ? R.string.start : R.string.tasks_manager_demo_status_open);


        TaskManager.getImpl().updateViewHolder(holder.id, holder);
        holder.downLoadPathTv.setText(model.getPath());

        holder.taskActionBtn.setEnabled(true);


        if (!TaskManager.getImpl().isReady()) {
            holder.taskStatusTv.setText(R.string.tasks_manager_demo_status_loading);
            holder.taskActionBtn.setEnabled(false);
            return;
        }

        if (TaskManager.getImpl().isReady()) {
            final int status = TaskManager.getImpl().getStatus(model.getId(), model.getPath());
            if (status == FileDownloadStatus.pending || status == FileDownloadStatus.started ||
                    status == FileDownloadStatus.connected) {
                //开始下载但是还未创建文件
                holder.updateDownloading(status, TaskManager.getImpl().getSoFar(model.getId())
                        , TaskManager.getImpl().getTotal(model.getId()));
            } else if (model.getPath() != null && !new File(model.getPath()).exists() &&
                    !new File(FileDownloadUtils.getTempPath(model.getPath())).exists()) {
                // 文件不存在
                holder.updateNotDownloaded(status, 0, 0);
            } else if (TaskManager.getImpl().isDownloaded(status) || DownloadUtil.scanAndCheckApkFiles(model.getMd5())) {
                // 已经下载并且存在
                holder.updateDownloaded();
            } else if (status == FileDownloadStatus.progress) {
                // 下载中
                holder.updateDownloading(status, TaskManager.getImpl().getSoFar(model.getId())
                        , TaskManager.getImpl().getTotal(model.getId()));
            } else {
                //未下载
                holder.updateNotDownloaded(status, TaskManager.getImpl().getSoFar(model.getId())
                        , TaskManager.getImpl().getTotal(model.getId()));
            }
        }
        //先判断是否已经下载该Apk
        if (DownloadUtil.scanAndCheckApkFiles(model.getMd5())) {
            holder.updateDownloaded();
        }
        //再判断是否已经安装该Apk
        if (model.getIsExist() == 1 ) {
            holder.updateIsExist();
        }
        //是否需要出厂
        if (!model.isNeedExFactory()) {
            boolean appInstalled = DownloadUtil.isAppInstalled(MyApplication.getInstance(), model.getPackageName());
            if (appInstalled) {
                holder.taskActionBtn.setText(R.string.tasks_manager_demo_status_existed);
            } else {
                PackageManager packageManager = new PackageManager.Singleton().getInstance();
                packageManager.deleteByPackageName(model.getPackageName());
            }
        }

    }

    @Override
    public TaskHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        TaskHolder holder = new TaskHolder(
                LayoutInflater.from(
                                parent.getContext())
                        .inflate(R.layout.item_task_manager, parent, false));

        holder.taskActionBtn.setOnClickListener(taskActionOnClickListener);
        holder.installBtn.setOnClickListener(v -> {
            if (installListener != null) {
                installListener.OnInstall(holder.downLoadPathTv.getText().toString());
            }
        });
        return holder;
    }

    @Override
    public int getItemCount() {
        return TaskManager.getImpl().getTaskCounts();
    }
}
