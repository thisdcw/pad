package com.mxsella.ex_factory.util;

import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;

public class MD5Util {

    // 计算文件的MD5值
    public static String calculateFileMD5(String filePath) {
        try (InputStream fis = new FileInputStream(filePath)) {
            // 创建MD5哈希实例
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] buffer = new byte[1024];
            int bytesRead;
            // 读取文件并更新哈希计算
            while ((bytesRead = fis.read(buffer)) != -1) {
                digest.update(buffer, 0, bytesRead);
            }
            // 获取MD5哈希值
            byte[] md5Bytes = digest.digest();
            // 将哈希值转换为十六进制字符串
            StringBuilder sb = new StringBuilder();
            for (byte b : md5Bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

}
