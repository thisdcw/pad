package com.mxsella.ex_factory.model;

public class LogInfo {

    public static final int INFO = 0;
    public static final int WARNING = 2;
    public static final int ERROR = 1;

    private String info;

    private int type;

    public LogInfo(String info) {
        this.info = info;
        this.type = LogInfo.INFO;
    }

    public LogInfo(String info, int type) {
        this.info = info;
        this.type = type;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public static LogInfo InfoTv(String info) {
        return new LogInfo(info, LogInfo.INFO);
    }

    public static LogInfo WarnTv(String info) {
        return new LogInfo(info, LogInfo.WARNING);
    }

    public static LogInfo ErrTv(String info) {
        return new LogInfo(info, LogInfo.ERROR);
    }
}
