package com.mxsella.ex_factory.db;

import com.mxsella.ex_factory.manager.BaseDBManager;
import com.mxsella.ex_factory.manager.SingletonManager;
import com.mxsella.ex_factory.inter.IManager;
import com.mxsella.ex_factory.db.domain.AppPackage;
import com.mxsella.ex_factory.util.LogUtil;

import org.litepal.LitePal;

import java.util.List;

public class PackageManager extends BaseDBManager<AppPackage> implements IManager<AppPackage> {

    private PackageManager() {
    }

    public static class Singleton extends SingletonManager<PackageManager> {
        @Override
        protected PackageManager createInstance() {
            return new PackageManager();
        }
    }

    @Override
    public List<AppPackage> getAll() {
        return LitePal.findAll(AppPackage.class);
    }

    @Override
    public AppPackage getById(String id) {
        return LitePal.where("id = ?", id).findLast(AppPackage.class);
    }

    public AppPackage getByName(String packageName) {
        return LitePal.where("packageName = ?", packageName).findLast(AppPackage.class);
    }

    @Override
    public void saveOrUpdate(AppPackage entity) {
        boolean b = entity.saveOrUpdate("packageName = ?", entity.getPackageName());
    }

    @Override
    public boolean deleteById(int id) {
        return LitePal.deleteAll(AppPackage.class, "id = ?", String.valueOf(id)) != 0;
    }

    public boolean deleteByPackageName(String packageName) {
        return LitePal.deleteAll(AppPackage.class, "packageName = ?", packageName) != 0;
    }

    @Override
    public List<AppPackage> getList(int page, int size) {
        if (page < 1)
            page = 1;
        return LitePal.limit(size).offset((page - 1) * size).limit(size).find(AppPackage.class);
    }
}
