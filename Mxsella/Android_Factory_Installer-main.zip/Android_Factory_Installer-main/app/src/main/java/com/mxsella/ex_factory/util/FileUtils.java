package com.mxsella.ex_factory.util;

import java.io.File;

public class FileUtils {

    public static boolean deleteFileAtPath(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            if (file.delete()) {
                LogUtil.d("文件删除成功: " + filePath);
                return true;
            } else {
                LogUtil.d("文件删除失败: " + filePath);
                return false;
            }
        } else {
            LogUtil.d("文件不存在: " + filePath);
            return false;
        }
    }
}
