package com.mxsella.ex_factory.base;

import android.content.SharedPreferences;
import android.os.Environment;

import com.mxsella.ex_factory.model.DiskInfo;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class Config {
    public static final boolean isDebug = true;
    public static SharedPreferences mainSP;
    public static String versionName = "";
    public static int versionCode = 0;

    public static String deviceId = "";
    public static final String CACHE_DIR = "cache_dir";
    public static final String WHITE_LIST = "white_list";

    public static Map<String, DiskInfo> diskMap = new HashMap<>();

    public static final File FILE_SAVE_DIRECTORY = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);


    public static String getCacheDir() {
        return mainSP.getString(CACHE_DIR, null);
    }

    public static String getWhiteList() {
        return mainSP.getString(WHITE_LIST, null);
    }

    public static void saveCacheDir(String path) {
        save(CACHE_DIR, path);
    }

    public static void saveWhiteList(String list) {
        save(WHITE_LIST, list);
    }

    public static void save(String key, Object value) {
        mainSP.edit().putString(key, String.valueOf(value)).apply();
    }
}
