package com.mxsella.ex_factory;

import android.app.Application;
import android.content.Intent;
import android.content.IntentFilter;

import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.connection.FileDownloadUrlConnection;
import com.mxsella.ex_factory.base.Config;
import com.mxsella.ex_factory.service.PackageReceiver;
import com.mxsella.ex_factory.util.AppUtils;
import com.mxsella.ex_factory.util.DeviceIdUtils;
import com.scwang.smart.refresh.footer.ClassicsFooter;
import com.scwang.smart.refresh.header.ClassicsHeader;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;

import org.litepal.LitePal;

import me.jessyan.autosize.AutoSizeConfig;

public class MyApplication extends Application {

    static {
        //设置全局的Header构建器
        SmartRefreshLayout.setDefaultRefreshHeaderCreator((context, layout) -> {
            layout.setPrimaryColorsId(R.color.primary, R.color.white);//全局设置主题颜色
            return new ClassicsHeader(context);
        });

        SmartRefreshLayout.setDefaultRefreshFooterCreator((context, layout) -> new ClassicsFooter(context).setDrawableSize(20));
    }

    private static MyApplication instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        LitePal.initialize(instance);
        AutoSizeConfig.getInstance().setExcludeFontScale(true).setUseDeviceSize(true);
        Config.mainSP = this.getSharedPreferences("main", 0);
        Config.versionName = AppUtils.getVersionName(this);
        Config.versionCode = AppUtils.getVersionCode(this);
        DeviceIdUtils.getDeviceId(this);
        FileDownloader.setupOnApplicationOnCreate(this)
                .connectionCreator(new FileDownloadUrlConnection
                        .Creator(new FileDownloadUrlConnection.Configuration()
                        .connectTimeout(15_000) // set connection timeout.
                        .readTimeout(15_000) // set read timeout.
                ))
                .commit();

        registerPackageReceiver();
    }

    private void registerPackageReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_PACKAGE_ADDED);
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        filter.addAction(Intent.ACTION_PACKAGE_REPLACED);
        filter.addDataScheme("package");
        registerReceiver(new PackageReceiver(), filter);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    public static MyApplication getInstance() {
        return instance;
    }
}
