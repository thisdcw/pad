package com.mxsella.ex_factory.ui.adapter.holder;

import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.liulishuo.filedownloader.model.FileDownloadStatus;
import com.mxsella.ex_factory.MyApplication;
import com.mxsella.ex_factory.R;

public class TaskHolder extends RecyclerView.ViewHolder {

    public TaskHolder(View itemView) {
        super(itemView);
        assignViews();
    }

    private View findViewById(final int id) {
        return itemView.findViewById(id);
    }


    public int position;

    public int id;

    public void update(final int id, final int position) {
        this.id = id;
        this.position = position;
    }


    public void updateDownloaded() {

        taskPb.setMax(1);
        taskPb.setProgress(1);

        taskStatusTv.setText(R.string.tasks_manager_demo_status_completed);
        taskActionBtn.setText(R.string.delete);
        taskActionBtn.setVisibility(View.GONE);
        installBtn.setVisibility(View.VISIBLE);
    }

    public void updateIsExist() {
        taskPb.setMax(1);
        taskPb.setProgress(1);
        taskActionBtn.setVisibility(View.VISIBLE);
        taskStatusTv.setText(R.string.tasks_manager_demo_status_existed);
//        taskActionBtn.setText(R.string.tasks_manager_demo_status_open);
        taskActionBtn.setText(R.string.tasks_manager_demo_status_ex);
        installBtn.setVisibility(View.GONE);
    }

    public void updateNotDownloaded(final int status, final long sofar, final long total) {
        if (sofar > 0 && total > 0) {
            final float percent = sofar
                    / (float) total;
            taskPb.setMax(100);
            taskPb.setProgress((int) (percent * 100));
        } else {
            taskPb.setMax(1);
            taskPb.setProgress(0);
        }
        taskActionBtn.setVisibility(View.VISIBLE);
        switch (status) {
            case FileDownloadStatus.error:
                taskStatusTv.setText(R.string.tasks_manager_demo_status_error);
                break;
            case FileDownloadStatus.paused:
                taskStatusTv.setText(R.string.tasks_manager_demo_status_paused);
                break;
            default:
                taskStatusTv.setText(R.string.tasks_manager_demo_status_not_downloaded);
                break;
        }
        taskActionBtn.setText(R.string.start);
        installBtn.setVisibility(View.GONE);
    }

    public void updateDownloading(final int status, final long sofar, final long total) {

        final float percent = sofar
                / (float) total;
        taskPb.setMax(100);
        taskPb.setProgress((int) (percent * 100));
        taskActionBtn.setVisibility(View.VISIBLE);
        switch (status) {
            case FileDownloadStatus.pending:
                taskStatusTv.setText(R.string.tasks_manager_demo_status_pending);
                break;
            case FileDownloadStatus.started:
                taskStatusTv.setText(R.string.tasks_manager_demo_status_started);
                break;
            case FileDownloadStatus.connected:
                taskStatusTv.setText(R.string.tasks_manager_demo_status_connected);
                break;
            case FileDownloadStatus.progress:
                taskStatusTv.setText(R.string.tasks_manager_demo_status_progress);
                break;
            default:
                taskStatusTv.setText(MyApplication.getInstance().getString(
                        R.string.tasks_manager_demo_status_downloading, status));
                break;
        }

        taskActionBtn.setText(R.string.pause);
        installBtn.setVisibility(View.GONE);
    }

    public TextView taskNameTv, downLoadPathTv, taskStatusTv;
    public ProgressBar taskPb;
    public Button taskActionBtn;
    public Button installBtn;

    private void assignViews() {
        taskNameTv = (TextView) findViewById(R.id.task_name_tv);
        taskStatusTv = (TextView) findViewById(R.id.task_status_tv);
        taskPb = (ProgressBar) findViewById(R.id.task_pb);
        taskActionBtn = (Button) findViewById(R.id.task_action_btn);
        installBtn = (Button) findViewById(R.id.install_btn);
        downLoadPathTv = (TextView) findViewById(R.id.download_path);
    }
}
