package com.mxsella.ex_factory.model.response;

public class ResultType {

    public static final int SUCCESS = 200;
    public static final int FAILED = 200;
    public static final int INVALID = 200;
    public static final int ERROR = 200;

    private final int code;

    private final String message;

    private String description;

    ResultType(int code, String message, String description) {
        this.code = code;
        this.message = message;
        this.description = description;
    }

    public static ResultType success() {
        return new ResultType(SUCCESS, "success", "");
    }

    public static ResultType failed() {
        return new ResultType(FAILED, "failed", "");
    }

    public static ResultType invalid() {
        return new ResultType(INVALID, "invalid token", "");
    }

    public static ResultType error() {
        return new ResultType(ERROR, "error", "");
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
