package com.mxsella.ex_factory.model.dvo;

public class TaskManagerModel {
    private int id;
    private String apkId;
    private String name;
    private String url;
    private String path;
    private Integer isExist;
    private String packageName;
    private String categoryId;
    private String itemId;
    private String remark;
    private int hasUpdate;
    private int versionCode;
    private String md5;
    private boolean needExFactory;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getApkId() {
        return apkId;
    }

    public void setApkId(String apkId) {
        this.apkId = apkId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Integer getIsExist() {
        return isExist;
    }

    public void setIsExist(Integer isExist) {
        this.isExist = isExist;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getHasUpdate() {
        return hasUpdate;
    }

    public void setHasUpdate(int hasUpdate) {
        this.hasUpdate = hasUpdate;
    }

    public int getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public boolean isNeedExFactory() {
        return needExFactory;
    }

    public void setNeedExFactory(boolean needExFactory) {
        this.needExFactory = needExFactory;
    }

    @Override
    public String toString() {
        return "TaskManagerModel{" +
                "id=" + id +
                ", apkId='" + apkId + '\'' +
                ", name='" + name + '\'' +
                ", url='" + url + '\'' +
                ", path='" + path + '\'' +
                ", isExist=" + isExist +
                ", packageName='" + packageName + '\'' +
                ", categoryId='" + categoryId + '\'' +
                ", itemId='" + itemId + '\'' +
                ", remark='" + remark + '\'' +
                ", hasUpdate=" + hasUpdate +
                ", versionCode=" + versionCode +
                ", md5='" + md5 + '\'' +
                ", needExFactory=" + needExFactory +
                '}';
    }
}



