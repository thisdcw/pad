package com.mxsella.ex_factory.base.brv;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;

public abstract class BaseRVAdapter<T, VDB extends ViewDataBinding> extends BRVAdapter<T, DBHolder<VDB>> {

    public static final String TAG = "BaseRVAdapter";

    protected VDB binding;

    protected DBHolder<VDB> holder;

    public abstract void initView(DBHolder<VDB> holder, int position, T item);

    public abstract int layoutId();

    public void onCVH(Context context, ViewGroup parent, int viewType) {
    }

    @Override
    protected void onBindViewHolder(DBHolder<VDB> holder, int position, T item) {
        binding = holder.getBinding();
        this.holder = holder;
        initView(holder, position, item);
        binding.executePendingBindings();
    }

    @Override
    protected DBHolder<VDB> onCreateViewHolder(Context context, ViewGroup parent, int viewType) {
        binding = DataBindingUtil.inflate(LayoutInflater.from(context), layoutId(), parent, false);
        onCVH(context, parent, viewType);
        return new DBHolder<>(binding);
    }
}
