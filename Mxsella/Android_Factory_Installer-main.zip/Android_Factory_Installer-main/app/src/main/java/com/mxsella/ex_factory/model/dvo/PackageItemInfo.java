package com.mxsella.ex_factory.model.dvo;

public class PackageItemInfo {

    private String typeName;

    private String versionName;

    private String link;

    private String apkName;

    private String updateInfo;

    private String packageName;

    private String remark;

    private String md5;

    private boolean isInstall = false;

    public boolean isInstall() {
        return isInstall;
    }

    public void setInstall(boolean install) {
        isInstall = install;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getApkName() {
        return apkName;
    }

    public void setApkName(String apkName) {
        this.apkName = apkName;
    }

    public String getUpdateInfo() {
        return updateInfo;
    }

    public void setUpdateInfo(String updateInfo) {
        this.updateInfo = updateInfo;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "PackageItemInfo{" +
                "typeName='" + typeName + '\'' +
                ", versionName='" + versionName + '\'' +
                ", link='" + link + '\'' +
                ", apkName='" + apkName + '\'' +
                ", updateInfo='" + updateInfo + '\'' +
                ", remark='" + remark + '\'' +
                ", md5='" + md5 + '\'' +
                '}';
    }
}
