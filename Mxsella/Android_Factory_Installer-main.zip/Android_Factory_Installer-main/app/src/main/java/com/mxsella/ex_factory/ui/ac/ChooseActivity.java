package com.mxsella.ex_factory.ui.ac;

import android.view.View;

import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.view.BaseActivity;
import com.mxsella.ex_factory.databinding.ActivityChooseBinding;

public class ChooseActivity extends BaseActivity<ActivityChooseBinding> {

    @Override
    public int layoutId() {
        return R.layout.activity_choose;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initObserve() {

    }

    @Override
    public void initListener() {

    }

    @Override
    public void initService() {

    }

    public void toInstall(View view) {
        navTo(MainActivity.class);
    }
}
