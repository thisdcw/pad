package com.mxsella.ex_factory.net.service;

import com.mxsella.ex_factory.model.dto.ApkMenu;
import com.mxsella.ex_factory.model.dto.MenuInfo;
import com.mxsella.ex_factory.model.request.ApkListRequestBody;
import com.mxsella.ex_factory.model.response.BaseResponse;
import com.mxsella.ex_factory.model.response.ListResponse;

import java.util.List;

import io.reactivex.rxjava3.core.Observable;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    String BASE_URL = "https://mmk.mxsella.com/ServiceManage/api/v1/";

    @GET("apk/category/list")
    Observable<BaseResponse<List<MenuInfo>>> fetchCategory();

    @POST("apk/list/{cur}/{size}")
    Observable<BaseResponse<ListResponse<ApkMenu>>> getApkList(@Path("cur") int cur, @Path("size") int size, @Body ApkListRequestBody body);

    @POST("apk/version/bind")
    Observable<BaseResponse<String>> bindVersion(@Query("apkId") String apkId, @Query("itemId") String itemId, @Query("deviceId") String deviceId);

    @POST("device/production")
    Observable<BaseResponse<String>> production(@Query("apkId") String apkId, @Query("deviceId") String deviceId);

    @GET("apk/package_name")
    Observable<BaseResponse<List<ApkMenu>>> getApkListByPackageName(@Query("packageName") String packageName);
}
