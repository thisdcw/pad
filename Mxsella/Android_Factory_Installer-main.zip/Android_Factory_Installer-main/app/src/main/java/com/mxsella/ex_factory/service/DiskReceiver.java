package com.mxsella.ex_factory.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.StatFs;
import android.util.Log;

import com.mxsella.ex_factory.base.Config;
import com.mxsella.ex_factory.inter.IDiskReceiver;
import com.mxsella.ex_factory.model.DiskInfo;
import com.mxsella.ex_factory.util.LogUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DiskReceiver extends BroadcastReceiver {

    public static final String TAG = "DiskReceiver";
    private static IDiskReceiver diskReceiver;

    private final Map<String, DiskInfo> mountedDisks = new HashMap<>();

    public static void setGlobalDiskReceiver(IDiskReceiver receiver) {
        diskReceiver = receiver;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) {
            return;
        }
        switch (action) {
            case Intent.ACTION_MEDIA_EJECT:
            case Intent.ACTION_MEDIA_UNMOUNTED:
            case Intent.ACTION_MEDIA_BAD_REMOVAL:
            case Intent.ACTION_MEDIA_REMOVED:
                handleDiskUnmount(getRealPathFromURI(intent));
                Log.i(TAG, "U盘移除");
                break;
            case Intent.ACTION_MEDIA_MOUNTED:
                handleDiskMount(getRealPathFromURI(intent));
                Log.i(TAG, "U盘接入");
                break;
            default:
                break;
        }
    }

    private String getRealPathFromURI(Intent intent) {
        Uri uri = intent.getData();
        if (uri == null) {
            return "";
        }
        return uri.getPath();
    }

    private void handleDiskMount(String uriPath) {
        StatFs statFs = new StatFs(uriPath);
        DiskInfo diskInfo = new DiskInfo();
        long totalSpace = statFs.getTotalBytes();
        long availableSpace = statFs.getAvailableBytes();
        List<String> fileList = getFileList(uriPath);

        diskInfo.setTotalSpace(totalSpace);
        diskInfo.setAvailableSpace(availableSpace);
        diskInfo.setFilePath(fileList);

        mountedDisks.put(uriPath, diskInfo);
        if (diskReceiver != null) {
            diskReceiver.UDiskInfo(mountedDisks);
        }
    }

    private void handleDiskUnmount(String uriPath) {
        DiskInfo diskInfo = mountedDisks.get(uriPath);
        mountedDisks.remove(uriPath) ;
        if (diskReceiver != null) {
            diskReceiver.UDiskDetach(diskInfo);
        }
    }

    private List<String> getFileList(String path) {
        List<String> fileList = new ArrayList<>();
        File directory = new File(path);
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                fileList.add(file.getAbsolutePath());
            }
        }
        return fileList;
    }
}
