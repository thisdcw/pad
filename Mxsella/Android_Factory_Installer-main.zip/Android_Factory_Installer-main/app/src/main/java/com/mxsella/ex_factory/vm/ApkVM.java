package com.mxsella.ex_factory.vm;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.mxsella.ex_factory.base.Config;
import com.mxsella.ex_factory.inter.HandlerLoading;
import com.mxsella.ex_factory.model.dto.ApkMenu;
import com.mxsella.ex_factory.model.dto.MenuInfo;
import com.mxsella.ex_factory.model.request.ApkListRequestBody;
import com.mxsella.ex_factory.model.response.ListResponse;
import com.mxsella.ex_factory.model.response.handler.NetWorkResult;
import com.mxsella.ex_factory.repository.PackageRepository;
import com.mxsella.ex_factory.util.LogUtil;

import java.util.List;

public class ApkVM extends BaseViewModel {

    private final PackageRepository net;

    public ApkVM() {
        net = new PackageRepository(new HandlerLoading() {
            @Override
            public void loading() {
                LogUtil.i("数据加载中...");
            }

            @Override
            public void complete() {
                LogUtil.i("数据加载完成...");
            }
        });
    }

    private final MutableLiveData<NetWorkResult<List<MenuInfo>>> _packageList = new MutableLiveData<>();

    private final MutableLiveData<NetWorkResult<ListResponse<ApkMenu>>> _appList = new MutableLiveData<>();
    private final MutableLiveData<NetWorkResult<List<ApkMenu>>> _appByNameList = new MutableLiveData<>();
    private final MutableLiveData<NetWorkResult<String>> _bindVersion = new MutableLiveData<>();
    private final MutableLiveData<NetWorkResult<String>> _production = new MutableLiveData<>();

    public LiveData<NetWorkResult<String>> getProduction() {
        return _production;
    }

    public LiveData<NetWorkResult<String>> getBindVersion() {
        return _bindVersion;
    }

    public LiveData<NetWorkResult<List<MenuInfo>>> getCategory() {
        return _packageList;
    }

    public LiveData<NetWorkResult<ListResponse<ApkMenu>>> getAppList() {
        return _appList;
    }

    public LiveData<NetWorkResult<List<ApkMenu>>> getAppByNameList() {
        return _appByNameList;
    }

    public void fetchCategory() {
        net.fetchCategory(createHandler(_packageList));
    }

    public void fetchAppList(int cur, int size, ApkListRequestBody body) {
        net.fetchApkList(cur, size, body, createHandler(_appList));
    }

    public void bindVersion(String apkId, String itemId) {
        net.bindVersion(apkId, itemId, Config.deviceId, createHandler(_bindVersion));
    }

    public void production(String apkId) {
        net.production(apkId, Config.deviceId, createHandler(_production));
    }

    public void getApkListByPkgName(String packageName) {
        net.fetchApkListByPackageName(packageName, createHandler(_appByNameList));
    }
}
