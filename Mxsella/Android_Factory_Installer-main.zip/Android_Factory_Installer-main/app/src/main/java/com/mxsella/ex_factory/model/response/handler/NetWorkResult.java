package com.mxsella.ex_factory.model.response.handler;

import com.mxsella.ex_factory.model.response.ResultType;

public class NetWorkResult<T> {

    private ResultType resultCode;

    private T data;

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public NetWorkResult(ResultType resultCode) {
        this.resultCode = resultCode;
        this.data = null;
        this.message = resultCode.getMessage();
    }

    public NetWorkResult(ResultType resultCode, T data) {
        this.resultCode = resultCode;
        this.data = data;
    }

    public NetWorkResult(ResultType resultCode, T data, String message) {
        this.resultCode = resultCode;
        this.data = data;
        this.message = message;
    }

    public NetWorkResult(ResultType resultCode, String message) {
        this.resultCode = resultCode;
        this.data = null;
        this.message = message;
    }

    public ResultType getResultCode() {
        return resultCode;
    }

    public void setResultCode(ResultType resultCode) {
        this.resultCode = resultCode;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
