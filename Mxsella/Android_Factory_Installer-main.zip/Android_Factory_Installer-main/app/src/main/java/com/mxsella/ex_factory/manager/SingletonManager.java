package com.mxsella.ex_factory.manager;

import com.mxsella.ex_factory.manager.BaseDBManager;

public abstract class SingletonManager<T extends BaseDBManager<?>> {
    private volatile T instance;

    protected abstract T createInstance();

    public T getInstance() {
        if (instance == null) {
            synchronized (this) {
                if (instance == null) {
                    instance = createInstance();
                }
            }
        }
        return instance;
    }
}

