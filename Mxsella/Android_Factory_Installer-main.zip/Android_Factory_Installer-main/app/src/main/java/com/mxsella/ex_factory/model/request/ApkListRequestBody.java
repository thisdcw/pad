package com.mxsella.ex_factory.model.request;

import com.google.gson.annotations.SerializedName;

public class ApkListRequestBody {

    @SerializedName("categoryId")
    private String categoryId;

    @SerializedName("name")
    private String name;

    public ApkListRequestBody(String categoryId) {
        this.categoryId = categoryId;
    }

    public ApkListRequestBody(String categoryId, String name) {
        this.categoryId = categoryId;
        this.name = name;
    }
}
