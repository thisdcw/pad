package com.mxsella.ex_factory.base.brv;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.recyclerview.widget.RecyclerView;

public class DBHolder<DB extends ViewDataBinding> extends RecyclerView.ViewHolder {

    private DB binding;

    public DBHolder(@NonNull DB binding) {
        super(binding.getRoot());
        this.binding = binding;
    }

    public DBHolder(@NonNull View itemView) {
        super(itemView);
        this.binding = DataBindingUtil.bind(itemView);
        if (this.binding == null) {
            throw new NullPointerException("DataBinding is null, check layout");
        }
    }

    @NonNull
    public DB getBinding() {
        return binding;
    }
}
