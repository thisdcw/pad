package com.mxsella.ex_factory.ui.ac;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.gson.Gson;
import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.view.BaseActivity;
import com.mxsella.ex_factory.databinding.ActivityFactoryBinding;
import com.mxsella.ex_factory.db.PackageManager;
import com.mxsella.ex_factory.inter.DialogClickListener;
import com.mxsella.ex_factory.model.LogInfo;
import com.mxsella.ex_factory.db.domain.AppPackage;
import com.mxsella.ex_factory.model.dto.Remark;
import com.mxsella.ex_factory.model.response.ResultType;
import com.mxsella.ex_factory.ui.adapter.LogAdapter;
import com.mxsella.ex_factory.util.CacheUtils;
import com.mxsella.ex_factory.util.DownloadUtil;
import com.mxsella.ex_factory.util.LogUtil;
import com.mxsella.ex_factory.util.ToastUtils;
import com.mxsella.ex_factory.view.dialog.ClearDataDialog;
import com.mxsella.ex_factory.vm.ApkVM;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FactoryActivity extends BaseActivity<ActivityFactoryBinding> {

    private ApkVM apkVM = new ApkVM();

    private List<String> packagelList = new ArrayList<>();
    private Set<String> ignoreList = new HashSet<>();

    private final String[] stepTitle = {"卸载其他软件", "清除软件缓存", "绑定出厂版本", "出厂"};
    private Remark remark;

    private String exPackageName;

    private Map<String, Boolean> unInstallApp = new HashMap<>();
    private AppPackage model;

    private LogAdapter logAdapter;
    private boolean isBinding = false;
    private PackageManager packageManager;

    private ClearDataDialog clearDataDialog;
    private BroadcastReceiver packageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            Uri uri = intent.getData();
            String packageName = uri != null ? uri.getSchemeSpecificPart() : null;

            if (Intent.ACTION_PACKAGE_ADDED.equals(action)) {
                LogUtil.d("应用已安装: " + packageName);
            } else if (Intent.ACTION_PACKAGE_REMOVED.equals(action)) {
                LogUtil.d("应用已卸载: " + packageName);
                setVLog(LogInfo.InfoTv("应用已卸载: " + packageName));
                boolean b = packageManager.deleteByPackageName(packageName);
                LogUtil.test("删除记录: " + b);
                unInstallApp.put(packageName, true);
                completeUninstall();
            } else if (Intent.ACTION_PACKAGE_REPLACED.equals(action)) {
                LogUtil.d("应用已更新: " + packageName);
            }
        }
    };

    @Override
    public int layoutId() {
        return R.layout.activity_factory;
    }

    private void registerPackageReceive() {
        // 创建 IntentFilter 监听应用安装、卸载、更新
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_PACKAGE_ADDED);
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        filter.addAction(Intent.ACTION_PACKAGE_REPLACED);
        filter.addDataScheme("package");  // 必须加上这一行
        // 注册广播接收器
        registerReceiver(packageReceiver, filter);
    }

    @Override
    public void initView() {
        registerPackageReceive();
        packageManager = new PackageManager.Singleton().getInstance();
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            exPackageName = (String) extras.get("packageName");
            String json = (String) extras.get("remark");
            ignoreList.add(exPackageName);
            model = packageManager.getByName(exPackageName);
            LogUtil.test(model.toString());
            LogUtil.test("remark: " + json);
            if (json != null) {
                remark = new Gson().fromJson(json, Remark.class);
            }
        }

        //获取所有非系统应用(排除自己)
        Map<String, Integer> installedPackages = DownloadUtil.getInstalledPackages(getPackageName());
        for (String key : installedPackages.keySet()) {
            LogUtil.d("key: " + key);
            packagelList.add(key);
        }
        initLog();
        initIgnore();
        binding.svStep.setSteps(Arrays.asList(stepTitle));
        binding.svStep.invalidate();  // 强制刷新视图
        binding.svStep.setStepsNumber(stepTitle.length);
        binding.step.setText(stepTitle[0]);
        binding.nextStep.setText(stepTitle[1]);

    }

    private void initIgnore() {
        if (remark != null) {
            List<String> whiteList = remark.getWhiteList();
            if (whiteList != null) {
                setVLog(LogInfo.InfoTv("发现白名单" + whiteList.size() + "个"));
                ignoreList.addAll(whiteList);
            } else {
                setVLog(LogInfo.WarnTv("没有白名单"));
            }
            List<String> pluginList = remark.getPluginList();
            if (pluginList != null) {
                setVLog(LogInfo.InfoTv("发现插件" + pluginList.size() + "个"));
                ignoreList.addAll(pluginList);
            } else {
                setVLog(LogInfo.WarnTv("没有插件"));
            }
        }
        ignoreList.add(getPackageName());
    }

    private void initLog() {
        binding.rvLog.setLayoutManager(new LinearLayoutManager(this));
        binding.rvLog.setAdapter(logAdapter = new LogAdapter());
        setVLog(LogInfo.InfoTv("准备出厂"));
    }


    private void setVLog(LogInfo info) {
        logAdapter.add(info);
    }


    @Override
    public void initObserve() {
        apkVM.getProduction().observe(this, result -> {
            setVLog(LogInfo.InfoTv("出厂结果: " + result.getData()));
            if (result.getResultCode().getCode() == ResultType.SUCCESS) {
                binding.svStep.go(4, true);
                binding.step.setText("完成出厂");
                setVLog(LogInfo.InfoTv("完成出厂"));
                uninstallApp(getPackageName());
            } else {
                setVLog(LogInfo.ErrTv("出厂失败"));
            }
        });

        apkVM.getBindVersion().observe(this, result -> {
            LogUtil.d("绑定安装包版本结果: " + result.getData());
            if (result.getResultCode().getCode() == ResultType.SUCCESS) {
                setVLog(LogInfo.InfoTv("绑定安装包成功"));
                isBinding = true;
                binding.svStep.go(3, true);
                binding.step.setText(stepTitle[3]);
                binding.nextStep.setText("完成出厂");
            } else {
                setVLog(LogInfo.ErrTv("绑定安装包失败"));
            }
        });

    }

    @Override
    public void initListener() {
        binding.svStep.setOnStepClickListener(i -> {
            LogUtil.d("点击了: " + i);
        });
        binding.step.setOnClickListener(v -> {
            int curStep = binding.svStep.getCurrentStep();
            switch (curStep) {
                case 0:
                    toUnInstall();
                    break;
                case 1:
                    toClearCache();
                    break;
                case 2:
                    toBind();
                    break;
                case 3:
                    exFactory();
                    break;
            }
        });
    }

    @Override
    public void initService() {

    }

    public void uninstallApp(String packageName) {
        Log.d("UninstallApp", packageName);
        Uri packageUri = Uri.parse("package:" + packageName);
//        Uri packageUri = Uri.fromParts("package", packageName, null);
        Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageUri);
        uninstallLauncher.launch(uninstallIntent);
    }

    private ActivityResultLauncher<Intent> uninstallLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                LogUtil.d(result.toString());
                // 无论 resultCode 是什么，检查应用是否还存在
            }
    );

    private void completeUninstall() {
        if (!unInstallApp.isEmpty()) {
            Collection<Boolean> values = unInstallApp.values();
            for (Boolean value : values) {
                if (!value) {
                    return;
                }
            }
        } else {
            setVLog(LogInfo.InfoTv("没有其他应用"));
        }
        setVLog(LogInfo.WarnTv("其他应用卸载完成"));
        binding.svStep.go(1, true);
        binding.step.setText(stepTitle[1]);
        binding.nextStep.setText(stepTitle[2]);
    }

    public void toUnInstall() {
        setVLog(LogInfo.InfoTv("开始卸载其他应用"));
        for (String packageName : packagelList) {
            //判断是不是忽略应用
            if (!ignoreList.contains(packageName)) {
                unInstallApp.put(packageName, false);
                uninstallApp(packageName);
            }
        }
        if (unInstallApp.isEmpty()) {
            completeUninstall();
        }
    }

    private void completeClearCache() {
        setVLog(LogInfo.InfoTv("清理缓存完成"));
        binding.svStep.go(2, true);
        binding.step.setText(stepTitle[2]);
        binding.nextStep.setText(stepTitle[3]);
    }

    public void toClearData() {
        setVLog(LogInfo.InfoTv("清除出厂应用的所有数据..."));
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + exPackageName));
        startActivity(intent);
    }

    public void toClearCache() {
        setVLog(LogInfo.InfoTv("开始清理缓存文件夹..."));
        if (remark != null) {
            List<String> localCachePath = remark.getLocalCachePath();
            for (String s : localCachePath) {
                boolean b = CacheUtils.clearAppCache(s);
                if (!b) {
                    setVLog(LogInfo.ErrTv("清理文件夹: " + s + "失败"));
                    return;
                } else {
                    setVLog(LogInfo.InfoTv("清理文件夹: " + s + "成功"));
                }
            }
        }
        setVLog(LogInfo.InfoTv("开始清理下载文件夹"));
        boolean b = CacheUtils.clearDownloadFolder();
        if (!b) {
            setVLog(LogInfo.ErrTv("清理下载文件夹失败"));
            return;
        }
        setVLog(LogInfo.InfoTv("清理下载文件夹成功"));
        toClearData();
        completeClearCache();
//        showClearDataDialog();
    }

    private void showClearDataDialog() {
        clearDataDialog = new ClearDataDialog();
        clearDataDialog.setDialogListener(new DialogClickListener() {
            @Override
            public void onConfirm() {
                setVLog(LogInfo.InfoTv("清除所有数据成功"));
                completeClearCache();
            }

            @Override
            public void onCancel() {
                setVLog(LogInfo.ErrTv("清除所有数据失败,请前往设置重新清理"));
            }
        });
    }

    public void toBind() {
        setVLog(LogInfo.InfoTv("绑定设备..."));
        apkVM.bindVersion(model.getApkId(), model.getItemId());
    }


    public void exFactory() {
        if (isBinding) {
            setVLog(LogInfo.InfoTv("出厂设备..."));
            apkVM.production(model.getApkId());
        } else {
            setVLog(LogInfo.InfoTv("绑定设备未完成,不允许出厂"));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(packageReceiver);
    }
}