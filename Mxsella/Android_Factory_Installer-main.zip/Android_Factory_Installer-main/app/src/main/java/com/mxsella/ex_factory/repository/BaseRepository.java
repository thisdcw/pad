package com.mxsella.ex_factory.repository;

import com.mxsella.ex_factory.inter.HandlerLoading;
import com.mxsella.ex_factory.net.RetrofitClient;
import com.mxsella.ex_factory.net.inter.ApiResponseHandler;
import com.mxsella.ex_factory.net.service.ApiService;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Observable;
import io.reactivex.rxjava3.core.Observer;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

/**
 * 网络请求仓库
 */
public class BaseRepository {
    public final ApiService apiService;

    private final HandlerLoading handlerLoading;

    public BaseRepository(HandlerLoading handlerLoading) {
        apiService = RetrofitClient.getInstance();
        this.handlerLoading = handlerLoading;
    }

    protected <T> void subscribeWithHandler(Observable<T> observable, ApiResponseHandler<T> handler) {
        observable.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<T>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {
                        handlerLoading.loading();
                    }

                    @Override
                    public void onNext(@NonNull T response) {
                        handler.onSuccess(response);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        handler.onError(e);
                        handlerLoading.complete();
                    }

                    @Override
                    public void onComplete() {
                        handlerLoading.complete();
                    }
                });
    }
}
