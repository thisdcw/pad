package com.mxsella.ex_factory.base.brv;

import android.content.Context;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public abstract class BRVAdapter<T, VH extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final String TAG = "BRVAdapter";
    private List<T> items = new ArrayList<>();

    private OnItemClickListener<T> mOnItemClickListener;
    private OnItemLongClickListener<T> mOnItemLongClickListener;
    private SparseArray<OnItemChildClickListener<T>> mOnItemChildClickArray;
    private SparseArray<OnItemChildLongClickListener<T>> mOnItemChildLongClickArray;

    public void setmOnItemClickListener(OnItemClickListener<T> mOnItemClickListener) {
        this.mOnItemClickListener = mOnItemClickListener;
    }

    public void setmOnItemLongClickListener(OnItemLongClickListener<T> mOnItemLongClickListener) {
        this.mOnItemLongClickListener = mOnItemLongClickListener;
    }

    public void setmOnItemChildClickArray(SparseArray<OnItemChildClickListener<T>> mOnItemChildClickArray) {
        this.mOnItemChildClickArray = mOnItemChildClickArray;
    }

    public void setmOnItemChildLongClickArray(SparseArray<OnItemChildLongClickListener<T>> mOnItemChildLongClickArray) {
        this.mOnItemChildLongClickArray = mOnItemChildLongClickArray;
    }

    protected abstract void onBindViewHolder(VH holder, int position, T item);

    protected abstract VH onCreateViewHolder(Context context, ViewGroup parent, int viewType);

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        VH vh = onCreateViewHolder(viewGroup.getContext(), viewGroup, i);
        bindViewClick(vh, i);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        onBindViewHolder((VH) viewHolder, i, items.get(i));
    }

    private void bindViewClick(VH holder, int viewType) {
        if (mOnItemClickListener != null) {
            holder.itemView.setOnClickListener(v -> {
                int position = holder.getAdapterPosition();
                if (position == RecyclerView.NO_POSITION) {
                    return;
                }
                onItemClick(v, position);
            });
        }
        if (mOnItemLongClickListener != null) {
            holder.itemView.setOnLongClickListener(v -> {
                int position = holder.getAdapterPosition();
                if (position == RecyclerView.NO_POSITION) {
                    return false;
                }
                return onItemLongClick(v, position);
            });
        }
        if (mOnItemChildClickArray != null) {
            for (int i = 0; i < mOnItemChildClickArray.size(); i++) {
                int keyAt = mOnItemChildClickArray.keyAt(i);
                View viewById = holder.itemView.findViewById(keyAt);
                if (viewById != null) {
                    viewById.setOnClickListener(v -> {
                        int position = holder.getAdapterPosition();
                        if (position == RecyclerView.NO_POSITION) {
                            return;
                        }
                        onItemChildClick(v, position);
                    });
                }

            }
        }
        if (mOnItemChildLongClickArray != null) {
            for (int i = 0; i < mOnItemChildLongClickArray.size(); i++) {
                int keyAt = mOnItemChildLongClickArray.keyAt(i);
                View viewById = holder.itemView.findViewById(keyAt);
                if (viewById != null) {
                    viewById.setOnLongClickListener(v -> {
                        int position = holder.getAdapterPosition();
                        if (position == RecyclerView.NO_POSITION) {
                            return false;
                        }
                        return onItemChildLongClick(v, position);
                    });
                }
            }
        }
    }

    protected boolean onItemChildLongClick(View v, int position) {
        if (mOnItemChildLongClickArray != null) {
            OnItemChildLongClickListener<T> tOnItemChildLongClickListener = mOnItemChildLongClickArray.get(v.getId());
            if (tOnItemChildLongClickListener != null) {
                return tOnItemChildLongClickListener.onItemLongClick(this, v, position);
            }
        }
        return false;
    }

    protected void onItemChildClick(View v, int position) {
        if (mOnItemChildClickArray != null) {
            OnItemChildClickListener<T> tOnItemChildClickListener = mOnItemChildClickArray.get(v.getId());
            if (tOnItemChildClickListener != null) {
                tOnItemChildClickListener.onItemClick(this, v, position);
            }
        }
    }

    protected boolean onItemLongClick(View v, int position) {
        if (mOnItemLongClickListener != null) {
            return mOnItemLongClickListener.OnLongClick(this, v, position);
        }
        return false;
    }

    protected void onItemClick(View v, int position) {
        if (mOnItemClickListener != null) {
            mOnItemClickListener.OnClick(this, v, position);
        }
    }

    /**
     * 设置新的数据集
     *
     * @param newDataList 新数据
     */
    public void submitList(List<T> newDataList) {
        if (newDataList == null || newDataList.isEmpty()) {
            return;
        }
        items.clear();
        items.addAll(newDataList);
        notifyDataSetChanged();
    }

    /**
     * 添加新数据
     *
     * @param data 新数据
     */
    public void add(T data) {
        if (items.add(data)) {
            notifyItemInserted(items.size() - 1);
        }
    }

    /**
     * 指定位置添加新数据
     *
     * @param position 下标
     * @param data     新数据
     */
    public void add(int position, T data) {
        if (position >= items.size() || position < 0) {
            throw new IndexOutOfBoundsException("position: " + position + " size: " + items.size());
        }
        items.add(position, data);
        notifyItemInserted(position);
    }

    /**
     * 添加一组新数据
     *
     * @param collection 新数据集合
     */
    public void addAll(Collection<T> collection) {
        if (collection.isEmpty()) return;
        int oldSize = items.size();
        if (items.addAll(collection)) {
            notifyItemRangeChanged(oldSize, collection.size());
        }
    }

    /**
     * 在指定位置添加新数据集合
     *
     * @param position   下标
     * @param collection 新数据集合
     */
    public void addAll(int position, Collection<T> collection) {
        if (collection.isEmpty()) return;
        if (position < 0 || position >= items.size()) {
            throw new IndexOutOfBoundsException("position: " + position + " size: " + items.size());
        }
        if (items.addAll(position, collection)) {
            notifyItemRangeChanged(position, collection.size());
        }
    }

    /**
     * 改变指定位置的数据
     *
     * @param position 下标
     * @param data     新数据
     */
    public void set(int position, T data) {
        if (position >= items.size()) {
            throw new IndexOutOfBoundsException("position: " + position + " size: " + items.size());
        }
        items.set(position, data);
        notifyItemChanged(position);
    }

    public void onViewRecycle(VH holder) {

    }

    @Override
    public void onViewRecycled(@NonNull RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);
        onViewRecycle((VH) holder);
    }

    private int getItemCount(List<T> items) {
        return items.size();
    }

    public interface OnItemClickListener<T> {
        void OnClick(BRVAdapter<T, ?> adapter, View view, int position);
    }

    public interface OnItemLongClickListener<T> {
        boolean OnLongClick(BRVAdapter<T, ?> adapter, View view, int position);
    }

    public interface OnItemChildClickListener<T> {
        void onItemClick(BRVAdapter<T, ?> adapter, View view, int position);
    }

    public interface OnItemChildLongClickListener<T> {
        boolean onItemLongClick(BRVAdapter<T, ?> adapter, View view, int position);
    }

    @Override
    public int getItemCount() {
        return getItemCount(items);
    }
}
