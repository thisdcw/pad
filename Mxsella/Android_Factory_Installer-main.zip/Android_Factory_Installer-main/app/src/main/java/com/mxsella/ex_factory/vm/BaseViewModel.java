package com.mxsella.ex_factory.vm;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.mxsella.ex_factory.model.response.ResultType;
import com.mxsella.ex_factory.model.response.BaseResponse;
import com.mxsella.ex_factory.model.response.handler.NetWorkResult;
import com.mxsella.ex_factory.model.response.handler.ResultUtil;
import com.mxsella.ex_factory.net.inter.ApiResponseHandler;
import com.mxsella.ex_factory.util.LogUtil;

public class BaseViewModel extends ViewModel {

    protected <T> ApiResponseHandler<BaseResponse<T>> createHandler(MutableLiveData<NetWorkResult<T>> liveData) {
        return new ApiResponseHandler<BaseResponse<T>>() {
            @Override
            public void onSuccess(BaseResponse<T> data) {
                if (data.getCode() == ResultType.success().getCode()) {
                    liveData.setValue(ResultUtil.success(data.getData(), data.getMessage()));
                } else {
                    liveData.setValue(ResultUtil.failed(data.getMessage()));
                }
            }

            @Override
            public void onError(Throwable error) {
                LogUtil.e(error.getMessage());
                liveData.setValue(ResultUtil.error(error.getMessage()));
            }
        };
    }
}
