package com.mxsella.ex_factory.manager;

import android.util.SparseArray;

import com.liulishuo.filedownloader.BaseDownloadTask;
import com.liulishuo.filedownloader.FileDownloadConnectListener;
import com.liulishuo.filedownloader.FileDownloader;
import com.liulishuo.filedownloader.model.FileDownloadStatus;
import com.mxsella.ex_factory.inter.DataChangeListener;
import com.mxsella.ex_factory.inter.TaskUpdateListener;
import com.mxsella.ex_factory.model.dvo.TaskManagerModel;
import com.mxsella.ex_factory.ui.adapter.holder.TaskHolder;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class TaskManager {

    private String selectId = "";

    private final static class HolderClass {
        private final static TaskManager INSTANCE
                = new TaskManager();
    }

    public static TaskManager getImpl() {
        return HolderClass.INSTANCE;
    }

    private TaskUpdateListener taskUpdateListener;

    public void setTaskUpdateListener(TaskUpdateListener taskUpdateListener) {
        this.taskUpdateListener = taskUpdateListener;
    }

    private List<TaskManagerModel> modelList = new CopyOnWriteArrayList<>();

    public void setModelList(List<TaskManagerModel> modelList) {
        this.modelList = modelList;
        if (taskUpdateListener != null) {
            taskUpdateListener.onTaskChange();
        }
    }


    public void setSelectId(String selectId) {
        this.selectId = selectId;
    }

    private TaskManager() {
    }

    private SparseArray<BaseDownloadTask> taskSparseArray = new SparseArray<>();

    public void addTaskForViewHolder(final BaseDownloadTask task) {
        taskSparseArray.put(task.getId(), task);
    }

    public void removeTaskForViewHolder(final int id) {
        taskSparseArray.remove(id);
    }

    public void updateViewHolder(final int id, final TaskHolder holder) {
        final BaseDownloadTask task = taskSparseArray.get(id);
        if (task == null) {
            return;
        }

        task.setTag(holder);
    }

    public void releaseTask() {
        taskSparseArray.clear();
    }

    private FileDownloadConnectListener listener;

    private <T extends DataChangeListener> void registerServiceConnectionListener(final WeakReference<T>
                                                                                          activityWeakReference) {
        if (listener != null) {
            FileDownloader.getImpl().removeServiceConnectListener(listener);
        }

        listener = new FileDownloadConnectListener() {

            @Override
            public void connected() {
                if (activityWeakReference == null
                        || activityWeakReference.get() == null) {
                    return;
                }

                activityWeakReference.get().postNotifyDataChanged();
            }

            @Override
            public void disconnected() {
                if (activityWeakReference == null
                        || activityWeakReference.get() == null) {
                    return;
                }

                activityWeakReference.get().postNotifyDataChanged();
            }
        };

        FileDownloader.getImpl().addServiceConnectListener(listener);
    }

    private void unregisterServiceConnectionListener() {
        FileDownloader.getImpl().removeServiceConnectListener(listener);
        listener = null;
    }

    public <T extends DataChangeListener> void onCreate(final WeakReference<T> activityWeakReference) {
        if (!FileDownloader.getImpl().isServiceConnected()) {
            FileDownloader.getImpl().bindService();
            registerServiceConnectionListener(activityWeakReference);
        }
    }

    public void onDestroy() {
        unregisterServiceConnectionListener();
        releaseTask();
    }

    public boolean isReady() {
        return FileDownloader.getImpl().isServiceConnected();
    }

    public TaskManagerModel get(final int position) {
        return modelList.get(position);
    }

    public TaskManagerModel getById(final int id) {
        for (TaskManagerModel model : modelList) {
            if (model.getId() == id) {
                return model;
            }
        }

        return null;
    }

    /**
     * @param status Download Status
     * @return has already downloaded
     * @see FileDownloadStatus
     */
    public boolean isDownloaded(final int status) {
        return status == FileDownloadStatus.completed;
    }

    public int getStatus(final int id, String path) {
        return FileDownloader.getImpl().getStatus(id, path);
    }

    public long getTotal(final int id) {
        return FileDownloader.getImpl().getTotal(id);
    }

    public long getSoFar(final int id) {
        return FileDownloader.getImpl().getSoFar(id);
    }

    public int getTaskCounts() {
        return modelList.size();
    }

}
