package com.mxsella.ex_factory.model;

import java.util.List;

public class DiskInfo {

    private Long totalSpace;

    private Long availableSpace;

    private List<String> filePath;


    public Long getTotalSpace() {
        return totalSpace;
    }

    public void setTotalSpace(Long totalSpace) {
        this.totalSpace = totalSpace;
    }

    public Long getAvailableSpace() {
        return availableSpace;
    }

    public void setAvailableSpace(Long availableSpace) {
        this.availableSpace = availableSpace;
    }

    public List<String> getFilePath() {
        return filePath;
    }

    public void setFilePath(List<String> filePath) {
        this.filePath = filePath;
    }

    @Override
    public String toString() {
        return "DiskInfo{" +
                "totalSpace=" + totalSpace +
                ", availableSpace=" + availableSpace +
                ", filePath=" + filePath +
                '}';
    }
}
