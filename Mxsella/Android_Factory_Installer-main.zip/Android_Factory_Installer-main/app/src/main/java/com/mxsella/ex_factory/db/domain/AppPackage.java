package com.mxsella.ex_factory.db.domain;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;

public class AppPackage extends LitePalSupport implements Serializable {

    private int id;

    private String packageName;

    private String apkId;

    private String itemId;

    private int versionCode;

    private int type;

    private String remark;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getApkId() {
        return apkId;
    }

    public void setApkId(String apkId) {
        this.apkId = apkId;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public int getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    @Override
    public String toString() {
        return "Package{" +
                "id=" + id +
                ", packageName='" + packageName + '\'' +
                ", apkId='" + apkId + '\'' +
                ", itemId='" + itemId + '\'' +
                ", versionCode=" + versionCode +
                ", type=" + type +
                '}';
    }
}
