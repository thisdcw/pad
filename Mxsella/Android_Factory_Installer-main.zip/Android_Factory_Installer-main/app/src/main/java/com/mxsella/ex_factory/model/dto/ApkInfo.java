package com.mxsella.ex_factory.model.dto;

public class ApkInfo {
    private String itemId;
    private String apkId;
    private String itemName;
    private String createTime;
    private int versionCode;
    private String versionName;
    private String apkLink;
    private String updateInfo;

    private String appShowInfo;
    private String md5;

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getApkId() {
        return apkId;
    }

    public void setApkId(String apkId) {
        this.apkId = apkId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public int getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public String getApkLink() {
        return apkLink;
    }

    public void setApkLink(String apkLink) {
        this.apkLink = apkLink;
    }

    public String getUpdateInfo() {
        return updateInfo;
    }

    public void setUpdateInfo(String updateInfo) {
        this.updateInfo = updateInfo;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getAppShowInfo() {
        return appShowInfo;
    }

    public void setAppShowInfo(String appShowInfo) {
        this.appShowInfo = appShowInfo;
    }

    @Override
    public String toString() {
        return "ApkInfo{" +
                "itemId='" + itemId + '\'' +
                ", apkId='" + apkId + '\'' +
                ", itemName='" + itemName + '\'' +
                ", createTime='" + createTime + '\'' +
                ", versionCode=" + versionCode +
                ", versionName='" + versionName + '\'' +
                ", apkLink='" + apkLink + '\'' +
                ", updateInfo='" + updateInfo + '\'' +
                ", appShowInfo='" + appShowInfo + '\'' +
                ", md5='" + md5 + '\'' +
                '}';
    }
}
