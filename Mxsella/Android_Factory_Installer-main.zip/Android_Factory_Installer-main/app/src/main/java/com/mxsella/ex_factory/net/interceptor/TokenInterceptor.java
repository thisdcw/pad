package com.mxsella.ex_factory.net.interceptor;

import androidx.annotation.NonNull;

import com.mxsella.ex_factory.util.LogUtil;

import java.io.IOException;

import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class TokenInterceptor implements Interceptor {

    @NonNull
    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        Request request = chain.request();

        Request.Builder builder = request.newBuilder();
        builder.addHeader("Content-Type", "application/json");
        //添加头部token和uid
        builder.addHeader("X-Token", getToken());
        builder.addHeader("uid", getUid());


        Request newRequest = builder.build();
        Headers headers = newRequest.headers();
        LogUtil.d("headers: " + headers);

        return chain.proceed(newRequest);
    }

    //获取用户token
    private String getToken() {

            return "";
    }
    private String getUid() {

            return "";
    }
}
