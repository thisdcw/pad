package com.mxsella.ex_factory.base;

public class Constant {
    public static final int FRESH_DELAY = 2000;
    public static final int LOAD_DELAY = 2000;

    public static final int APP_INSTALL = 0;
    public static final int APP_UNINSTALL = 1;
    public static final int APP_UPDATE = 2;

    public static final String LIULISHUO_APK_URL = "http://cdn.llsapp.com/android/LLS-v4.0-595-20160908-143200.apk";

    public static final String LIULISHUO_CONTENT_DISPOSITION_FILENAME = "LLS-v4.0-595-20160908-143200.apk";

    public static final String[] BIG_FILE_URLS = {
            // 5m
            "http://mirror.internode.on.net/pub/test/5meg.test5",
            // 6m
            "http://download.chinaunix.net/down.php?id=10608&ResourceID=5267&site=1",
            // 8m
            "http://7xjww9.com1.z0.glb.clouddn.com/Hopetoun_falls.jpg",
            // 10m
            "http://dg.101.hk/1.rar"};

    public static final String[] CHUNKED_TRANSFER_ENCODING_DATA_URLS = {
            "http://www.httpwatch.com/httpgallery/chunked/chunkedimage.aspx?0.04400023248109086",
    };

}
