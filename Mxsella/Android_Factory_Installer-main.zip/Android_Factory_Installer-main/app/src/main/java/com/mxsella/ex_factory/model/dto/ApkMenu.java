package com.mxsella.ex_factory.model.dto;

import java.util.List;

public class ApkMenu {
    private String apkId;
    private String categoryId;
    private String apkName;
    private String packageName;
    private String apkInfo;
    private String createTime;
    private String remark;

    private int branch;

    private boolean needExFactory;
    private List<ApkInfo> itemList;

    public boolean isNeedExFactory() {

        return needExFactory;
    }

    public void setNeedExFactory(boolean needExFactory) {
        this.needExFactory = needExFactory;
    }

    public int getBranch() {
        return branch;
    }

    public void setBranch(int branch) {
        this.branch = branch;
    }

    public List<ApkInfo> getItemList() {
        return itemList;
    }

    public void setItemList(List<ApkInfo> itemList) {
        this.itemList = itemList;
    }

    public String getApkId() {
        return apkId;
    }

    public void setApkId(String apkId) {
        this.apkId = apkId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getApkName() {
        return apkName;
    }

    public void setApkName(String apkName) {
        this.apkName = apkName;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getApkInfo() {
        return apkInfo;
    }

    public void setApkInfo(String apkInfo) {
        this.apkInfo = apkInfo;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<ApkInfo> getInfoList() {
        return itemList;
    }

    public void setInfoList(List<ApkInfo> infoList) {
        this.itemList = infoList;
    }

    @Override
    public String toString() {
        return "ApkMenu{" +
                "apkId='" + apkId + '\'' +
                ", categoryId='" + categoryId + '\'' +
                ", apkName='" + apkName + '\'' +
                ", packageName='" + packageName + '\'' +
                ", apkInfo='" + apkInfo + '\'' +
                ", createTime='" + createTime + '\'' +
                ", remark='" + remark + '\'' +
                ", branch=" + branch +
                ", needExFactory=" + needExFactory +
                ", itemList=" + itemList +
                '}';
    }
}
