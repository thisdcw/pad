package com.mxsella.ex_factory.ui.ac;

import android.os.Bundle;
import android.view.View;

import androidx.recyclerview.widget.LinearLayoutManager;

import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.view.BaseActivity;
import com.mxsella.ex_factory.base.Constant;
import com.mxsella.ex_factory.databinding.ActivityMainBinding;
import com.mxsella.ex_factory.manager.TaskManager;
import com.mxsella.ex_factory.model.dto.MenuInfo;
import com.mxsella.ex_factory.model.response.ResultType;
import com.mxsella.ex_factory.ui.adapter.MenuItemAdapter;
import com.mxsella.ex_factory.util.LogUtil;
import com.mxsella.ex_factory.vm.ApkVM;
import com.scwang.smart.refresh.footer.ClassicsFooter;
import com.scwang.smart.refresh.header.ClassicsHeader;
import com.scwang.smart.refresh.layout.api.RefreshLayout;

import java.util.List;

public class MainActivity extends BaseActivity<ActivityMainBinding> {

    private MenuItemAdapter adapter;
    private final ApkVM apkVM = new ApkVM();
    private RefreshLayout refreshLayout;

    @Override
    public int layoutId() {
        return R.layout.activity_main;
    }

    @Override
    public void initView() {
        adapter = new MenuItemAdapter();
        refreshLayout = binding.rvRefresh.refreshLayout;
        refreshLayout.setRefreshHeader(new ClassicsHeader(this));
        refreshLayout.setRefreshFooter(new ClassicsFooter(this));
        binding.rvRefresh.rv.setLayoutManager(new LinearLayoutManager(this));
        binding.rvRefresh.rv.setAdapter(adapter);
        getMenuList();
    }

    @Override
    public void initObserve() {
        apkVM.getCategory().observe(this, result -> {
            if (result.getResultCode().getCode() == ResultType.SUCCESS) {
                List<MenuInfo> data = result.getData();
                if (data != null && !data.isEmpty()) {
                    binding.rvRefresh.empty.setVisibility(View.GONE);
                    adapter.submitList(data);
                } else {
                    binding.rvRefresh.empty.setVisibility(View.VISIBLE);
                }
            } else {
                binding.rvRefresh.empty.setVisibility(View.VISIBLE);
            }

        });
    }

    @Override
    public void initListener() {
        adapter.setOnSelectClick((info, view) -> {
            TaskManager.getImpl().setSelectId(info.getCategoryId());
            LogUtil.d("选择的产品: " + info.toString());
            Bundle bundle = new Bundle();
            bundle.putString("menuName", info.getCategoryName());
            bundle.putString("menuId", info.getCategoryId());
            navToWithParam(PackageActivity.class, bundle);
        });
        refreshLayout.setOnRefreshListener(refreshlayout -> {
            getMenuList();
            refreshlayout.finishRefresh(Constant.FRESH_DELAY);//传入false表示刷新失败
        });
        refreshLayout.setOnLoadMoreListener(refreshlayout -> {
            refreshlayout.setNoMoreData(true);
            refreshlayout.finishLoadMore(Constant.LOAD_DELAY);//传入false表示加载失败
        });
    }

    @Override
    protected void onDestroy() {
//        TaskManager.getImpl().clearDB();
        super.onDestroy();
    }

    private void getMenuList() {
        apkVM.fetchCategory();
    }

    @Override
    public void initService() {

    }
}