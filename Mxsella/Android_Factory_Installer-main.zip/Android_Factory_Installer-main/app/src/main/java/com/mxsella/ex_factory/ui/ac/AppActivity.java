package com.mxsella.ex_factory.ui.ac;

import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;

import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.view.BaseActivity;
import com.mxsella.ex_factory.databinding.ActivityAppBinding;
import com.mxsella.ex_factory.model.AppInfo;
import com.mxsella.ex_factory.ui.adapter.AppAdapter;
import com.mxsella.ex_factory.util.DownloadUtil;
import com.mxsella.ex_factory.util.LogUtil;

import java.util.ArrayList;
import java.util.List;

public class AppActivity extends BaseActivity<ActivityAppBinding> {

    private List<AppInfo> appInfoList = new ArrayList<>();

    private AppAdapter adapter = new AppAdapter();

    @Override
    public int layoutId() {
        return R.layout.activity_app;
    }

    @Override
    public void initView() {
        appInfoList.addAll(DownloadUtil.getInstalledApps(getPackageName()).values());
        binding.rv.setLayoutManager(new LinearLayoutManager(this));
        binding.rv.setAdapter(adapter);
        adapter.submitList(appInfoList);

        adapter.setOnSelectClick((info, view) -> {
            LogUtil.d("点击: " + info);
            Bundle bundle = new Bundle();
            bundle.putString("packageName", info.getPackageName());
            bundle.putInt("versionCode", info.getVersionCode());
            navToWithParam(FactoryActivity.class, bundle);
        });
    }

    @Override
    public void initObserve() {

    }

    @Override
    public void initListener() {

    }

    @Override
    public void initService() {

    }
}