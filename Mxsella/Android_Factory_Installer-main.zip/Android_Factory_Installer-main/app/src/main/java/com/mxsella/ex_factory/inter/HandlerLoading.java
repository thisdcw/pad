package com.mxsella.ex_factory.inter;

public interface HandlerLoading {
    void loading();

    void complete();
}
