package com.mxsella.ex_factory.model.response.handler;


import com.mxsella.ex_factory.model.response.ResultType;

public class ResultUtil {

    public static <T> NetWorkResult<T> success(T data) {
        return new NetWorkResult<>(ResultType.success(), data);
    }

    public static <T> NetWorkResult<T> success(T data, String message) {
        return new NetWorkResult<>(ResultType.success(), data, message);
    }

    public static <T> NetWorkResult<T> failed(String message) {
        return new NetWorkResult<>(ResultType.failed(), message);
    }

    public static <T> NetWorkResult<T> error(String message) {
        return new NetWorkResult<>(ResultType.error(), message);
    }

}
