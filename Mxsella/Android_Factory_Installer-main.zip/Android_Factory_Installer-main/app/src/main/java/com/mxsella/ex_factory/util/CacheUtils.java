package com.mxsella.ex_factory.util;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.util.Log;

import com.mxsella.ex_factory.MyApplication;
import com.mxsella.ex_factory.base.Config;

import java.io.File;
import java.io.IOException;

/**
 * 缓存工具类
 */
public class CacheUtils {

    /**
     * 清除app的缓存
     */
    public static boolean clearAppCache(String cDir) {
        File cacheDir = new File(Environment.getExternalStorageDirectory(), cDir);
        if (cacheDir.exists() && cacheDir.isDirectory()) {
            try {
                deleteDirectoryContents(cacheDir);
                Log.i("CacheUtils", "Cache cleared for: " + cDir);
                return true;
            } catch (IOException e) {
                Log.e("CacheUtils", "Error clearing cache for: " + cDir, e);
                return false;
            }
        }
        Log.i("CacheUtils", "No cache directory found for: " + cDir);
        return true;
    }

    public static boolean clearDownloadFolder() {
        File downloadDir = Config.FILE_SAVE_DIRECTORY;

        if (downloadDir.exists() && downloadDir.isDirectory()) {
            File[] files = downloadDir.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        boolean deleted = file.delete();
                        if (!deleted) {
                            return false;
                        }
                    }
                }
            }
        }
        return true;
    }

    /**
     * 删除文件夹
     *
     * @param directory 文件夹
     * @throws IOException 抛出IO异常
     */
    private static void deleteDirectoryContents(File directory) throws IOException {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectoryContents(file);
                }
                if (!file.delete()) {
                    Log.e("CacheUtils", "Failed to delete file: " + file.getAbsolutePath());
                }
            }
        }
    }

}
