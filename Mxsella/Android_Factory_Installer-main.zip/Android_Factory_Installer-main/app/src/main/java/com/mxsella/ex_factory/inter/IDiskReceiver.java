package com.mxsella.ex_factory.inter;

import com.mxsella.ex_factory.model.DiskInfo;

import java.util.Map;

public interface IDiskReceiver {
    void UDiskInfo(Map<String, DiskInfo> diskMap);

    void UDiskDetach(DiskInfo diskInfo);
}
