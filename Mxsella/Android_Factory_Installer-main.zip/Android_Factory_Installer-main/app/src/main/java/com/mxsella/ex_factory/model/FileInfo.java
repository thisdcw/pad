package com.mxsella.ex_factory.model;

public class FileInfo {

    private String filename;

    private String md5;

    private String path;
    private String fullPath;

    private Long size;

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    @Override
    public String toString() {
        return "FileInfo{" +
                "filename='" + filename + '\'' +
                ", md5='" + md5 + '\'' +
                ", path='" + path + '\'' +
                ", fullPath='" + fullPath + '\'' +
                ", size=" + size +
                '}';
    }

    public String getFullPath() {
        return fullPath;
    }

    public void setFullPath(String fullPath) {
        this.fullPath = fullPath;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

}
