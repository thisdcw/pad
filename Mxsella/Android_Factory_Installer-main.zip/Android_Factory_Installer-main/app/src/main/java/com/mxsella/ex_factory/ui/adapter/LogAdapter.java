package com.mxsella.ex_factory.ui.adapter;

import androidx.core.content.ContextCompat;

import com.mxsella.ex_factory.MyApplication;
import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.brv.BaseRVAdapter;
import com.mxsella.ex_factory.base.brv.DBHolder;
import com.mxsella.ex_factory.databinding.ItemLogBinding;
import com.mxsella.ex_factory.model.LogInfo;

public class LogAdapter extends BaseRVAdapter<LogInfo, ItemLogBinding> {
    @Override
    public void initView(DBHolder<ItemLogBinding> holder, int position, LogInfo item) {
        binding.setLog(item);
        switch (item.getType()) {
            case LogInfo.ERROR:
                binding.tvLog.setTextColor(ContextCompat.getColor(MyApplication.getInstance(), R.color.red));
                break;
            case LogInfo.WARNING:
                binding.tvLog.setTextColor(ContextCompat.getColor(MyApplication.getInstance(), R.color.yellow));
                break;
            case LogInfo.INFO:
            default:
                binding.tvLog.setTextColor(ContextCompat.getColor(MyApplication.getInstance(), R.color.gray));
                break;
        }
    }

    @Override
    public int layoutId() {
        return R.layout.item_log;
    }
}
