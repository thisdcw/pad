package com.mxsella.ex_factory.manager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class BaseDBManager<T> {

    protected final ExecutorService service = Executors.newSingleThreadExecutor();

    // 单例的通用实现
    protected BaseDBManager() {
    }

}
