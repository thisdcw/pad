package com.mxsella.ex_factory.inter;

public interface DialogClickListener {
    void onConfirm();

    void onCancel();
}
