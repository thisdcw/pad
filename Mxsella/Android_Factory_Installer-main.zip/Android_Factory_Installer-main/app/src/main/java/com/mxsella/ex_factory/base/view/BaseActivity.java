package com.mxsella.ex_factory.base.view;

import android.app.Activity;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;

import com.mxsella.ex_factory.base.Config;
import com.mxsella.ex_factory.inter.IDiskReceiver;
import com.mxsella.ex_factory.manager.ActivityStackManager;
import com.mxsella.ex_factory.model.DiskInfo;
import com.mxsella.ex_factory.service.DiskReceiver;
import com.mxsella.ex_factory.util.LogUtil;

import java.util.Map;


public abstract class BaseActivity<DB extends ViewDataBinding> extends AppCompatActivity implements IDiskReceiver {

    public DB binding;

    /**
     * 设置布局
     *
     * @return 布局资源ID
     */
    public abstract int layoutId();

    /**
     * 初始化UI
     */
    public abstract void initView();

    /**
     * 初始化观察者
     */
    public abstract void initObserve();

    /**
     * 初始化监听
     */
    public abstract void initListener();

    /**
     * 初始化服务(Service, Receiver)
     */
    public abstract void initService();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityStackManager.getInstance().addActivity(this);
        try {
            binding = DataBindingUtil.setContentView(this, layoutId());
        } catch (Exception e) {
            LogUtil.e("error activity layout -> " + e.getMessage());
        }
        DiskReceiver.setGlobalDiskReceiver(this);
        initService();
        initView();
        initListener();
        initObserve();
    }


    @Override
    public void onBackPressed() {
        ActivityStackManager.getInstance().finishCurrentActivity(this);
        ActivityStackManager.getInstance().removeActivity(this);
        super.onBackPressed();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (binding != null) {
            binding.unbind();
            binding = null;
        }
    }

    @Override
    public void UDiskInfo(Map<String, DiskInfo> diskMap) {
        LogUtil.d("u盘信息: " + diskMap);
        Config.diskMap = diskMap;
    }

    @Override
    public void UDiskDetach(DiskInfo diskInfo) {
        LogUtil.d("U盘已移除: " + diskInfo);
    }


    public void navTo(Class<? extends Activity> cls) {
        ActivityStackManager.getInstance().startActivityNoFinish(this, cls);

    }

    public void navToFinishAll(Class<? extends Activity> cls) {
        ActivityStackManager.getInstance().finishAllAndStart(this, cls);
    }

    public void navToWithFinish(Class<? extends Activity> cls) {
        ActivityStackManager.getInstance().startActivity(this, cls);
    }

    public void navToWithParam(Class<? extends Activity> cls, Bundle bundle) {
        ActivityStackManager.getInstance().startActivityNoFinish(this, cls, bundle);
    }

    public void finish(Activity activity) {
        ActivityStackManager.getInstance().finishCurrentActivity(activity);
    }
}
