package com.mxsella.ex_factory.net.inter;

public interface ApiResponseHandler<T> {
    void onSuccess(T data);

    void onError(Throwable error);
}
