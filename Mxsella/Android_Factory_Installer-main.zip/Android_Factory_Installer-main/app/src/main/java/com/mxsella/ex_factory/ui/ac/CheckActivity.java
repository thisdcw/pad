package com.mxsella.ex_factory.ui.ac;

import android.Manifest;
import android.annotation.SuppressLint;
import android.os.Handler;

import com.mxsella.ex_factory.R;
import com.mxsella.ex_factory.base.Config;
import com.mxsella.ex_factory.base.view.BaseActivity;
import com.mxsella.ex_factory.databinding.ActivityCheckBinding;
import com.mxsella.ex_factory.util.LogUtil;
import com.tbruyelle.rxpermissions3.RxPermissions;

public class CheckActivity extends BaseActivity<ActivityCheckBinding> {
    private static final long DELAY_TIME = 3000; // 3秒

    public CheckActivity() {
    }

    @Override
    public int layoutId() {
        return R.layout.activity_check;
    }

    @Override
    public void initView() {
        requestPermission();
        binding.deviceId.setText(Config.deviceId);
        Runnable navRunnable = this::navTo;
        //跳转
        new Handler().postDelayed(navRunnable, DELAY_TIME);

    }

    @Override
    public void initObserve() {

    }

    @Override
    public void initListener() {

    }

    @Override
    public void initService() {

    }

    @SuppressLint("CheckResult")
    private void requestPermission() {
        RxPermissions rxPermission = new RxPermissions(CheckActivity.this);
        rxPermission.requestEach(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_WIFI_STATE,
                        Manifest.permission.CHANGE_NETWORK_STATE,
                        Manifest.permission.INSTALL_PACKAGES,
                        Manifest.permission.ACCESS_NETWORK_STATE)
                .subscribe(permission -> {
                    if (permission.granted) {
                        LogUtil.i(permission.name + "权限授予");
                    } else {
                        LogUtil.i(permission.name + "权限未授予");
                    }
                });
    }

    private void navTo() {
//        tr.syncTask();
        navToWithFinish(ChooseActivity.class);
    }
}