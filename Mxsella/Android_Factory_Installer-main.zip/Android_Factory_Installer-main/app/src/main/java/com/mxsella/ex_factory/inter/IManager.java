package com.mxsella.ex_factory.inter;

import java.util.List;

public interface IManager<T> {
    List<T> getAll();

    T getById(String id);

    void saveOrUpdate(T entity);

    boolean deleteById(int id);

    List<T> getList(int page, int size);
}
