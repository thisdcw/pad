<template>
  <div class="BlePopup">
    <van-popup
      :show="showBlePopup"
      round
      :closeable="true"
      position="bottom"
      custom-style="height: 70%"
      z-index="99999"
      @close="onClose"
    >
      <view style="height: 100%">
        <view style="height: 80%">
          <!-- 彩虹扇形背景 -->
          <div style="width: 100%; height: 60%; background-color: red">
            // TODO 背景
          </div>
        </view>
        <view style="height: 20%; background-color: red">
          <!-- <button>搜索</button> -->
        </view>
      </view>
    </van-popup>
  </div>
</template>

<script lang="ts" setup>
import { onShow } from '@dcloudio/uni-app';
import { computed, ref, watch } from 'vue';
import { useStore } from 'vuex';

const store = useStore();

const props = defineProps();

const btState = computed(() => store.getters['page/isShowBlePage']);

const showBlePopup = ref(btState.value);
// const showBlePopup = ref(false);

watch(btState, (newValue) => {
  showBlePopup.value = newValue;
});

const onClose = () => {
  console.log('关闭');
  showBlePopup.value = false;
  store.commit('page/showBlePage', false);
};

onShow(() => {
  console.log('111');
});
</script>

<style lang="scss"></style>
