<template>
  <div class="AddMemberCard">
    <van-cell-group>
      <div
        style="
          font-size: 24rpx;
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          padding: 20rpx 40rpx;
        "
      >
        <text style="color: #8e8e8e"> 基本信息 </text>
      </div>
      <van-field
        :value="newMember.username"
        required
        clearable
        label="姓名"
        @input="onUsernameChange"
        placeholder="请输入姓名"
      />
    </van-cell-group>
    <div
      style="
        display: flex;
        align-items: center;
        justify-content: center;
        margin-top: 40rpx;
      "
    >
      <div
        style="
          width: 360rpx;
          height: 80rpx;
          background: linear-gradient(to right, #2088e9, #0367cc);
          border-radius: 36rpx;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
        "
        @click="addMember"
      >
        <text>添加</text>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { MemberStorage } from '@/storage/member';
import { ref } from 'vue';

const props = defineProps();

const newMember = ref({
  id: 3,
  username: '',
  gender: 0,
  birth: '',
  address: '',
  height: '',
  weight: '',
  waist: '',
  bust: '',
  hip: '',
  cup: '',
  hobby: '',
  isDeleted: 0
});
const onUsernameChange = (event: any) => {
  console.log('username change: ', event.detail);
  newMember.value.username = event.detail;
};
const addMember = () => {
  console.log('添加成员: ', newMember.value);
  MemberStorage.addMember(newMember.value);
  uni.navigateBack()
};
</script>

<style lang="scss"></style>
