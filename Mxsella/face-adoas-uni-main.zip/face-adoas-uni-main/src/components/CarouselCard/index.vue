<template>
  <div class="CarouselCard" style="border-radius: 24rpx">
    <swiper
      autoplay="true"
      interval="3000"
      circular="true"
      indicator-dots="false"
      style="width: 100%; height: 250rpx"
      indicator-style="bottom: 10rpx;"
    >
      <!-- 第一个 swiper-item -->
      <swiper-item>
        <view
          style="
            width: 100%;
            height: 250rpx;
            background-color: #e05b23;
            border-radius: 24rpx;
            display: flex;
            flex-direction: column;
          "
        >
          <view style="margin-top: 20rpx; margin-left: 20rpx">
            <text style="color: white; font-size: 20rpx">护理时长</text>
          </view>
          <view
            style="
              display: flex;
              flex-direction: row;
              margin-top: 20rpx;
              justify-content: space-around;
            "
          >
            <view
              style="
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
              "
            >
              <text style="color: white;font-size: 48rpx; font-weight: bold">
                {{ trainRecord.today / 60 }}
                <text style="margin-left: 10rpx; font-size: 24rpx">min</text>
              </text>
              <text style="color: white; font-size: 20rpx; margin-top: 20rpx"
                >今日护理时长</text
              >
            </view>
            <view
              style="
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
              "
            >
              <text style="font-size: 48rpx; font-weight: bold; color: white">
                {{ trainRecord.total / 60 }}
                <text style="margin-left: 10rpx; font-size: 24rpx">min</text>
              </text>
              <text style="color: white; font-size: 20rpx; margin-top: 20rpx"
                >累计护理时长</text
              >
            </view>
            <view
              style="
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
              "
            >
              <text style="font-size: 48rpx; font-weight: bold; color: white">
                {{ trainRecord.days }}
              </text>
              <text style="color: white; font-size: 20rpx; margin-top: 20rpx"
                >护理天数</text
              >
            </view>
          </view>
        </view>
      </swiper-item>

      <!-- 第二个 swiper-item (你可以复制并修改内容) -->
      <swiper-item>
        <view
          style="
            width: 100%;
            height: 250rpx;
            background-color: #e05b23;
            border-radius: 24rpx;
            display: flex;
            flex-direction: column;
          "
        >
          <view style="margin-top: 20rpx; margin-left: 20rpx">
            <text style="color: white; font-size: 20rpx">偏爱喜好</text>
          </view>
          <view
            style="
              display: flex;
              flex-direction: row;
              margin-top: 20rpx;
              justify-content: space-around;
            "
          >
            <view
              style="
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
              "
            >
              <text style="font-size: 48rpx; color: white">
                {{ trainRecord.part }}
              </text>
              <text style="color: white; font-size: 20rpx; margin-top: 20rpx"
                >偏爱部位</text
              >
            </view>
            <view
              style="
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
              "
            >
              <text style="font-size: 48rpx; color: white">
                {{ trainRecord.mode }}
              </text>
              <text style="color: white; font-size: 20rpx; margin-top: 20rpx"
                >偏爱模式</text
              >
            </view>
          </view>
        </view>
      </swiper-item>
    </swiper>
  </div>
</template>

<script lang="ts" setup>
import { ref, watchEffect } from 'vue';

interface TrainRecord {
  record: Model.TrainRecord;
}

const props = defineProps<TrainRecord>();

const trainRecord = ref(props.record);

watchEffect(() => {
  trainRecord.value = props.record;
});
</script>

<style lang="scss"></style>
