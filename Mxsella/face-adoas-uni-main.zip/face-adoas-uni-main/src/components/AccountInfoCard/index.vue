<template>
  <div class="AccountInfoCard">
    <!-- <van-cell title="头像" is-link @click="handleUpImg">
      <image :src="info.avatar" style="height: 36rpx; width: 36rpx"></image>
    </van-cell> -->
    <van-cell
      title="昵称"
      is-link
      :value="info.nickname"
      @click="showModel('nickname')"
    />
    <van-cell
      title="手机号"
      is-link
      :value="info.phone"
      @click="showModel('phone')"
    />
    <van-cell
      title="个人简介"
      :value="info.remark"
      is-link
      @click="showModel('remark')"
    />
  </div>
</template>

<script lang="ts" setup>
import { updateUserInfo } from '@/service/user';
import { ref, watchEffect } from 'vue';

interface AccountInfo {
  info: Model.AccountInfo;
}
const props = defineProps<AccountInfo>();

const info = ref(props.info);

watchEffect(() => {
  info.value = props.info;
});

const showModel = (type: string) => {
  let message = '';
  let text = '';
  switch (type) {
    case 'nickname':
      message = '请输入昵称';
      text = info.value.nickname;
      break;
    case 'phone':
      message = '请输入号码';
      text = info.value.phone;
      break;
    case 'remark':
      message = '请输入备注';
      text = info.value.remark;
      break;
  }
  uni.showModal({
    title: message,
    content: text,
    editable: true,
    success: (res) => {
      if (res.confirm) {
        setModelData(type, res.content);
      } else {
      }
    },
    fail: (fail) => {}
  });
};

const setModelData = (type: string, value: any) => {
  console.log(info.value);
  console.log(`修改${type}: ${value}`);
  switch (type) {
    case 'nickname':
      info.value.nickname = value;
      break;
    case 'phone':
      info.value.phone = value;
      break;
    case 'remark':
      info.value.remark = value;
      break;
  }

  updateUserInfo(info.value);
};

const handleUpImg = () => {
  // 点击图片区域，选择图片并上传
  uni.chooseImage({
    // 选择图片
    count: 1,
    success: (res) => {
      // 图片选择成功的回调（必传），会返回一个对象
      info.value.avatar = res.tempFilePaths[0]; // 用于更新视图
      uni.uploadFile({
        url: '/hospital/user/updateAvatar', // 请求地址
        filePath: res.tempFilePaths[0], // 临时文件路径
        name: 'avatarfile', // 文件对应的key值
        header: {
          type: 'client' // 需要带的请求头，token等等
        },
        // formData: {
        //   // 额外的请求数据
        //   username: info.value.username
        // },
        success: (res) => {
          // 成功后的回调
          console.log('修改成功');
        }
      });
    }
  });
};
</script>

<style lang="scss"></style>
