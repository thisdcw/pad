<template>
  <div>
    <van-cell
      title="姓名"
      is-link
      :value="info.username"
      @click="showModel('username')"
    />
    <van-cell
      title="性别"
      is-link
      :value="info.gender === 0 ? '女' : '男'"
      @click="showGender = true"
    />
    <van-cell
      title="出生年月"
      is-link
      :value="info.birth"
      @click="showCalender = true"
    />
    <van-cell
      title="所在城市"
      is-link
      :value="info.address"
      @click="showAddress = true"
    />
    <van-cell
      title="身高"
      is-link
      :value="info.height"
      @click="showHeight = true"
    />
    <van-cell
      title="体重"
      is-link
      :value="info.weight"
      @click="showWeight = true"
    />
    <van-cell
      title="腰围"
      is-link
      :value="info.waist"
      @click="showModel('waist')"
    />
    <van-cell
      title="胸围"
      is-link
      :value="info.bust"
      @click="showModel('bust')"
    />
    <van-cell
      title="臀围"
      is-link
      :value="info.hip"
      @click="showModel('hip')"
    />
    <van-cell
      title="罩杯"
      is-link
      :value="info.cup"
      @click="showModel('cup')"
    />
    <van-cell
      title="兴趣爱好"
      is-link
      :value="info.hobby"
      @click="showModel('hobby')"
    />
    <div
      style="
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-around;
        margin-top: 40rpx;
      "
    >
      <div
        style="
          width: 300rpx;
          height: 80rpx;
          background: linear-gradient(to right, #5fadef, #0366cc);
          border-radius: 36rpx;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
        "
        @click="props.save(info)"
        v-if="props.showSave"
      >
        <text>保存</text>
      </div>
      <div
        style="
          width: 300rpx;
          height: 80rpx;
          background: linear-gradient(to right, #f29e21, #e40001);
          border-radius: 36rpx;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
        "
        @click="props.delete(info)"
        v-if="props.showDelete"
      >
        <text>删除</text>
      </div>
    </div>
    <van-action-sheet
      :show="showGender"
      :actions="genderActions"
      @close="showGender = false"
      @select="onGenderSelect"
    />
    <van-action-sheet
      :show="showCalender"
      title="选择出生日期"
      @close="showCalender = false"
    >
      <div>
        <van-datetime-picker
          type="date"
          :value="currentDate"
          :min-date="minDate"
          :formatter="formatter"
          @confirm="onDateConfirm"
          @cancel="showCalender = false"
        />
      </div>
    </van-action-sheet>
    <van-action-sheet
      :show="showHeight"
      @close="showHeight = false"
      title="选择身高"
    >
      <div>
        <van-picker
          :columns="heightColumns"
          :show-toolbar="true"
          @confirm="confirmHeight"
          @cancel="showHeight = false"
        />
      </div>
    </van-action-sheet>
    <van-action-sheet
      :show="showWeight"
      title="选择体重"
      @click="showWeight = false"
    >
      <div>
        <van-picker
          :show-toolbar="true"
          :columns="weightColumns"
          @confirm="confirmWeight"
          @cancel="showWeight = false"
          :default-index="weightColumns.length % 4"
        />
      </div>
    </van-action-sheet>
    <van-action-sheet
      :show="showAddress"
      title="选择城市"
      @close="showAddress = false"
    >
      <div>
        <van-area
          :area-list="area"
          @confirm="confirmAddress"
          @cancel="showAddress = false"
        />
      </div>
    </van-action-sheet>
  </div>
</template>

<script lang="ts" setup>
import { ref, watchEffect } from 'vue';
import { areaList } from '@vant/area-data';
import { formatTimestamp } from '@/utils/dateTime';
import { generateHeightArray, generateWeightArray } from '@/utils/bodyMetrics';

interface UserProps {
  basicInfo: Model.BasicInfo;
  save: (info: Model.BasicInfo) => {};
  delete: (info: Model.BasicInfo) => {};
  showDelete: boolean;
  showSave: boolean;
}

const props = defineProps<UserProps>();

const showGender = ref(false);
const showCalender = ref(false);
const showHeight = ref(false);
const showWeight = ref(false);
const showAddress = ref(false);
const area = ref(areaList);

const currentDate = ref(new Date());
const minDate = ref(new Date(1960, 0, 1));

const confirmAddress = (event: any) => {
  const values = event.detail.values;
  const address = `${values[0].name} ${values[1].name} ${values[2].name}`;
  console.log(address);
  info.value.address = address;
  showAddress.value = false;
};

const genderActions = [
  { name: '男', value: 1 },
  { name: '女', value: 0 }
];

const height = generateHeightArray(130, 220);

const weight = generateWeightArray(40, 80);

const heightColumns = ref(height);

const weightColumns = ref(weight);

const info = ref(props.basicInfo);

watchEffect(() => {
  info.value = props.basicInfo;
});

const showModel = (type: string) => {
  let message = '';
  switch (type) {
    case 'username':
      message = '请输入用户名';
      break;
    case 'waist':
      message = '请输入腰围';
      break;
    case 'bust':
      message = '请输入胸围';
      break;
    case 'hip':
      message = '请输入臀围';
      break;
    case 'cup':
      message = '请输入罩杯';
      break;
    case 'hobby':
      message = '请输入爱好';
      break;
  }
  uni.showModal({
    title: message,
    editable: true,
    success: (res) => {
      if (res.confirm) {
        setModelData(type, res.content);
      } else {
      }
    },
    fail: (fail) => {}
  });
};

const setModelData = (type: string, value: any) => {
  console.log(`修改${type}: ${value}`);
  switch (type) {
    case 'username':
      info.value.username = value;
      break;
    case 'waist':
      info.value.waist = value;
      break;
    case 'bust':
      info.value.bust = value;
      break;
    case 'hip':
      info.value.hip = value;
      break;
    case 'cup':
      info.value.cup = value;
      break;
    case 'hobby':
      info.value.hobby = value;
      break;
  }
};

const confirmHeight = (event: any) => {
  info.value.height = event.detail.value + ' cm';
  showHeight.value = false;
};
const confirmWeight = (event: any) => {
  info.value.weight = event.detail.value + ' kg';
  showWeight.value = false;
};
const formatter = (type: any, value: any) => {
  if (type === 'year') {
    return `${value}年`;
  }
  if (type === 'month') {
    return `${value}月`;
  }
  return value;
};

const onDateConfirm = (event: any) => {
  const newDate = formatTimestamp(event.detail);
  info.value.birth = newDate;
  showCalender.value = false;
};

const onGenderSelect = (event: any) => {
  info.value.gender = event.detail.value;
};
</script>

<style lang="scss">
.info {
  height: 100vh;
  width: 100vw;
  background-color: #f7f7f7;
}
</style>
