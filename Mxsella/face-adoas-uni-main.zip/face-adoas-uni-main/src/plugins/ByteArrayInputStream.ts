export class ByteArrayInputStream {
    private buffer: Uint8Array;
    private pos: number = 0;

    constructor(buffer: Uint8Array) {
        this.buffer = buffer;
    }

    public read(): number {
        if (this.pos < this.buffer.length) {
            return this.buffer[this.pos++] & 0xff;
        } else {
            return -1; // Indicates the end of the stream
        }
    }

    public readFully(bytes: Uint8Array, offset: number = 0, length: number = bytes.length): void {
        if (this.pos + length > this.buffer.length) {
            throw new Error('Not enough data available');
        }
        for (let i = 0; i < length; i++) {
            bytes[offset + i] = this.buffer[this.pos++];
        }
    }

    public close(): void {
        // No resources to release in this implementation, but method is here for API compatibility
        console.log('ByteArrayInputStream closed');
    }
}
