import { ble } from '../config/config'
import { utils } from './protocol'
/**
 * 向蓝牙设备发送数据
 * @param data 发送的数据
 * @param deviceId 蓝牙设备ID
 * @returns 
 */
export const sendData = (data: string, deviceId: string) => {

    const cleanedData = data.replace(/\s+/g, '');

    console.log("发送数据: " + cleanedData + " 到: " + deviceId);

    const bufferData = utils.hexToByteArray(cleanedData).buffer;

    return new Promise((resolve, reject) => {
        uni.writeBLECharacteristicValue({
            characteristicId: ble.WRITE_CHARACTERISTIC_ID,
            serviceId: ble.SERVICE_ID,
            deviceId: deviceId,
            value: bufferData,
            success: res => {
                resolve(res)
            },
            fail: err => {
                reject(err)
            }
        })
    })
}
/**
 * 扫描蓝牙
 * @returns 
 */
export const scan = () => {
    return new Promise<Map<string, Model.Ble>>((resolve, reject) => {
        const devicesMap = new Map<string, Model.Ble>();
        let loadingShown = false;  // 标志位，跟踪加载动画是否显示

        // 清除之前的扫描状态
        uni.stopBluetoothDevicesDiscovery();  // 停止之前的扫描
        uni.closeBluetoothAdapter({
            complete: () => {
                // 重新初始化蓝牙适配器
                uni.openBluetoothAdapter({
                    success: res => {
                        console.log("蓝牙适配器已打开", res);
                        // 开始扫描蓝牙设备
                        uni.startBluetoothDevicesDiscovery({
                            allowDuplicatesKey: false,
                            success: () => {
                                uni.showLoading({
                                    title: '正在扫描设备...',
                                    mask: true
                                });
                                loadingShown = true;  // 标志位设为true

                                // 清除之前的设备发现事件监听
                                uni.offBluetoothDeviceFound();

                                // 监听蓝牙设备发现
                                uni.onBluetoothDeviceFound((res) => {
                                    res.devices.forEach((device) => {
                                        if (device.name) {
                                            const ble = {} as Model.Ble;
                                            ble.RSSI = device.RSSI;
                                            ble.advertisServiceUUIDs = device.advertisServiceUUIDs;
                                            ble.name = device.name;
                                            ble.deviceId = device.deviceId;
                                            ble.localName = device.localName;
                                            devicesMap.set(device.deviceId, ble);
                                        }
                                    });
                                });

                                // 停止扫描并处理结果
                                setTimeout(() => {
                                    uni.stopBluetoothDevicesDiscovery();
                                    if (loadingShown) {
                                        uni.hideLoading(); // 隐藏加载动画
                                        loadingShown = false;  // 标志位设为false
                                    }
                                    resolve(devicesMap);
                                }, ble.SCAN_TIMEOUT);
                            },
                            fail: (err) => {
                                uni.stopBluetoothDevicesDiscovery();
                                if (loadingShown) {
                                    uni.hideLoading(); // 隐藏加载动画
                                    loadingShown = false;
                                }
                                reject(err);
                            }
                        });
                    },
                    fail: err => {
                        console.log("蓝牙适配器打开失败", err);
                        reject(err);  // 确保 reject
                    }
                });
            }
        });
    });
}

/**
 * 快速连接
 * @param deviceId 设备id
 * @returns 
 */
export const quickConnect = (deviceId: string) => {
    return new Promise((resolve, reject) => {
        let loadingShown = false;
        let connected = false;  // 标志位，避免重复连接

        // 先关闭可能存在的蓝牙扫描和适配器，以清除缓存数据
        uni.stopBluetoothDevicesDiscovery();
        uni.closeBluetoothAdapter({
            complete: () => {
                // 重新打开蓝牙适配器
                uni.openBluetoothAdapter({
                    success: res => {
                        console.log("蓝牙适配器已打开", res);

                        // 开始扫描蓝牙设备
                        uni.startBluetoothDevicesDiscovery({
                            allowDuplicatesKey: false,
                            success: () => {
                                uni.showLoading({
                                    title: '正在扫描设备...',
                                    mask: true
                                });
                                loadingShown = true;

                                // 清除之前的设备发现事件监听，防止事件重复注册
                                uni.offBluetoothDeviceFound();

                                // 监听蓝牙设备发现
                                uni.onBluetoothDeviceFound((res) => {
                                    if (connected) return;  // 避免重复连接

                                    res.devices.forEach((device) => {
                                        if (device.deviceId === deviceId) {
                                            connected = true;
                                            uni.stopBluetoothDevicesDiscovery();
                                            if (loadingShown) {
                                                uni.hideLoading();
                                                loadingShown = false;
                                            }
                                            connect(device.deviceId)
                                                .then(res => resolve(res))
                                                .catch(err => reject(err));
                                        }
                                    });
                                });

                                // 如果超时还未找到设备，则停止扫描
                                setTimeout(() => {
                                    if (!connected) {
                                        uni.stopBluetoothDevicesDiscovery();
                                        if (loadingShown) {
                                            uni.hideLoading();
                                            loadingShown = false;
                                        }
                                        reject(new Error('设备未找到'));
                                    }
                                }, ble.SCAN_TIMEOUT);
                            },
                            fail: (err) => {
                                uni.stopBluetoothDevicesDiscovery();
                                if (loadingShown) {
                                    uni.hideLoading();
                                    loadingShown = false;
                                }
                                reject(err);
                            }
                        });
                    },
                    fail: err => {
                        console.log("蓝牙适配器打开失败", err);
                        reject(err);  // 确保 reject
                    }
                });
            }
        });
    });
};

/**
 * 快速连接（支持重试）
 * @param deviceId 设备id
 * @param maxRetries 最大重试次数，默认3次
 * @returns 
 */
export const quickConnectWithRetry = (deviceId: string, maxRetries: number = 3) => {
    const attemptQuickConnect = (retryCount: number): Promise<any> => {
        return new Promise((resolve, reject) => {
            let loadingShown = false;
            let connected = false; // 标志位，避免重复连接

            // 关闭可能存在的蓝牙扫描和适配器，以清除缓存数据
            uni.stopBluetoothDevicesDiscovery();
            uni.closeBluetoothAdapter({
                complete: () => {
                    // 重新打开蓝牙适配器
                    uni.openBluetoothAdapter({
                        success: res => {
                            console.log("蓝牙适配器已打开", res);

                            // 开始扫描蓝牙设备
                            uni.startBluetoothDevicesDiscovery({
                                allowDuplicatesKey: false,
                                success: () => {
                                    uni.showLoading({
                                        title: '正在扫描设备...',
                                        mask: true
                                    });
                                    loadingShown = true;

                                    // 清除之前的设备发现事件监听，防止事件重复注册
                                    uni.offBluetoothDeviceFound();

                                    // 监听蓝牙设备发现
                                    uni.onBluetoothDeviceFound((res) => {
                                        if (connected) return; // 避免重复连接

                                        res.devices.forEach((device) => {
                                            if (device.deviceId === deviceId) {
                                                connected = true;
                                                uni.stopBluetoothDevicesDiscovery();
                                                if (loadingShown) {
                                                    uni.hideLoading();
                                                    loadingShown = false;
                                                }
                                                connect(device.deviceId)
                                                    .then(res => resolve(res))
                                                    .catch(err => reject(err));
                                            }
                                        });
                                    });

                                    // 如果超时还未找到设备，则停止扫描
                                    setTimeout(() => {
                                        if (!connected) {
                                            uni.stopBluetoothDevicesDiscovery();
                                            if (loadingShown) {
                                                uni.hideLoading();
                                                loadingShown = false;
                                            }
                                            reject(new Error('设备未找到'));
                                        }
                                    }, ble.SCAN_TIMEOUT);
                                },
                                fail: (err) => {
                                    uni.stopBluetoothDevicesDiscovery();
                                    if (loadingShown) {
                                        uni.hideLoading();
                                        loadingShown = false;
                                    }
                                    reject(err);
                                }
                            });
                        },
                        fail: err => {
                            console.log("蓝牙适配器打开失败", err);
                            reject(err); // 确保 reject
                        }
                    });
                }
            });
        }).catch((err) => {
            if (retryCount < maxRetries) {
                console.warn(`快速连接失败，重试第${retryCount + 1}次...`);
                return attemptQuickConnect(retryCount + 1);
            }
            throw err;
        });
    };

    return attemptQuickConnect(0);
};

/**
 * 断开连接蓝牙
 * @param deviceId 设备id
 * @returns 
 */
export const disconnect = (deviceId: string) => {
    return new Promise((resolve, reject) => {
        uni.closeBLEConnection({
            deviceId: deviceId,
            success: (res) => {
                resolve(res);
            },
            fail: (err) => {
                reject(err);
            }
        });
    });
}
/**
 * 连接蓝牙
 * @param deviceId 设备id
 * @returns 
 */
export const connect = (deviceId: string) => {
    return new Promise((resolve, reject) => {
        const timeout = ble.CONNECT_TIMEOUT;
        const connectPromise = new Promise((innerResolve, innerReject) => {
            uni.createBLEConnection({
                deviceId: deviceId,
                success: (res) => {
                    console.log("蓝牙连接成功", res);
                    openDataListener(
                        deviceId,
                        ble.READ_CHARACTERISTIC_ID,
                        ble.SERVICE_ID
                    );
                    innerResolve(res);
                },
                fail: (err) => {
                    innerReject(err);
                }
            });
        });
        const timeoutPromise = new Promise((innerResolve, innerReject) => {
            setTimeout(() => {
                innerReject(new Error('Connection timeout'));
            }, timeout);
        });

        Promise.race([connectPromise, timeoutPromise])
            .then(() => {
                uni.hideLoading();
                uni.getBLEDeviceServices({
                    deviceId: deviceId,
                    success: (res) => {
                        resolve(res);
                    },
                    fail: (err) => {
                        reject(err);
                    }
                });
            })
            .catch((err) => {
                uni.hideLoading();
                reject(err);
            });
        // 显示加载中提示
        uni.showLoading({
            title: '正在连接设备',
            mask: true
        });
    });
}
/**
 * 连接蓝牙（支持重试）
 * @param deviceId 设备id
 * @param maxRetries 最大重试次数，默认3次
 * @returns 
 */
export const connectWithRetry = (deviceId: string, maxRetries: number = 3) => {
    const attemptConnection = (retryCount: number): Promise<any> => {
        return new Promise((resolve, reject) => {
            const timeout = ble.CONNECT_TIMEOUT;
            const connectPromise = new Promise((innerResolve, innerReject) => {
                uni.createBLEConnection({
                    deviceId: deviceId,
                    success: (res) => {
                        console.log("蓝牙连接成功", res);
                        openDataListener(
                            deviceId,
                            ble.READ_CHARACTERISTIC_ID,
                            ble.SERVICE_ID
                        );
                        innerResolve(res);
                    },
                    fail: (err) => {
                        innerReject(err);
                    }
                });
            });
            const timeoutPromise = new Promise((innerResolve, innerReject) => {
                setTimeout(() => {
                    innerReject(new Error('Connection timeout'));
                }, timeout);
            });

            Promise.race([connectPromise, timeoutPromise])
                .then(() => {
                    uni.hideLoading();
                    uni.getBLEDeviceServices({
                        deviceId: deviceId,
                        success: (res) => {
                            resolve(res);
                        },
                        fail: (err) => {
                            reject(err);
                        }
                    });
                })
                .catch((err) => {
                    uni.hideLoading();
                    reject(err);
                });

            // 显示加载中提示
            uni.showLoading({
                title: '正在连接设备',
                mask: true
            });
        }).catch((err) => {
            if (retryCount < maxRetries) {
                console.warn(`连接失败，重试第${retryCount + 1}次...`);
                return attemptConnection(retryCount + 1);
            }
            throw err;
        });
    };

    return attemptConnection(0);
};

/**
 * 打开监听
 * @param deviceId 蓝牙设备id
 * @param characteristicId 读取特征值ID
 * @param serviceId 服务id
 */
export const openDataListener = (deviceId: string, characteristicId: string, serviceId: string) => {
    uni.getBLEDeviceServices({
        deviceId,
        success: res => {
            console.log("获取蓝牙设备服务", res)
            // 获取蓝牙设备特征值
            uni.getBLEDeviceCharacteristics({
                deviceId,
                serviceId,
                success: res => {
                    console.log("获取蓝牙设备特征值", res)
                    // 开始监听蓝牙数据变化
                    startBleDataChange(deviceId, characteristicId, serviceId)
                },
                fail: err => {
                    console.log("获取蓝牙设备特征值失败", err)
                }
            })
        },
        fail: err => {
            console.log("获取蓝牙设备服务失败", err)
        }
    })
}
/**
 * 打开蓝牙适配器
 */
export const openBleAdapter = () => {
    uni.openBluetoothAdapter({
        success: res => {
            console.log("蓝牙适配器已打开", res)
            // 开始扫描蓝牙设备
        },
        fail: err => {
            console.log("蓝牙适配器打开失败", err)
        }
    })
}
/**
 * 开启蓝牙监听
 * @param deviceId 蓝牙设备id
 * @param characteristicId 读取特征值id
 * @param serviceId 服务ID
 */
const startBleDataChange = (deviceId: string, characteristicId: string, serviceId: string) => {
    uni.notifyBLECharacteristicValueChange({
        deviceId,
        serviceId,
        characteristicId,
        state: true,
        success: res => {
            console.log("开始监听蓝牙数据变化", res)
        },
        fail: err => {
            console.log("开始监听蓝牙数据变化失败", err)
        }
    })
}
