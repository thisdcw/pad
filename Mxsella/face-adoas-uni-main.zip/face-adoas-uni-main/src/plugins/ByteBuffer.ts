export class ByteBuffer {
    private buffer: Uint8Array;
    private position: number;

    constructor(initialCapacity: number = 200) {
        this.buffer = new Uint8Array(initialCapacity);
        this.position = 0;
    }

    put(data: Uint8Array): void {
        this.ensureCapacity(this.position + data.length);
        this.buffer.set(data, this.position);
        this.position += data.length;
    }

    flip(): void {
        this.buffer = this.buffer.slice(0, this.position);
        this.position = 0;
    }

    get(): Uint8Array {
        return this.buffer.slice(0, this.position);
    }

    clear(): void {
        this.buffer.fill(0);
        this.position = 0;
    }

    set(index: number, value: number): void {
        if (index >= 0 && index < this.position) {
            this.buffer[index] = value;
        } else {
            console.error("Index out of bounds or position not set.");
        }
    }
    length(): number {
        return this.position;
    }

    private ensureCapacity(minCapacity: number): void {
        if (this.buffer.length < minCapacity) {
            const newCapacity = Math.max(this.buffer.length * 2, minCapacity);
            const newBuffer = new Uint8Array(newCapacity);
            newBuffer.set(this.buffer);
            this.buffer = newBuffer;
        }
    }
}
