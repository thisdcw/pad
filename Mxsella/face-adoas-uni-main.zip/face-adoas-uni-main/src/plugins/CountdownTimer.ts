class CountdownTimer {
    private timerId: NodeJS.Timeout | null = null;
    private remainingTime: number;
    private initialTime: number;
    private onTickCallback: (time: number) => void;
    private onFinishCallback: () => void;
  
    constructor(initialTime: number, onTickCallback: (time: number) => void, onFinishCallback: () => void) {
      this.initialTime = initialTime;
      this.remainingTime = initialTime;
      this.onTickCallback = onTickCallback;
      this.onFinishCallback = onFinishCallback;
    }
  
    // 开始倒计时
    start(): void {
      if (this.timerId) return; // 已经在计时中
  
      this.timerId = setInterval(() => {
        this.remainingTime -= 1000; // 每秒减少 1000 毫秒
  
        if (this.remainingTime <= 0) {
          this.stop(false); // 时间到，停止并不重置时间
          this.onFinishCallback();
        } else {
          this.onTickCallback(this.remainingTime);
        }
      }, 1000);
    }
  
    // 暂停倒计时
    pause(): void {
      if (this.timerId) {
        clearInterval(this.timerId);
        this.timerId = null;
      }
    }
  
    // 继续倒计时
    continue(): void {
      if (this.timerId) return; // 已经在计时中
  
      this.start();
    }
  
    // 停止倒计时并选择是否重置时间
    stop(resetTime: boolean = false): void {
      if (this.timerId) {
        clearInterval(this.timerId);
        this.timerId = null;
      }
  
      if (resetTime) {
        this.remainingTime = this.initialTime;
      }
    }
  
    // 设置新的倒计时时间
    setTime(newTime: number): void {
      this.initialTime = newTime;
      this.remainingTime = newTime;
    }
  }
  
  export default CountdownTimer;
  