import { ByteArrayInputStream } from './ByteArrayInputStream'; // 假设 ByteArrayInputStream 已经实现
import { utils, protocol } from '@/plugins/protocol'
import { ByteBuffer } from './ByteBuffer'
let byteBuffer = new ByteBuffer(200);

/**
 * 处理指令
 * @param hexString 16进制字符串数据
 * @param callback 处理成功回调数据
 * @returns 无
 */
export const receiveTask = (hexString: string, callback?: (byteArray: Uint8Array) => void) => {

    const data = utils.hexToByteArray(hexString);
    const head = utils.hexToByteArray(protocol.HEAD);

    let readLength = 0;
    let inputStream = new ByteArrayInputStream(data);

    try {
        let flag = -1;
        while ((flag = inputStream.read()) !== -1) {
            readLength++;
            let byteList = [flag];
            let read = -1;
            let hasHead = false;

            while ((read = inputStream.read()) !== -1) {
                readLength++;
                byteList.push(read);
                let bytes = new Uint8Array(byteList);

                if (utils.endWith(bytes, head)) {
                    hasHead = true;
                    break;
                }
            }

            if (!hasHead) {
                break;
            }

            let len = -1;
            if ((len = inputStream.read()) !== -1) {
                readLength++;
                if (len > 50) {
                    return;
                }

                if (readLength + len > data.length) {
                    byteBuffer.put(data.subarray(readLength - head.length, data.length));
                    break;
                }

                let bytes = new Uint8Array(len);
                inputStream.readFully(bytes, 0, len);
                readLength += len;
                if (callback) {
                    callback(bytes);
                } else {

                    handleData(bytes);
                }
            } else {
                byteBuffer.put(data.subarray(data.length - head.length, data.length));
            }
        }
    } catch (e) {
        console.error(e);
    }
}
function handleData(data: Uint8Array) {
    // 实现处理逻辑
    console.log('handle => ' + Array.from(data).map(byte => byte.toString(16).padStart(2, '0')).join(' '));
}

