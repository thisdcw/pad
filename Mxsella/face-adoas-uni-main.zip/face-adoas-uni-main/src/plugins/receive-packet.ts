import { utils, protocol } from './protocol';

export class ReceivePacket {
    bytes: Uint8Array;
    command: number;
    len: number;
    remainTimes: number;
    workTime: number;
    mac: string;
    tail: number;
    type: string;

    constructor(bytes: Uint8Array) {
        this.bytes = bytes;
        this.command = bytes[0];
        this.len = bytes[1];
        this.remainTimes = 0;
        this.workTime = 0;
        this.mac = '';
        this.tail = bytes[bytes.length - 1];
        this.type = this.determineType();
        this.parseDataList();
    }

    determineType(): string {
        // if (this.command === protocol.ADDR_MAC) {
        //     return constant.TYPE_MAC;
        // } else if (this.command === protocol.ADDR_PAY) {
        //     return constant.TYPE_PAY;
        // } else if (this.command === protocol.ADDR_INFO) {
        //     return constant.TYPE_INFO;
        // } else if (this.command === protocol.ADDR_RESET) {
        //     return constant.TYPE_RESET;
        // } else {
        //     return constant.TYPE_UNKNOWN;
        // }
        return '';
    }

    parseDataList(): void {
        if (this.type === constant.TYPE_MAC) {
            this.mac = utils.bytesToHexString(this.bytes.slice(2, 8));
        } else if (this.type === constant.TYPE_PAY || this.type === constant.TYPE_INFO || this.type === constant.TYPE_RESET) {
            this.remainTimes = utils.bytesToInt(this.bytes.slice(2, 4));
            this.workTime = utils.bytesToInt(this.bytes.slice(4, 6));
        }
    }
}

export const constant = {
    TYPE_MAC: 'mac',
    TYPE_PAY: 'pay',
    TYPE_INFO: 'info',
    TYPE_RESET: 'reset',
    TYPE_UNKNOWN: 'unknown'
};
