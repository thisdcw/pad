<template>
  <div class="member">
    <van-tabs
      :active="active"
      title-inactive-color="#8B8B8B"
      title-active-color="#E61B1B"
      @change="changeActiveTab"
    >
      <div v-for="(item, index) in memberList" :key="index">
        <van-tab :title="item.username || `护理人-${index}`">
          <div
            style="
              font-size: 24rpx;
              display: flex;
              flex-direction: row;
              justify-content: space-between;
              padding: 20rpx 40rpx;
            "
          >
            <text style="color: #8e8e8e"> 基本信息 </text>
          </div>
          <div>
            <basic-info-card
              :basicInfo="item"
              :save="updateMember"
              :delete="removeMember"
              :showDelete="true"
              :showSave="true"
            />
          </div>
        </van-tab>
      </div>
      <van-tab title="+ 添加">
        <div>
          <add-member-card />
        </div>
      </van-tab>
    </van-tabs>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import { MemberStorage } from '@/storage/member';
import { onShow } from '@dcloudio/uni-app';

const active = ref(0);

const memberList = ref([] as Model.Member[]);

const fetchMemberList = () => {
  let members = MemberStorage.getMemberList();
  const list = members.filter((item) => item.isDeleted !== 1);
  console.log('memberList: ', list);
  memberList.value = list;
};

const changeActiveTab = (event: any) => {
  console.log(event.detail);
  active.value = event.detail.index;
};

const updateMember = (info: Model.Member) => {
  console.log('saveOrUpdateMember: ', info);
  MemberStorage.updateMember(info);
};

const removeMember = (item: Model.Member) => {
  console.log('移除成员: ', item);
  item.isDeleted = 1;
  MemberStorage.updateMember(item);

  uni.navigateBack();
};

onShow(() => {
  fetchMemberList();
});
</script>

<style lang="scss"></style>
