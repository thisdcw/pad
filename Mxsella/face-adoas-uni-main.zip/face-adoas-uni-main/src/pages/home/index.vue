<template>
  <!-- <base-view :active-tab="0"> </base-view> -->
  <!-- 自定义 tabbar 底部导航栏 -->
  <view class="parent">
    <van-nav-bar />
    <Head />
    <Carousel style="display: flex; justify-content: center" />
    <view class="recently-list">
      <view
        style="
          margin-bottom: 50rpx;
          width: 100%;
          margin-top: 40rpx;
          display: flex;
          margin-left: 80rpx;
        "
      >
        <text style="font-size: 32rpx; color: #636363" @click="setBle">
          我的常用设备<text v-show="false" style="font-size: 22rpx; color: red">
            (测试阶段,点击此处可模拟蓝牙连接和断开的状态)
          </text>
        </text>
      </view>
      <Recent :recentlyList="recentlyList" :onConnect="onConnect" />
    </view>
  </view>
  <van-popup
    :show="showConnectBle"
    round
    z-index="99999"
    @close="onConnectBleClose"
  >
    <div
      style="
        width: 678rpx;
        height: 300rpx;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
      "
    >
      <div
        style="
          width: 500rpx;
          height: 80rpx;
          border: #086cd1 3rpx solid;
          border-radius: 12rpx;
          color: #086cd1;
          font-weight: bold;
          display: flex;
          align-items: center;
          justify-content: center;
        "
      >
        {{ selectDevice.device?.deviceId }}
      </div>
      <div
        style="
          height: 60rpx;
          width: 140rpx;
          margin-top: 40rpx;
          background: linear-gradient(to right, #086cd1, #0e7fe1);
          color: white;
          border-radius: 12rpx;
          display: flex;
          align-items: center;
          justify-content: center;
        "
        @click="onConnectDevice"
      >
        连接
      </div>
    </div>
  </van-popup>
  <!-- <ble-popup /> -->
  <custom-tabbar />
</template>

<script lang="ts" setup>
import { onShareAppMessage, onShareTimeline, onShow } from '@dcloudio/uni-app';
import { computed, ref } from 'vue';
import { useStore } from 'vuex';
import { disconnect, quickConnect } from '@/plugins/bluetooth';
import { BleStorage } from '@/storage/ble';
import Carousel from '@/pages/home/module/Carousel.vue';
import Recent from '@/pages/home/module/Recent.vue';
import Head from '@/pages/home/module/Head.vue';

const store = useStore();
const showConnectBle = ref(false);
const selectDevice = ref({} as Model.RecentDevice);

const btState = computed(() => store.getters['bt/getBleState']);
const ble = computed(() => store.getters['bt/getBle']);

const setBle = () => {
  store.commit('bt/setBleState', !btState.value);
  uni.showToast({
    title: `${btState.value ? '蓝牙已连接' : '蓝牙已断开'}`,
    icon: 'none'
  });
};

const recentlyList = ref({} as Model.RecentDevice[]);
const fetchRecentlyList = () => {
  const fullList = BleStorage.getBleList(); // 获取完整列表
  recentlyList.value = fullList.slice(0, 2); // 筛选前两条数据
};
const onConnect = (recentDevice: Model.RecentDevice) => {
  if (btState.value) {
    if (ble.value?.deviceId === recentDevice.device.deviceId) {
      uni.showToast({
        title: '请勿重复连接',
        icon: 'fail'
      });
      return;
    }
    disconnect(ble.value?.deviceId)
      .then((res) => {
        store.commit('bt/setBleState', false);
        console.log('连接: ', recentDevice.device.deviceId);
        selectDevice.value = recentDevice;
        showConnectBle.value = true;
      })
      .catch((err) => {
        console.log('断开失败', err);
      });
  } else {
    console.log('连接: ', recentDevice.device.deviceId);
    selectDevice.value = recentDevice;
    showConnectBle.value = true;
  }
};
const onConnectDevice = async () => {
  await quickConnect(selectDevice.value.device.deviceId)
    .then((res) => {
      uni.showToast({
        title: '连接成功',
        icon: 'success'
      });
      store.commit('bt/setBleState', true);
      store.commit('bt/setBle', selectDevice.value.device);
      showConnectBle.value = false;
    })
    .catch((err) => {
      console.log(err);

      uni.showToast({
        title: '连接失败',
        icon: 'error'
      });
    });
};
const onConnectBleClose = () => {
  showConnectBle.value = false;
  selectDevice.value = {} as Model.RecentDevice;
  console.log('关闭弹框');
};
const onLongPress = (item: Model.RecentDevice) => {
  uni.showModal({
    title: '提示',
    content: '确定要删除吗？',
    success: (res) => {
      if (res.confirm) {
        console.log('用户点击确定');
        BleStorage.removeBle(item.device.deviceId);
      }
    }
  });
};
onShow(() => {
  store.commit('tab/setTab', 0);
  console.log('home onShow');

  fetchRecentlyList();
});

onShareAppMessage(() => {
  return {
    title: '合舜智能',
    path: '/pages/home/index'
  };
});
onShareTimeline(() => {
  return {
    title: '合舜智能',
    path: '/pages/home/index'
  };
})
</script>

<style lang="scss">
$page-fill-color: white;
$page-shadow-color: #f7f7f7;
.parent {
  height: 100vh;
  background-color: $page-fill-color;

  :deep(.van-nav-bar) {
    border-bottom: none; /* 去掉下边框 */
    box-shadow: none; /* 如果有阴影也需要移除 */
    background-color: $page-fill-color;
  }
  :deep(.van-nav-bar::after) {
    border-bottom: none; /* 针对一些可能的伪元素边框 */
  }
}
.recently-list {
  margin-top: 40rpx;
  background-color: $page-shadow-color;
  border-radius: 60rpx 60rpx 0 0;
  height: auto;
  height: 760rpx;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: column;
}
</style>
