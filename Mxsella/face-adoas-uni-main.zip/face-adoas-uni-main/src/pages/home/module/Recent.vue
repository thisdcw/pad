<template>
  <div class="Recent">
    <view v-for="(item, index) in props.recentlyList" :key="index">
      <view
        style="
          width: 676rpx;
          height: 180rpx;
          background-color: white;
          margin-top: 20rpx;
          border-radius: 36rpx;
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
        "
        @click="props.onConnect(item)"
      >
        <image
          src="https://gitee.com/thisdcw/static/raw/master/home_device_new.png"
          style="
            width: 180rpx;
            height: 100rpx;
            border-radius: 36rpx;
            margin-left: 20rpx;
          "
        />
        <text
          style="
            margin-right: 20rpx;
            color: #545454;
            font-size: 28rpx;
            font-weight: bold;
          "
          >{{ item.name }}</text
        >
      </view>
    </view>
  </div>
</template>

<script lang="ts" setup>
interface RecentProps {
  recentlyList: Model.RecentDevice[];
  onConnect: Function;
}
const props = withDefaults(defineProps<RecentProps>(), {
  recentlyList: [] as Model.RecentDevice[], // 显式声明类型
  onConnect: (item: Model.RecentDevice) => {}, // 保持不变
});
</script>

<style lang="scss"></style>
