<template>
  <div>
    <swiper
      autoplay="true"
      interval="3000"
      circular="true"
      indicator-dots="false"
      style="width: 670rpx; height: 400rpx"
    >
      <swiper-item>
        <div style="display: flex; justify-content: center">
          <image
            src="https://gitee.com/thisdcw/static/raw/master/carousel1.png"
            mode="scaleToFill"
            style="width: 670rpx; height: 400rpx; border-radius: 60rpx"
          />
        </div>
      </swiper-item>
      <swiper-item>
        <div style="display: flex; justify-content: center">
          <image
            src="https://gitee.com/thisdcw/static/raw/master/carousel2.png"
            mode="scaleToFill"
            style="width: 670rpx; height: 400rpx; border-radius: 60rpx"
          />
        </div>
      </swiper-item>
      <swiper-item>
        <div style="display: flex; justify-content: center">
          <image
            src="https://gitee.com/thisdcw/static/raw/master/carousel3.png"
            mode="scaleToFill"
            style="width: 670rpx; height: 400rpx; border-radius: 60rpx"
          />
        </div>
      </swiper-item>
    </swiper>
  </div>
</template>

<script lang="ts" setup>
const props = defineProps();
</script>

<style lang="scss"></style>
