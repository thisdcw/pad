<template>
  <view style="padding-left: 40rpx">
      <view style="font-size: 48rpx">合舜智能</view>
      <view
        style="
          color: #339efa;
          font-size: 24rpx;
          font-weight: bold;
          margin-top: 10rpx;
        "
        >{{ currentDate }}</view
      >
    </view>
</template>

<script lang="ts" setup>
  const props = defineProps();

  const currentDate = new Date().toDateString().split(' ').slice(1).join(' ');
</script>

<style lang="scss"></style>
