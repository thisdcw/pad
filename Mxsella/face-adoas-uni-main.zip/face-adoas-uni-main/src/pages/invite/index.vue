<template>
  <div>
    <!-- <basic-info-card
      :basicInfo="basicInfo"
      :saveOrUpdateUserInfo="saveOrUpdateUser"
    /> -->
  </div>
</template>

<script lang="ts" setup>
import { fetchUserInfo } from '@/service/user';
import { ref } from 'vue';

const saveOrUpdateUser = (info: Model.UserInfo) => {
  console.log('保存: ', info);
};
const basicInfo = ref(fetchUserInfo());
</script>

<style lang="scss"></style>
