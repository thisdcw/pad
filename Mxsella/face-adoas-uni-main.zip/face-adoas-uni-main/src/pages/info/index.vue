<template>
  <div class="info">
    <div
      style="
        font-size: 24rpx;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        padding: 20rpx 40rpx;
      "
    >
      <text style="color: #8e8e8e"> 账号信息 </text>
      <text style="color: #e62020" @click="toMemberPage"> 其他护理人> </text>
    </div>
    <account-info-card :info="accountInfo" />
    <div style="height: 20rpx; background-color: #f7f7f7"></div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import { fetchUserInfo } from '@/service/user';


const userInfo = fetchUserInfo();
const accountInfo = ref(userInfo as Model.AccountInfo);

const toMemberPage = () => {
  uni.navigateTo({
    url: '/pages/member/index'
  });
};
</script>

<style lang="scss">
.info {
  height: 100vh;
  width: 100vw;
  background-color: #f7f7f7;
}
</style>
