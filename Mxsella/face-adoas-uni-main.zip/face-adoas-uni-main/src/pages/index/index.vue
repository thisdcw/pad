<template>
  <view
    style="display: flex; flex-direction: column; background-color: #f7f7f7"
  >
    <view class="parent">
      <view class="bkg_card">
        <view
          style="
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            margin-right: 80rpx;
          "
        >
          <image
            :src="
              accountInfo.avatar ||
              'https://gitee.com/thisdcw/static/raw/master/device_icon.png'
            "
            style="width: 160rpx; height: 160rpx"
          ></image>
          <view
            style="display: flex; flex-direction: column; margin-left: 60rpx"
          >
            <text style="color: #3a3b3b; font-size: 36rpx; font-weight: bold">
              {{ accountInfo.nickname || '请先设置昵称' }}
            </text>
            <text style="color: #3f4141; font-size: 24rpx"></text>
          </view>
        </view>
      </view>
      <view
        style="
          width: 600rpx;
          height: 320rpx;
          position: absolute;
          background-color: white;
          top: 350rpx;
          border-radius: 36rpx;
          padding: 20rpx 40rpx;
        "
      >
        <view
          style="
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10rpx;
          "
        >
          <text style="font-size: 28rpx; font-weight: bold; color: #484848"
            >AI智能电子膜</text
          >
          <!-- <text
            style="color: #8d8d8d; font-size: 22rpx"
            @click="showMoreDevice = true"
            >我的更多设备 ></text
          > -->
        </view>
        <div style="border-radius: 24rpx">
          <carousel-card :record="trainRecord" />
        </div>
      </view>
    </view>
    <view
      style="
        margin-top: 270rpx;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      "
    >
      <view
        style="
          background-color: white;
          width: 640rpx;
          height: 150rpx;
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          border-radius: 24rpx;
        "
        @click="nav('/pages/info/index')"
      >
        <view
          style="
            margin-left: 40rpx;
            display: flex;
            flex-direction: row;
            align-items: center;
          "
        >
          <image
            src="https://gitee.com/thisdcw/static/raw/master/info_icon.png"
            class="item-img"
          ></image>
          <text class="item-text">我的资料</text>
        </view>

        <image
          src="https://gitee.com/thisdcw/static/raw/master/return.png"
          style="width: 40rpx; height: 40rpx; margin-right: 80rpx"
        ></image>
      </view>
      <view
        style="
          margin-top: 40rpx;
          background-color: white;
          width: 640rpx;
          height: 150rpx;
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          border-radius: 24rpx;
        "
        @click="nav('/pages/invite/index')"
      >
        <view
          style="
            margin-left: 40rpx;
            display: flex;
            flex-direction: row;
            align-items: center;
          "
        >
          <image
            src="https://gitee.com/thisdcw/static/raw/master/invite_icon.png"
            class="item-img"
          ></image>
          <text class="item-text">邀请好友</text>
        </view>

        <image
          src="https://gitee.com/thisdcw/static/raw/master/return.png"
          style="width: 40rpx; height: 40rpx; margin-right: 80rpx"
        ></image>
      </view>
      <view
        style="
          margin-top: 40rpx;
          margin-bottom: 400rpx;
          background-color: white;
          width: 640rpx;
          height: 150rpx;
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          border-radius: 24rpx;
        "
        @click="nav('/pages/problem/index')"
      >
        <view
          style="
            margin-left: 40rpx;
            display: flex;
            flex-direction: row;
            align-items: center;
          "
        >
          <image
            src="https://gitee.com/thisdcw/static/raw/master/problem_icon.png"
            class="item-img"
          ></image>
          <text class="item-text">常见问题</text>
        </view>

        <image
          src="https://gitee.com/thisdcw/static/raw/master/return.png"
          style="width: 40rpx; height: 40rpx; margin-right: 80rpx"
        ></image>
      </view>
    </view>
    <van-popup
      :show="showMoreDevice"
      z-index="99999"
      round
      lock-scroll
      close-on-click-overlay
    >
      <view
        style="
          overflow-y: auto;
          margin-left: 10rpx;
          margin-right: 10rpx;
          height: 500rpx;
        "
      >
        <view
          v-for="(item, index) in moreDevice"
          :key="index"
          style="
            width: 676rpx;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 150rpx;
            margin-top: 20rpx;
          "
        >
          <view
            style="
              display: flex;
              flex-direction: row;
              justify-content: space-between;
              align-items: center;
            "
          >
            <van-radio-group
              :value="radio"
              @change="onRadioChange"
              direction="horizontal"
              style="
                display: flex;
                flex-direction: row;
                justify-content: space-between;
              "
            >
              <view
                style="
                  display: flex;
                  flex-direction: row;
                  margin-left: 20rpx;
                  align-items: flex-start;
                  justify-content: space-between;
                  width: 560rpx;
                "
              >
                <image
                  :src="item.icon"
                  style="width: 200rpx; height: 138rpx"
                ></image>
                <view
                  style="
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    width: 360rpx;
                    height: 138rpx;
                  "
                >
                  <text style="color: #5b5b5b">{{ item.name }}</text>
                </view>
              </view>

              <van-radio :name="item.id" style="margin-top: 50rpx"></van-radio>
            </van-radio-group>
          </view>
          <view
            style="
              width: 100%;
              height: 1rpx;
              background-color: #cccccc;
              margin-top: 20rpx;
            "
          ></view>
        </view>
      </view>
      <view
        @click="showMoreDevice = false"
        style="
          height: 80rpx;
          background-color: white;
          display: flex;
          background-color: #2c97f4;
          color: white;
          align-items: center;
          justify-content: center;
        "
        >关闭</view
      >
    </van-popup>
    <!-- <ble-popup /> -->
  </view>
  <!-- 自定义 tabbar 底部导航栏 -->
  <custom-tabbar />
</template>

<script setup lang="ts">
import { onShow } from '@dcloudio/uni-app';
import { onMounted, ref } from 'vue';
import { deviceList } from '@/config/config';
import { useStore } from 'vuex';
import { trainDataList } from '@/mock/device';
import { fetchUserInfo } from '@/service/user';

const tabStore = useStore();
const radio = ref(0);

const nav = (path: string) => {
  if (path !== '/pages/problem/index') {
    uni.showModal({
      title: '提示',
      showCancel: false,
      content: '功能暂未开放!'
    });
    return;
  }
  uni.navigateTo({
    url: path
  });
};
const showMoreDevice = ref(false);
const moreDevice = ref(deviceList);
const trainRecord = ref(trainDataList[0]);

const userInfo = fetchUserInfo();
const accountInfo = ref(userInfo as Model.AccountInfo);

const onRadioChange = (event: any) => {
  console.log('event', event.detail);
  radio.value = event.detail;
  trainRecord.value = trainDataList[event.detail];
  showMoreDevice.value = false;
};

onMounted(() => {});

onShow(() => {
  accountInfo.value = fetchUserInfo();

  console.log(accountInfo.value);

  tabStore.commit('tab/setTab', 2);
  console.log('index onShow');
});
</script>

<style lang="scss" scoped>
$page-fill-color: #f7f7f7;
.bkg_card {
  width: 100vw;
  height: 500rpx;
  background: #e6916c;
  border-radius: 0 0 60rpx 60rpx;
  display: flex;
  align-items: center;
  justify-content: center;
}
.parent {
  background-color: $page-fill-color;
  display: flex;
  justify-content: center;
}
.content {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.logo {
  height: 200rpx;
  width: 200rpx;
  margin-top: 200rpx;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 50rpx;
}

.text-area {
  display: flex;
  justify-content: center;
}

.title {
  font-size: 36rpx;
  color: #8f8f94;
}
.item-img {
  width: 60rpx;
  height: 60rpx;
}
.item-text {
  margin-left: 40rpx;
  color: #565656;
  font-size: 32rpx;
  font-weight: bold;
}
</style>
