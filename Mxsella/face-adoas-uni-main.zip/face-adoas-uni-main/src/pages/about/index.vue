<template>
  <div class="about">
    <image
      src="https://gitee.com/thisdcw/static/raw/master/about_img.png"
      style="width: 304rpx; height: 200rpx; margin-top: 150rpx"
    >
    </image>
    <text style="margin-top: 20rpx; font-size: 32rpx; color: black;"
      >智能Face v1.0.0</text
    >

    <view
      style="width: 500rpx; margin-top: 60rpx; color: #a8a8a8; font-size: 32rpx"
    >
      <text>
        提供美胸,丰胸,护理等多项智能化,个性化胸部美化,养护方案,从个性化智能产品的体验到个人情绪,睡眠,运动,饮食,内衣穿戴等全方位大数据管理服务,让女性从内到外唤醒最美的自己!
      </text>
    </view>
  </div>
</template>

<script lang="ts" setup></script>

<style lang="scss">
.about {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
</style>
