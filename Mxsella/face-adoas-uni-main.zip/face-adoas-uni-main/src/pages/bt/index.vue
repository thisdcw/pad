<template>
  <div class="bt">
    <van-nav-bar
      left-arrow
      title="蓝牙连接"
      @click-left="onClickLeft"
      class="nav-left-text"
    />
    <div class="ble-container">
      <div
        style="
          width: 678rpx;
          height: 96rpx;
          margin-top: 24rpx;
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          background-color: white;
          border-radius: 10rpx;
        "
      >
        <text
          style="color: #000000; font-size: 32rpx; margin-left: 40rpx"
          @click="mockSend"
          >扫描蓝牙</text
        ><image
          src="https://gitee.com/thisdcw/static/raw/master/loading.png"
          style="height: 64rpx; width: 64rpx; margin-right: 40rpx"
          @click="scanBle"
        ></image>
      </div>

      <div
        style="
          background-color: white;
          margin-top: 16rpx;
          border-radius: 12rpx;
          height: 1250rpx;
          overflow-y: auto;
        "
      >
        <div v-for="(item, index) in bleList" :key="index">
          <div
            style="
              width: 678rpx;
              height: 96rpx;
              margin-top: 24rpx;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              align-items: center;
              background-color: white;
              border-radius: 10rpx;
            "
          >
            <div
              style="
                display: flex;
                flex-direction: row;
                justify-content: space-between;
                width: 100%;
                align-items: center;
                margin-top: 16rpx;
              "
            >
              <text
                style="color: #000000; font-size: 28rpx; margin-left: 40rpx"
                >{{ item.name }}</text
              ><text
                style="font-size: 28rpx; margin-right: 40rpx"
                @click="
                  bleState ? onDisconnectClick(item) : onConnectClick(item)
                "
                :class="[
                  connectBle.deviceId === item.deviceId
                    ? 'connect'
                    : 'disconnect'
                ]"
                >{{
                  connectBle.deviceId === item.deviceId ? '已连接' : '未连接'
                }}</text
              >
            </div>
            <view
              style="height: 1rpx; width: 678rpx; background-color: #d4d4d4"
            ></view>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, ref } from 'vue';
import * as Ble from '@/plugins/bluetooth';
import { receiveTask } from '@/plugins/command';
import { useStore } from 'vuex';
import { BleStorage } from '@/storage/ble';

const store = useStore();

const bleState = computed(() => store.getters['bt/getBleState']);

const bleList = ref([] as Model.Ble[]);

const connectBle = ref({} as Model.Ble);

const onConnectClick = (item: Model.Ble) => {
  uni.showModal({
    title: '提示',
    content: `是否连接蓝牙${item.name}`,
    success: (res) => {
      if (res.confirm) {
        Ble.connect(item.deviceId)
          .then((res) => {
            connectBle.value = item;
            store.commit('bt/setBleState', true);
            store.commit('bt/setBle', item);
            const ble = BleStorage.findBle(item.deviceId);
            if (!ble) {
              const storageBle = {} as Model.RecentDevice;
              storageBle.device = item;
              storageBle.icon = 'https://gitee.com/thisdcw/static/raw/master/home_device_item.png';
              storageBle.name = item.name;
              BleStorage.addBle(storageBle);
            }

            uni.showToast({
              title: '连接成功',
              icon: 'success'
            });
            uni.switchTab({
              url: '/pages/device/index'
            })
            console.log(res);
          })
          .catch((err) => {
            uni.showToast({
              title: '连接失败',
              icon: 'error'
            });
            console.log(err);
          });
      }
    }
  });
};
const onDisconnectClick = (item: Model.Ble) => {
  uni.showModal({
    title: '提示',
    content: `是否断开蓝牙${item.name}`,
    success: (res) => {
      if (res.confirm) {
        Ble.disconnect(item.deviceId)
          .then((res) => {
            store.commit('bt/setBleState', false);
            store.commit('bt/setBle', {} as Model.Ble);
          })
          .catch((err) => {
            uni.showToast({
              title: '断开失败',
              icon: 'error'
            });
          });
      }
    }
  });
};
const scanBle = () => {
  Ble.scan()
    .then((res: any) => {
      console.log(res);
      const devicesArray = Array.from(res.values()) as Model.Ble[];

      bleList.value = devicesArray;
      console.log('可用蓝牙: ', devicesArray);
    })
    .catch((err) => {
      console.log(err);
    });
};
const mockSend = () => {
  const hexString = '5AA50683550001005A';
  const callback = (byteArray: Uint8Array) => {
    const data = Array.from(byteArray)
      .map((byte) => byte.toString(16).padStart(2, '0'))
      .join(' ');
    console.log('处理后的值 => ', data);
  };
  receiveTask(hexString, callback);
};
const onClickLeft = () => {
  uni.navigateBack();
};
</script>

<style lang="scss">
.bt {
  height: 100vh;
  background-color: #f7f7f7;
}
.ble-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.connect {
  color: #499de9;
}
.disconnect {
  color: #aaaaaa;
}
</style>
