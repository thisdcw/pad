<template>
  <div class="problem">
    <van-cell-group>
      <van-cell title="关于我们" @click="nav('/pages/about/index')" is-link />
      <van-cell title="联系我们" @click="showContact = true" is-link />
    </van-cell-group>

    <van-popup
      :show="showContact"
      position="bottom"
      custom-style="height: 20%;"
      round
      @close="onClose"
    >
      <view
        style="
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          width: 100%;
          align-items: center;
          margin-top: 40rpx;
        "
      >
        <view style="margin-left: 40rpx; color: #4b4b4b">
          <text style="font-weight: bold; font-size: 28rpx"
            >客服微信号: {{ contact }}</text
          >
        </view>
        <view
          style="
            width: 200rpx;
            height: 60rpx;
            background-color: #1076da;
            border-radius: 24rpx;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 40rpx;
          "
           @click="copyContact"
        >
          <text style="font-size: 22rpx; color: white"
            >复制</text
          >
        </view>
      </view>
    </van-popup>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue';

const showContact = ref(false);
const contact = ref('ABCDEFGH');

const nav = (url: string) => {
  uni.navigateTo({
    url: url
  });
};
const copyContact = () => {
  uni.setClipboardData({
    data: contact.value,
    success: function () {
      uni.showToast({
        title: '复制成功',
        icon:'success'
      });
    }
  });
};
const onClose = () => {
  console.log('关闭');
  showContact.value = false;
};
</script>

<style lang="scss"></style>
