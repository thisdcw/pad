export class CommandBuilder {
    // 固定头码和尾码
    private static HEADER = 0xBB;
    private static FOOTER = 0x44;

    // 计算 CRC 校验码
    private static calculateCRC(cmd: number, data: number[]): number {
        let crc = cmd + data.length;
        for (let b of data) {
            crc += b;
        }
        return crc & 0xFF; // 保证 CRC 是 1 个字节
    }

    /**
     * 通用命令生成 (例如启动、停止、暂停)
     * @param cmd 命令码
     * @param data 数据
     * @returns 指令
     */
    public static buildGeneralCommand(cmd: number, data: number): string {
        const result: number[] = [
            this.HEADER,
            cmd,
            0x01,  // 数据长度
            data,
            0,     // CRC 占位
            this.FOOTER,
        ];
        result[4] = this.calculateCRC(cmd, [data]);
        return this.bytesToHex(result);
    }
    /**
     * 生成档位
     * @param grade 档位，范围 1-20
     * @returns 指令
     */
    private static getLevelFromGrade(grade: number): number {
        if (grade < 0 || grade > 20) {
            throw new Error("档数必须在 0 到 20 之间");
        }
        // const level = Math.floor((255 / 20) * (grade - 1)); // 每档占 12 的范围
        return grade;
    }

    /**
     * 模式命令生成 (例如肩颈模式、腰腹模式等)
     * @param cmd 命令码
     * @param mode 模式
     * @param level 档位
     * @returns 指令
     */
    public static buildModeCommand(cmd: number, mode: number, level: number): string {
        const gear = this.getLevelFromGrade(level);
        const result: number[] = [
            this.HEADER,
            cmd,
            0x02,  // 数据长度
            mode,
            gear,
            0,     // CRC 占位
            this.FOOTER,
        ];
        result[5] = this.calculateCRC(cmd, [mode, level]);
        return this.bytesToHex(result);
    }


    // 将 number[] 转换为十六进制字符串，方便查看
    public static bytesToHex(bytes: number[]): string {
        return bytes.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
    }
}
