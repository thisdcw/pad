/**
 * 生成身高数组
 * @param min 最小值
 * @param max 最大值
 * @param step 步长
 * @returns 身高数组
 */
export const generateHeightArray = (min: number, max: number, step: number = 1): number[] => {
    let arr: number[] = [];
    for (let i = min; i <= max; i += step) {
        arr.push(i);
    }
    return arr;
}

/**
 * 生成体重数组
 * @param min 最小值
 * @param max 最大值
 * @param step 步长
 * @returns 体重数组
 */
export const generateWeightArray = (min: number, max: number, step: number = 1): number[] => {
    let arr: number[] = [];
    for (let i = min; i <= max; i += step) {
        arr.push(i);
    }
    return arr;
}
