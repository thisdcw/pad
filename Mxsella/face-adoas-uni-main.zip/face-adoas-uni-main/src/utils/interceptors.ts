// 例外不用token的地址
const exceptionAddrArr = [
    "xxxxx"
];

/**
 * 请求拦截器:
 * 在这里实现的作用是将所有请求前判断用户是否授权获取用户信息
 * @param {*} config 
 */
export const requestInterceptor = (config: any) => {
    console.log("经过了请求拦截器", config.url);
    return new Promise((resolve, reject) => {
        if (!config.header.authorization && !isExceptionUrl(config.url)) {
            if (config.isDumpToPay) {
                console.log("直接解析");
                resolve(config);
            } else {
                console.log("token解析");
                const token = "test_token";
                const uid = "1111111";
                if (token && uid) {
                    config.header['X-Token'] = token;
                    config.header['uid'] = uid;
                    resolve(config);
                } else {
                    reject("No token or UID found.");
                }
            }
        } else {
            resolve(config);
        }
    });
}

// 响应拦截器
export const responseInterceptor = (response: any) => {
    console.log("经过响应拦截器");
    return new Promise((resolve, reject) => {
        // 处理响应结果
        if (response.data.code === 200) {
            resolve(response);
        } else {
            uni.showToast({
                title: response.data.message,
                icon: "error",
                duration: 2000
            });
            reject(response);
        }
    });
}

// 请求头处理函数
export function createHeader(method: string, isJSON: boolean) {
    let header = {} as any;
    if (method === 'POST' && !isJSON) {
        header['content-type'] = 'application/x-www-form-urlencoded';
    } else {
        header['content-type'] = 'application/json';
    }
    return header;
}
function isExceptionUrl(url: string) {
    return exceptionAddrArr.some(exception => url.endsWith(exception));
}
