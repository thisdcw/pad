import { requestInterceptor, responseInterceptor, createHeader } from './interceptors';

export const postRequest = async<T>(url: string, data: object, isJSON: boolean = false, success?: (res: Model.R<T>) => void, failed?: (err: any) => void): Promise<Model.R<T>> => {
    try {
        const res: Model.R<T> = await request({
            url: url,
            method: 'POST',
            isJSON: isJSON,
            data: data
        });
        success?.(res)
        return res;
    } catch (error) {
        failed?.(error);
        console.error(`Error with request to ${url}:`, error);
        return {} as Model.R<T>;
    }
}
export const getRequest = async <T>(url: string, data: object, isJSON: boolean = false, success?: (res: Model.R<T>) => void, failed?: (err: any) => void): Promise<Model.R<T>> => {
    try {
        const res: Model.R<T> = await request({
            url: url,
            method: 'GET',
            isJSON: isJSON,
            data: data
        });
        success?.(res)
        return res;
    } catch (error) {
        failed?.(error);
        console.error(`Error with request to ${url}:`, error);
        return {} as Model.R<T>;
    }
}
export const buildPageUrl = (base: string, current: number = 1, size: number = 10): string => `${base}/${current}/${size}`;

const request = (options: any): any => {
    return new Promise((resolve, reject) => {
        const config = {
            ...options,
            header: createHeader(options.method, options.isJSON)
        };
        requestInterceptor(config)
            .then((config: any) => {
                console.log(config);

                uni.request({
                    ...config,
                    success: (response: any) => {
                        responseInterceptor(response)
                            .then((res: any) => resolve(res.data))
                            .catch((err: any) => reject(err));
                    },
                    fail: (err: any) => {
                        reject(err);
                    }
                });
            })
            .catch((err: any) => reject(err));
    });
}
