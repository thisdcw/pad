/**
 * 格式化日期时间戳为'yyyy-MM-dd'格式
 * @param timestamp 时间戳
 * @returns 日期字符串
 */
export const formatTimestamp = (timestamp: number): string => {
    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
};
