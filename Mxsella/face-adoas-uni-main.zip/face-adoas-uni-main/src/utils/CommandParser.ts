export class CommandParser {
    static HEAD_CODE = 0xAA;
    static TAIL_CODE = 0x55;

    static parseCommand(buffer: Uint8Array) {
        if (buffer[0] !== CommandParser.HEAD_CODE || buffer[buffer.length - 1] !== CommandParser.TAIL_CODE) {
            throw new Error("Invalid head or tail code");
        }

        const cmd = buffer[1];
        const len = buffer[2];
        const data = buffer.slice(3, 3 + len);
        const crc = buffer[3 + len];

        const calculatedCrc = CommandParser.calculateCRC(cmd, len, data);
        console.log(crc, calculatedCrc);

        if (crc !== calculatedCrc) {
            throw new Error("Invalid CRC");
        }

        return { cmd, data };
    }

    static calculateCRC(cmd: number, len: number, data: Uint8Array) {
        let crc = cmd + len;
        for (let i = 0; i < data.length; i++) {
            crc += data[i];
        }
        return crc & 0xFF;
    }

    static processCommand(cmd: number, data: Uint8Array) {
        switch (cmd) {
            case 0x01: // 通用命令
                return CommandParser.processCommonCommand(data);
            case 0xA1: // 胸部模式
                return CommandParser.processModeCommand("Chest", data);
            case 0xA2: // 肩颈模式
                return CommandParser.processModeCommand("Shoulder", data);
            case 0xA3: // 腰腹模式
                return CommandParser.processModeCommand("Waist", data);
            case 0xA4: // 私密模式
                return CommandParser.processModeCommand("Private", data);
            case 0xA5: // 臀部模式
                return CommandParser.processModeCommand("Butt", data);
            default:
                throw new Error("Unknown command");
        }
    }

    static processCommonCommand(data: Uint8Array) {
        switch (data[0]) {
            case 0x00:
                return "Stop";
            case 0x01:
                return "Start";
            case 0x02:
                return "Pause";
            default:
                throw new Error("Unknown common command data");
        }
    }

    static processModeCommand(mode: string, data: Uint8Array) {
        const subMode = data[0];
        const level = data[1];
        if (subMode < 1 || subMode > 5) {
            throw new Error("Invalid sub-mode");
        }
        return { mode, subMode, level };
    }
}
