const BLE_CONSTANT = {
    BLE_LIST: 'ble_list',
    LAST_ID: 'ble_last_id'  // 用于存储最后一个ID的key
}

export const BleStorage = {
    // 获取存储中的蓝牙设备数组
    getBleList(): Model.RecentDevice[] {
        try {
            const bleList = uni.getStorageSync(BLE_CONSTANT.BLE_LIST);
            return bleList ? bleList as Model.RecentDevice[] : [];
        } catch (error) {
            console.error('获取蓝牙设备列表失败', error);
            return [];
        }
    },

    // 保存整个蓝牙设备数组
    saveBleList(bleList: Model.RecentDevice[]) {
        try {
            uni.setStorageSync(BLE_CONSTANT.BLE_LIST, bleList);
        } catch (error) {
            console.error('保存蓝牙设备列表失败', error);
        }
    },

    // 获取当前递增的ID
    getNextId(): number {
        const lastId = uni.getStorageSync(BLE_CONSTANT.LAST_ID) || 0;
        const nextId = lastId + 1;
        uni.setStorageSync(BLE_CONSTANT.LAST_ID, nextId);
        return nextId;
    },

    // 增加蓝牙设备，设置递增的ID
    addBle(ble: Model.RecentDevice) {
        try {
            const bleList = this.getBleList();
            ble.id = this.getNextId();  // 设置递增ID
            bleList.push(ble);
            this.saveBleList(bleList);
        } catch (error) {
            console.error('添加蓝牙设备失败', error);
        }
    },

    // 删除蓝牙设备（根据 deviceId）
    removeBle(deviceId: string) {
        try {
            let bleList = this.getBleList();
            bleList = bleList.filter(device => device.device.deviceId !== deviceId);
            this.saveBleList(bleList);
        } catch (error) {
            console.error('删除蓝牙设备失败', error);
        }
    },

    // 更新蓝牙设备信息（根据 deviceId）
    updateBle(updatedBle: Model.RecentDevice) {
        try {
            let bleList = this.getBleList();
            const index = bleList.findIndex(device => device.device.deviceId === updatedBle.device.deviceId);
            if (index !== -1) {
                bleList[index] = updatedBle;
                this.saveBleList(bleList);
            } else {
                console.error('未找到需要更新的设备');
            }
        } catch (error) {
            console.error('更新蓝牙设备失败', error);
        }
    },

    // 查找蓝牙设备（根据 deviceId）
    findBle(deviceId: string): Model.RecentDevice | null {
        try {
            const bleList = this.getBleList();
            return bleList.find(device => device.device.deviceId === deviceId) || null;
        } catch (error) {
            console.error('查找蓝牙设备失败', error);
            return null;
        }
    }
}
