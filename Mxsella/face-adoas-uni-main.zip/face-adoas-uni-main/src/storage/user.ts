const userConstant = {
    INFO: 'user_info'
}
export const userStorage = {
    saveUser: (info: Model.AccountInfo) => {
        uni.setStorageSync(userConstant.INFO, JSON.stringify(info))
    },
    getUser: (): Model.AccountInfo => {
        const userData = uni.getStorageSync(userConstant.INFO);
        return userData ? JSON.parse(userData) : {
            uid: "",
            avatar: "",
            nickname: "",
            phone: "",
            remark: "",
        };
    }
    
}
