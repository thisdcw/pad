const MEMBER_CONSTANT = {
    MEMBER_LIST: 'member_list',
    LAST_ID: 'last_id'
}

export const MemberStorage = {
    // 获取存储中的成员列表
    getMemberList(): Model.Member[] {
        try {
            const memberList = uni.getStorageSync(MEMBER_CONSTANT.MEMBER_LIST);
            return memberList ? memberList as Model.Member[] : [];
        } catch (error) {
            console.error('获取成员列表失败', error);
            return [];
        }
    },

    // 保存整个成员列表
    saveMemberList(memberList: Model.Member[]) {
        try {
            uni.setStorageSync(MEMBER_CONSTANT.MEMBER_LIST, memberList);
        } catch (error) {
            console.error('保存成员列表失败', error);
        }
    },

    // 增加成员
    addMember(member: Model.Member) {
        try {
            const memberList = this.getMemberList();
            member.id = this.getNextId();
            memberList.push(member);
            this.saveMemberList(memberList);
        } catch (error) {
            console.error('添加成员失败', error);
        }
    },
    // 获取当前递增的ID
    getNextId(): number {
        const lastId = uni.getStorageSync(MEMBER_CONSTANT.LAST_ID) || 0;
        const nextId = lastId + 1;
        uni.setStorageSync(MEMBER_CONSTANT.LAST_ID, nextId);
        return nextId;
    },
    // 删除成员（根据 ID）
    removeMember(memberId: number) {
        try {
            let memberList = this.getMemberList();
            memberList = memberList.filter(member => member.id !== memberId);
            this.saveMemberList(memberList);
        } catch (error) {
            console.error('删除成员失败', error);
        }
    },

    // 更新成员信息（根据 ID）
    updateMember(updatedMember: Model.Member) {
        try {
            let memberList = this.getMemberList();
            const index = memberList.findIndex(member => member.id === updatedMember.id);
            if (index !== -1) {
                memberList[index] = updatedMember;
                this.saveMemberList(memberList);
            } else {
                console.error('未找到需要更新的成员');
            }
        } catch (error) {
            console.error('更新成员失败', error);
        }
    },

    // 查找成员（根据 ID）
    findMember(memberId: number): Model.Member | null {
        try {
            const memberList = this.getMemberList();
            return memberList.find(member => member.id === memberId) || null;
        } catch (error) {
            console.error('查找成员失败', error);
            return null;
        }
    }
}
