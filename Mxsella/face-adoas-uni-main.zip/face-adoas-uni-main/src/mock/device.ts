export const trainData = {
    today: 20 * 60,
    total: 428 * 60,
    days: 3,
    part: '腰腹',
    mode: '深度模式'
}

export const trainDataList = [
    {
        today: 20 * 60,
        total: 428 * 60,
        days: 3,
        part: '腰腹',
        mode: '深度模式'
    }, {
        today: 10 * 60,
        total: 528 * 60,
        days: 6,
        part: '肩颈',
        mode: '深度模式'
    }, {
        today: 40 * 60,
        total: 228 * 60,
        days: 2,
        part: '臀部',
        mode: '深度模式'
    }
]
