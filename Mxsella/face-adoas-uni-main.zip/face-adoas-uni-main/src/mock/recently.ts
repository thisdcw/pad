const recentlyList = [
    {
        id: 0,
        name: '智能Face机器人',
        icon: 'https://gitee.com/thisdcw/static/raw/master/home_device_item.png',
        device: {
            RSSI: -55,
            advertisServiceUUIDs: [],
            deviceId: 'FF-EE-DD-CC-BB-AA',
            localName: '测试',
            name: '测试名',
        }
    },
    {
        id: 1,
        name: '智能chest机器人',
        icon: 'https://gitee.com/thisdcw/static/raw/master/home_device_item.png',
        device: {
            RSSI: -65,
            advertisServiceUUIDs: [],
            deviceId: 'AA-BB-CC-DD-EE-FF',
            localName: '测试二',
            name: '测试名二',
        }
    }
]

export const getRecentDevice = (): Model.RecentDevice[] => {
    return recentlyList
}
