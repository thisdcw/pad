
export const userInfo = {
    uid: 0,
    avatar: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
    nickname: '小红',
    phone: '12345678910',
    remark: '个人简介',
    username: '李红',
    gender: 0,
    birth: '2000-08-27',
    address: '广东省 广州市 天河区',
    height: '160cm',
    weight: '55kg',
    waist: '腰围',
    bust: '胸围',
    hip: '臀围',
    cup: '28A',
    hobby: '爱好'
}

export const memberList = [
    {
        id: 0,
        username: '李红',
        gender: 0,
        birth: '2002-08-27',
        address: '广东省 广州市 海珠区',
        height: '160cm',
        weight: '45kg',
        waist: '腰围',
        bust: '胸围',
        hip: '臀围',
        cup: '28A',
        hobby: '爱好',
        isDelete: 0
    },
    {
        id: 1,
        username: '王五',
        gender: 1,
        birth: '2001-08-27',
        address: '广东省 广州市 天河区',
        height: '165cm',
        weight: '50kg',
        waist: '腰围',
        bust: '胸围',
        hip: '臀围',
        cup: '28A',
        hobby: '爱好',
        isDelete: 0
    },
    {
        id: 2,
        username: '小丽',
        gender: 0,
        birth: '2024-8-27',
        address: '广东省 广州市 白云区',
        height: '170cm',
        weight: '45kg',
        waist: '腰围',
        bust: '胸围',
        hip: '臀围',
        cup: '28A',
        hobby: '爱好',
        isDelete: 0
    }
]
