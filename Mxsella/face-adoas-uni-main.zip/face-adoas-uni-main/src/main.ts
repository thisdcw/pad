import { createSSRApp } from "vue";
import App from "./App.vue";
import customTabbar from "./custom-tab-bar/index.vue"
import basicInfoCard from './components/BasicInfoCard/index.vue'
import addMemberCard from './components/AddMemberCard/index.vue'
import accountInfoCard from './components/AccountInfoCard/index.vue'
import carouselCard from './components/CarouselCard/index.vue'
import BlePopup from "./components/BlePopup/index.vue"
import store from "./store/index"
export function createApp() {
  const app = createSSRApp(App);
  app.use(store)
  app.component('custom-tabbar', customTabbar)
  app.component('basic-info-card', basicInfoCard)
  app.component('account-info-card', accountInfoCard)
  app.component('add-member-card', addMemberCard)
  app.component('carousel-card', carouselCard)
  app.component('ble-popup', BlePopup)
  return {
    app,
  };
}
