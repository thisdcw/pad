const state = {
    connectState: false,
    ble: {
        RSSI: -54,
        advertisServiceUUIDs:[],
        deviceId: "test deviceId",
        localName: "test localName",
        name: "test name",
    } as Model.Ble
}

const mutations = {
    setBleState(state: any, connect: boolean) {
        state.connectState = connect
    },
    setBle(state: any, ble: Model.Ble) {
        state.ble = ble
    }
}

const actions = {
    setBleState({ commit }: any, state: boolean) {
        commit('setBleState', state)
    },
    setBle({ commit }: any, ble: Model.Ble) {
        commit('setBle', ble)
    }
}
const getters = {
    getBleState(state: any) {
        return state.connectState
    },
    getBle(state: any) {
        return state.ble
    }
}


export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters
}
