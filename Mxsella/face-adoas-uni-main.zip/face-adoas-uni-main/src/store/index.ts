import { createStore } from 'vuex'
import tab from './tab'
import bt from './bt'
import work from './work'
import page from './page'
export default createStore({
    modules: {
        tab,
        bt,
        work,
        page
    }
})
