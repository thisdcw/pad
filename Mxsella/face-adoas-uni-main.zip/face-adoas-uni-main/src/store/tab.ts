const state = {
    tab: 0
}
const mutations = {
    setTab(state:any, tab:number) {
        state.tab = tab
    }
}

const actions = {
    setTab({ commit }:any, tab:number) {
        commit('setTab', tab)
    }
}
const getters = {
    getTab(state:any) {
        return state.tab
    }
}

export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters
}
