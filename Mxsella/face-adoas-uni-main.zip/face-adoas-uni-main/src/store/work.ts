const state = {
    isReady: false,
    selectItem: 0,
}


const mutations = {
    setReady(state: any, ready: boolean) {
        state.isReady = ready
    },
    setSelectItem(state: any, selectItem: number) {
        state.selectItem = selectItem
    }
}
const actions = {
    setReady({ commit }: any, ready: boolean) {
        commit('setReady', ready)
    },
    setSelectItem({ commit }: any, selectItem: number) {
        commit('setSelectItem', selectItem)
    }
}
const getters = {
    getReady(state: any) {
        return state.isReady
    },
    getSelectItem(state: any) {
        return state.selectItem
    }
}
export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters
}
