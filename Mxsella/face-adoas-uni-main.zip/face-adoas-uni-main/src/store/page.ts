const state = {
    showBlePage: false
}
const mutations = {
    showBlePage(state: any, show: boolean) {
        state.showBlePage = show
    }
}

const actions = {
    showBlePage({ commit }: any, show: boolean) {
        commit('showBlePage', show)
    }
}
const getters = {
    isShowBlePage(state: any) {
        return state.showBlePage
    }
}

export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters
}
