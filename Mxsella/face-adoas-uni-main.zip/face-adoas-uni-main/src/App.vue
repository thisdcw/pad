<script setup lang="ts">
import { onShow, onHide, onLaunch, onUnload } from '@dcloudio/uni-app';
import { onMounted, onUnmounted, ref } from 'vue';
import { useStore } from 'vuex';
import { BleStorage } from './storage/ble';
import { connect, sendData } from './plugins/bluetooth';
import { eventBus } from './event/eventBus';
import { utils } from './plugins/protocol';
import { ble } from './config/config';

const store = useStore();

let intervalId: NodeJS.Timeout | null = null;

const isBluetoothEnabled = ref(false);
const isConnected = ref(false);
const deviceId = ref('');
const sendTimeout = ref(1000 * 60);
let connectCount = ref(0);

// 监听蓝牙适配器状态变化
const onBluetoothAdapterStateChange = (res: any) => {
  console.log('蓝牙适配器状态变化', res);
  isBluetoothEnabled.value = res.available;
};

const send = async () => {
  await sendData('BBAACCDDFFEE44', deviceId.value)
    .then((res) => {})
    .catch((err) => {});
};

eventBus.on('resetSend', (reset) => {
  if (reset) {
    // 重置发送
    resetSendTask();
  }
});
// 重置定时任务
const resetSendTask = () => {
  if (intervalId) {
    clearInterval(intervalId); // 清除当前定时器
    intervalId = null; // 重置 intervalId
  }

  // 重新设置定时器
  intervalId = setInterval(() => {
    send(); // 调用发送数据的方法
  }, sendTimeout.value);
};

// 监听事件总线的重置发送事件
eventBus.on('resetSend', (reset) => {
  console.log('重置发送定时任务');
  resetSendTask(); // 调用重置定时任务的方法
});

const onReConnect = (deviceId: string) => {
  console.log('重新连接蓝牙: ', deviceId);
  console.log('重连次数: ', connectCount.value);

  //TODO 重新连接
  connect(deviceId)
    .then(() => {})
    .catch(() => {
      if(connectCount.value >= 2){
        uni.showToast({
        title: `第${connectCount.value + 1}次重连失败`,
        icon: 'error'
      });
      }
    });
};
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// 监听蓝牙连接状态变化
const onBluetoothConnectionStateChange = (res: any) => {
  console.log('蓝牙连接状态变化', res);
  isConnected.value = res.connected;
  if (res.connected) {
    connectCount.value = 0;
    store.commit('bt/setBleState', true);
    const device = BleStorage.findBle(res.deviceId)?.device;
    store.commit('bt/setBle', device);
    deviceId.value = res.deviceId;
    resetSendTask();
  } else {
    while (connectCount.value < 3) {
      onReConnect(res.deviceId);
      connectCount.value++;
      delay(1 * 1000);
    }
    if (connectCount.value >= 3) {
      connectCount.value = 0;
      store.commit('bt/setBleState', false);
      store.commit('bt/setBle', {} as Model.Ble);
      deviceId.value = '';
      if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
      }
    }
  }
};

onLaunch(() => {
  console.log('APP加载');

  // 注册全局蓝牙适配器状态变化监听
  uni.onBluetoothAdapterStateChange(onBluetoothAdapterStateChange);

  // 注册全局蓝牙连接状态变化监听
  uni.onBLEConnectionStateChange(onBluetoothConnectionStateChange);
});

onUnload(() => {
  //   // 取消全局蓝牙适配器状态变化监听
  // uni.offBluetoothAdapterStateChange(onBluetoothAdapterStateChange);
  //   // 取消全局蓝牙连接状态变化监听
  // uni.offBLEConnectionStateChange(onBluetoothConnectionStateChange);
});
onShow(() => {});

// onHide(() => {
//   // 取消全局蓝牙适配器状态变化监听
//   uni.offBluetoothAdapterStateChange(onBluetoothAdapterStateChange);

//   // 取消全局蓝牙连接状态变化监听
//   uni.offBLEConnectionStateChange(onBluetoothConnectionStateChange);
// });
</script>
