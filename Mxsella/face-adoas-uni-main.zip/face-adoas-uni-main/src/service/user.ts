import { userInfo, memberList } from '@/mock/user'
import { userStorage } from '@/storage/user';
export const fetchUserInfo = () => {
    return userStorage.getUser();
}

export const updateUserInfo = (info: any) => {
    //更新用户信息
    userStorage.saveUser(info);
}

export const fetchMemberList = () => {
    return memberList;
}
