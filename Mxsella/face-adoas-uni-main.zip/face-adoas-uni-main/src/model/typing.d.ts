declare namespace Model {

    type R<T> = {
        code: number,
        msg: string,
        data: T
    };
    type Page<T> = {
        total: number,
        size: number,
        current: number,
        pages: number,
        records: T[]
    };
    type AccountInfo = {
        uid: number,
        avatar: string,
        nickname: string,
        phone: string,
        remark: string,
    }
    type BasicInfo = {
        username: string,
        gender: number,
        birth: string,
        address: string,
        height: string,
        weight: string,
        waist: string,
        bust: string,
        hip: string,
        cup: string,
        hobby: string
    }
    type UserInfo = AccountInfo & BasicInfo;

    type Member = {
        id: number,
        username: string,
        gender: number,
        birth: string,
        address: string,
        height: string,
        weight: string,
        waist: string,
        bust: string,
        hip: string,
        cup: string,
        hobby: string
        isDeleted: number,
    }
    type Ble = {
        RSSI: number,
        advertisServiceUUIDs: string[],
        deviceId: string,
        localName: string,
        name: string,
    }
    type RecentDevice = {
        id: number,
        name: string,
        icon: string,
        device: Ble
    }
    type TrainRecord = {
        today: number,
        total: number,
        days: number,
        part: string,
        mode: string
    }
    type TrainItem = {
        id: number,
        part: string,
        selectIcon: string,
        unselectIcon: string,
        icon: string,
        gender: number
    }
}
