<template>
  <view class="container">
    <view
      class="tabbar-item"
      :class="[item.centerItem ? ' center-item' : '']"
      :style="'width: calc(100% /' + tabbarList.length + ')'"
      v-for="(item, i) in tabbarList"
      :key="i"
    >
      <view class="item-top">
        <image
          v-if="!item.centerItem"
          class="tabbar-image"
          :src="selectTab === item.id ? item.selectedIconPath : item.iconPath"
        />
        <view
          v-if="item.centerItem"
          :class="[item.centerItem ? 'cus-center' : '']"
           @click="changeItem(item)"
        >
          {{ bleConnect ? '开启护理' : '连接设备' }}
        </view>
      </view>
      <view class="item-bottom">
        <text :class="selectTab === item.id ? 'item-active' : ''">
          {{ item.text }}
        </text>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { computed, ref } from 'vue';
import { useStore } from 'vuex';

const store = useStore();

const selectTab = computed(() => store.getters['tab/getTab']);
const bleConnect = computed(() => {
  return store.getters['bt/getBleState'];
});
const isReadyWork = computed(() => store.getters['work/getReady']);

const showBlePopup = ref(true);

const onClose = () => {
  console.log('关闭');
  showBlePopup.value = false;
};
const tabbarList = [
  // {
  //   id: 0,
  //   pagePath: '/pages/home/index',
  //   iconPath: '../static/home.png',
  //   selectedIconPath: '../static/home_select.png',
  //   text: '首页',
  //   centerItem: false
  // },
  {
    id: 1,
    pagePath: '/pages/device/index',
    iconPath: '../static/start.png',
    selectedIconPath: '../static/stop.png',
    text: '',
    centerItem: true
  },
  // {
  //   id: 2,
  //   pagePath: '/pages/index/index',
  //   iconPath: '../static/index.png',
  //   selectedIconPath: '../static/index_select.png',
  //   text: '我的',
  //   centerItem: false
  // }
];
//切换tab
const changeItem = (item: any) => {
  if (item.centerItem) {
    console.log(`蓝牙连接状态: ${bleConnect.value}`);
    if (bleConnect.value) {
      console.log('蓝牙连接,跳转工作页');
      if (isReadyWork.value) {
        uni.navigateTo({
          url: '/pages/work/index'
        });
      } else {
        uni.switchTab({
          url: item.pagePath
        });
      }
    } else {
      store.commit('page/showBlePage', true);
      const ble = computed(() => store.getters['page/isShowBlePage']);
      console.log(ble.value);
      //TODO 优化连接页面(上弹框蓝牙连接注释掉下面行)
      uni.navigateTo({
        url: '/pages/bt/index'
      });
    }
    return;
  }
  store.commit('work/setReady', false);
  uni.switchTab({
    url: item.pagePath
  });
};
</script>

<style lang="scss" scoped>
$textDefaultColor: #999; // 文字默认颜色
$bottomBg: #fff; // 底部背景
$textSelectedColor: #086cd1; // 文字选中颜色
$centerItemBg: #F5E7E1; // 中间凸起按钮背景
.container {
  position: fixed;
  bottom: 0;
  left: 0;
  display: flex;
  align-items: center;
  width: 100%;
  height: 160rpx;
  color: $textDefaultColor;
  padding: 5rpx 0;
  background-color: #F7F7F7;
}
.tabbar-item {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  height: 100rpx;
  .item-top {
    flex-shrink: 0;
    width: 65rpx;
    height: 65rpx;
    padding: 4rpx;
    .tabbar-image {
      width: 100%;
      height: 100%;
    }
  }
  .item-bottom {
    width: 100%;
    font-size: 28rpx;
  }
  .item-active {
    color: $textSelectedColor;
  }
}
.center-item {
  position: relative;
  .item-top {
    position: absolute;
    top: -160rpx;
    left: 50%;
    transform: translateX(-50%);
    width: 256rpx;
    height: 256rpx;
    background-color: $centerItemBg;
    border-radius: 50%;
  }
  .item-bottom {
    position: absolute;
    bottom: 5rpx;
  }
}
.cus-center {
  width: 200rpx;
  height: 200rpx;
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  border-radius: 270rpx;
  background-color: #FE6B2B;
}
</style>
