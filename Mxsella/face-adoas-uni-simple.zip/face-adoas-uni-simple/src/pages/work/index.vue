<template>
  <div class="work">
    <van-nav-bar
      left-arrow
      :left-text="`已连接${ble.deviceId}`"
      class="nav-left-text"
      @click-left="onClickLeft"
    />
    <view
      style="
        width: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      "
    >
      <view
        style="
          width: 676rpx;
          height: 220rpx;
          background-color: #F4F4F4;
          border-radius: 36rpx;
          margin-top: 20rpx;
        "
      >
        <view
          style="
            display: flex;
            justify-content: space-between;
            flex-direction: row;
            margin-top: 20rpx;
            margin-left: 30rpx;
            margin-right: 30rpx;
            color: #505455;
          "
        >
          <text style="font-size: 28rpx; font-weight: bold"
            >设备: AI 智能电子膜</text
          >
          <view
            style="display: flex; flex-direction: column; align-items: center"
          >
            <text style="font-size: 20rpx">电量: {{ battery }}</text>
            <text v-show="false" style="font-size: 20rpx"
              >发送: {{ sendCommand }}</text
            >
            <text v-show="false" style="font-size: 20rpx"
              >接收:{{ receiveData }}</text
            >
          </view>
        </view>
        <view
          style="
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-around;
            margin-top: 26rpx;
          "
        >
          <view style="margin-left: 60rpx">
            <image
              src="https://gitee.com/thisdcw/static/raw/master/new_plus.png"
              style="width: 102rpx; height: 102rpx"
              @click="plusPower"
            />
          </view>
          <view
            style="display: flex; align-items: center; justify-content: center"
          >
            <text
              style="font-size: 80rpx; color: #FF7A40; font-weight: bolder"
              >{{ power }}</text
            >
          </view>
          <view style="margin-right: 60rpx"
            ><image
              src="https://gitee.com/thisdcw/static/raw/master/new_minus.png"
              style="width: 102rpx; height: 102rpx"
              @click="minusPower"
          /></view>
        </view>
      </view>
      <view
        style="
          width: 676rpx;
          height: 80rpx;
          margin-top: 20rpx;
          border-radius: 64rpx;
          background-color: #FF7A40;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 32rpx;
          font-weight: bold;
        "
      >
        <text style="margin-right: 12rpx">倒计时</text>
        {{ formatTime(times) }}
      </view>
      <view>
        <!-- {{ errorMsg }} -->
      </view>
      <view style="margin-top: 30rpx; width: 422rpx; height: 422rpx">
        <image
          :src="workIcon[item]"
          style="width: 100%; height: 100%; object-fit: contain"
        ></image>

        <video
          v-show="false"
          ref="workVideo"
          id="workVideo"
          :src="workVideo[item]"
          :controls="false"
          autoplay="true"
          loop="true"
          muted="true"
          :poster="workIcon[item]"
          style="object-fit: fill; width: 422rpx; height: 422rpx"
        ></video>
      </view>
      <view class="text-carousel">
        <view class="text-wrapper">
          <text class="carousel-text">
            为了你的护理过程可以顺利进行,请保持手机常亮并将小程序保持常驻前台
          </text>
          <!-- 再复制一份文字，用于无缝衔接 -->
          <text class="carousel-text">
            为了你的护理过程可以顺利进行,请保持手机常亮并将小程序保持常驻前台
          </text>
        </view>
      </view>
      <view style="display: flex; flex-direction: row; margin-top: 40rpx">
        <view
          v-show="false"
          v-for="(item, index) in workItemList"
          :key="index"
          style="margin-right: 20rpx"
          @click="changeItem(index, item)"
        >
          <view style="position: relative; display: inline-block">
            <image
              :src="selectItem === index ? item.selectIcon : item.unselectIcon"
              style="width: 120rpx; height: 120rpx"
            ></image>
            <view
              style="
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 120rpx;
                height: 120rpx;
                display: flex;
                align-items: flex-end;
                justify-content: center;
              "
            >
              <text
                style="font-size: 26rpx; margin-bottom: 6rpx"
                :class="selectItem === index ? 'select-item' : 'unselect-item'"
                >{{ item.name }}</text
              >
            </view>
          </view>
        </view>
      </view>
      <view v-if="!isPause" style="margin-top: 26rpx" @click="startOnclick">
        <view
          style="
            width: 232rpx;
            height: 232rpx;
            background-color: #e9f3fc;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
          "
        >
          <view
            style="
              width: 190rpx;
              height: 190rpx;
              border-radius: 50%;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              text-align: center;
            "
            :style="
              isStart
                ? 'background-color: #EC5E13;'
                : 'background-color: #EC5E13;'
            "
          >
            <image
              :src="
                isStart
                  ? 'https://gitee.com/thisdcw/static/raw/master/pause.png'
                  : 'https://gitee.com/thisdcw/static/raw/master/start.png'
              "
              style="height: 100rpx; width: 100rpx"
            ></image>
            <text style="color: white; font-size: 28rpx">{{
              isStart ? '暂停' : '开始'
            }}</text>
          </view>
        </view>
      </view>
      <view
        v-if="isPause"
        style="
          margin-top: 26rpx;
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          height: 232rpx;
        "
      >
        <view
          style="
            width: 176rpx;
            height: 176rpx;
            background-color: #e9f3fc;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
          "
          @click="continueOnClick"
        >
          <view
            style="
              width: 136rpx;
              height: 136rpx;
              background-color: #EC5E13;
              border-radius: 50%;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
            "
          >
            <image
              src="https://gitee.com/thisdcw/static/raw/master/start.png"
              style="width: 60rpx; height: 60rpx"
            ></image>
            <text style="color: white; font-size: 26rpx">继续</text>
          </view>
        </view>
        <view
          style="
            margin-left: 42rpx;
            width: 176rpx;
            height: 176rpx;
            background-color: #e9f3fc;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
          "
          @click="stopOnClick"
        >
          <view
            style="
              width: 136rpx;
              height: 136rpx;
              background: linear-gradient(to right, #f1941e, #e40001);
              border-radius: 50%;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
            "
          >
            <image
              src="https://gitee.com/thisdcw/static/raw/master/stop.png"
              style="width: 60rpx; height: 60rpx"
            ></image>
            <text style="color: white; font-size: 26rpx">结束</text>
          </view>
        </view>
      </view>
      <!-- <view
        style="
          margin-top: 20rpx;
          width: 460rpx;
          height: 110rpx;
          border: #339ffa 2rpx solid;
          border-radius: 60rpx;
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
        "
      >
        <image
          src="https://gitee.com/thisdcw/static/raw/master/pre.png"
          style="height: 48rpx; width: 48rpx; margin-left: 80rpx"
          @click="preMusic"
        ></image>
        <image
          :src="
            stopMusic
              ? 'https://gitee.com/thisdcw/static/raw/master/no_music.png'
              : 'https://gitee.com/thisdcw/static/raw/master/music.png'
          "
          style="height: 104rpx; width: 104rpx"
          @click="stopMusicOnclick"
        ></image>
        <image
          src="https://gitee.com/thisdcw/static/raw/master/next.png"
          style="height: 48rpx; width: 48rpx; margin-right: 80rpx"
          @click="nextMusic"
        ></image>
      </view> -->
    </view>
    <van-popup
      :close-on-click-overlay="false"
      :show="showDisconnected"
      round
      @close="showDisconnected = false"
    >
      <div
        style="
          width: 678rpx;
          height: 700rpx;
          display: flex;
          flex-direction: column;
          align-items: center;
        "
      >
        <div style="">
          <image
            src="https://gitee.com/thisdcw/static/raw/master/device_disconnect.png"
            mode="scaleToFill"
            style="width: 360rpx; height: 320rpx; margin-top: 80rpx"
          />
        </div>
        <div
          style="
            margin-top: 40rpx;
            margin-left: 40rpx;
            margin-right: 40rpx;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #696969;
          "
        >
          <text>系统检测到设备断开连接,请确保主机电量充足并处于开机状态</text>
        </div>
        <div
          style="
            display: flex;
            flex-direction: row;
            width: 100%;
            margin-top: 40rpx;
            justify-content: space-around;
          "
        >
          <div
            style="
              width: 262rpx;
              height: 108rpx;
              background-color: #d3e7f8;
              display: flex;
              align-items: center;
              justify-content: center;
              border-radius: 12rpx;
              color: #696969;
            "
            @click="onCancelConnect"
          >
            取消连接
          </div>
          <div
            style="
              width: 262rpx;
              height: 108rpx;
              background-color: #1c84e5;
              display: flex;
              align-items: center;
              justify-content: center;
              border-radius: 12rpx;
              color: white;
            "
            @click="onReConnect"
          >
            重新连接
          </div>
        </div>
      </div>
    </van-popup>
    <van-popup
      :close-on-click-overlay="false"
      :show="showBackDialog"
      round
      @close="showBackDialog = false"
    >
      <div
        style="
          width: 678rpx;
          height: 400rpx;
          display: flex;
          flex-direction: column;
          align-items: center;
        "
      >
        <div style="margin-top: 40rpx">
          <text style="color: black; font-weight: bold">提示</text>
        </div>
        <div
          style="
            margin-top: 40rpx;
            margin-left: 40rpx;
            margin-right: 40rpx;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #696969;
          "
        >
          <text>当前正在护理中,是否要断开连接呢?</text>
        </div>
        <div
          style="
            display: flex;
            flex-direction: row;
            width: 100%;
            margin-top: 40rpx;
            justify-content: space-around;
          "
        >
          <div
            style="
              width: 262rpx;
              height: 108rpx;
              background-color: #d3e7f8;
              display: flex;
              align-items: center;
              justify-content: center;
              border-radius: 12rpx;
              color: #696969;
            "
            @click="onBackCancel"
          >
            不了
          </div>
          <div
            style="
              width: 262rpx;
              height: 108rpx;
              background-color: #1c84e5;
              display: flex;
              align-items: center;
              justify-content: center;
              border-radius: 12rpx;
              color: white;
            "
            @click="onBackConfirm"
          >
            断开
          </div>
        </div>
      </div>
    </van-popup>
  </div>
</template>

<script lang="ts" setup>
import { onHide, onLoad, onShow, onUnload } from '@dcloudio/uni-app';
import { computed, nextTick, ref, watch } from 'vue';
import { useStore } from 'vuex';
import CountdownTimer from '@/plugins/CountdownTimer';
import { workList, workIcon, workVideo } from '@/config/config';
import { connect, quickConnect, sendData } from '@/plugins/bluetooth';
import { CommandBuilder } from '@/utils/CommandBuilder';
import { CommandParser } from '@/utils/CommandParser';
import { command, mode, position, protocol, utils } from '@/plugins/protocol';
import { eventBus } from '@/event/eventBus';

const store = useStore();
const ble = computed(() => store.getters['bt/getBle']);
const item = computed(() => store.getters['work/getSelectItem']);

let localDevice = ble.value.deviceId;
const isPause = ref(false);
const isStart = ref(false);
const sendCommand = ref('发送的指令会显示在此处');
const receiveData = ref('接收的数据会显示在此处');
const showDisconnected = ref(false);
const showBackDialog = ref(false);
const errorMsg = ref('');
const battery = ref(0);

const workItemList = workList[item.value];

const selectItem = ref(0);
const stopMusic = ref(false);
const power = ref(5);
const countDownTime = ref(12 * 60 * 1000);
const times = ref(countDownTime.value);

// 创建一个倒计时实例
const timer = new CountdownTimer(
  countDownTime.value,
  (time) => {
    const remainTime = Math.floor(time / 1000);
    console.log(`剩余时间: ${remainTime} 秒`);
    times.value = time;
  },
  () => {
    finishedCountDown();
  }
);
const btState = computed(() => store.getters['page/isShowBlePage']);
const device = computed(() => store.getters['bt/getBle']);

watch(btState, (newValue) => {
  stopOnClick();
  showDisconnected.value = newValue;
});

const onReConnect = () => {
  //TODO 重新连接
  connect(localDevice)
    .then(() => {
      uni.showToast({
        title: '连接成功',
        icon: 'success'
      });
    })
    .catch(() => {
      uni.showToast({
        title: '连接失败',
        icon: 'error'
      });
      uni.navigateBack();
    });
};

const onCancelConnect = () => {
  //TODO 取消连接
  uni.navigateBack();
};

const onBackCancel = () => {
  //TODO 取消返回
  showBackDialog.value = false;
};

const onBackConfirm = () => {
  //TODO 确认返回
  stopOnClick();
  uni.navigateBack();
};
const sendPower = (power: number) => {
  const command = workItemList[selectItem.value].command;
  const data = CommandBuilder.buildModeCommand(
    command,
    position[selectItem.value],
    power
  );
  send(data);
};
function formatTime(milliseconds: number): string {
  const totalSeconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  // 格式化为两位数
  const formattedMinutes = minutes.toString().padStart(2, '0');
  const formattedSeconds = seconds.toString().padStart(2, '0');

  return `${formattedMinutes}:${formattedSeconds}`;
}
const startCountDown = async () => {
  console.log('开始倒计时');
  timer.start();
  const data = CommandBuilder.buildGeneralCommand(mode.COMMON, command.START);
  sendPower(power.value);
  send(data);
  await nextTick();
  const videoContext = uni.createVideoContext('workVideo');
  videoContext.play();
};
const stopCountDown = async () => {
  console.log('停止倒计时');
  timer.stop(true);
  const data = CommandBuilder.buildGeneralCommand(mode.COMMON, command.STOP);
  send(data);
  await nextTick();
  const videoContext = uni.createVideoContext('workVideo');
  videoContext.pause();
};

const pauseCountDown = async () => {
  console.log('暂停倒计时');
  timer.pause();
  const data = CommandBuilder.buildGeneralCommand(mode.COMMON, command.PAUSE);
  send(data);
  await nextTick();
  const videoContext = uni.createVideoContext('workVideo');
  videoContext.pause();
};
const finishedCountDown = () => {
  console.log('倒计时结束');
  console.log('当前状态 - isStart:', isStart.value, 'isPause:', isPause.value);
  timer.setTime(countDownTime.value);
  times.value = countDownTime.value;
  const data = CommandBuilder.buildGeneralCommand(mode.COMMON, command.STOP);
  console.log('发送停止命令' + data);

  send(data);
  isStart.value = false;
  isPause.value = false;
};

const stopMusicOnclick = () => {
  //模拟接收数据
  // handlerReceiveData(
  //   new Uint8Array([0xaa, 0xa1, 0x02, 0x02, 0x05, 0xaa, 0x55])
  // );
  console.log(`${stopMusic.value ? '开始' : '暂停'}音乐`);
  stopMusic.value = !stopMusic.value;
};
const preMusic = () => {
  console.log('上一曲');
};
const nextMusic = () => {
  console.log('下一曲');
};

const pauseOnclick = () => {
  pauseCountDown();
  console.log('暂停');
  isPause.value = true;
};
const startOnclick = () => {
  if (isStart.value) {
    pauseOnclick();
  } else {
    startCountDown();
    console.log('开始');
    isStart.value = true;
  }
};
const continueOnClick = () => {
  console.log('继续');
  if (isPause.value) {
    startCountDown();
    isPause.value = false;
  }
};
const plusPower = () => {
  if (power.value >= 20) {
    uni.showToast({
      title: '档位最高为20',
      icon: 'error'
    });
    return;
  }
  console.log('能量+1');
  power.value++;
  // TODO 发送能量值
  sendPower(power.value);
};
const minusPower = () => {
  if (power.value - 1 < 0) {
    uni.showToast({
      title: '能量最低为0',
      icon: 'error'
    });
    return;
  }
  console.log('能量-1');
  power.value--;
  //TODO 发送能量值
  sendPower(power.value);
};
const stopOnClick = () => {
  console.log('结束');
  stopCountDown();
  finishedCountDown();
};

const send = async (hex: string) => {
  eventBus.emit('resetSend', true);
  sendCommand.value = hex;
  await sendData(hex, ble.value.deviceId)
    .then((res) => {
      console.log('发送成功');
      errorMsg.value = '发送成功' + hex;
    })
    .catch((err) => {
      errorMsg.value = '发送失败' + hex;
    })
    .finally(() => {
      eventBus.emit('resetSend', false);
    });
};
const changeItem = (index: any, item: any) => {
  if (isStart.value) {
    uni.showToast({
      title: '请先结束训练',
      icon: 'error'
    });
    return;
  }
  console.log('选择1: ', index);
  //TODO 生成模式指令发送
  selectItem.value = index;
  sendPower(power.value);
};

const onClickLeft = () => {
  if (isStart.value) {
    // uni.showToast({
    //   title: '请先结束训练',
    //   icon: 'error'
    // });
    showBackDialog.value = true;
    return;
  }
  uni.navigateBack();
};
const handlerReceiveData = (r_data: Uint8Array) => {
  console.log('Received data:', r_data);

  // const { cmd, data } = CommandParser.parseCommand(r_data);
  // const result = CommandParser.processCommand(cmd, data);

  // console.log('解析结果:', result);
  // const receive = utils.uint8ArrayToHex(r_data);

  // 停止: BB 01 01 00 02 44
  const str = utils.uint8ArrayToHex(r_data);
  receiveData.value = str;

  if (r_data[0] == protocol.POWER) {
    let bat = r_data[3];
    battery.value = bat;
  }

  if (r_data[0] === protocol.C_D) {
    switch (r_data[3]) {
      case command.STOP:
        uni.showToast({
          title: '训练结束',
          icon: 'success'
        });
        stopOnClick();
        break;
      case command.PAUSE:
        uni.showToast({
          title: '训练暂停',
          icon: 'exception'
        });
        startOnclick();
        break;
      case command.START:
        uni.showToast({
          title: '训练开始',
          icon: 'success'
        });
        startOnclick();
        break;
    }
  }
};
const openDataListener = () => {
  //打开蓝牙监听
  uni.onBLECharacteristicValueChange((res) => {
    console.log('Characteristic value changed:', res);

    const buffer = res.value;

    // 将 ArrayBuffer 转为 Uint8Array，便于处理二进制数据
    const r_data = new Uint8Array(buffer);
    handlerReceiveData(r_data);
  });
};

// uni.onBLEConnectionStateChange(({ deviceId, connected }) => {
//   localDevice = deviceId;
//   if (!connected) {
//     onReConnect();
//   }
// });

onLoad(() => {
  sendPower(power.value);
  openDataListener();
});
onUnload(() => {
  console.log('页面销毁，移除蓝牙监听');
  // uni.offBLEConnectionStateChange();
});

onHide(() => {
  console.log('on hide');
  // stopCountDown();
  // finishedCountDown();
  // if (isStart.value) {
  //   const data = CommandBuilder.buildGeneralCommand(mode.COMMON, command.STOP);
  //   send(data);
  //   isStart.value = false;
  //   isPause.value = false;
  // }
});
onUnload(() => {
  console.log('on hide');
  if (isStart.value) {
    stopCountDown();
    finishedCountDown();
    const data = CommandBuilder.buildGeneralCommand(mode.COMMON, command.STOP);
    send(data);
    isStart.value = false;
    isPause.value = false;
  }
});
</script>

<style lang="scss" scoped>
$page-fill-color: white;
.work {
  :deep(.van-nav-bar) {
    border-bottom: none; /* 去掉下边框 */
    box-shadow: none; /* 如果有阴影也需要移除 */
    background-color: $page-fill-color;
  }
  :deep(.van-nav-bar::after) {
    border-bottom: none; /* 针对一些可能的伪元素边框 */
  }
}
.select-item {
  color: white;
}
.unselect-item {
  color: #a2a2a2;
}
.text-carousel {
  width: 80%; /* 容器宽度 */
  height: 30rpx; /* 容器高度 */
  overflow: hidden; /* 隐藏超出内容 */
  position: relative;
}

.text-wrapper {
  display: flex;
  animation: scrollText 10s linear infinite; /* 横向滚动动画 */
}

.carousel-text {
  white-space: nowrap; /* 防止换行 */
  text-align: center;
  color: red;
  font-size: 20rpx;
  margin-right: 50rpx; /* 添加间距 */
}

/* 定义横向滚动动画 */
@keyframes scrollText {
  0% {
    transform: translateX(0);
  }
  100% {
    transform: translateX(-100%);
  }
}
</style>
