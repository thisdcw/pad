<template>
  <view class="parent">
    <van-nav-bar left-text="" class="nav-left-text" />
    <view style="font-weight: bold; font-size: 36rpx; color: #545454">
      <text style="margin-left: 40rpx; color: #fc5d16; font-size: 24rpx">{{
        currentDate
      }}</text>

      <view
        style="
          margin-left: 40rpx;
          background-color: #e8e8ed;
          width: 676rpx;
          height: 200rpx;
          border-radius: 40rpx;
          margin-top: 20rpx;
          display: flex;
          flex-direction: row;
          align-items: center;
        "
        @click="disConnectDevice"
      >
        <image
          src="https://gitee.com/thisdcw/static/raw/master/device_icon.png"
          style="width: 160rpx; height: 160rpx; margin-left: 40rpx"
        ></image>
        <view style="display: flex; flex-direction: column; margin-left: 40rpx">
          <text style="color: #545454; font-size: 32rpx; font-weight: bold"
            >设备: AI智能电子膜</text
          >
          <text style="color: #8d8d8e; font-size: 18rpx"
            >mac地址: AB:CD:EF:GH:IJ:KL</text
          >
          <text v-show="false" style="color: red; font-size: 22rpx"
            >测试阶段,点击此处可模拟断开连接设备,进入蓝牙连接页面</text
          >
        </view>
      </view>
      <!-- <view
        style="
          margin-left: 40rpx;
          border-radius: 36rpx;
          background-color: #FC5D16;
          width: 676rpx;
          height: 120rpx;
          margin-top: 20rpx;
          display: flex;
          flex-direction: row;
          justify-content: center;
          align-items: center;
          color: white;
        "
        v-if="!selectMember"
        @click="showChooseMember = true"
      >
        + 选择护理人
      </view> -->
      <view
        v-if="selectMember"
        style="
          width: 676rpx;
          height: 120rpx;
          margin-top: 40rpx;
          background-color: #fc5d16;
          margin-left: 40rpx;
          border-radius: 36rpx;
          display: flex;
          flex-direction: column;
          color: white;
          font-size: 32rpx;
        "
        @click="showChooseMember = true"
      >
        <text style="margin-left: 40rpx; margin-top: 20rpx">
          {{ selectMember.username }}
        </text>
        <view
          style="
            margin-left: 40rpx;
            margin-right: 40rpx;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
          "
        >
          <text>
            {{ selectMember.gender === 0 ? '女' : '男' }}
          </text>
          <text> {{ calculateAge(selectMember.birth) }}岁 </text>
        </view>
      </view>
      <view class="train-list">
        <view
          style="
            margin-bottom: 50rpx;
            margin-top: 20rpx;
            width: 100%;
            margin-left: 60rpx;
          "
        >
          <text style="font-size: 32rpx; color: #636363"> 护理部位 </text>
        </view>
        <view
          v-show="false"
          style="
            display: flex;
            flex-wrap: wrap; /* 自动换行 */
            justify-content: space-between; /* 平均分配空间 */
            width: 680rpx;
          "
        >
          <view
            v-for="(item, index) in trainItems"
            :key="index"
            @click="toggleSelect(item.id)"
            :class="[selectItem === item.id ? 'selected' : 'unselected']"
            style="
              width: 332rpx;
              height: 108rpx;
              margin-bottom: 50rpx;
              border-radius: 24rpx;
              display: flex;
              flex-direction: row;
              justify-content: space-between;
              align-items: center;
              /* 控制每个元素的宽度，使得每行最多放两个 */
              flex: 0 1 calc(50% - 10rpx); /* 50% 宽度减去间距 */
              box-sizing: border-box; /* 包括 padding 和 border 在内 */
            "
          >
            <image
              :src="
                selectItem === item.id ? item.selectIcon : item.unselectIcon
              "
              style="
                width: 94rpx;
                height: 88rpx;
                border-radius: 36rpx;
                margin-left: 20rpx;
              "
            />
            <text
              style="margin-right: 10rpx; font-size: 24rpx; margin-left: 10rpx"
              :class="{ selected: selectItem === item.id }"
              >{{ item.part }}</text
            >
            <text
              style="margin-right: 20rpx; font-size: 24rpx"
              :class="[
                item.gender === 0 ? 'woman' : 'man',
                selectItem === item.id ? 'selected' : ''
              ]"
            >
              <!-- {{
                item.gender === 0
                  ? '女士专用'
                  : item.gender === 1
                  ? '男士专用'
                  : '男女通用'
              }} -->
            </text>
          </view>
        </view>
        <!-- <part
          :toggle-select="toggleSelect"
          :select-item="selectItem"
          :train-items="trainItems"
          style="margin-bottom: 220rpx;"
        /> -->
      </view>
    </view>
  </view>
  <van-popup
    :show="showChooseMember"
    z-index="99999"
    round
    lock-scroll
    close-on-click-overlay
  >
    <div
      style="
        width: 676rpx;
        height: 80rpx;
        background-color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        border-bottom: #8d8d8e solid 1rpx;
      "
    >
      <text style="color: #fc5d16">成员列表</text>
    </div>
    <view
      style="
        overflow-y: auto;
        margin-left: 10rpx;
        margin-right: 10rpx;
        height: 500rpx;
      "
    >
      <view
        v-for="(item, index) in memberList"
        :key="index"
        style="
          width: 676rpx;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          height: 150rpx;
          margin-top: 20rpx;
        "
      >
        <view
          style="
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
          "
        >
          <van-radio-group
            :value="radio"
            @change="onRadioChange"
            direction="horizontal"
            style="
              display: flex;
              flex-direction: row;
              justify-content: space-between;
            "
          >
            <view
              style="
                display: flex;
                flex-direction: column;
                margin-left: 20rpx;
                width: 200rpx;
              "
            >
              <text style="color: #0366cc">{{ item.username }}</text>

              <view style="margin-top: 10rpx">
                <text>{{ item.gender == 0 ? '女' : '男' }}</text>
                <text style="margin-left: 60rpx"
                  >{{ calculateAge(item.birth) }}岁</text
                >
              </view>
            </view>
            <view style="margin-right: 20rpx; margin-left: 350rpx">
              <van-radio :name="item.id"></van-radio>
            </view>
          </van-radio-group>
        </view>
        <view
          style="width: 100%; height: 1rpx; background-color: #cccccc"
        ></view>
      </view>
    </view>
    <div>
      <button style="color: #fc5d16" @click="toAddMember">添加成员</button>
    </div>
    <view
      @click="showChooseMember = false"
      style="
        height: 80rpx;
        background-color: white;
        display: flex;
        background-color: #fc5d16;
        color: white;
        align-items: center;
        justify-content: center;
      "
      >关闭</view
    >
  </van-popup>
  <!-- 自定义 tabbar 底部导航栏 -->
  <custom-tabbar />
</template>

<script lang="ts" setup>
import { trainList, workList } from '@/config/config';
import { onHide, onLoad, onShow } from '@dcloudio/uni-app';
import { ref } from 'vue';

import { useStore } from 'vuex';
import { MemberStorage } from '@/storage/member';

const store = useStore();
const selectItem = ref();

const currentDate = new Date().toDateString().split(' ').slice(1).join(' ');

const setReadyWorking = () => {
  console.log('检查是否准备工作: ', selectItem.value, selectMember.value);
  if (trainItems.some((item) => item.id == selectItem.value)) {
    store.commit('work/setReady', true);
    uni.showToast({ title: '准备就绪', icon: 'success' });
  }
};
const disConnectDevice = () => {
  store.commit('bt/setBleState', false);
  uni.switchTab({
    url: '/pages/home/index'
  });
};
const toggleSelect = (index: number) => {
  console.log('选择了: ', index);
  selectItem.value = index;
  store.commit('work/setSelectItem', index);
  setReadyWorking();
};
const showChooseMember = ref(false);

const trainItems = trainList;

const memberList = ref([] as Model.Member[]);

const getMemberList = () => {
  const list = MemberStorage.getMemberList();
  memberList.value = list;
};

const radio = ref();
const onRadioChange = (event: any) => {
  console.log(event.detail);
  radio.value = event.detail;
  selectMember.value = memberList.value.find(
    (item) => item.id === event.detail
  );
  setReadyWorking();
  showChooseMember.value = false;
};
const calculateAge = (birthDateString: string): number => {
  // 将字符串转换为日期对象
  const birthDate = new Date(birthDateString);
  const today = new Date();

  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDifference = today.getMonth() - birthDate.getMonth();
  const dayDifference = today.getDate() - birthDate.getDate();
  // 如果生日的月份和日期在今天之前，年龄要减去一岁
  if (monthDifference < 0 || (monthDifference === 0 && dayDifference < 0)) {
    age--;
  }

  return age | 1;
};
const selectMember = ref();
onShow(() => {
  store.commit('tab/setTab', 1);
  console.log('device onShow');
  getMemberList();
});
onLoad(() => {});
const toAddMember = () => {
  uni.navigateTo({
    url: '/pages/member/index'
  });
};
// onHide(() => {
//   console.log('device onHide');
//   selectItem.value = null;
//   store.commit('work/setReady', false);
// });
</script>

<style lang="scss" scoped>
$page-fill-color: white;
$page-shadow-color: #f7f7f7;
.parent {
  height: 100vh;
  background-color: $page-fill-color;
  :deep(.van-nav-bar__left .van-nav-bar__text) {
    font-size: 40rpx;
    color: #545454;
  }
  :deep(.van-nav-bar) {
    border-bottom: none; /* 去掉下边框 */
    box-shadow: none; /* 如果有阴影也需要移除 */
    background-color: $page-fill-color;
  }
  :deep(.van-nav-bar::after) {
    border-bottom: none; /* 针对一些可能的伪元素边框 */
  }
}
.train-list {
  margin-top: 40rpx;
  background-color: $page-shadow-color;
  border-radius: 60rpx 60rpx 0 0;
  height: 70vh;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.man {
  color: #0a63ba;
}
.woman {
  color: #e33d63;
}
.selected {
  background-color: #fc5d16;
  color: white;
}
.unselected {
  background-color: white;
}
</style>
