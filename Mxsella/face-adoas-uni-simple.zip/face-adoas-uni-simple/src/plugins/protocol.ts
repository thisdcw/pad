export const utils = {
    bytesToInt(bytes: any) {
        let res = 0;
        for (let i = 0; i < bytes.length; i++) {
            res = (res << 8) | (bytes[i] & 0xff);
        }
        return res;
    },
    bytesToHexString(bytes: any) {
        let hexString = '';
        for (let b of bytes) {
            hexString += ('0' + (b & 0xFF).toString(16)).slice(-2).toUpperCase();
        }
        return hexString;
    },
    hexToByte(inHex: string) {
        return parseInt(inHex, 16);
    },
    hexToByteArray(inHex: any): any {
        if (typeof inHex !== 'string') {
            console.log(typeof inHex)
            throw new TypeError('Input should be a string');
        }

        let hexlen = inHex.length;
        let result;
        if (hexlen % 2 === 1) {
            hexlen++;
            result = new Uint8Array(hexlen / 2);
            inHex = "0" + inHex;
        } else {
            result = new Uint8Array(hexlen / 2);
        }
        let j = 0;
        for (let i = 0; i < hexlen; i += 2) {
            result[j] = this.hexToByte(inHex.substring(i, i + 2));
            j++;
        }
        return result;
    },
    arrayBufferToHex(buffer: ArrayBuffer): string {
        const uint8Array = new Uint8Array(buffer);
        let hexString = '';

        uint8Array.forEach((byte) => {
            // 将每个字节转换为两位十六进制字符串并拼接
            hexString += byte.toString(16).padStart(2, '0');
        });

        return hexString.toUpperCase(); // 如果需要大写的十六进制
    },
    uint8ArrayToHex(uint8Array: Uint8Array): string {
        let hexString = '';
        uint8Array.forEach((byte) => {
            // 将每个字节转换为两位的十六进制字符串，不足两位前面补'0'
            hexString += byte.toString(16).padStart(2, '0');
        });
        return hexString.toUpperCase(); // 转换为大写格式的十六进制字符串（可选）
    },
    endWith(src: any, target: any) {
        if (target.length === 0) return false;
        if (src.length < target.length) return false;

        for (let i = 0; i < target.length; i++) {
            if (target[i] !== src[src.length - target.length + i]) {
                return false;
            }
        }
        return true;
    },
}
export const protocol = {
    DEVICE_TO_CLIENT: '82',
    CLIENT_TO_DEVICE: '83',
    HEAD: '5AA5',
    D_C: 0xAA,
    C_D: 0xBB,
    POWER: 0xA5,
}
export const mode = {
    COMMON: 0x01,//通用指令
    CHEST: 0xA1,//胸部模式
    SHOULDER_NECK: 0xA2,//肩颈模式
    WAIST_ABDOMEN: 0xA3,//腰腹模式
    PRIVATE: 0xA4,//私密模式
    BUTTOCKS: 0xA5,//臀部模式
    FACE: 0xA6,//面部模式
    HAND: 0xA7,//手部模式
    JOINT: 0xA8,//关节模式
    BACK: 0xA9,//背部模式
    THIGH: 0xAA,//大腿
    CALF: 0xAB,//小腿

}
export const position = [
    0x01,
    0x02,
    0x03,
    0x04,
    0x05,
]
export const command = {
    //开关
    START: 0x01,//启动
    STOP: 0x00,//停止
    PAUSE: 0x02,//暂停

    //胸部模式
    XIONG_1: '5AA506835300010001',
    XIONG_2: '5AA506835300010002',
    XIONG_3: '5AA506835300010003',
    XIONG_4: '5AA506835300010004',
    XIONG_5: '5AA506835300010005',

    //肩颈模式
    JIAN_1: '5AA506835400010001',
    JIAN_2: '5AA506835400010002',
    JIAN_3: '5AA506835400010003',
    JIAN_4: '5AA506835400010004',
    JIAN_5: '5AA506835400010005',

    //腰腹模式
    YAO_1: '5AA506835300010001',
    YAO_2: '5AA506835300010002',
    YAO_3: '5AA506835300010003',
    YAO_4: '5AA506835300010004',
    YAO_5: '5AA506835300010005',
    //私密模式
    SHIMI_1: '5AA506835200010001',
    SHIMI_2: '5AA506835200010002',
    SHIMI_3: '5AA506835200010003',
    SHIMI_4: '5AA506835200010004',
    SHIMI_5: '5AA506835200010005',

    //臀部模式
    TUN_1: '5AA506835100010001',
    TUN_2: '5AA506835100010002',
    TUN_3: '5AA506835100010003',
    TUN_4: '5AA506835100010004',
    TUN_5: '5AA506835100010005',

}
