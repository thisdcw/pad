import { mode } from "@/plugins/protocol"

export const ble = {
	SERVICE_ID: '0000FFF0-0000-1000-8000-00805F9B34FB',//服务ID
	READ_CHARACTERISTIC_ID: '0000FFF1-0000-1000-8000-00805F9B34FB',//读取特征值ID
	WRITE_CHARACTERISTIC_ID: '0000FFF1-0000-1000-8000-00805F9B34FB',//写入特征值ID
	CONNECT_TIMEOUT: 10000,//蓝牙连接超时时间
	SCAN_TIMEOUT: 5000//蓝牙扫描超时时间,
}
export const deviceList = [
	{
		id: 0,
		icon: 'https://gitee.com/thisdcw/static/raw/master/home_device_item.png',
		name: '智能face机器人'
	},
	{
		id: 1,
		icon: 'https://gitee.com/thisdcw/static/raw/master/home_device_item.png',
		name: '智能chest机器人'
	},
	{
		id: 2,
		icon: 'https://gitee.com/thisdcw/static/raw/master/home_device_item.png',
		name: '智能abdomen机器人'
	}
]
export const trainList = [
	{
		id: 8,
		part: '背部',
		selectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_back.png',
		unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_back.png',
		icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
		gender: 3
	},
	// {
	// 	id: 0,
	// 	part: '胸部',
	// 	selectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-s.png',
	// 	unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-us.png',
	// 	icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
	// 	gender: 0
	// },
	// {
	// 	id: 1,
	// 	part: '私密',
	// 	selectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-s.png',
	// 	unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-us.png',
	// 	icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
	// 	gender: 0
	// },
	{
		id: 2,
		part: '肩颈',
		selectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_shoulder.png',
		unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_shoulder.png',
		icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
		gender: 3
	},
	// {
	// 	id: 3,
	// 	part: '腰腹',
	// 	selectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-s.png',
	// 	unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-us.png',
	// 	icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
	// 	gender: 3
	// },
	// {
	// 	id: 4,
	// 	part: '臀部',
	// 	selectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-s.png',
	// 	unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-us.png',
	// 	icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
	// 	gender: 3
	// },
	// {
	// 	id: 5,
	// 	part: '面部',
	// 	selectIcon: 'https://gitee.com/thisdcw/static/raw/master/f-s.png',
	// 	unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/f-us.png',
	// 	icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
	// 	gender: 3
	// },
	{
		id: 6,
		part: '手部',
		selectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_arm.png',
		unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_arm.png',
		icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
		gender: 3
	},
	// {
	// 	id: 7,
	// 	part: '关节',
	// 	selectIcon: 'https://gitee.com/thisdcw/static/raw/master/g_s.png',
	// 	unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/g_us.png',
	// 	icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
	// 	gender: 3
	// }
	{
		id: 9,
		part: '大腿',
		selectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_thigh.png',
		unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_thigh.png',
		icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
		gender: 3
	},
	{
		id: 10,
		part: '小腿',
		selectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_calf.png',
		unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/new_calf.png',
		icon: 'https://gitee.com/thisdcw/static/raw/master/device_icon.png',
		gender: 3
	},

]
export const workIcon = [
	'https://gitee.com/thisdcw/static/raw/master/xiong.png',
	'https://gitee.com/thisdcw/static/raw/master/simi.png',
	'https://gitee.com/thisdcw/static/raw/master/new_shoulder.png',
	'https://gitee.com/thisdcw/static/raw/master/yao.png',
	'https://gitee.com/thisdcw/static/raw/master/tun.png',
	'https://gitee.com/thisdcw/static/raw/master/face.png',
	'https://gitee.com/thisdcw/static/raw/master/new_arm.png',
	'https://gitee.com/thisdcw/static/raw/master/joint.png',
	'https://gitee.com/thisdcw/static/raw/master/new_back.png',
	'https://gitee.com/thisdcw/static/raw/master/new_thigh.png',
	'https://gitee.com/thisdcw/static/raw/master/new_calf.png',
]
export const workVideo = [
	'https://gitee.com/thisdcw/static/raw/master/video/work_chest.mp4',
	'https://gitee.com/thisdcw/static/raw/master/video/work_private.mp4',
	'https://gitee.com/thisdcw/static/raw/master/video/work_shoulder_nick.mp4',
	'https://gitee.com/thisdcw/static/raw/master/video/work_waist.mp4',
	'https://gitee.com/thisdcw/static/raw/master/video/work_buttocks.mp4',
	'https://gitee.com/thisdcw/static/raw/master/video/face.mp4',
	'https://gitee.com/thisdcw/static/raw/master/video/hand.mp4',
	'https://gitee.com/thisdcw/static/raw/master/video/joint.mp4',
	'https://gitee.com/thisdcw/static/raw/master/video/joint.mp4',//back
	'https://gitee.com/thisdcw/static/raw/master/video/joint.mp4',//thigh
	'https://gitee.com/thisdcw/static/raw/master/video/joint.mp4',//calf
]
export const workList = [
	[

		{
			id: 0,
			name: '胸部经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-1.png',
			command: mode.CHEST
		},
		{
			id: 1,
			name: '疏通排毒',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-22.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-2.png',
			command: mode.CHEST
		},
		{
			id: 2,
			name: '细胞激活',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-3.png',
			command: mode.CHEST
		},
		{
			id: 3,
			name: '脉冲导入',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-44.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-4.png',
			command: mode.CHEST
		},
		{
			id: 4,
			name: '深度排毒',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-55.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/x-5.png',
			command: mode.CHEST
		}
	]
	,
	[
		{
			id: 0,
			name: '女士经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-1.png',
			command: mode.PRIVATE
		},
		{
			id: 1,
			name: '腺体激活',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-22.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-2.png',
			command: mode.PRIVATE
		},
		{
			id: 2,
			name: '揉捏按摩',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-3.png',
			command: mode.PRIVATE
		},
		{
			id: 3,
			name: '律动提拉',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-44.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-4.png',
			command: mode.PRIVATE
		},
		{
			id: 4,
			name: '按压揉动',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-55.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/s-5.png',
			command: mode.PRIVATE
		}
	],
	[
		{
			id: 0,
			name: '肩颈经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-1.png',
			command: mode.SHOULDER_NECK
		},
		{
			id: 1,
			name: '肩颈拍打',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-22.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-2.png',
			command: mode.SHOULDER_NECK
		},
		{
			id: 2,
			name: '经络代谢',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-3.png',
			command: mode.SHOULDER_NECK
		},
		{
			id: 3,
			name: '经络疏通',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-44.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-4.png',
			command: mode.SHOULDER_NECK
		},
		{
			id: 4,
			name: '舒缓紧绷',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-55.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/j-5.png',
			command: mode.SHOULDER_NECK
		}
	],
	[
		{
			id: 0,
			name: '腹部经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-1.png',
			command: mode.WAIST_ABDOMEN
		},
		{
			id: 1,
			name: '腹部紧致',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-22.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-2.png',
			command: mode.WAIST_ABDOMEN
		},
		{
			id: 2,
			name: '经络代谢',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-3.png',
			command: mode.WAIST_ABDOMEN
		},
		{
			id: 3,
			name: '脂肪燃烧',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-44.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-4.png',
			command: mode.WAIST_ABDOMEN
		},
		{
			id: 4,
			name: '深度代谢',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-55.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/y-5.png',
			command: mode.WAIST_ABDOMEN
		}
	],
	[
		{
			id: 0,
			name: '臀部经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-1.png',
			command: mode.BUTTOCKS
		},
		{
			id: 1,
			name: '臀部紧致',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-22.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-2.png',
			command: mode.BUTTOCKS
		},
		{
			id: 2,
			name: '臀部塑性',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-3.png',
			command: mode.BUTTOCKS
		},
		{
			id: 3,
			name: '臀部疏通',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-44.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/t-4.png',
			command: mode.BUTTOCKS
		}
	],
	[
		{
			id: 0,
			name: '深层滋养',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/f-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/f-1.png',
			command: mode.FACE
		},
		{
			id: 1,
			name: '紧致提拉',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/f-22.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/f-2.png',
			command: mode.FACE
		},
		{
			id: 2,
			name: '渗透导入',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/f-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/f-3.png',
			command: mode.FACE
		}
	],
	[
		{
			id: 0,
			name: '手部经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/shou-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/shou-1.png',
			command: mode.HAND
		},
		{
			id: 1,
			name: '按压揉动',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/shou-22.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/shou-2.png',
			command: mode.HAND
		},
		{
			id: 2,
			name: '手部紧致',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/shou-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/shou-3.png',
			command: mode.HAND
		},
		{
			id: 3,
			name: '手部疏通',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/shou-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/shou-3.png',
			command: mode.HAND
		}
	],
	[
		{
			id: 0,
			name: '关节经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-1.png',
			command: mode.JOINT
		},
		{
			id: 1,
			name: '关节疏通',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-22.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-2.png',
			command: mode.JOINT
		},
		{
			id: 2,
			name: '深度代谢',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-3.png',
			command: mode.JOINT
		},
		{
			id: 3,
			name: '律动激活',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-33.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-3.png',
			command: mode.JOINT
		}
	],
	[
		{
			id: 0,
			name: '经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-1.png',
			command: mode.BACK
		}
	],
	[
		{
			id: 0,
			name: '经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-1.png',
			command: mode.THIGH
		}
	]
	,
	[
		{
			id: 0,
			name: '经典',
			selectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-11.png',
			unselectIcon: 'https://gitee.com/thisdcw/static/raw/master/joint-1.png',
			command: mode.CALF
		}
	]
]
