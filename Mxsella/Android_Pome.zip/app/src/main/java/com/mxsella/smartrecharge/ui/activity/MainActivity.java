package com.mxsella.smartrecharge.ui.activity;

import android.graphics.Color;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

import com.mxsella.smartrecharge.R;
import com.mxsella.smartrecharge.comm.ICommunicateService;
import com.mxsella.smartrecharge.comm.Protocol;
import com.mxsella.smartrecharge.comm.SPService;
import com.mxsella.smartrecharge.common.Config;
import com.mxsella.smartrecharge.common.Constants;
import com.mxsella.smartrecharge.common.base.BaseActivity;
import com.mxsella.smartrecharge.databinding.ActivityMainBinding;
import com.mxsella.smartrecharge.utils.DateTimeUtils;
import com.mxsella.smartrecharge.utils.LogUtil;
import com.mxsella.smartrecharge.utils.StringUtils;
import com.mxsella.smartrecharge.utils.ToastUtils;

public class MainActivity extends BaseActivity<ActivityMainBinding> {

    private ICommunicateService communicateService;
    private int workTime = Constants.DEFAULT_WORK_TIME;

    private int workPower = Constants.DEFAULT_WORK_POWER;
    private boolean isStart = false;
    private Handler addHandler = new Handler();
    private boolean isAddLongPress = false;
    private Handler reduceHandler = new Handler();
    private boolean isReduceLongPress = false;
    private CountDownTimer countDownTimer;

    @Override
    public void initView() {
        SPService.getInstance().connect("/dev/" + Config.getCommMode().split("_")[1]);
        communicateService = SPService.getInstance();
        communicateService.startService();
        initUI();
        initPower();
        initTimeProgress();
        initClick();
    }

    public void initPower() {
        binding.progressP.setMaxProgress(Constants.MAX_WORK_POWER);
        binding.progressP.setCurrentProgress(workPower);
        binding.workPower.setText(String.valueOf(workPower));
    }

    public void powerAdd(View view) {
        int cur = Integer.parseInt(binding.workPower.getText().toString().trim());
        if (cur + 1 > Constants.MAX_WORK_POWER) {
            ToastUtils.showToast("能量最大为10 !");
            return;
        }
        workPower += 1;
        binding.progressP.setCurrentProgress(workPower);
        binding.workPower.setText(String.valueOf(workPower));
        send(Protocol.ADDR_POWER, (short) workPower);
    }

    public void powerReduce(View view) {
        int cur = Integer.parseInt(binding.workPower.getText().toString().trim());
        if (cur - 1 < Constants.MIN_WORK_POWER) {
            ToastUtils.showToast("能量最小为1 !");
            return;
        }
        workPower -= 1;
        binding.progressP.setCurrentProgress(workPower);
        binding.workPower.setText(String.valueOf(workPower));
        send(Protocol.ADDR_POWER, (short) workPower);
    }

    private void initClick() {
        binding.add.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isAddLongPress = true;
                addHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isAddLongPress) {
                            // 增加数字的逻辑
                            incrementNumber();
                            // 每隔一段时间执行一次，实现快速增长
                            addHandler.postDelayed(this, 100);
                        }
                    }
                }, 500); // 长按 500ms 后开始增加数字

                return true;
            }

            private void incrementNumber() {
                String str = binding.workTime.getText().toString();
                int time = DateTimeUtils.parseMinutesAndSecondsToSeconds(str);
                if (time > Constants.MAX_WORK_TIME - 60) {
                    ToastUtils.showToast("最大为60分钟!");
                    binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(Constants.MAX_WORK_TIME));
                    workTime = Constants.MAX_WORK_TIME;
                    return;
                }
                binding.progressC.increaseProgress(1);
                workTime = time + 60;
                binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(time + 60));
            }
        });

        binding.add.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                // 当用户释放按钮时，停止计时器
                isAddLongPress = false;
                addHandler.removeCallbacksAndMessages(null);
            }
            return false;
        });

        binding.reduce.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                isReduceLongPress = true;
                reduceHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isReduceLongPress) {
                            // 增加数字的逻辑
                            incrementNumber();
                            // 每隔一段时间执行一次，实现快速增长
                            reduceHandler.postDelayed(this, 100);
                        }
                    }
                }, 500); // 长按 500ms 后开始增加数字

                return true;
            }

            private void incrementNumber() {
                if (isStart) {
                    ToastUtils.showToast("请先停止工作!");
                    return;
                }
                int time = DateTimeUtils.parseMinutesAndSecondsToSeconds(binding.workTime.getText().toString());
                if (time < 60) {
                    workTime = 0;
                    binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(Constants.MIN_WORK_TIME));
                    return;
                }
                binding.progressC.decreaseProgress(1);
                workTime = time - 60;
                binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(time - 60));
            }
        });

        binding.reduce.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                // 当用户释放按钮时，停止计时器
                isReduceLongPress = false;
                reduceHandler.removeCallbacksAndMessages(null);
            }
            return false;
        });
    }

    public void initUI() {
        binding.stop.setBackgroundResource(R.drawable.btn_bkg);
        binding.start.setBackgroundResource(R.drawable.stop_bkg);

    }

    public void initTimeProgress() {
        workTime = Constants.DEFAULT_WORK_TIME;
        runOnUiThread(() -> {
            binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(workTime));
        });
        binding.progressC.setCurrentProgress(workTime / 60);
    }


    public void add(View view) {
        if (isStart) {
            ToastUtils.showToast("请先停止工作!");
            return;
        }
        String str = binding.workTime.getText().toString();
        int time = DateTimeUtils.parseMinutesAndSecondsToSeconds(str);
        if (time > Constants.MAX_WORK_TIME - 60) {
            ToastUtils.showToast("最大为60分钟!");
            workTime = Constants.MAX_WORK_TIME;
            binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(workTime));
            return;
        }
        binding.progressC.increaseProgress(1);
        workTime = time + 60;
        binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(time + 60));
    }

    public void reduce(View view) {
        if (isStart) {
            ToastUtils.showToast("请先停止工作!");
            return;
        }
        int time = DateTimeUtils.parseMinutesAndSecondsToSeconds(binding.workTime.getText().toString());
        if (time < 60) {
            workTime = 0;
            binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(Constants.MIN_WORK_TIME));
            binding.progressC.decreaseProgress(1);
            return;
        }
        binding.progressC.decreaseProgress(1);
        workTime = time - 60;
        binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(time - 60));
    }

    public void send(short addr, short command) {
        communicateService.send(addr, command);
    }

    public void start(View view) {
        if (isStart) {
            return;
        }
        if (workTime < 1) {
            ToastUtils.showToast("时间太短!");
            return;
        }
        startUI();
        send(Protocol.ADDR_POWER, (short) workPower);
        send(Protocol.ADDR_SWITCH, (short) 1);
        isStart = true;
        countDown();
    }

    public void stop(View view) {
        if (!isStart) {
            return;
        }
        if (countDownTimer == null) {
            return;
        }
        countDownTimer.cancel();
        send(Protocol.ADDR_SWITCH, (short) 0);
        stopUI();
        isStart = false;
        workTime = DateTimeUtils.parseMinutesAndSecondsToSeconds(binding.workTime.getText().toString());
    }

    private void countDown() {
        countDownTimer = new CountDownTimer(workTime * 1000L, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                workTime = (int) millisUntilFinished / 1000;
                binding.workTime.setText(DateTimeUtils.getMinAndSecondBySeconds(workTime));
                binding.progressC.setCurrentProgress(workTime / 60);
            }

            @Override
            public void onFinish() {
                initTimeProgress();
                isStart = false;
                send(Protocol.ADDR_SWITCH, (short) 0);
                stopUI();
            }
        };
        countDownTimer.start();
    }

    private void stopUI() {
        binding.status.setImageResource(R.drawable.stop);
        binding.stop.setBackgroundResource(R.drawable.btn_bkg);
        binding.start.setBackgroundResource(R.drawable.stop_bkg);
        binding.stop.setTextColor(Color.WHITE);
        binding.start.setTextColor(getResources().getColor(R.color.btn_color));
    }

    private void startUI() {
        binding.status.setImageResource(R.drawable.work);
        binding.stop.setBackgroundResource(R.drawable.stop_bkg);
        binding.start.setBackgroundResource(R.drawable.btn_bkg);
        binding.start.setTextColor(Color.WHITE);
        binding.stop.setTextColor(getResources().getColor(R.color.btn_color));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        send(Protocol.ADDR_SWITCH, (short) 0);
        countDownTimer.cancel();
        isStart = false;
    }

    @Override
    public int layoutId() {
        return R.layout.activity_main;
    }
}