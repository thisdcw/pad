package com.mxsella.smartrecharge.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.mxsella.smartrecharge.R;

public class CustomArcProgressBar extends View {
    private int progressColor;
    private int backgroundColor;
    private int maxProgress = 60;
    private int maxAngle = 180;
    private int currentProgress;
    private float progressWidth;
    private float backgroundWidth;
    private int startAngle;
    private int sweepAngle;
    private Paint progressPaint;
    private Paint backgroundPaint;
    private RectF arcRect;

    public CustomArcProgressBar(Context context) {
        this(context, null);
    }

    public CustomArcProgressBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.CustomerArcProgress);
        progressColor = typedArray.getColor(R.styleable.CustomerArcProgress_arc_progress_color, getResources().getColor(R.color.primary));
        backgroundColor = typedArray.getColor(R.styleable.CustomerArcProgress_arc_bg_color, getResources().getColor(R.color.pr_bg));
        progressWidth = typedArray.getDimension(R.styleable.CustomerArcProgress_arc_progress_width, 30);
        currentProgress = typedArray.getInteger(R.styleable.CustomerArcProgress_arc_progress, 0);
        backgroundWidth = typedArray.getDimension(R.styleable.CustomerArcProgress_arc_bg_width, 30);
        startAngle = typedArray.getInteger(R.styleable.CustomerArcProgress_arc_start_angle, 180);
        sweepAngle = typedArray.getInteger(R.styleable.CustomerArcProgress_arc_sweep_angle, 180);

        progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeWidth(progressWidth);
        progressPaint.setColor(progressColor);

        backgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        backgroundPaint.setStyle(Paint.Style.STROKE);
        backgroundPaint.setStrokeWidth(backgroundWidth);
        backgroundPaint.setColor(backgroundColor);

        arcRect = new RectF();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();
        float centerX = width / 2f;
        float centerY = height / 2f;

        //计算圆的半径
        float radius = Math.min(width, height) / 2f - progressPaint.getStrokeWidth() / 2f;
        // 绘制背景圆弧
        arcRect.set(centerX - radius, centerY - radius, centerX + radius, centerY + radius);
        canvas.drawArc(arcRect, startAngle, sweepAngle, false, backgroundPaint);

        // 计算进度圆弧的角度
        float sa = (float) currentProgress / maxProgress * maxAngle;
        // 绘制进度圆弧
        canvas.drawArc(arcRect, startAngle, sa, false, progressPaint);
    }

    public void setProgressColor(int color) {
        progressColor = color;
        invalidate();
    }

    public void setBackgroundColor(int color) {
        backgroundColor = color;
        invalidate();
    }

    public void setMaxProgress(int max) {
        maxProgress = max;
        invalidate();
    }

    public void setCurrentProgress(int progress) {
        if (progress >= 0 && progress <= maxProgress) {
            currentProgress = progress;
            invalidate();
        }
    }

    public void increaseProgress(int amount) {
        setCurrentProgress(currentProgress + amount);
    }

    public void decreaseProgress(int amount) {
        setCurrentProgress(currentProgress - amount);
    }
}
