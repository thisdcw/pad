package com.mxsella.smartrecharge.comm;

import com.kongqw.serialportlibrary.SerialPortManager;
import com.kongqw.serialportlibrary.listener.OnSerialPortDataListener;
import com.mxsella.smartrecharge.common.Constants;
import com.mxsella.smartrecharge.utils.LogUtil;
import com.mxsella.smartrecharge.utils.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SPService extends SerialPortManager implements ICommunicateService {

    private static final String TAG = "SPService";

    private DataReceiveListener mListener;
    private ExecutorService executors = Executors.newSingleThreadExecutor();

    public static SPService getInstance() {
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static final SPService INSTANCE = new SPService();
    }

    private OnSerialPortDataListener mOnSerialPortDataListener = new OnSerialPortDataListener() {
        @Override
        public void onDataReceived(byte[] bytes) {
//             LocalLog.test("Receive - " + StringUtils.bytesToHex(bytes));
            if (!executors.isShutdown()) {
                executors.execute(new ReceiveTask(Protocol.short2Bytes(Protocol.HEAD), bytes));
            }
        }

        @Override
        public void onDataSent(byte[] bytes) {

        }
    };

    @Override
    public void imitateReceive(byte[] bytes) {
//        LocalLog.test("Imitate - " + StringUtils.bytesToHex(bytes));
        executors.execute(new ReceiveTask(Protocol.short2Bytes(Protocol.HEAD), bytes));
    }

    private ByteBuffer byteBuffer = ByteBuffer.allocate(500);

    private class ReceiveTask implements Runnable {

        private byte[] head;
        private byte[] tail;
        private int headLen, tailLen;
        private byte[] data;

        public ReceiveTask(byte[] head, byte[] data) {
            this(head, "".getBytes(), data);
        }

        public ReceiveTask(byte[] head, byte[] tail, byte[] data) {
            this.head = head;
            this.tail = tail;
            this.headLen = head.length;
            this.tailLen = tail.length;
            this.data = data;
        }

        private boolean endWith(Byte[] src, byte[] target) {
            if (target.length == 0) return false;
            if (src.length < target.length) return false;
            for (int i = 0; i < target.length; i++) {
                if (target[target.length - i - 1] != src[src.length - i - 1]) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public void run() {
            DataInputStream inputStream = null;
            int readLength = 0;
            try {
                if (byteBuffer.position() != 0) {
                    byteBuffer.put(data);
                    byteBuffer.flip();
                    data = new byte[byteBuffer.limit()];
                    byteBuffer.get(data);
                    byteBuffer.clear();
                }
                inputStream = new DataInputStream(new ByteArrayInputStream(data));
                int flag = -1;
                while ((flag = inputStream.read()) != -1) {
                    readLength++;
                    List<Byte> byteList = new ArrayList<>();
                    byteList.add((byte) flag);
                    int read = -1;
                    boolean hasHead = false;
                    while ((read = inputStream.read()) != -1) {
                        readLength++;
                        byteList.add((byte) read);
                        Byte[] bytes = byteList.toArray(new Byte[0]);
                        if (endWith(bytes, head)) {
                            hasHead = true;
                            break;
                        }
                    }
                    if (!hasHead) {
                        break;
                    }
                    int len = -1;
                    if ((len = inputStream.read()) != -1) {
                        if (len > 50)
                            return;
                        readLength++;
                        if (readLength + len > data.length) {
                            byteBuffer.put(Arrays.copyOfRange(data, readLength - 3, data.length));
                            break;
                        }
                        byte[] bytes = new byte[len];
                        inputStream.readFully(bytes);
                        readLength += len;

                        ReceivePacket packet = new ReceivePacket(bytes);
                        if (mListener != null) {
//                            Log.d(TAG, "---------->" + Arrays.toString(bytes));
                            mListener.onReceive(packet);
                        }
                    } else {
                        byteBuffer.put(Arrays.copyOfRange(data, data.length - 2, data.length));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @Override
    public void send(byte[] bytes) {
        if (bytes != null) {
            LogUtil.test("Send - " + StringUtils.bytesToHex(bytes));
            sendBytes(bytes);
        }
    }

    @Override
    public void send(String str) {
        sendBytes(str.getBytes(StandardCharsets.UTF_8));
    }

    @Override
    public void send(short address, short command) {
        send(Protocol.encode(address, command));
    }

    @Override
    public void setListener(DataReceiveListener mListener) {
        this.mListener = mListener;
    }

    public void connect(String address) {
        openSerialPort(new File(address), Constants.BAUD_RATE);
    }

    @Override
    public boolean isConnected() {
        return false;
    }

    @Override
    public boolean isEnable() {
        return true;
    }

    @Override
    public void startService() {
        getInstance().setOnSerialPortDataListener(mOnSerialPortDataListener);
    }

    @Override
    public void restartService() {

    }

    @Override
    public void stopService() {
        getInstance().setOnSerialPortDataListener(null);
    }

    @Override
    public void destroy() {
        closeSerialPort();
    }
}
