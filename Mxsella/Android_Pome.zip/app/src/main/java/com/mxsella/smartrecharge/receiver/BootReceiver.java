package com.mxsella.smartrecharge.receiver;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.Toast;

import com.mxsella.smartrecharge.ui.activity.MainActivity;
import com.mxsella.smartrecharge.utils.ToastUtils;

import java.util.List;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action != null && action.equals(Intent.ACTION_BOOT_COMPLETED)) {
            // 在这里添加开机自启动的逻辑，例如启动你的应用或执行其他操作
            ToastUtils.showToast("收到开机广播");
            Intent newIntent = new Intent(context, MainActivity.class);
            newIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (!isAppRunning(context, context.getPackageName()))
                context.startActivity(newIntent);
        }
    }


    /**
     * 判断应用是否在前台运行
     */
    public static boolean isAppRunning(Context context, String packageName) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> list = activityManager.getRunningTasks(1);
        return list.size() > 0 && list.get(0).topActivity.getClassName().equals(packageName);
    }
}
