package com.mxsella.smartrecharge.common;

public class Constants {


    public static final String MODE_SP_TTY = "SP_ttyS1";
    public static final int MAX_WORK_TIME = 60 * 60;
    public static final int DEFAULT_WORK_TIME = 30 * 60;
    public static final int MIN_WORK_TIME = 0;
    public static final int DEFAULT_WORK_POWER = 5;
    public static final int MAX_WORK_POWER = 10;
    public static final int MIN_WORK_POWER = 1;
    public static final int BAUD_RATE = 115200;

    public static final String BLE_CONNECT = "com.mxsella.smartrecharge.BLE_CONNECT";
    public static final String BLE_DISCONNECT = "com.mxsella.smartrecharge.BLE_DISCONNECT";
    public static final String SERVER_SUCCESS = "200";
    public static final byte[] PWD = new byte[]{0x01, 0x01, 0x01, 0x01, 0x00, 0x00};
}
