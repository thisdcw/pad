package com.mxsella.smartrecharge;

import org.junit.Test;

import static org.junit.Assert.*;

import com.mxsella.smartrecharge.utils.PayUtils;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {

    }


}