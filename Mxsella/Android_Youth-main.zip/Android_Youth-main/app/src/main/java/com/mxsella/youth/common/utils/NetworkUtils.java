package com.mxsella.youth.common.utils;

import android.util.Log;

import androidx.annotation.NonNull;

import com.mxsella.youth.bean.BaseResponse;
import com.mxsella.youth.bean.Record;
import com.mxsella.youth.bean.User;
import com.mxsella.youth.common.net.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class NetworkUtils {
    private static final String BASE_URL = "";

    private ApiService apiService;

    public NetworkUtils() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        apiService = retrofit.create(ApiService.class);
    }

    public void upload(BaseResponse<Record> data, Callback<BaseResponse<Record>> callback) {

        Call<BaseResponse<Record>> call = apiService.upload(data);
        call.enqueue(callback);
    }
}
