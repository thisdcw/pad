package com.mxsella.youth.comm;

import android.app.Application;
import android.bluetooth.BluetoothGatt;

import com.clj.fastble.BleManager;
import com.clj.fastble.callback.BleGattCallback;
import com.clj.fastble.callback.BleNotifyCallback;
import com.clj.fastble.callback.BleWriteCallback;
import com.clj.fastble.data.BleDevice;
import com.clj.fastble.exception.BleException;
import com.clj.fastble.scan.BleScanRuleConfig;
import com.mxsella.youth.R;
import com.mxsella.youth.bean.ReceivePacket;
import com.mxsella.youth.common.utils.MediaHelper;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BleService implements ICommunicateService {

    private static final String TAG = "BleService";

    private BleManager manager = BleManager.getInstance();
    public static final String SERVICE_UUID_STR = "0000ffe0-0000-1000-8000-00805f9b34fb";
    public static final String READ_CHARACTERIZE_STR = "0000ffe1-0000-1000-8000-00805f9b34fb";
    public static final String WRITE_CHARACTERIZE_STR = "0000ffe1-0000-1000-8000-00805f9b34fb";
    public static final UUID SERVICE_UUID = UUID.fromString(SERVICE_UUID_STR);
    public static final UUID READ_UUID = UUID.fromString(READ_CHARACTERIZE_STR);
    public static final UUID WRITE_UUID = UUID.fromString(WRITE_CHARACTERIZE_STR);
    private BleDevice curDevice;
    private DataReceiveListener mListener;
    private ExecutorService executors = Executors.newSingleThreadExecutor();
    private boolean isStart = false;
    private String curMac;
    private Thread readThread;
    private IBleConnectStateCallback connectStateCallback;

    private BleNotifyCallback notifyCallback = new BleNotifyCallback() {
        @Override
        public void onNotifySuccess() {

        }

        @Override
        public void onNotifyFailure(BleException exception) {

        }

        @Override
        public void onCharacteristicChanged(byte[] data) {
            if (!executors.isShutdown()) {
                executors.execute(new ReceiveTask(Protocol.short2Bytes(Protocol.HEAD), data));
            }
        }
    };

    //模拟蓝牙数据
    public void imitateReceive(byte[] bytes){
        executors.execute(new ReceiveTask(Protocol.short2Bytes(Protocol.HEAD), bytes));
    }

    private BleGattCallback connectCallback = new BleGattCallback() {
        @Override
        public void onStartConnect() {
            if (connectStateCallback != null) {
                connectStateCallback.startConnect();
            }
        }

        @Override
        public void onConnectFail(BleDevice bleDevice, BleException exception) {
            if (connectStateCallback != null) {
                connectStateCallback.connectFailure(exception.getDescription());
            }
        }

        @Override
        public void onConnectSuccess(BleDevice bleDevice, BluetoothGatt gatt, int status) {
            BleService.getInstance().setCurDevice(bleDevice);
            // 连接成功时主动发送关闭指令 因为可能出现设备异常关闭 导致单片机状态未改变
            startService();
//            send(Protocol.ADDR_WORK_SWITCH, Protocol.MODE_OFF);

            MediaHelper.playSound(R.raw.ble_tooth_conn_success);
            if (connectStateCallback != null) {
                connectStateCallback.connectSuccess();
            }
        }

        @Override
        public void onDisConnected(boolean isActiveDisConnected, BleDevice device, BluetoothGatt gatt, int status) {
            //LocalLog.d(TAG, "蓝牙设备断开连接---" + device + "---" + status);
            MediaHelper.playSound(R.raw.ble_tooth_dis_conn);
            if (connectStateCallback != null) {
                connectStateCallback.disConnect();
            }
        }
    };

    public static BleService getInstance() {
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static BleService INSTANCE = new BleService();
    }

    private BleService() {}

    public void init(Application application) {
        manager.init(application);
        manager.enableLog(true)
                .setReConnectCount(2, 5000)
                .setOperateTimeout(5000);
        BleScanRuleConfig scanRuleConfig = new BleScanRuleConfig.Builder()
//                .setServiceUuids(new UUID[]{SERVICE_UUID}) // 扫描指定服务的设备
//                .setAutoConnect(true) // 是否自动连接
                .setScanTimeOut(3000) // 扫描超时时间
                .build();
        manager.initScanRule(scanRuleConfig);
    }

    public void setConnectStateCallback(IBleConnectStateCallback connectStateCallback) {
        this.connectStateCallback = connectStateCallback;
    }

    public void setCurDevice(BleDevice curDevice) {
        this.curDevice = curDevice;
        if (curDevice != null) {
            this.curMac = curDevice.getMac();
        }
    }

    public BleDevice getCurDevice() {
        return curDevice;
    }

    @Override
    public void send(byte[] bytes) {
        if (curDevice != null && bytes != null) {
            manager.write(curDevice, SERVICE_UUID_STR, READ_CHARACTERIZE_STR, bytes, new BleWriteCallback() {
                @Override
                public void onWriteSuccess(int current, int total, byte[] justWrite) {
                    //LocalLog.d(TAG, "蓝牙发送消息成功");
                }

                @Override
                public void onWriteFailure(BleException exception) {
                    //LocalLog.d(TAG, "蓝牙发送消息失败------" + exception.getDescription());
                }
            });
        } else {
            if (curDevice == null ||
                    BleManager.getInstance().isConnected(curDevice.getMac())) {
                //LocalLog.d(TAG, "发送数据失败----蓝牙已经断开连接");
            }
        }
    }

    @Override
    public void send(String str) {

        send(str.getBytes(StandardCharsets.UTF_8));
    }

    public void send(short address, short command) {
        send(Protocol.encode(address, command));
    }

    @Override
    public boolean isConnected() {
        return isEnable() && curDevice != null
                && BleManager.getInstance().isConnected(curDevice);
    }

    public void connect(String mac, IBleConnectStateCallback callback) {
        if (mac == null) {
            //LocalLog.d(TAG, "连接设备的地址为空!");
            return;
        }
        this.connectStateCallback = callback;
        BleManager.getInstance().connect(mac, connectCallback);
    }

    public void connect(String mac) {
        connect(mac, null);
    }

    @Override
    public boolean isEnable() {
        return manager.isBlueEnable();
    }

    @Override
    public void startService() {
        this.isStart = true;
        if (isConnected()) {
            BleManager.getInstance().notify(curDevice, SERVICE_UUID_STR,
                    READ_CHARACTERIZE_STR, notifyCallback);
        }
    }

    @Override
    public void restartService() {

    }

    @Override
    public void stopService() {
        this.isStart = false;
        if (readThread != null) {
            readThread.interrupt();
        }
        if (curDevice != null) {
            BleManager.getInstance().removeNotifyCallback(curDevice, READ_CHARACTERIZE_STR);
        }
    }

    @Override
    public void destroy() {
        manager.disconnectAllDevice();
        manager.destroy();
    }

    private ByteBuffer byteBuffer = ByteBuffer.allocate(500);

    private class ReceiveTask implements Runnable {

        private byte[] head;
        private byte[] tail;
        private int headLen, tailLen;
        private byte[] data;

        public ReceiveTask(byte[] head, byte[] data) {
            this(head, "".getBytes(), data);
        }

        public ReceiveTask(byte[] head, byte[] tail, byte[] data) {
            this.head = head;
            this.tail = tail;
            this.headLen = head.length;
            this.tailLen = tail.length;
            this.data = data;
        }

        private boolean endWith(Byte[] src, byte[] target) {
            if (target.length == 0) return false;
            if (src.length < target.length) return false;
            for (int i = 0;i < target.length;i++) {
                if (target[target.length - i - 1] != src[src.length - i - 1]) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public void run() {
            DataInputStream inputStream = null;
            int readLength = 0;
            try {
                if (byteBuffer.position() != 0) {
                    byteBuffer.put(data);
                    byteBuffer.flip();
                    data = new byte[byteBuffer.limit()];
                    byteBuffer.get(data);
                    byteBuffer.clear();
                }
                inputStream = new DataInputStream(new ByteArrayInputStream(data));
                int flag = -1;
                while((flag = inputStream.read()) != -1) {
                    readLength++;
                    List<Byte> byteList = new ArrayList<>();
                    byteList.add((byte) flag);
                    int read = -1;
                    boolean hasHead = false;
                    while ((read = inputStream.read()) != -1) {
                        readLength++;
                        byteList.add((byte) read);
                        Byte[] bytes = byteList.toArray(new Byte[0]);
                        if (endWith(bytes, head)) {
                            hasHead = true;
                            break;
                        }
                    }
                    if (!hasHead) {
                        break;
                    }
                    int len = -1;
                    if ((len = inputStream.read()) != -1) {
                        if (len > 50)
                            return;
                        readLength++;
                        if (readLength + len > data.length) {
                            byteBuffer.put(Arrays.copyOfRange(data, readLength - 3, data.length));
                            break;
                        }
                        byte[] bytes = new byte[len];
                        inputStream.readFully(bytes);
                        readLength += len;

                        ReceivePacket packet = new ReceivePacket(bytes);
                        if (mListener != null)
                            mListener.onReceive(packet);
                    } else {
                        byteBuffer.put(Arrays.copyOfRange(data, data.length - 2, data.length));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public void reconnect() {
        if (curDevice != null) {
            BleManager.getInstance().connect(curDevice.getMac(), connectCallback);
        }
    }

    @Override
    public void setListener(DataReceiveListener mListener) {
        this.mListener = mListener;
    }
}
