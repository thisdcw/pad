package com.mxsella.youth.common.widget;

import android.app.Dialog;
import android.content.Context;
import androidx.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.mxsella.youth.R;
import com.mxsella.youth.common.utils.NavigationBarUtil;

import java.util.Objects;

public class EditDialog extends Dialog {

    private Context context;
    private int position;

    private TextView tvEditUser;
    private TextView tvDeleteUser;
    private Button btnEditUser;
    private Button btnDeleteUser;

    public EditDialog(@NonNull Context context) {
        super(context);
        this.context = context;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_edit, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        tvEditUser = view.findViewById(R.id.tv_edit_user);
        tvDeleteUser = view.findViewById(R.id.tv_delete_user);
        btnEditUser = view.findViewById(R.id.btn_edit_user);
        btnDeleteUser = view.findViewById(R.id.btn_delete_user);
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public void setEditClickListener(View.OnClickListener listener) {
        tvEditUser.setOnClickListener(listener);
        btnEditUser.setOnClickListener(listener);
    }

    public void setDeleteClickListener(View.OnClickListener listener) {
        tvDeleteUser.setOnClickListener(listener);
        btnDeleteUser.setOnClickListener(listener);
    }

    @Override
    public void show() {
        Objects.requireNonNull(getWindow()).setBackgroundDrawable(null);
        NavigationBarUtil.focusNotAle(getWindow());
        try {
            super.show();
        } catch (Exception e){
            e.printStackTrace();
        }

        NavigationBarUtil.hideNavigationBar(getWindow());
        NavigationBarUtil.clearFocusNotAle(getWindow());
    }
}
