package com.mxsella.youth.common.utils;

public class WorkParam {

    /*
       line:
           space   1.5-5   0.1/each
           length  5.0-25.0  1.0/each
           power   0.5-3   0.1J/each
     */
    public static final double LINE_MAX_SPACE = 5;
    public static final double LINE_MIN_SPACE = 1.5;
    public static final double LINE_MAX_LENGTH = 25;
    public static final double LINE_MIN_LENGTH = 5.0;
    public static final double LINE_MAX_POWER = 3;
    public static final double LINE_MIN_POWER = 0.5;
    /*
    point:
           speed       1-10    1/each
           quantity    1-10    1/each
           power       0-3     0.1J/each
    */
    public static final int POINT_MAX_SPEED = 10;
    public static final int POINT_MIN_SPEED = 1;
    public static final int POINT_MAX_QUANTITY = 10;
    public static final int POINT_MIN_QUANTITY = 1;
    public static final double POINT_MAX_POWER = 3;
    public static final double POINT_MIN_POWER = 0;
}
