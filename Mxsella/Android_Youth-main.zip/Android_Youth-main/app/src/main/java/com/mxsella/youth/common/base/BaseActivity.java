package com.mxsella.youth.common.base;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import com.mxsella.youth.CheckActivity;
import com.mxsella.youth.R;
import com.mxsella.youth.common.utils.AppManager;
import com.mxsella.youth.common.utils.AppUtils;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.Constants;
import com.mxsella.youth.common.utils.ImageLoadUtils;
import com.mxsella.youth.service.OnlineService;

import butterknife.ButterKnife;
import butterknife.Unbinder;
import me.jessyan.autosize.AutoSizeCompat;

public abstract class BaseActivity extends FragmentActivity {

    Context mContext;

    protected Unbinder unBinder;

    private TimeBroadcastReceiver timeBroadcastReceiver;

    private ImageView imgWifi;
    private boolean isStopCheck = false;
    private Thread wifiCheckThread;
    private final int[] wifiImages = {R.drawable.ic_wifi_0, R.drawable.ic_wifi_1, R.drawable.ic_wifi_2, R.drawable.ic_wifi_3, R.drawable.ic_wifi_4};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        doBeforeSetContentView();
        setContentView(this.getLayoutId());
        mContext = this;
        unBinder = ButterKnife.bind(this);
        initView();
        initEventAndData();
        registerBroadcastReceiver();
    }

    /**
     * 设置layout前配置
     */
    protected void doBeforeSetContentView() {
        //setRequestedOrientation(ActivityInfo .SCREEN_ORIENTATION_LANDSCAPE);
        AppManager.getAppManager().addActivity(this);
        hideBottomUIMenu();
    }

    /**
     * 隐藏虚拟按键，并且全屏
     */
    public void hideBottomUIMenu() {
        //隐藏虚拟按键，并且全屏
        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
            View v = getWindow().getDecorView();
            v.setSystemUiVisibility(View.GONE);
        } else if (Build.VERSION.SDK_INT >= 19) {
            //for nuew api versions.
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    /**
     * 就算你在Manifest.xml设置横竖屏切换不重走生命周期。横竖屏切换还是会走这里
     */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        if(getRequestedOrientation()!= ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
        super.onResume();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(timeBroadcastReceiver);
        if (this.unBinder != null) {
            this.unBinder.unbind();
        }
        isStopCheck = true;
        if (wifiCheckThread != null && !wifiCheckThread.isInterrupted()) {
            wifiCheckThread.interrupt();
        }
        AppManager.getAppManager().removeActivity(this);
        super.onDestroy();
    }

    /**
     * 设置布局
     * @return
     */
    public abstract int getLayoutId();

    /**
     * 初始化视图
     */
    public void initView() {
        /*ImageView imgLogo = (ImageView) findViewById(R.id.img_logo);
        if(imgLogo != null && !TextUtils.isEmpty(Config.getLogoUrl())) {
            //imgLogo.setVisibility(View.GONE);
            Glide.with(this).load(Config.getLogoUrl()).into(imgLogo);
        }*/
        /*ImageView imgBkg= (ImageView) findViewById(R.id.img_main_bkg);
        if(imgBkg != null && !TextUtils.isEmpty(Config.getMainBkgUrl())) {
            ImageLoadUtils.glideLoad(this, Config.getMainBkgUrl(), imgBkg);
        }*/
        imgWifi = (ImageView) findViewById(R.id.img_wifi);
        if(imgWifi != null) {
            imgWifi.setOnClickListener(view -> {
                Intent intent = new Intent();
                intent.setAction("android.net.wifi.PICK_WIFI_NETWORK");
                startActivity(intent);
            });
        }
    }

    /**
     * 初始化事件监听器
     */
    protected void initEventAndData() {
        if (imgWifi != null && wifiCheckThread == null) {
            wifiCheckThread = new Thread(new GetWifiTask());
            wifiCheckThread.start();
        }
    }

    private void registerBroadcastReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Config.APP_STOP);
        timeBroadcastReceiver = new TimeBroadcastReceiver();
        registerReceiver(timeBroadcastReceiver, intentFilter);
    }

    class TimeBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case Config.APP_STOP:
                    stopAction();
                    break;
            }
        }
    }

    public void stopAction() {

    }

    class GetWifiTask implements Runnable {
        @Override
        public void run() {
            try {
                while (!isStopCheck) {
                    int index = AppUtils.getWifiStrength(BaseActivity.this);
                    if (imgWifi == null) break;
                    BaseActivity.this.runOnUiThread(() -> {
                        if (imgWifi !=null) {
                            imgWifi.setImageDrawable(getResources().getDrawable(wifiImages[index]));
                        }
                    });
                    Thread.sleep(5000);
                }
            } catch (Exception e) {
                //e.printStackTrace();
            }
        }
    }

    // setExcludeFontScale(true)在Fragment中可能无效，更改语言后可能适配无效，重写该方法
    @Override
    public Resources getResources() {
        AutoSizeCompat.autoConvertDensityOfGlobal(super.getResources());
        return super.getResources();
    }
    public void navigateTo(Class<?> cls){
        Intent intent = new Intent(mContext,cls);
        startActivity(intent);
    }
}
