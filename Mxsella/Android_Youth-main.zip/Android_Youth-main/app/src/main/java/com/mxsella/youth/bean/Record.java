package com.mxsella.youth.bean;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;
import java.util.Date;

public class Record extends LitePalSupport implements Serializable {
    private int userId;
    private String usedDate;
    private int item;
    private String toolHead;
    private int count;

    @Override
    public String toString() {
        return "Record{" +
                "userId=" + userId +
                ", usedDate='" + usedDate + '\'' +
                ", item=" + item +
                ", toolHead='" + toolHead + '\'' +
                ", count=" + count +
                '}';
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Record() {
    }


    public Record(int userId, String usedDate, int item, String toolHead, int count) {
        this.userId = userId;
        this.usedDate = usedDate;
        this.item = item;
        this.toolHead = toolHead;
        this.count = count;
    }

    public String getUsedDate() {
        return usedDate;
    }

    public void setUsedDate(String usedDate) {
        this.usedDate = usedDate;
    }

    public int getItem() {
        return item;
    }

    public void setItem(int item) {
        this.item = item;
    }

    public String getToolHead() {
        return toolHead;
    }

    public void setToolHead(String toolHead) {
        this.toolHead = toolHead;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
