package com.mxsella.youth;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.mxsella.youth.adapter.RecordAdapter;
import com.mxsella.youth.bean.Record;
import com.mxsella.youth.bean.User;
import com.mxsella.youth.common.base.BaseActivity;
import com.mxsella.youth.common.utils.RecordHelper;
import com.mxsella.youth.common.utils.ToastUtil;
import com.mxsella.youth.common.utils.UserHelper;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class RecordActivity extends BaseActivity {
    public static String USER = "user";
    @BindView(R.id.rcv_record)
    RecyclerView rcvRecord;
    @BindView(R.id.tv_number_record)
    TextView tvNumberRecord;
    @BindView(R.id.tv_current_page_record)
    TextView tvCurrentPageRecord;
    @BindView(R.id.tv_total_page_record)
    TextView tvTotalPageRecord;
    @BindView(R.id.edt_jump_record)
    EditText edtJumpRecord;
    @BindView(R.id.tv_jump_record)
    TextView tvJumpRecord;
    @BindView(R.id.tv_last_page_record)
    TextView tvLastPageRecord;
    @BindView(R.id.tv_next_page_record)
    TextView tvNextPageRecord;
    @BindView(R.id.return_btn)
    ImageView return_btn;
    private InputMethodManager manager;
    private static final int DEFAULT_SIZE = 10;
    private String stringHaveRecords;
    private List<Record> recordList;
    private RecordAdapter recordAdapter;
    private int currentPageUser = 0;
    private int totalPageRecord = 0;
    int userId;

    @Override
    public int getLayoutId() {
        return R.layout.activity_record;
    }

    @Override
    public void initView() {
        super.initView();

        setFocusChangeListener(edtJumpRecord);
        setEdtEnter(edtJumpRecord, tvJumpRecord);

        userId = getIntent().getIntExtra("userId", 1);
        recordList = RecordHelper.getInstance().getRecordByUserId(userId);

        tvLastPageRecord.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        tvNextPageRecord.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        tvJumpRecord.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        stringHaveRecords = getResources().getString(R.string.have_records);

        tvNumberRecord.setText(String.format(stringHaveRecords, RecordHelper.getInstance().total(userId)));

        totalPageRecord = RecordHelper.getInstance().totalPage(DEFAULT_SIZE, userId);
        if (totalPageRecord == 0)
            currentPageUser = 0;
        else
            currentPageUser = 1;
        tvTotalPageRecord.setText(String.valueOf(totalPageRecord));
        tvCurrentPageRecord.setText(String.valueOf(currentPageUser));

        recordAdapter = new RecordAdapter(this, recordList, DEFAULT_SIZE);
        recordAdapter.setPage(totalPageRecord);
        rcvRecord.setLayoutManager(new LinearLayoutManager(this));
        rcvRecord.setAdapter(recordAdapter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @OnClick(R.id.return_btn)
    public void onReturnClick() {
        finish();
    }

    @OnClick({
            R.id.tv_last_page_record, R.id.tv_next_page_record, R.id.tv_jump_record})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_last_page_record:
                if (currentPageUser <= 1)
                    return;
                refresh(currentPageUser-1);
                break;
            case R.id.tv_next_page_record:
                if (currentPageUser >= totalPageRecord)
                    return;
                refresh(currentPageUser +1);
                break;
            case R.id.tv_jump_record:
                int pageUser = Integer.parseInt(edtJumpRecord.getText().toString());
                if (pageUser < 1 || pageUser > totalPageRecord) {
                    ToastUtil.showToast(getString(R.string.input_correct_page));
                    return;
                }
                currentPageUser = pageUser;
                refresh(pageUser);
                break;
            default:
                break;
        }
    }

    private void refresh(int page) {
        page = Math.max(1, page);

        recordList.clear();
        totalPageRecord = RecordHelper.totalPageRecord(userId, DEFAULT_SIZE);
        if (totalPageRecord == 0) {
            currentPageUser = 0;
        } else {
            currentPageUser = Math.min(totalPageRecord, page);
            recordList.addAll(RecordHelper.getRecordList(userId, currentPageUser, DEFAULT_SIZE));
        }
        tvCurrentPageRecord.setText(String.valueOf(currentPageUser));

        tvTotalPageRecord.setText(String.valueOf(totalPageRecord));

        tvNumberRecord.setText(String.format(stringHaveRecords, RecordHelper.totalRecord(userId)));

        recordAdapter.setPage(currentPageUser);
        recordAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    public void setEdtEnter(EditText editText, View callView) {
        editText.setOnEditorActionListener((textView, i, keyEvent) -> {
            if (i == EditorInfo.IME_ACTION_DONE) {
                //隐藏软键盘
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
                callView.callOnClick();
            }
            return false;
        });
        editText.setOnKeyListener((view, i, keyEvent) -> {
            if (keyEvent.getAction() == KeyEvent.ACTION_UP) {
                if (i == KeyEvent.KEYCODE_NUMPAD_ENTER || i == KeyEvent.KEYCODE_ENTER) {
                    //隐藏软键盘
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
                    callView.callOnClick();
                }
            }
            return false;
        });
    }

    public void setFocusChangeListener(EditText editText) {
        editText.setOnFocusChangeListener((view, hasFocus) -> {
            if (!hasFocus) {
                if (manager != null) {
                    manager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                    hideBottomUIMenu();
                }
            }
        });
    }
}