package com.mxsella.youth.common.utils;

import android.content.SharedPreferences;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Config {

    //Ble地址
    private static final String BLE_ADDRESS = "ble_address";

    private static final String TAG = "Config";

    public static String versionName = "";
    public static int versionCode = 0;
    public static String deviceId = "";
    public static final String PACKAGE_NAME = "com.mxsella.youth";
    public static final String APP_STOP = "com.mxsella.youth.APP_STOP";
    public static final String IS_ACTIVE = "IS_ACTIVE";
    public static final String LAST_ACTIVE_TIME = "LAST_ACTIVE_TIME";
    public static boolean ifDebug = false;
    public static boolean write_log = false;
    public static int onlineState = Constants.STATE_AWAIT;

    // 极光推送绑定状态
    private static final String J_PUSH_BIND = "j_push_bind";
    // 欢迎页启用状态
    private static final String WELCOME_BKG_STATE = "welcome_bkg_state";
    // 欢迎页背景地址
    private static final String WELCOME_BKG_URL = "welcome_bkg_url";
    // 主页背景地址
    private static final String MAIN_BKG_URL = "main_bkg_url";
    // Logo地址
    private static final String LOGO_URL = "logo_url";
    //忽略版本更新
    private static final String IGNORE_VERSION_CODE = "ignore_version_code";
    //通信模式
    private static final String COMM_MODE = "comm_mode";
    private static final String DEFAULT_COMM_MODE = Constants.MODE_SP_TTYS0;
    //剩余次数
    private static final String REMAIN_TIMES = "remain_times_";
    private static final String PASSWORD = "password";
    public static final String DEFAULT_PASSWORD = "000000";
    public static SharedPreferences mainSP;
    public static final String LANGUAGE = "language";
    public static final String CURRENT_LINE_ITEM = "currLineItem";
    public static final String CURRENT_POINT_ITEM = "currPointItem";

    public static String[] handle = {"M4.5", "M3.0", "M1.5", "D4.5", "D3.0"};

    private static final HashMap<String, Integer> handleType = new HashMap<String, Integer>() {{
        put(handle[0], 0);
        put(handle[1], 1);
        put(handle[2], 2);
        put(handle[3], 3);
        put(handle[4], 4);
    }};
    public static final HashMap<Integer, String> frequency = new HashMap<Integer, String>() {{
        put(0, "40.0");
        put(1, "20.0");
        put(2, "70.0");
        put(3, "40.0");
        put(4, "70.0");
    }};

    public static String getHandle(int index) {
        if (index < 0 || index > 4) {
            return handle[0];
        }
        return handle[index];
    }

    public static String getFrequency(int index) {
        if (index < 0 || index > 4) {
            return frequency.get(0);
        }
        return frequency.get(index);
    }

    public static Integer getHandleTypeByKey(String key) {
        return handleType.get(key);
    }

    public static void saveItem(int type, String depth) {
        if (type == 1) {
            saveSync(CURRENT_LINE_ITEM, depth);
        } else if (type == 0) {
            saveSync(CURRENT_POINT_ITEM, depth);
        }
    }

    public static String getDepth(int type) {
        if (type == 1) {
            return mainSP.getString(CURRENT_LINE_ITEM, "00");
        }
        return mainSP.getString(CURRENT_POINT_ITEM, "00");
    }

    public static String getParam(String item) {
        String value = "";
        switch (item) {
            case "spacing":
                value = mainSP.getString("spacing", String.valueOf(1.7));
                break;
            case "length":
                value = mainSP.getString("length", String.valueOf(25.0));
                break;
            case "line_power":
                value = mainSP.getString("line_power", String.valueOf(1.0));
                break;
            case "point_power":
                value = mainSP.getString("point_power", String.valueOf(1.0));
                break;
            case "speed":
                value = mainSP.getString("speed", String.valueOf((int) 5));
                break;
            case "quantity":
                value = mainSP.getString("quantity", String.valueOf((int) 5));
                break;
            default:
                break;
        }
        return value;
    }

    public static void saveOrUpdateParam(String item, double value) {
        switch (item) {
            case "spacing":
                saveSync("spacing", String.valueOf(value));
                break;
            case "length":
                saveSync("length", String.valueOf(value));
                break;
            case "line_power":
                saveSync("line_power", String.valueOf(value));
                break;
            case "point_power":
                saveSync("point_power", String.valueOf(value));
                break;
            case "speed":
                saveSync("speed", String.valueOf((int) value));
                break;
            case "quantity":
                saveSync("quantity", String.valueOf((int) value));
                break;
            default:
                break;
        }
    }

    public static String getLanguage() {
        return mainSP.getString(LANGUAGE, "ko");
    }

    public static void saveLanguage(String s) {
        mainSP.edit().putString(LANGUAGE, s).apply();
    }

    public static void saveOrUpdatePassword(String newPassword) {
        saveSync(PASSWORD, newPassword);
    }

    public static String getPassword() {
        return mainSP.getString(PASSWORD, DEFAULT_PASSWORD);
    }

    public static void saveSync(String key, Object value) {
        mainSP.edit().putString(key, String.valueOf(value)).apply();
    }

    public static Boolean getJPushBind() {
        return mainSP.getBoolean(J_PUSH_BIND, false);
    }

    public static void saveJPushBind(Boolean b) {
        mainSP.edit().putBoolean(J_PUSH_BIND, b).apply();
    }

    public static boolean isAlreadyActive() {
        return mainSP.getBoolean(IS_ACTIVE, false);
    }

    public static void saveOrUpdateActiveState(boolean isActive) {
        mainSP.edit().putBoolean(IS_ACTIVE, isActive).apply();
    }

    public static long getLastActiveTime() {
        return mainSP.getLong(LAST_ACTIVE_TIME, 0);
    }

    public static void saveLastActiveTime(long time) {
        mainSP.edit().putLong(LAST_ACTIVE_TIME, time).apply();
    }

    public static int getIgnoreVersionCode() {
        return Integer.parseInt(mainSP.getString(IGNORE_VERSION_CODE, "0"));
    }

    public static void saveIgnoreVersionCode(String versionCode) {
        saveSync(IGNORE_VERSION_CODE, versionCode);
    }

    public static String getBleAddress() {
        return mainSP.getString(BLE_ADDRESS, "");
    }

    public static void saveBleAddress(String address) {
        saveSync(BLE_ADDRESS, address);
    }

    public static List<Integer> getAllRemainTimes() {
        List<Integer> timesList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
                timesList.add(Integer.parseInt(Objects.requireNonNull(mainSP.getString(REMAIN_TIMES + i, "-1"))));
        }
        return timesList;
    }

    public static int getRemainTimes(int handleType) {
        return Integer.parseInt(Objects.requireNonNull(mainSP.getString(REMAIN_TIMES + handleType, "-1")));
    }

    public static void saveRemainTimes(int handleType, int times) {
        saveSync(REMAIN_TIMES + handleType, times);
    }

    public static String getCommMode() {
        return mainSP.getString(COMM_MODE, DEFAULT_COMM_MODE);
    }

    public static void saveCommMode(String mode) {
        saveSync(COMM_MODE, DEFAULT_COMM_MODE);
    }

    public static boolean getWelcomeBkgState() {
        return mainSP.getBoolean(WELCOME_BKG_STATE, false);
    }

    public static void saveWelcomeBkgState(boolean welcomeBkgState) {
        mainSP.edit().putBoolean(WELCOME_BKG_STATE, welcomeBkgState).apply();
    }

    public static String getWelcomeBkgUrl() {
        return mainSP.getString(WELCOME_BKG_URL, "");
    }

    public static void saveWelcomeBkgUrl(String welcomeBkgUrl) {
        saveSync(WELCOME_BKG_URL, welcomeBkgUrl);
    }

    public static String getMainBkgUrl() {
        return mainSP.getString(MAIN_BKG_URL, "");
    }

    public static void saveMainBkgUrl(String mainBkgUrl) {
        saveSync(MAIN_BKG_URL, mainBkgUrl);
    }

    public static String getLogoUrl() {
        return mainSP.getString(LOGO_URL, "");
    }

    public static void saveLogoUrl(String logoUrl) {
        saveSync(LOGO_URL, logoUrl);
    }

    public @interface Tag_MAIN_SP {
        String deviceId = "deviceId";
    }
}
