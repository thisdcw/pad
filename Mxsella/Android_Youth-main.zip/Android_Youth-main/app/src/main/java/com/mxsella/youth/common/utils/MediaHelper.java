package com.mxsella.youth.common.utils;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;

import com.mxsella.youth.common.MyApplication;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 音频播放工具类
 */
public class MediaHelper {

    private static MediaPlayer mPlayer;
    private static boolean isPause = false;
    private static ExecutorService service = Executors.newSingleThreadExecutor();

    public static void playSound(String filePath, MediaPlayer.OnCompletionListener listener) {
        if (mPlayer == null) {
            mPlayer = new MediaPlayer();
        } else {
            mPlayer.reset();
        }
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setOnCompletionListener(listener);
        mPlayer.setOnErrorListener((mp, what, extra) -> {
            mPlayer.reset();
            return false;
        });
        try {
            mPlayer.setDataSource(filePath);
            mPlayer.prepare();
        } catch (IllegalArgumentException | SecurityException | IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException("读取文件异常：" + e.getMessage());
        }
        mPlayer.start();
        isPause = false;
    }

    public static void playSound(int id, boolean isLooping, MediaPlayer.OnCompletionListener listener) {
        if (mPlayer != null) {
            mPlayer.pause();
            mPlayer.release();
        }
        mPlayer = MediaPlayer.create(MyApplication.getInstance(), id);
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setLooping(isLooping);
        mPlayer.setOnCompletionListener(listener);
        mPlayer.setOnErrorListener((mp, what, extra) -> {
            mPlayer.reset();
            return false;
        });
        /*try {
            mPlayer.prepare();
        } catch (IllegalArgumentException | SecurityException | IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException("读取文件异常：" + e.getMessage());
        }*/
        mPlayer.start();
        isPause = false;
    }

    public static void playSound(int id, MediaPlayer.OnCompletionListener listener) {
        playSound(id, false, listener);
    }

    public static void playSound(int id, boolean isLooping) {
        playSound(id, isLooping, mp -> {});
    }

    public static void playSound(int id) {
        playSound(id, false, mp -> {});
    }

    public static void playSoundOnBackground(int id) {
        service.execute(new PlayOnBackgroundTask(id, MyApplication.getInstance()));
//        BackgroundMediaHelper.playSound(id, MyApplication.getInstance());

    }

    public static void playSoundOnBackground(int id, Context context) {
        service.execute(new PlayOnBackgroundTask(id, context));

    }

    public static void pause() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.pause();
            isPause = true;
        }
    }

    // 继续播放
    public static void resume() {
        if (mPlayer != null && isPause) {
            mPlayer.start();
            isPause = false;
        }
    }

    public static void release() {
        pause();
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
    }

    private static class PlayOnBackgroundTask implements Runnable {

        private Context context;
        private int id;

        PlayOnBackgroundTask(int id, Context context) {
            this.id = id;
            this.context = context;
        }

        @Override
        public void run() {
            BackgroundMediaHelper.playSound(id, context);
        }
    }
}
