package com.mxsella.youth.comm;

public abstract class ConnectStateHelper implements IBleConnectStateCallback {

    @Override
    public void startConnect() {

    }

    @Override
    public void connectFailure(String msg) {

    }


}
