package com.mxsella.youth.common.net;

import com.mxsella.youth.bean.BaseResponse;
import com.mxsella.youth.bean.Device;
import com.mxsella.youth.bean.Record;
import com.mxsella.youth.bean.UpdateInfo;
import com.mxsella.youth.bean.UseTimesHistory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiService {

    String BASE_URL = "http://mmk.mxsella.com/Youth/";

    @POST("app/upload")
    Call<BaseResponse<Record>> upload(@Body BaseResponse<Record> dateResponse);
    /**
     * 检查更新
     */
    @FormUrlEncoded
    @POST("device/version/update")
    Observable<BaseResponse<UpdateInfo>> requestUpdate(@FieldMap Map<String, String> map);

    /**
     * 获取设备状态信息
     */
    @GET("device/status")
    Observable<BaseResponse<Device>> getDeviceStatus(@Query("deviceId") String deviceId);

    /**
     * 上传设备在线状态
     */
    @GET("device/set-online-state")
    Observable<BaseResponse<String>> uploadOnlineState(@Query("deviceId") String deviceId,
                                                       @Query("state") int state);

    /**
     * 上传设备使用次数历史
     */
    @POST("device/use-times-history/upload")
    Observable<BaseResponse<List<Integer>>> uploadUseTimesHistory(@Query("deviceId") String deviceId,
                                                                  @Body HashMap<String,Object> map);
}
