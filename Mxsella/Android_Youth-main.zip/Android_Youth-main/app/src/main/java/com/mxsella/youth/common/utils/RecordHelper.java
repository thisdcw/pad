package com.mxsella.youth.common.utils;

import com.mxsella.youth.bean.Record;
import com.mxsella.youth.bean.User;

import org.litepal.LitePal;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RecordHelper {
    private Record record;
    private ExecutorService service = Executors.newSingleThreadExecutor();

    public static RecordHelper getInstance() {
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static RecordHelper INSTANCE = new RecordHelper();
    }

    public void saveOrUpdate(Record record) {
        service.execute(() -> record.saveOrUpdate("userId = ?", String.valueOf(record.getUserId())));
    }
    public void deleteAllRecord() {
        LitePal.deleteAll(Record.class);
    }
    public void saveRecord(Record record) {
//        Log.d("Record: ", "save success"+record.toString() );
        service.execute(record::save);
    }
    public static int totalPageRecord(int userId, int size) {
        return (int) Math.ceil(LitePal.where("userId = ?", String.valueOf(userId)).count(Record.class) / (size * 1.0f));
    }
    public boolean deleteRecordByUserId(int userId) {
        return LitePal.deleteAll(Record.class, "userId = ?", String.valueOf(userId)) != 0;
    }
    public static int totalRecord(int userId) {
        return LitePal.where("userId = ?", String.valueOf(userId)).count(Record.class);
    }
    public static List<Record> getRecordList(int userId, int page, int size) {
        if(page < 1)
            page = 1;
        return LitePal.where("userId = ?", String.valueOf(userId)).order("usedDate DESC").limit(size).offset((page - 1) * size).limit(size).find(Record.class);
    }
    public List<Record> getRecordByUserId(int userId) {
        return LitePal.where("userId = ? AND count > 0", String.valueOf(userId)).order("usedDate DESC").find(Record.class);
    }

    public List<Record> getRecordList(int page, int size) {
        if(page < 1)
            page = 1;
        return LitePal.limit(size).offset((page - 1) * size).limit(size).find(Record.class);
    }

    public List<Record> getAllRecordList() {
        return LitePal.findAll(Record.class);
    }

    public int totalPage(int size,int userId) {
        return (int) Math.ceil(LitePal.where("userId = ? AND count > 0", String.valueOf(userId)).count(Record.class) / (size * 1.0f));
    }

    public int total(int userId) {
        return LitePal.where("userId = ? AND count > 0", String.valueOf(userId)).count(Record.class);
    }
}
