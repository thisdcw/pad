package com.mxsella.youth.push;

import com.google.gson.Gson;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class PushMessage<T> {

    private int status;
    private String actionName;
    private String msg = "";
    private String hashValue = "";
    private String dateTime = "";
    private long timeStamp = 0;
    private T data;

    public static PushMessage fromJson(String json, Class clazz) {
        Gson gson = new Gson();
        Type objectType = type(PushMessage.class, clazz);
        return gson.fromJson(json, objectType);
    }

    static ParameterizedType type(final Class raw, final Type... args) {
        return new ParameterizedType() {
            public Type getRawType() {
                return raw;
            }

            public Type[] getActualTypeArguments() {
                return args;
            }

            public Type getOwnerType() {
                return null;
            }
        };
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getHashValue() {
        return hashValue;
    }

    public void setHashValue(String hashValue) {
        this.hashValue = hashValue;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "PushMessage{" +
                "status=" + status +
                ", msg='" + msg + '\'' +
                ", hashValue='" + hashValue + '\'' +
                ", dateTime='" + dateTime + '\'' +
                ", timeStamp='" + timeStamp + '\'' +
                ", data=" + data +
                '}';
    }

    public String toJson(Class<T> clazz) {
        Gson gson = new Gson();
        Type objectType = type(PushMessage.class, clazz);
        return gson.toJson(this, objectType);
    }

}
