package com.mxsella.youth.common.utils;

import com.mxsella.youth.bean.PointMode;
import com.mxsella.youth.bean.PointMode;

import org.litepal.LitePal;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PointModeHelper {
    private PointMode pointMode;
    private ExecutorService service = Executors.newSingleThreadExecutor();

    public static PointModeHelper getInstance() {
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static PointModeHelper INSTANCE = new PointModeHelper();
    }

    public void saveOrUpdate(PointMode pointMode) {
        service.execute(() -> pointMode.saveOrUpdate("userId = ?", String.valueOf(pointMode.getUserId())));
    }
    public void savePointMode(PointMode pointMode) {
        service.execute(pointMode::save);
    }


    public PointMode getPointModeByUserId(int userId) {
        return LitePal.where("userId = ?", String.valueOf(userId)).findLast(PointMode.class);
    }

    public int total() {
        return LitePal.count(PointMode.class);
    }
}
