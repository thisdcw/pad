package com.mxsella.youth.bean;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;

public class LineMode extends LitePalSupport implements Serializable {
    private long userId;
    private double m1_power;
    private double m2_power;
    private double m3_power;
    private double m1_length;
    private double m2_length;
    private double m3_length;
    private double m1_spacing;
    private double m2_spacing;
    private double m3_spacing;
    private int line_total;
    private String date;
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public int getLine_total() {
        if (this.line_total==0){
            return 0;
        }
        return line_total;
    }

    public void setLine_total(int line_total) {
        this.line_total = line_total;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public double getM1_power() {
        if (this.m1_power==0){
            return 2.5;
        }
        return m1_power;
    }

    public void setM1_power(double m1_power) {
        this.m1_power = m1_power;
    }

    public double getM2_power() {
        if (this.m2_power==0){
            return 2.5;
        }
        return m2_power;
    }

    public void setM2_power(double m2_power) {
        this.m2_power = m2_power;
    }

    public double getM3_power() {
        if (this.m3_power==0){
            return 2.5;
        }
        return m3_power;
    }

    public void setM3_power(double m3_power) {
        this.m3_power = m3_power;
    }

    public double getM1_length() {
        if (this.m1_length==0){
            return 20;
        }
        return m1_length;
    }

    public void setM1_length(double m1_length) {
        this.m1_length = m1_length;
    }

    public double getM2_length() {
        if (this.m2_length==0){
            return 20;
        }
        return m2_length;
    }

    public void setM2_length(double m2_length) {
        this.m2_length = m2_length;
    }

    public double getM3_length() {
        if (this.m3_length==0){
            return 20;
        }
        return m3_length;
    }

    public void setM3_length(double m3_length) {
        this.m3_length = m3_length;
    }

    public double getM1_spacing() {
        if (this.m1_spacing==0){
            return 2.0;
        }
        return m1_spacing;
    }

    public void setM1_spacing(double m1_spacing) {
        this.m1_spacing = m1_spacing;
    }

    public double getM2_spacing() {
        if (this.m2_spacing==0){
            return 2.5;
        }
        return m2_spacing;
    }

    public void setM2_spacing(double m2_spacing) {
        this.m2_spacing = m2_spacing;
    }

    public double getM3_spacing() {
        if (this.m3_spacing==0){
            return 2.5;
        }
        return m3_spacing;
    }

    public void setM3_spacing(double m3_spacing) {
        this.m3_spacing = m3_spacing;
    }
}