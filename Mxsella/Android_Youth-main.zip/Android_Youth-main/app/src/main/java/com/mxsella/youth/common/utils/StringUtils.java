package com.mxsella.youth.common.utils;

import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class StringUtils {

    public static String getRandomString(int length){
        String str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random=new Random();
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<length;i++){
            int number=random.nextInt(62);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }

    public static String integerSerialize(List<Integer> list) {
        if (list == null) return "";
        StringBuilder builder = new StringBuilder();
        for (int i : list) {
            builder.append(i).append(",");
        }
        builder.deleteCharAt(builder.lastIndexOf(","));
        return builder.toString();
    }

    public static String stringSerialize(List<String> list) {
        if (list == null) return "";
        StringBuilder builder = new StringBuilder();
        for (String i : list) {
            builder.append(i).append(",");
        }
        builder.deleteCharAt(builder.lastIndexOf(","));
        return builder.toString();
    }

    public static List<Integer> integerDeserialize(String str) {
        if (TextUtils.isEmpty(str)) return new ArrayList<>();
        String[] strs = str.split(",");
        List<Integer> list = new ArrayList<>();
        for (String s: strs) {
            list.add(Integer.parseInt(s));
        }
        return list;
    }

    public static List<String> stringDeserialize(String str) {
        if (TextUtils.isEmpty(str)) return new ArrayList<>();
        String[] strs = str.split(",");
        List<String> list = new ArrayList<>();
        for (String s: strs) {
            list.add(s);
        }
        return list;
    }

    public static byte[] hexToByteArray(String inHex){
        int hexlen = inHex.length();
        byte[] result;
        if (hexlen % 2 == 1){
            //奇数
            hexlen++;
            result = new byte[(hexlen/2)];
            inHex="0"+inHex;
        }else {
            //偶数
            result = new byte[(hexlen/2)];
        }
        int j=0;
        for (int i = 0; i < hexlen; i+=2){
            result[j]=hexToByte(inHex.substring(i,i+2));
            j++;
        }
        return result;
    }

    /**
     * Hex字符串转byte
     * @param inHex 待转换的Hex字符串
     * @return  转换后的byte
     */
    public static byte hexToByte(String inHex){
        return (byte)Integer.parseInt(inHex,16);
    }

    public static String bytesToHex(byte[] bytes){
        String strHex = "";
        StringBuilder sb = new StringBuilder("");
        for (int n = 0; n < bytes.length; n++) {
            strHex = Integer.toHexString(bytes[n] & 0xFF);
            sb.append((strHex.length() == 1) ? "0" + strHex : strHex); // 每个字节由两个字符表示，位数不够，高位补0
        }
        return sb.toString().trim();
    }
}
