package com.mxsella.youth.presenter;

import com.mxsella.youth.contract.MainContract;

import java.util.Map;

public class UserRecordPresenter extends BasePresenter<MainContract.View>
        implements MainContract.Presenter{
    public UserRecordPresenter(MainContract.View view) {
        super(view);
    }

    @Override
    public void requestUpdate(Map<String, String> map) {

    }
}
