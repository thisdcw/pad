package com.mxsella.youth.bean;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;

public class PointMode extends LitePalSupport implements Serializable {

    private long userId;
    private double m1_power;
    private double m2_power;
    private double m3_power;
    private int m1_speed;
    private int m2_speed;
    private int m3_speed;
    private int m1_quantity;
    private int m2_quantity;
    private int m3_quantity;
    private int point_total;
    private String date;
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public int getPoint_total() {
        if (this.point_total == 0) {
            return 0;
        }
        return point_total;
    }

    public void setPoint_total(int point_total) {
        this.point_total = point_total;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public double getM1_power() {
        if (this.m1_power == 0) {
            return 2.5;
        }
        return m1_power;
    }

    public void setM1_power(double m1_power) {
        this.m1_power = m1_power;
    }

    public double getM2_power() {
        if (this.m2_power == 0) {
            return 2.5;
        }
        return m2_power;
    }

    public void setM2_power(double m2_power) {
        this.m2_power = m2_power;
    }

    public double getM3_power() {
        if (this.m3_power == 0) {
            return 2.5;
        }
        return m3_power;
    }

    public void setM3_power(double m3_power) {
        this.m3_power = m3_power;
    }

    public int getM1_speed() {
        if (this.m1_speed == 0) {
            return 2;
        }
        return m1_speed;
    }

    public void setM1_speed(int m1_speed) {
        this.m1_speed = m1_speed;
    }

    public int getM2_speed() {
        if (this.m2_speed == 0) {
            return 5;
        }
        return m2_speed;
    }

    public void setM2_speed(int m2_speed) {
        this.m2_speed = m2_speed;
    }

    public int getM3_speed() {
        if (this.m3_speed == 0) {
            return 5;
        }
        return m3_speed;
    }

    public void setM3_speed(int m3_speed) {
        this.m3_speed = m3_speed;
    }

    public int getM1_quantity() {
        if (this.m1_quantity == 0) {
            return 5;
        }
        return m1_quantity;
    }

    public void setM1_quantity(int m1_quantity) {
        this.m1_quantity = m1_quantity;
    }

    public int getM2_quantity() {
        if (this.m1_quantity == 0) {
            return 5;
        }
        return m2_quantity;
    }

    public void setM2_quantity(int m2_quantity) {
        this.m2_quantity = m2_quantity;
    }

    public int getM3_quantity() {
        if (this.m3_quantity == 0) {
            return 5;
        }
        return m3_quantity;
    }

    public void setM3_quantity(int m3_quantity) {
        this.m3_quantity = m3_quantity;
    }
}
