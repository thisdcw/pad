package com.mxsella.youth.contract;

import com.mxsella.youth.bean.UpdateInfo;

import java.util.Map;

public interface MainContract {

    interface Presenter extends BaseContract.Presenter {
        /**
         * 检查更新
         * @param map
         */
        void requestUpdate(Map<String, String> map);
    }

    interface View extends BaseContract.View<MainContract.Presenter> {
        /**
         * 更新弹窗
         * @param updateInfo
         */
        void showUpdateDialog(UpdateInfo updateInfo);
    }

}
