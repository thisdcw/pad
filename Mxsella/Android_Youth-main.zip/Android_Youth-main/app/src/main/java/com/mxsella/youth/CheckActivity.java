package com.mxsella.youth;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.widget.TextView;

import com.mxsella.youth.common.base.BaseMvpActivity;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.Constants;
import com.mxsella.youth.common.utils.UseTimesHistoryHelper;
import com.mxsella.youth.contract.CheckContract;
import com.mxsella.youth.presenter.CheckPresenter;
import com.mxsella.youth.service.OnlineService;
import com.tbruyelle.rxpermissions2.RxPermissions;

import butterknife.BindView;

public class CheckActivity extends BaseMvpActivity<CheckContract.Presenter>
        implements CheckContract.View {

    @Override
    public int getLayoutId() {
        return R.layout.activity_check;
    }

    @Override
    protected CheckContract.Presenter initPresenter() {
        return new CheckPresenter(this);
    }

//    @BindView(R.id.img_welcome_bkg)
//    ImageView imgWelcomeBkg;
    @BindView(R.id.tv_version)
    TextView tvVersion;
    @BindView(R.id.tv_deviceId)
    TextView tvDeviceId;

    @Override
    public void initView() {
        super.initView();

        tvVersion.setText(Config.versionName);
        tvDeviceId.setText(Config.deviceId);

        if (Build.VERSION.SDK_INT >= 23) {
            requestPermission();
            // 获取悬浮窗权限
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 0);
            } else {
                mPresenter.uploadUseTimesHistory(Config.deviceId, Config.getAllRemainTimes(), UseTimesHistoryHelper.getInstance().getNotUpload());
            }
        } else {
            mPresenter.uploadUseTimesHistory(Config.deviceId, Config.getAllRemainTimes(), UseTimesHistoryHelper.getInstance().getNotUpload());
        }
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        Intent startIntent = new Intent(this, OnlineService.class);
        startService(startIntent);
    }

    @Override
    protected void onRestart() {
        super.onRestart();

        mPresenter.uploadUseTimesHistory(Config.deviceId, Config.getAllRemainTimes(), UseTimesHistoryHelper.getInstance().getNotUpload());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(Config.onlineState == Constants.STATE_AWAIT) {
            Intent stopService = new Intent(CheckActivity.this, OnlineService.class);
            stopService(stopService);
        }
    }

    @Override
    public void jumpToMain(boolean jump) {
        if(jump) {
            showWelcomeBkgUrl();
        }
    }

    public void showWelcomeBkgUrl() {
        if(Config.getWelcomeBkgState()) {
            new Handler().postDelayed(this::enterMain, 5000);
        } else {
            enterMain();
        }
    }

    public void enterMain() {
        UseTimesHistoryHelper.getInstance().setOnline();
        startActivity(new Intent(CheckActivity.this, MainActivity.class));
        finish();
    }

    @SuppressLint("CheckResult")
    private void requestPermission() {
        RxPermissions rxPermission = new RxPermissions(CheckActivity.this);
        rxPermission.requestEach(Manifest.permission.RECEIVE_BOOT_COMPLETED,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.CHANGE_NETWORK_STATE,
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.ACCESS_NETWORK_STATE,
                Manifest.permission.VIBRATE,
                Manifest.permission.SYSTEM_ALERT_WINDOW)
                .subscribe( permission ->  {
                });
    }
}