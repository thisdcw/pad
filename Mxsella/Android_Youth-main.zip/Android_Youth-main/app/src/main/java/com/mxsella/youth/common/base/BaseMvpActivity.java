package com.mxsella.youth.common.base;

import android.content.Context;

import com.mxsella.youth.contract.BaseContract;

public abstract class BaseMvpActivity<T extends BaseContract.Presenter>
        extends BaseActivity implements BaseContract.View<T> {

    protected T mPresenter;

    protected abstract T initPresenter();

    @Override
    public void setPresenter(T presenter) {
        this.mPresenter = presenter;
    }

    @Override
    public void initView() {
        super.initView();
        initPresenter();
    }

    @Override
    public Context getContext() {
        return this;
    }

    @Override
    public void onDestroy() {
        if (mPresenter != null) {
            mPresenter.detach();
        }
        super.onDestroy();
    }
}
