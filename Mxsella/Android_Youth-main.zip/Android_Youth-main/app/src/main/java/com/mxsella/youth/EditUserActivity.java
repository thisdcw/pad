package com.mxsella.youth;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.mxsella.youth.bean.User;
import com.mxsella.youth.common.base.BaseActivity;
import com.mxsella.youth.common.utils.ToastUtil;
import com.mxsella.youth.common.utils.UserHelper;
import com.mxsella.youth.common.widget.DateChooseDialog;
import com.mxsella.youth.common.widget.SoftKeyboardStateHelper;

import java.util.Calendar;

import butterknife.BindView;
import butterknife.OnClick;

public class EditUserActivity extends BaseActivity {

    public static String USER = "user";

    @BindView(R.id.return_btn)
    ImageView return_btn;
    @BindView(R.id.edt_username)
    EditText edtUsername;
    @BindView(R.id.edt_telephone)
    EditText edtTelephone;
    @BindView(R.id.edt_birth)
    EditText edtBirth;
    @BindView(R.id.edt_age)
    EditText edtAge;
    @BindView(R.id.edt_weight)
    EditText edtWeight;
    @BindView(R.id.edt_other)
    EditText edtOther;
    @BindView(R.id.radio_group)
    RadioGroup radioGroup;
    @BindView(R.id.radio_female)
    RadioButton radio_female;
    @BindView(R.id.radio_male)
    RadioButton radio_male;

    private User user;

    private InputMethodManager manager;

    public static void show(Context context, User user) {
        Intent intent = new Intent();
        intent.putExtra(USER, user);
        intent.setClass(context, EditUserActivity.class);
        context.startActivity(intent);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_edit_user;
    }

    @Override
    public void initView() {
        super.initView();

        return_btn.setOnClickListener(v -> {
            navigateTo(ManageActivity.class);
            finish();
        });

        user = (User) getIntent().getSerializableExtra(USER);
        edtUsername.setText(user.getUsername());
        edtTelephone.setText(user.getTelephone());
        edtBirth.setText(user.getBirth());
        edtAge.setText(String.valueOf(user.getAge()));
        edtWeight.setText(String.valueOf(user.getWeight()));
        edtOther.setText(user.getOther());

        if (user.getSex() == 0) {
            radioGroup.check(R.id.radio_female);
            radio_female.setBackgroundResource(R.drawable.sex_radio_select);
        } else {
            radioGroup.check(R.id.radio_male);
            radio_male.setBackgroundResource(R.drawable.sex_radio_select);
        }
        radioGroup.setOnCheckedChangeListener((radioGroup, i) -> {
            if (i == R.id.radio_female) {
                radio_male.setBackgroundResource(R.drawable.sex_radio_unselect);
                radio_female.setBackgroundResource(R.drawable.sex_radio_select);
                user.setSex(0);
            } else if (i == R.id.radio_male) {
                radio_female.setBackgroundResource(R.drawable.sex_radio_unselect);
                radio_male.setBackgroundResource(R.drawable.sex_radio_select);
                user.setSex(1);
            }
        });
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        manager = ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE));
        SoftKeyboardStateHelper helper = new SoftKeyboardStateHelper(edtUsername);
        helper.addSoftKeyboardStateListener(new SoftKeyboardStateHelper.SoftKeyboardStateListener() {
            @Override
            public void onSoftKeyboardOpened(int keyboardHeightInPx) {
            }

            @Override
            public void onSoftKeyboardClosed() {
                hideBottomUIMenu();
            }
        });
        setFocusChangeListener(edtUsername);
        setFocusChangeListener(edtAge);
        setFocusChangeListener(edtTelephone);
        setFocusChangeListener(edtBirth);
        setFocusChangeListener(edtWeight);
        setFocusChangeListener(edtOther);
    }

    @OnClick(R.id.return_btn)
    public void onReturnClick() {
        finish();
    }


    private int mYear, mMonth, mDay;

    @OnClick({R.id.btn_birth_select, R.id.btn_save})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_birth_select:
                if (mYear == 0) {
                    Calendar ca = Calendar.getInstance();
                    mYear = ca.get(Calendar.YEAR);
                    mMonth = ca.get(Calendar.MONTH);
                    mDay = ca.get(Calendar.DAY_OF_MONTH);
                }
                DateChooseDialog dateChooseDialog = new DateChooseDialog(this, R.style.DialogDateChoose,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                edtBirth.setText(year + "-" + String.format("%02d", (month + 1)) + "-" + String.format("%02d", dayOfMonth));
                                mYear = year;
                                mMonth = month;
                                mDay = dayOfMonth;
                                Calendar ca = Calendar.getInstance();
                                int age = ca.get(Calendar.YEAR) - year;
                                if (age <= 0) {
                                    age = 0;
                                } else {
                                    if (ca.get(Calendar.MONTH) - month < 0) {
                                        age -= 1;
                                    } else if (ca.get(Calendar.DAY_OF_MONTH) - dayOfMonth > 0) {
                                        age -= 1;
                                    }
                                }
                                edtAge.setText(String.valueOf(age));
                            }
                        },
                        mYear, mMonth, mDay);
                DatePicker datePicker = dateChooseDialog.getDatePicker();
                datePicker.setCalendarViewShown(false);
                datePicker.setSpinnersShown(true);
                dateChooseDialog.show();
                break;
            case R.id.btn_save:
                if (TextUtils.isEmpty(edtUsername.getText().toString())) {
                    ToastUtil.showToast(getResources().getString(R.string.no_empty_name));
                    return;
                }
                if (UserHelper.getInstance().getUserByName(edtUsername.getText().toString().trim())){
                    ToastUtil.showToast(getResources().getString(R.string.no_repeat_name));
                    return;
                }
                if (TextUtils.isEmpty(edtTelephone.getText().toString())) {
                    ToastUtil.showToast(getResources().getString(R.string.no_empty_telephone));
                    return;
                }
                if (TextUtils.isEmpty(edtAge.getText().toString())) {
                    ToastUtil.showToast(getResources().getString(R.string.no_empty_age));
                    return;
                }
                user.setUsername(edtUsername.getText().toString());
                user.setTelephone(edtTelephone.getText().toString());
                user.setBirth(edtBirth.getText().toString());
                user.setAge(Integer.parseInt(edtAge.getText().toString()));
                user.setWeight(Integer.parseInt(edtWeight.getText().toString()));
                user.setOther(edtOther.getText().toString());
                UserHelper.getInstance().saveOrUpdate(user);
                finish();
                break;
            default:
                break;
        }
    }

    public void setFocusChangeListener(EditText editText) {
        editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (!hasFocus) {
                    if (manager != null) {
                        manager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                        hideBottomUIMenu();
                    }
                }
            }
        });
    }
}