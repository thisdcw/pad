package com.mxsella.youth.common.net;

import com.mxsella.youth.common.MyApplication;
import com.mxsella.youth.common.utils.LocalLog;

import java.io.File;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class TxtNetworkService {

    private volatile static TxtNetworkService instance;
    private final ApiService mService;

    private TxtNetworkService() {
        // 指定缓存路径和大小
        final Cache cache = new Cache(new File(MyApplication.getInstance().getCacheDir(), "HttpCache"),
                1024*1024*1024);

        final OkHttpClient client = new OkHttpClient.Builder()
                .cache(cache)
                .addInterceptor(chain -> {
                    // 拿到请求
                    Request original = chain.request();
                    // 重新进行build
                    Request.Builder builder = original.newBuilder();
                    builder.addHeader("Content-Type","multipart/form-data;charset=utf-8");
                    Request newRequest = builder.build();
                    return chain.proceed(newRequest);
                })
                .addInterceptor(getLoggerInterceptor())
                .writeTimeout(30*1000, TimeUnit.MILLISECONDS)
                .readTimeout(20*1000, TimeUnit.MILLISECONDS)
                .connectTimeout(6*1000, TimeUnit.MILLISECONDS)
                // 请求失败重试
                .retryOnConnectionFailure(true)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(client)
                .baseUrl(ApiService.BASE_URL)
                .build();
        mService = retrofit.create(ApiService.class);
    }

    public static ApiService getApi() {

        if (instance == null) {
            synchronized(ApiService.class) {
                if (instance == null) {
                    instance = new TxtNetworkService();
                }
            }
        }

        return instance.mService;
    }

    public final static HttpLoggingInterceptor getLoggerInterceptor() {
        // 日志显示级别
        HttpLoggingInterceptor.Level level = HttpLoggingInterceptor.Level.HEADERS;

        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor(message -> {
            LocalLog.d("ApiUrl","----->"+message);
        });
        loggingInterceptor.setLevel(level);
        return loggingInterceptor;
    }
}
