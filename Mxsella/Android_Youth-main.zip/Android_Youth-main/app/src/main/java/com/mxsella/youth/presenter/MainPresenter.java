package com.mxsella.youth.presenter;

import android.util.Log;

import com.mxsella.youth.bean.UpdateInfo;
import com.mxsella.youth.common.net.BaseObserver;
import com.mxsella.youth.bean.BaseResponse;
import com.mxsella.youth.common.net.NetworkService;
import com.mxsella.youth.common.net.RxScheduler;
import com.mxsella.youth.contract.MainContract;

import java.util.Map;

public class MainPresenter extends BasePresenter<MainContract.View>
        implements MainContract.Presenter{

    public MainPresenter(MainContract.View view) {
        super(view);
    }

    @Override
    public void requestUpdate(Map<String, String> map) {
        addDisposable(NetworkService.getApi().requestUpdate(map)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<UpdateInfo>>() {
                    @Override
                    public void onSuccess(BaseResponse<UpdateInfo> data) {
                        if (data.getCode() == 1) {
                            Log.d("requestUpdate",data.getData().toString());
                            mView.showUpdateDialog(data.getData());
                        }
                    }
                }));
    }
}
