package com.mxsella.youth.push;

import static com.blankj.utilcode.util.ActivityUtils.startActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.mxsella.youth.CheckActivity;
import com.mxsella.youth.common.MyApplication;
import com.mxsella.youth.common.base.BaseActivity;
import com.mxsella.youth.common.utils.AppUtils;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.GsonUtils;
import com.mxsella.youth.common.utils.LocalLog;
import com.mxsella.youth.common.utils.ToastUtil;

@SuppressLint("ShowToast")
public class MessageHandler {

    public static final String TAG = "MessageHandler";

    private static final String RESET_PASSWORD = "resetPassword";  // 重置密码
    private static final String LOCK_DEVICE = "lockDevice";  // 锁定设备

    /**
     * 统一处理个推和极光消息
     */
    public static void pushMessage(final Context context, String data) {
        PushMessage msg = GsonUtils.deserialize(data, PushMessage.class);
        if (msg == null) return;
        String hashValue = msg.getHashValue();
        synchronized (PushUtils.pushSync) {
            if (!PushUtils.isNeedHandle(hashValue)) {
                LocalLog.d(TAG, "||推送 消息重复:" + hashValue);
                return;
            }
            PushUtils.pushSync[PushUtils.lastPushId] = hashValue;
            PushUtils.lastPushId = (PushUtils.lastPushId + 1)
                    % PushUtils.pushNum;
        }
        String actionName = msg.getActionName();
        if (actionName != null) {
            switch (actionName) {
                case RESET_PASSWORD:
                    Config.saveOrUpdatePassword(Config.DEFAULT_PASSWORD);
                    break;
                case LOCK_DEVICE:
                    // 处理设备锁定的推送消息，返回检查页，如果在工作页，下发结束指令
                    ToastUtil.showToast("设备已锁定");
                    Log.d(TAG, "-------------> pushMessage: 设备已锁定");
                    Config.saveOrUpdateActiveState(false);
                    AppUtils.reStartApp(context, 0, true);
                    break;
            }
        }
    }

}
