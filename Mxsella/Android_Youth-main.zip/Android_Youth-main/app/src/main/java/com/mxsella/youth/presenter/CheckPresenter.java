package com.mxsella.youth.presenter;

import android.util.Log;

import com.mxsella.youth.R;
import com.mxsella.youth.bean.Device;
import com.mxsella.youth.bean.UseTimesHistory;
import com.mxsella.youth.common.net.BaseObserver;
import com.mxsella.youth.bean.BaseResponse;
import com.mxsella.youth.common.net.NetworkService;
import com.mxsella.youth.common.net.RxScheduler;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.Constants;
import com.mxsella.youth.common.utils.LocalLog;
import com.mxsella.youth.common.utils.StringUtils;
import com.mxsella.youth.common.utils.ToastUtil;
import com.mxsella.youth.contract.CheckContract;

import java.util.HashMap;
import java.util.List;

public class CheckPresenter extends BasePresenter<CheckContract.View>
        implements CheckContract.Presenter {

    private static final String TAG = "CheckPresenter";

    private int reconnect = 2;
    private boolean ifSuccess = false;

    public CheckPresenter(CheckContract.View view) {
        super(view);
    }

    @Override
    public void uploadUseTimesHistory(String deviceId, List<Integer> remainTimes, List<UseTimesHistory> useTimesHistoryList) {

        HashMap<String, Object> map = new HashMap<>();
        map.put("remainTimes", remainTimes);
        map.put("history", useTimesHistoryList);
//        Log.d(TAG, "------>"+map);
        addDisposable(NetworkService.getApi().uploadUseTimesHistory(deviceId, map)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<List<Integer>>>() {
                    @Override
                    public void onSuccess(BaseResponse<List<Integer>> data) {
//                        Log.d("Data onSuccess", "------------------->: " + data.toString());
                        if (data.getCode() == Constants.SUCCESS) {
                            for (int i = 0; i < data.getData().size(); i++) {
//                                Log.d(TAG, i + "onSuccess: " + data.getData().get(i));
                                Config.saveRemainTimes(i, data.getData().get(i));
                            }
                            for (UseTimesHistory h : useTimesHistoryList) {
                                h.setIfUpload(true);
                                h.save();
                            }
                        }
                        queryDeviceStatus(deviceId);
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
//                        Log.d("Data onFail", "------------------->: " + errorMsg);
                        queryDeviceStatus(deviceId);
                    }
                }));
    }

    @Override
    public void queryDeviceStatus(String deviceId) {
        addDisposable(NetworkService.getApi().getDeviceStatus(deviceId)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<Device>>() {
                    @Override
                    public void onSuccess(BaseResponse<Device> data) {
                        if (ifSuccess) {
                            return;
                        } else {
                            ifSuccess = true;
                        }
                        if (data.getCode() == Constants.SUCCESS) {
                            Device device = data.getData();
                            Config.saveOrUpdateActiveState(device.getActive());
                            Config.saveCommMode(device.getCommMode());
                            Config.saveWelcomeBkgState(device.getWelcomeBkgState());
                            Config.saveWelcomeBkgUrl(device.getWelcomeBkgUrl());
                            Config.saveMainBkgUrl(device.getMainBkgUrl());
                            Config.saveLogoUrl(device.getLogoUrl());
                            if (device.getActive()) {
                                Config.saveLastActiveTime(System.currentTimeMillis());
                                mView.jumpToMain(true);
                            } else {
                                ToastUtil.showToast(mView.getContext().getString(R.string.no_active));
                            }
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                        ToastUtil.showToast(errorMsg);
                        if (Config.isAlreadyActive()) {
                            if (System.currentTimeMillis() - Config.getLastActiveTime() > 7 * 24 * 60 * 60 * 1000) {
                                if (reconnect > 0) {
                                    reconnect--;
                                    queryDeviceStatus(Config.deviceId);
                                } else {
                                    ToastUtil.showToast(mView.getContext().getString(R.string.net_to_active));
                                }
                                return;
                            }
                            mView.jumpToMain(true);
                        } else {
                            ToastUtil.showToast(mView.getContext().getString(R.string.no_active));
                        }
                    }
                }));
    }
}
