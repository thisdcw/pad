package com.mxsella.youth.common.utils;

import com.mxsella.youth.bean.Record;
import com.mxsella.youth.bean.User;

import org.litepal.LitePal;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UserHelper {

    private User loginUser;
    private ExecutorService service = Executors.newSingleThreadExecutor();

    public static UserHelper getInstance() {
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static UserHelper INSTANCE = new UserHelper();
    }

    public void saveOrUpdate(User user) {
        service.execute(() -> user.saveOrUpdate("userId = ?", String.valueOf(user.getUserId())));
    }

    public void deleteAllUsers() {
        LitePal.deleteAll(User.class);
    }

    public boolean deleteByUserId(int userId) {
        return LitePal.deleteAll(User.class, "userId = ?", String.valueOf(userId)) != 0;
    }

    public User getUserById(int userId) {
        return LitePal.where("userId = ?", String.valueOf(userId)).findLast(User.class);
    }

    public boolean getUserByName(String name) {
        return LitePal.where("username = ?", String.valueOf(name)).findLast(User.class) != null;
    }

    public int totalPageUser(int size) {
        return (int) Math.ceil(LitePal.count(User.class) / (size * 1.0f));
    }

    public List<User> getUserList(int page, int size) {
        if (page < 1)
            page = 1;
        return LitePal.limit(size).offset((page - 1) * size).limit(size).find(User.class);
    }

    public List<User> getAllUserList() {
        return LitePal.findAll(User.class);
    }

    public int totalPage(int size) {
        return (int) Math.ceil(LitePal.count(User.class) / (size * 1.0f));
    }

    public int total() {
        return LitePal.count(User.class);
    }

    public List<User> getUserListByKeyword(String keyword, int page, int size) {
        if (page < 1)
            page = 1;
        return LitePal.where("username like ? or telephone like ?", "%" + keyword + "%", "%" + keyword + "%").
                limit(size).offset((page - 1) * size).limit(size).find(User.class);
    }

    public List<User> getAllUserListByKeyword(String keyword) {
        return LitePal.where("username like ? or telephone like ?", "%" + keyword + "%", "%" + keyword + "%").find(User.class);
    }

    public int totalPageByKeyword(String keyword, int size) {
        int count = LitePal.where("username like ? or telephone like ?", "%" + keyword + "%", "%" + keyword + "%").count(User.class);
        return (int) Math.ceil(count / (size * 1.0f));
    }

    public int totalByKeyword(String keyword) {
        return LitePal.where("username like ? or telephone like ?", "%" + keyword + "%", "%" + keyword + "%").count(User.class);
    }
}
