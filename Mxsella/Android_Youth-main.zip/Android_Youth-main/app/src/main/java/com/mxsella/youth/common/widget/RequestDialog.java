package com.mxsella.youth.common.widget;

import android.app.Dialog;
import android.content.Context;

import androidx.annotation.NonNull;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.mxsella.youth.R;
import com.mxsella.youth.common.utils.NavigationBarUtil;

import java.util.Objects;

public class RequestDialog extends Dialog {

    private Context context;
    private String request;
    private int position;

    private TextView tvRequest;
    private Button btnConfirm;
    private Button btnCancel;

    private ImageView qr;

    public RequestDialog(@NonNull Context context, String request) {
        super(context);
        this.context = context;
        this.request = request;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_request, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        tvRequest = view.findViewById(R.id.tv_request);
        btnConfirm = view.findViewById(R.id.btn_confirm);
        btnCancel = view.findViewById(R.id.btn_cancel);
        qr = view.findViewById(R.id.qr_code);
        tvRequest.setText(request);
    }
    public void setQRVisible(int visible) {
        if (visible == View.VISIBLE || visible == View.INVISIBLE || visible == View.GONE) {
            qr.setVisibility(visible);
        } else {
            throw new IllegalArgumentException("Invalid visibility parameter for confirmBtn");
        }
    }
    public void setConfirmVisible(int visible) {
        if (visible == View.VISIBLE || visible == View.INVISIBLE || visible == View.GONE) {
            btnConfirm.setVisibility(visible);
        } else {
            throw new IllegalArgumentException("Invalid visibility parameter for confirmBtn");
        }
    }

    public void setCancelVisible(int visible) {
        if (visible == View.VISIBLE || visible == View.INVISIBLE || visible == View.GONE) {
            btnCancel.setVisibility(visible);
        } else {
            throw new IllegalArgumentException("Invalid visibility parameter for cancelBtn");
        }
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public void setConfirmClickListener(View.OnClickListener listener) {
        btnConfirm.setOnClickListener(listener);
    }

    public void setCancelClickListener(View.OnClickListener listener) {
        btnCancel.setOnClickListener(listener);
    }

    @Override
    public void show() {
        Objects.requireNonNull(getWindow()).setBackgroundDrawable(null);
        NavigationBarUtil.focusNotAle(getWindow());
        try {
            super.show();
        } catch (Exception e) {
            e.printStackTrace();
        }

        NavigationBarUtil.hideNavigationBar(getWindow());
        NavigationBarUtil.clearFocusNotAle(getWindow());
    }
}
