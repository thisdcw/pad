package com.mxsella.youth.contract;

import com.mxsella.youth.bean.UseTimesHistory;

import java.util.List;

public interface CheckContract {

    interface Presenter extends BaseContract.Presenter {

        /**
         * 上传使用次数记录
         */
        void uploadUseTimesHistory(String deviceId, List<Integer> remainTimes, List<UseTimesHistory> useTimesHistoryList);

        /**
         * 查询设备激活信息
         */
        void queryDeviceStatus(String deviceId);

    }

    interface View extends BaseContract.View<Presenter> {

        /**
         * 跳转到主页
         */
        void jumpToMain(boolean jump);
    }
}
