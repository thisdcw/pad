package com.mxsella.youth.common.utils;

import android.content.Context;
import android.widget.Toast;

import com.mxsella.youth.common.MyApplication;

public class ToastUtil {

    private static final float ALERT_BASE_WIDTH = 1024;

    public static void showToast(String info) {
        showToast(MyApplication.getInstance(), info);
    }

    public static void showLongToast(String info) {
        showLongToast(MyApplication.getInstance(), info);
    }

    public static void showToast(Context context, String info) {
        if (context != null) {
            Toast.makeText(context, info, Toast.LENGTH_SHORT).show();
        }
    }

    public static void showLongToast(Context context, String info) {
        if (context != null) {
            Toast.makeText(context, info, Toast.LENGTH_LONG).show();
        }
    }
}
