package com.mxsella.youth;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.blankj.utilcode.util.LanguageUtils;
import com.mxsella.youth.common.base.BaseActivity;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.RecordHelper;
import com.mxsella.youth.common.utils.ToastUtil;
import com.mxsella.youth.common.utils.UserHelper;

import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;

public class SettingsActivity extends BaseActivity {

    @BindView(R.id.return_btn)
    ImageView return_btn;
    @BindView(R.id.et_old_password)
    EditText et_old_password;
    @BindView(R.id.et_new_password)
    EditText et_new_password;
    @BindView(R.id.password_save)
    Button save_btn;
    @BindView(R.id.btn_lang_chinese)
    Button btnLangChinese;
    @BindView(R.id.btn_lang_english)
    Button btnLangEnglish;
    @BindView(R.id.btn_lang_korean)
    Button btnLangKorean;
    @BindView(R.id.iv_old_password_view)
    ImageView iv_old_password_view;
    @BindView(R.id.iv_new_password_view)
    ImageView iv_new_password_view;
    private String currentLang;
    private String lang;
    int selectionOldStart;
    int selectionOldEnd;
    int selectionStart;
    int selectionEnd;
    @Override
    public int getLayoutId() {
        return R.layout.activity_settings;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void initView() {
        super.initView();
        currentLang = Config.getLanguage();
        Log.d("language",currentLang);
        if (TextUtils.isEmpty(currentLang)) {
            Config.saveLanguage(this.getResources().getConfiguration().locale.getLanguage());
            currentLang = Config.getLanguage();
        }
        Log.d("language",currentLang);
        lang = currentLang;
        switch (currentLang) {
            case "zh":
                btnLangChinese.setSelected(true);
                break;
            case "en":
                btnLangEnglish.setSelected(true);
                break;
            case "ko":
                btnLangKorean.setSelected(true);
                break;
        }

        iv_old_password_view.setOnTouchListener((v, event) -> {
            int action = event.getAction();
            if (v.getId() == R.id.iv_old_password_view) {
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        iv_old_password_view.setSelected(true);
                        selectionOldStart = et_old_password.getSelectionStart();
                        selectionOldEnd = et_old_password.getSelectionEnd();
                        et_old_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                        et_old_password.setSelection(selectionOldStart, selectionOldEnd);
                        break;
                    case MotionEvent.ACTION_UP:
                        iv_old_password_view.setSelected(false);
                        selectionStart = et_old_password.getSelectionStart();
                        selectionEnd = et_old_password.getSelectionEnd();
                        et_old_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        et_old_password.setSelection(selectionStart, selectionEnd);
                        break;
                }
            }
            return true;
        });

        iv_new_password_view.setOnTouchListener((v, event) -> {
            int action = event.getAction();
            if (v.getId() == R.id.iv_new_password_view) {
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        iv_new_password_view.setSelected(true);
                        selectionStart = et_new_password.getSelectionStart();
                        selectionEnd = et_new_password.getSelectionEnd();
                        et_new_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                        et_new_password.setSelection(selectionStart, selectionEnd);
                        break;
                    case MotionEvent.ACTION_UP:
                        iv_old_password_view.setSelected(false);
                        selectionStart = et_new_password.getSelectionStart();
                        selectionEnd = et_new_password.getSelectionEnd();
                        et_new_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        et_new_password.setSelection(selectionStart, selectionEnd);
                        break;
                }
            }
            return true;
        });

        et_old_password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().equals("aa6546")) {
                   UserHelper.getInstance().deleteAllUsers();
                   RecordHelper.getInstance().deleteAllRecord();
                   navigateTo(MainActivity.class);
                   finish();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    @OnClick(R.id.return_btn)
    public void onReturnClick() {
        finish();
    }

    @OnClick({R.id.password_save, R.id.tv_confirm, R.id.btn_lang_chinese, R.id.btn_lang_english,R.id.btn_lang_korean})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.password_save:
                String curr_password = Config.getPassword();
                String old_password = et_old_password.getText().toString();
                if (curr_password.equals(old_password)) {
                    String new_password = et_new_password.getText().toString();
                    Config.saveOrUpdatePassword(new_password);
                    navigateTo(MainActivity.class);
                    this.finish();
                } else {
                    ToastUtil.showToast(this.getResources().getString(R.string.correct_old_password_info));
                    break;
                }
                break;
            case R.id.tv_confirm:
                if (currentLang.equals(lang)) {
                    ToastUtil.showToast(getResources().getString(R.string.no_change_language));
                } else {
                    Config.saveLanguage(lang);
                    if (lang.equals("zh")) {
                        // 会更改系统density导致适配失效，暂时在BaseActivity中重写getResources方法，后续需要调整
                        LanguageUtils.applyLanguage(Locale.SIMPLIFIED_CHINESE, true);
                    } else if (lang.equals("en")) {
                        LanguageUtils.applyLanguage(Locale.ENGLISH, true);
                    }else if (lang.equals("ko")) {
                        LanguageUtils.applyLanguage(Locale.KOREA, true);
                    }
                    ToastUtil.showToast(getResources().getString(R.string.change_language_success));
                }
                break;
            case R.id.btn_lang_chinese:
                lang = "zh";
                btnLangChinese.setSelected(true);
                btnLangEnglish.setSelected(false);
                btnLangKorean.setSelected(false);
                break;
            case R.id.btn_lang_english:
                lang = "en";
                btnLangChinese.setSelected(false);
                btnLangKorean.setSelected(false);
                btnLangEnglish.setSelected(true);
                break;
            case R.id.btn_lang_korean:
                lang = "ko";
                btnLangChinese.setSelected(false);
                btnLangEnglish.setSelected(false);
                btnLangKorean.setSelected(true);
                break;
            default:
                break;
        }
    }

}