package com.mxsella.youth.bean;

import java.io.Serializable;

public class Device implements Serializable {

    private String deviceId;
    private boolean active;
    private String commMode;
    private boolean welcomeBkgState;
    private String welcomeBkgUrl;
    private String mainBkgUrl;
    private String logoUrl;

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getCommMode() {
        return commMode;
    }

    public void setCommMode(String commMode) {
        this.commMode = commMode;
    }

    public boolean getWelcomeBkgState() {
        return welcomeBkgState;
    }

    public void setWelcomeBkgState(boolean welcomeBkgState) {
        this.welcomeBkgState = welcomeBkgState;
    }

    public String getWelcomeBkgUrl() {
        return welcomeBkgUrl;
    }

    public void setWelcomeBkgUrl(String welcomeBkgUrl) {
        this.welcomeBkgUrl = welcomeBkgUrl;
    }

    public String getMainBkgUrl() {
        return mainBkgUrl;
    }

    public void setMainBkgUrl(String mainBkgUrl) {
        this.mainBkgUrl = mainBkgUrl;
    }

    public String getLogoUrl() {
        return logoUrl;
    }

    public void setLogoUrl(String logoUrl) {
        this.logoUrl = logoUrl;
    }

    @Override
    public String toString() {
        return "Device{" +
                "deviceId='" + deviceId + '\'' +
                ", active=" + active +
                ", commMode='" + commMode + '\'' +
                ", welcomeBkgState=" + welcomeBkgState +
                ", welcomeBkgUrl='" + welcomeBkgUrl + '\'' +
                ", mainBkgUrl='" + mainBkgUrl + '\'' +
                ", logoUrl='" + logoUrl + '\'' +
                '}';
    }
}
