package com.mxsella.youth.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import com.mxsella.youth.bean.BaseResponse;
import com.mxsella.youth.common.net.BaseObserver;
import com.mxsella.youth.common.net.NetworkService;
import com.mxsella.youth.common.net.RxScheduler;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.Constants;
import com.mxsella.youth.common.utils.UseTimesHistoryHelper;

import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

public class OnlineService extends Service {

    private boolean isDestroy = false;
    private CompositeDisposable mDisposables;

    public OnlineService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> {
            while (!isDestroy) {
                UseTimesHistoryHelper.getInstance().updateOnlineState();
                UseTimesHistoryHelper.getInstance().updateUseTimesHistory();
                try {
                    Thread.sleep(20000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(!isDestroy) {
            isDestroy = true;
            Config.onlineState = Constants.STATE_OFFLINE;
            UseTimesHistoryHelper.getInstance().updateOnlineState();
            UseTimesHistoryHelper.getInstance().updateUseTimesHistory();
        }
        //unDisposable();
    }

    public void addDisposable(Disposable disposable) {
        if (mDisposables == null || mDisposables.isDisposed()) {
            mDisposables = new CompositeDisposable();
        }
        mDisposables.add(disposable);
    }

    public void unDisposable() {
        if (mDisposables != null) {
            mDisposables.clear();
        }
    }
}