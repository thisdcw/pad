package com.mxsella.youth.comm;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class ImitateReceiveProtocol {

    public static byte[] LINE_UNCONNECTED = Protocol.hexToByteArray("5AA5058210460001");//line未连接
    public static byte[] LINE_CONNECTED = Protocol.hexToByteArray("5AA5058210460000");//line已连接
    public static byte[] POINT_UNCONNECTED = Protocol.hexToByteArray("5AA5058210480001");//point未连接
    public static byte[] POINT_CONNECTED = Protocol.hexToByteArray("5AA5058210480000");//point已连接
    public static byte[] SPACING = Protocol.hexToByteArray("5AA5058210080010");
    public static byte[] LENGTH = Protocol.hexToByteArray("5AA505821012"+intToBytes(10));
    public static byte[] LINE_POWER = Protocol.hexToByteArray("5AA505821014"+intToBytes(10));
    public static byte[] LINE_FREQUENCY = Protocol.hexToByteArray("5AA505821003XXXX");
    public static byte[] LINE_SHOTS_DONE = Protocol.hexToByteArray("5AA505821007XXXX");
    public static byte[] LINE_SHOTS_REMAIN = Protocol.hexToByteArray("5AA505821009XXXX");
    public static byte[] LINE_M1 = Protocol.hexToByteArray("5AA505821060"+intToBytes(1));
    public static byte[] LINE_M2 = Protocol.hexToByteArray("5AA5058210600002");
    public static byte[] LINE_M3 = Protocol.hexToByteArray("5AA5058210600003");
    public static byte[] LINE_MP = Protocol.hexToByteArray("5AA5058210920000");
    public static byte[] LINE_NORMAL = Protocol.hexToByteArray("5AA5058210920001");
    public static byte[] SPEED = Protocol.hexToByteArray("5AA50582100AXXXX");
    public static byte[] QUANTITY = Protocol.hexToByteArray("5AA50582100EXXXX");
    public static byte[] POINT_POWER = Protocol.hexToByteArray("5AA50582101CXXXX");
    public static byte[] POINT_FREQUENCY = Protocol.hexToByteArray("5AA505821030XXXX");
    public static byte[] POINT_SHOTS_DONE = Protocol.hexToByteArray("5AA505821034XXXX");
    public static byte[] POINT_SHOTS_REMAIN = Protocol.hexToByteArray("5AA505821036XXXX");
    public static byte[] POINT_UNM = Protocol.hexToByteArray("5AA50582106A0000");
    public static byte[] POINT_M1 = Protocol.hexToByteArray("5AA50582106A0001");
    public static byte[] POINT_M2 = Protocol.hexToByteArray("5AA50582106A0002");
    public static byte[] POINT_M3 = Protocol.hexToByteArray("5AA50582106A0003");
    public static byte[] POINT_UN_MODE = Protocol.hexToByteArray("5AA5058210960000");
    public static byte[] POINT_MP = Protocol.hexToByteArray("5AA5058210960001");
    public static byte[] POINT_NORMAL = Protocol.hexToByteArray("5AA5058210960002");
    public static byte[] LINE = Protocol.hexToByteArray("5AA50582100BXXXX");
    public static byte[] LINE_TOTAL = Protocol.hexToByteArray("5AA505821020XXXX");
    public static byte[] POINT = Protocol.hexToByteArray("5AA50582100DXXXX");
    public static byte[] POINT_TOTAL = Protocol.hexToByteArray("5AA505821022XXXX");
    //    "M4.5", "M3.0", "M1.5", "D4.5", "D3.0"
    public static byte[] item0 = Protocol.hexToByteArray("5AA5058210904d342e35");
    public static byte[] item1 = Protocol.hexToByteArray("5AA505821090362e3136");
    public static byte[] item2 = Protocol.gbkToBytes("5AA5058210984d312e35");
    public static byte[] item3 = Protocol.hexToByteArray("5AA50582109844342e35");
    public static byte[] item4 = Protocol.gbkToBytes("5AA50582109844332e30");


    public static String intToBytes(int value) {
        return Arrays.toString(ByteBuffer.allocate(4).putInt(value).array());
    }


}
