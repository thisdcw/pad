package com.mxsella.youth.bean;

import com.mxsella.youth.comm.Protocol;

import java.util.Arrays;

public class ReceivePacket {

    private static final String TAG = "ReceivePacket";
    public static final String TYPE_LINE_WORK = "line_work";
    public static final String TYPE_POINT_WORK = "point_work";
    public static final String TYPE_SPACING = "spacing";
    public static final String TYPE_LENGTH = "length";
    public static final String TYPE_LINE_POWER = "line_power";
    public static final String TYPE_LINE_FREQUENCY = "line_frequency";
    public static final String TYPE_LINE_DEPTH = "line_depth";
    public static final String TYPE_LINE_SHOTS_DONE = "line_shots_done";
    public static final String TYPE_LINE_SHOTS_REMAIN = "line_shots_remain";
    public static final String TYPE_LINE_M = "line_m";
    public static final String TYPE_LINE_MODE = "line_mode";
    public static final String TYPE_SPEED = "speed";
    public static final String TYPE_QUANTITY = "quantity";
    public static final String TYPE_QUANTITY_DISPLAY = "quantity_display";
    public static final String TYPE_POINT_POWER = "point_power";
    public static final String TYPE_POINT_FREQUENCY = "point_frequency";
    public static final String TYPE_POINT_DEPTH = "point_depth";
    public static final String TYPE_POINT_SHOTS_DONE = "point_shots_done";
    public static final String TYPE_POINT_SHOTS_REMAIN = "point_shots_remain";
    public static final String TYPE_POINT_M = "point_m";
    public static final String TYPE_POINT_MODE = "point_mode";
    public static final String TYPE_LINE = "line";
    public static final String TYPE_POINT = "point";
    public static final String TYPE_LINE_TOTAL = "line_total";
    public static final String TYPE_POINT_TOTAL = "point_total";
    public static final String TYPE_READY_WORK = "ready_work";
    public static final String TYPE_UNKNOWN = "unknown";
    private byte[] bytes;
    private String type;
    private byte from;
    private double data = -1;
    private int len = -1;
    private short mode; // 模式选择,m:0,1,2,3;mode:1,2
    private String gbk;

    public void setData(double data) {
        this.data = data;
    }

    public String getGbk() {
        return gbk;
    }

    public void setGbk(String gbk) {
        this.gbk = gbk;
    }

    public ReceivePacket(byte[] bytes) {
        this.bytes = bytes;
        this.from = bytes[0];
        this.len = bytes.length;

        if (from != Protocol.DEVICE_TO_CLIENT) {
            this.type = TYPE_UNKNOWN;
            return;
        }
        byte[] addr = Arrays.copyOfRange(bytes, 1, 3);
        if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE_STATUS))) {
            this.type = TYPE_LINE_WORK;
            this.mode = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        }else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT_STATUS))) {
            this.type = TYPE_POINT_WORK;
            this.mode = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_SPACING))) {
            this.type = TYPE_SPACING;
            this.data = Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LENGTH))) {
            this.type = TYPE_LENGTH;
            this.data = Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE_POWER))) {
            this.type = TYPE_LINE_POWER;
            this.data = Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_SPEED))) {
            this.type = TYPE_SPEED;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_QUANTITY))) {
            this.type = TYPE_QUANTITY;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT_POWER))) {
            this.type = TYPE_POINT_POWER;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        }else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE_FREQUENCY))) {
            this.type = TYPE_LINE_FREQUENCY;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE_DEPTH))) {
            this.type = TYPE_LINE_DEPTH;
            this.gbk =Protocol.gbkBytesToShow((Arrays.copyOfRange(bytes, len - 5, len-1)));;
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE_SHOTS_DONE))) {
            this.type = TYPE_LINE_SHOTS_DONE;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE_SHOTS_REMAIN))) {
            this.type = TYPE_LINE_SHOTS_REMAIN;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT_FREQUENCY))) {
            this.type = TYPE_POINT_FREQUENCY;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT_DEPTH))) {
            this.type = TYPE_POINT_DEPTH;
            this.gbk = Protocol.gbkBytesToShow((Arrays.copyOfRange(bytes, len - 5, len-1)));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT_SHOTS_DONE))) {
            this.type = TYPE_POINT_SHOTS_DONE;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT_SHOTS_REMAIN))) {
            this.type = TYPE_POINT_SHOTS_REMAIN;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE_MODE))) {
            this.type = TYPE_LINE_MODE;
            this.mode = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT_MODE))) {
            this.type = TYPE_POINT_MODE;
            this.mode = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE_M))) {
            this.type = TYPE_LINE_M;
            this.mode = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT_M))) {
            this.type = TYPE_POINT_M;
            this.mode = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        }else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE))) {
            this.type = TYPE_LINE;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT))) {
            this.type = TYPE_POINT;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_LINE_TOTAL))) {
            this.type = TYPE_LINE_TOTAL;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        } else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_POINT_TOTAL))) {
            this.type = TYPE_POINT_TOTAL;
            this.data = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        }else if (Protocol.endWith(addr, Protocol.short2Bytes(Protocol.ADDR_READY))) {
            this.type = TYPE_READY_WORK;
            this.mode = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len));
        }
        else {
            this.type = TYPE_UNKNOWN;
        }
    }

    public byte[] getBytes() {
        return bytes;
    }

    public void setBytes(byte[] bytes) {
        this.bytes = bytes;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public static String getTypeUnknown() {
        return TYPE_UNKNOWN;
    }

    public byte getFrom() {
        return from;
    }

    public void setFrom(byte from) {
        this.from = from;
    }

    public double getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public int getLen() {
        return len;
    }

    public void setLen(int len) {
        this.len = len;
    }

    public short getMode() {
        return mode;
    }

    public void setMode(short mode) {
        this.mode = mode;
    }

    @Override
    public String toString() {
        return "ReceivePacket{" +
                "bytes=" + Arrays.toString(bytes) +
                ", type='" + type + '\'' +
                ", from=" + from +
                ", data=" + data +
                ", len=" + len +
                ", mode=" + mode +
                '}';
    }
}
