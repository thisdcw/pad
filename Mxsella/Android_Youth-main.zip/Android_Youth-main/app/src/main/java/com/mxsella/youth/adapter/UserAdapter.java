package com.mxsella.youth.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.mxsella.youth.R;
import com.mxsella.youth.bean.User;

import java.util.List;

import me.jessyan.autosize.AutoSize;

public class UserAdapter extends BaseQuickAdapter<User, BaseViewHolder> {

    private final Context context;
    private long selectUserId = 0;

    private int page = 1;

    private int size;

    public void setPage(int page) {
        this.page = page;
    }

    public UserAdapter(Context context, @Nullable List<User> data, int size) {
        super(R.layout.item_user, data);
        this.context = context;
        this.size = size;
    }

    @Override
    protected void convert(BaseViewHolder helper, User item) {
        // 部分系统因为RecyclerView复用可能导致Item大小不一
        AutoSize.autoConvertDensityOfGlobal((Activity) context);
        int position = helper.getAdapterPosition();
        helper.setText(R.id.user_username, item.getUsername());
        helper.setText(R.id.user_age, String.valueOf(item.getAge()));
        helper.setText(R.id.user_sex, String.valueOf(item.getSex()));
        if (item.getUserId() == selectUserId) {
            helper.setBackgroundRes(R.id.user_lyt_background, R.drawable.bkg_user_record);
        } else {
            helper.setBackgroundRes(R.id.user_lyt_background, R.drawable.bkg_frame);
        }
        if (item.getSex() == 0) {
            helper.setText(R.id.user_sex, mContext.getResources().getString(R.string.female));
        } else {
            helper.setText(R.id.user_sex, mContext.getResources().getString(R.string.male));
        }
        helper.addOnClickListener(R.id.btn_detail);
        helper.addOnClickListener(R.id.btn_operation);
    }

    public void setSelectUserId(long id) {
        selectUserId = id;
    }
}
