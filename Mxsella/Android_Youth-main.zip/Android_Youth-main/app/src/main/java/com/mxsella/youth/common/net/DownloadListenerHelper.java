package com.mxsella.youth.common.net;

import com.azhon.appupdate.listener.OnDownloadListener;

public abstract class DownloadListenerHelper implements OnDownloadListener {

    @Override
    public void start() {

    }

    @Override
    public void downloading(int max, int progress) {

    }

    @Override
    public void cancel() {

    }

    @Override
    public void error(Exception e) {

    }
}
