package com.mxsella.youth.bean;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class User extends LitePalSupport implements Serializable {

    private int userId;
    private String username;
    private String telephone;
    private int sex;
    private String birth;
    private int age;
    private int weight;
    private String other;
    private List<Record> listRecord;

    public List<Record> getListRecord() {
        return listRecord;
    }

    public void setListRecord(List<Record> listRecord) {
        this.listRecord = listRecord;
    }

    public User() {
    }

    public User(int userId, String username, String telephone, int sex, String birth, int age, int weight, String other, List<Record> listRecord) {
        this.userId = userId;
        this.username = username;
        this.telephone = telephone;
        this.sex = sex;
        this.birth = birth;
        this.age = age;
        this.weight = weight;
        this.other = other;
        this.listRecord = listRecord;
    }

    public List<Record> getRecord() {
        return listRecord;
    }

    public void setRecord(List<Record> listRecord) {
        this.listRecord = listRecord;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", telephone='" + telephone + '\'' +
                ", sex=" + sex +
                ", birth='" + birth + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                ", other='" + other + '\'' +
                '}';
    }
}
