package com.mxsella.youth.push;


import cn.jpush.android.service.JCommonService;

public class JIGUANGPushService extends JCommonService {

}
