package com.mxsella.youth.bean;

import androidx.annotation.NonNull;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;

public class UseTimesHistory extends LitePalSupport implements Serializable {

    private String historyId;
    private int handleType;
    private String startTime;
    private String endTime;
    private String remark;
    private boolean ifUpload = false;

    public UseTimesHistory(String historyId, int handleType, String startTime, String endTime, String remark, boolean ifUpload) {
        this.historyId = historyId;
        this.handleType = handleType;
        this.startTime = startTime;
        this.endTime = endTime;
        this.remark = remark;
        this.ifUpload = ifUpload;
    }

    public String getHistoryId() {
        return historyId;
    }

    public void setHistoryId(String historyId) {
        this.historyId = historyId;
    }

    public int getHandleType() {
        return handleType;
    }

    public void setHandleType(int handleType) {
        this.handleType = handleType;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public boolean getIfUpload() {
        return ifUpload;
    }

    public void setIfUpload(boolean ifUpload) {
        this.ifUpload = ifUpload;
    }

    @NonNull
    @Override
    public String toString() {
        return "UseTimesHistory{" +
                "historyId='" + historyId + '\'' +
                ", handleType=" + handleType +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", remark='" + remark + '\'' +
                ", ifUpload=" + ifUpload +
                '}';
    }
}
