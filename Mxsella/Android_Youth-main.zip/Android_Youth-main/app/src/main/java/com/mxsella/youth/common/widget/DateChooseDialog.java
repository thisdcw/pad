package com.mxsella.youth.common.widget;

import android.app.DatePickerDialog;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mxsella.youth.common.utils.NavigationBarUtil;

public class DateChooseDialog extends DatePickerDialog {

    public DateChooseDialog(@NonNull Context context, int themeResId, @Nullable OnDateSetListener listener, int year, int monthOfYear, int dayOfMonth) {
        super(context, themeResId, listener, year, monthOfYear, dayOfMonth);
    }

    @Override
    public void show() {
        NavigationBarUtil.focusNotAle(getWindow());
        try {
            super.show();
        } catch (Exception e){
            e.printStackTrace();
        }

        NavigationBarUtil.hideNavigationBar(getWindow());
        NavigationBarUtil.clearFocusNotAle(getWindow());
    }

}
