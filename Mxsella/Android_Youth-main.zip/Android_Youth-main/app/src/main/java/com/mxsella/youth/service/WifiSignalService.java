package com.mxsella.youth.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.IBinder;

public class WifiSignalService extends Service {
    private WifiManager wifiManager;
    private Handler handler = new Handler();

    @Override
    public void onCreate() {
        super.onCreate();
        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                int signalStrength = wifiManager.getConnectionInfo().getRssi();
                Intent broadcastIntent = new Intent("wifi_signal");
                broadcastIntent.putExtra("signal_strength", signalStrength);
                sendBroadcast(broadcastIntent);
                handler.postDelayed(this, 5000); // 每5秒检测一次
            }
        }, 0);

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

