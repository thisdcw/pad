package com.mxsella.youth.service;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.Toast;

import com.mxsella.youth.CheckActivity;
import com.mxsella.youth.common.utils.AppUtils;
import com.mxsella.youth.common.utils.Config;

import java.util.List;


public class MainReceiver extends BroadcastReceiver {

    private static final String TAG = "MainReceiver";
    private static final String action_boot = "android.intent.action.BOOT_COMPLETED";

    private Context mContext;

    @Override
    public void onReceive(final Context context, Intent intent) {
        mContext = context;
        //判断收到的是什么广播
        String action = intent.getAction();
        if (action.equals(action_boot)) {
            // Toast.makeText(context, "收到开机广播", Toast.LENGTH_LONG).show();
            Intent newIntent = new Intent(context, CheckActivity.class);  // 要启动的Activity
            //1.如果自启动APP，参数为需要自动启动的应用包名
            //Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
            //这句话必须加上才能开机自动运行app的界面
            newIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            //2.如果自启动Activity
            if(!isAppRunning(context, context.getPackageName()))
                context.startActivity(newIntent);
        } else {
            Uri uri = intent.getData();
            String uriStr = uri.toString();
            if (Intent.ACTION_PACKAGE_ADDED.equals(action)) {
                //LocalLog.test("应用被安装" + uri);
                //获取安装更新卸载的是什么应用
                if (uriStr.contains(Config.PACKAGE_NAME)) {
                    Toast.makeText(context, "被安装了" + uri, Toast.LENGTH_SHORT).show();
                }
            } else if (Intent.ACTION_PACKAGE_REMOVED.equals(action)) {
                //LocalLog.test("应用被卸载" + uri);
                //获取安装更新卸载的是什么应用
                if (uriStr.contains(Config.PACKAGE_NAME)) {
                    Toast.makeText(context, "被卸载了" + uri, Toast.LENGTH_SHORT).show();
                }
            }  else if (Intent.ACTION_PACKAGE_REPLACED.equals(action)) {
                //获取安装更新卸载的是什么应用
                if (uriStr.contains(Config.PACKAGE_NAME)) {
                    Toast.makeText(context, "被更新了" + uri, Toast.LENGTH_LONG).show();
                    if (!TextUtils.isEmpty(Config.PACKAGE_NAME)) {
                        AppUtils.reStartApp(context, 2000, true);
                    }
                }
            }
        }
    }

    /**
     * 判断应用是否在前台运行
     */
    public static boolean isAppRunning(Context context, String packageName) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> list = activityManager.getRunningTasks(1);
        return list.size() > 0 && list.get(0).topActivity.getClassName().equals(packageName);
    }

    /**
     * 判断应用是否启动
     */
    public boolean isAppAlive(Context context, String packageName) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> processInfo = activityManager.getRunningAppProcesses();
        for (int i = 0; i < processInfo.size(); i++) {
            if (processInfo.get(i).processName.equals(packageName)) {
                return true;
            }
        }
        return false;
    }
}