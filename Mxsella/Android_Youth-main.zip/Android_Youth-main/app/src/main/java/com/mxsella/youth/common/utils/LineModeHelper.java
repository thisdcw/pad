package com.mxsella.youth.common.utils;

import com.mxsella.youth.bean.LineMode;
import com.mxsella.youth.bean.Record;

import org.litepal.LitePal;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LineModeHelper {
    private LineMode lineMode;
    private ExecutorService service = Executors.newSingleThreadExecutor();

    public static LineModeHelper getInstance() {
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static LineModeHelper INSTANCE = new LineModeHelper();
    }

    public void saveOrUpdate(LineMode lineMode) {
        service.execute(() -> lineMode.saveOrUpdate("userId = ?", String.valueOf(lineMode.getUserId())));
    }
    public void saveLineMode(LineMode lineMode) {
        service.execute(lineMode::save);
    }


    public LineMode getLineModeByUserId(int userId) {
        return LitePal.where("userId = ?", String.valueOf(userId)).findLast(LineMode.class);
    }

    public int total() {
        return LitePal.count(LineMode.class);
    }
}
