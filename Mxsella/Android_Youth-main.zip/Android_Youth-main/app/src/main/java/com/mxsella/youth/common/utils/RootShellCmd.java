package com.mxsella.youth.common.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;

import com.mxsella.youth.common.MyApplication;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.Locale;

public class RootShellCmd {

    private static final String TAG = "RootShellCmd";
    private static OutputStream os;
    private static DateFormat df;

    /**
     * 切换语言环境
     *
     * @param locale 要切换的语言环境
     */
    public static void updateLocale(Locale locale) {
        Locale currentLocale = locale;
        // 获得res资源对象
        Resources resources = MyApplication.getInstance().getResources();
        // 获得设置对象
        Configuration config = resources.getConfiguration();
        // 获得屏幕参数：主要是分辨率，像素等。
        DisplayMetrics dm = resources.getDisplayMetrics();
        // 语言
        config.locale = currentLocale;
        resources.updateConfiguration(config, dm);
    }

    /**
     * 隐藏工具栏
     */
    @SuppressLint("ObsoleteSdkInt")
    public static void closeBar() {
        try {
            // REQUIRES ROOT
            Build.VERSION_CODES vc = new Build.VERSION_CODES();
            Build.VERSION vr = new Build.VERSION();
            String ProcID = "79"; // HONEYCOMB AND OLDER

            // v.RELEASE //4.0.3
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
                ProcID = "42"; // ICS AND NEWER
            }

            exec("service call activity " + ProcID
                    + " s16 com.android.systemui");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * 请求ROOT权限后执行命令
     */
    public static void exec(final String cmd) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Process process = null;
                DataOutputStream os = null;
                try {
                    try {
                        process = Runtime.getRuntime().exec("su");
                    } catch (IOException e) {
                        e.printStackTrace();
                        process = Runtime.getRuntime().exec("sh");
                    }
                    os = new DataOutputStream(process.getOutputStream());
                    os.writeBytes(cmd + "\n");
                    os.writeBytes("exit\n");
                    process.waitFor();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (os != null) {
                            os.flush();
                            os.close();
                        }
                        process.destroy();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

    }

    /**
     * 静默安装
     *
     * @param fileName
     */
    @SuppressLint("SdCardPath")
    public static void install(String fileName) {
//        try {
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        exec("pm install -i com.imstlife.mamakang -r " + fileName + "\n" +
//                "am start -n com.imstlife.mamakang/.ui.MainActivity");
//        exec("pm install -i com.imstlife.mamakang -r " + fileName + "\n" +
//                "am start -n com.imstlife.mamakang/.ui.MainActivity");
        installBySlient(MyApplication.getInstance(), "/sdcard/Vimyage/apk/" + fileName);
    }


    public static int installBySlient(Context context, String filePath) {
        int result = 1;
        try {
            Log.i(TAG, "installBySlient , filePath : " + filePath);
            File file = new File(filePath);
            if (filePath == null || filePath.length() == 0
                    || (file = new File(filePath)) == null
                    || file.length() <= 0 || !file.exists() || !file.isFile()) {
                return result;
            }
            String[] args = {"pm", "install", "-r", filePath};
            ProcessBuilder processBuilder = new ProcessBuilder(args);

            Process process = null;
            BufferedReader successResult = null;
            BufferedReader errorResult = null;
            StringBuilder successMsg = new StringBuilder();
            StringBuilder errorMsg = new StringBuilder();

            try {

                process = processBuilder.start();
                successResult = new BufferedReader(new InputStreamReader(
                        process.getInputStream()));
                errorResult = new BufferedReader(new InputStreamReader(
                        process.getErrorStream()));
                String s;

                while ((s = successResult.readLine()) != null) {
                    successMsg.append(s);
                }

                while ((s = errorResult.readLine()) != null) {
                    errorMsg.append(s);
                }
                Log.d(TAG, "s : " + s);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (successResult != null) {
                        successResult.close();
                    }
                    if (errorResult != null) {
                        errorResult.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (process != null) {
                    process.destroy();
                }
            }

            if (successMsg != null && (successMsg.toString().contains("Success")
                    || successMsg.toString().contains("success"))) {
                    result = 1;
            }

            Log.d(TAG, "installBySlient complete :" + "successMsg:" + successMsg + ", ErrorMsg:" + errorMsg);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static void backHome() {
        exec("am start -n com.imstlife.myrunning/.ui.activity.MainActivity");
    }

    public static void exec(String... cmds) {

        StringBuilder command = new StringBuilder();
        if (cmds.length <= 0) {
            return;
        }
        for (String cmd : cmds) {
            command.append(cmd).append("\n");
        }

        exec(command.toString());
    }

    public static boolean isRoot() {
        String binPath = "/system/bin/su";
        String xBinPath = "/system/xbin/su";
        if (new File(binPath).exists() && isExecutable(binPath))
            return true;
        if (new File(xBinPath).exists() && isExecutable(xBinPath))
            return true;
        return false;
    }

    private static boolean isExecutable(String filePath) {
        Process p = null;
        try {
            p = Runtime.getRuntime().exec("ls -l " + filePath);
            // 获取返回内容
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String str = in.readLine();
            Log.i(TAG, str);
            if (str != null && str.length() >= 4) {
                char flag = str.charAt(3);
                if (flag == 's' || flag == 'x')
                    return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (p != null) {
                p.destroy();
            }
        }
        return false;
    }

    /**
     * 后台模拟全局按键
     *
     * @param keyCode 键值
     */
    public static void inputKeyEvent(int keyCode) {
        exec("input keyevent " + keyCode);
    }

    public static void killProcess(String packageName) {
        exec("am force-stop " + packageName);
    }



}