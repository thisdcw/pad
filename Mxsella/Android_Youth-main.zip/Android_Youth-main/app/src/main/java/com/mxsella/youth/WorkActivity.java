package com.mxsella.youth;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.os.UserManager;
import android.os.Vibrator;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.LogUtils;
import com.mxsella.youth.bean.BaseResponse;
import com.mxsella.youth.bean.LineMode;
import com.mxsella.youth.bean.PointMode;
import com.mxsella.youth.bean.ReceivePacket;
import com.mxsella.youth.bean.Record;
import com.mxsella.youth.bean.UseTimesHistory;
import com.mxsella.youth.comm.ICommunicateService;
import com.mxsella.youth.comm.ImitateReceiveProtocol;
import com.mxsella.youth.comm.Protocol;
import com.mxsella.youth.comm.SPService;
import com.mxsella.youth.common.base.BaseActivity;
import com.mxsella.youth.common.base.BaseMvpActivity;
import com.mxsella.youth.common.net.BaseObserver;
import com.mxsella.youth.common.net.NetworkService;
import com.mxsella.youth.common.net.RxScheduler;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.Constants;
import com.mxsella.youth.common.utils.GsonUtils;
import com.mxsella.youth.common.utils.NetworkUtils;
import com.mxsella.youth.common.utils.RecordHelper;
import com.mxsella.youth.common.utils.TimeDateUtils;
import com.mxsella.youth.common.utils.ToastUtil;
import com.mxsella.youth.common.utils.UseTimesHistoryHelper;
import com.mxsella.youth.common.utils.UserHelper;
import com.mxsella.youth.common.utils.WorkParam;
import com.mxsella.youth.common.widget.RequestDialog;
import com.mxsella.youth.contract.CheckContract;
import com.mxsella.youth.presenter.BasePresenter;
import com.mxsella.youth.presenter.CheckPresenter;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.OnLongClick;
import butterknife.OnTouch;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WorkActivity extends BaseMvpActivity<CheckContract.Presenter>
        implements CheckContract.View {

    @BindView(R.id.item_line_btn)
    Button item_line_btn;
    @BindView(R.id.item_point_btn)
    Button item_point_btn;
    @BindView(R.id.work_lyt_bkg)
    LinearLayout work_lyt_bkg;
    @BindView(R.id.iv_item)
    ImageView iv_item;
    @BindView(R.id.btn_space_add)
    Button lyt_space_up;
    @BindView(R.id.btn_space_reduce)
    Button lyt_space_down;
    @BindView(R.id.btn_length_add)
    Button lyt_length_up;
    @BindView(R.id.btn_length_reduce)
    Button lyt_length_down;
    @BindView(R.id.btn_power_add)
    Button lyt_power_up;
    @BindView(R.id.btn_power_reduce)
    Button lyt_power_down;
    @BindView(R.id.btn_speed_add)
    Button lyt_speed_up;
    @BindView(R.id.btn_speed_reduce)
    Button lyt_speed_down;
    @BindView(R.id.btn_quantity_add)
    Button lyt_quantity_up;
    @BindView(R.id.btn_quantity_reduce)
    Button lyt_quantity_down;
    @BindView(R.id.tv_space)
    TextView tv_space;
    @BindView(R.id.tv_length)
    TextView tv_length;
    @BindView(R.id.tv_power)
    TextView tv_power;
    @BindView(R.id.tv_speed)
    TextView tv_speed;
    @BindView(R.id.tv_quantity)
    TextView tv_quantity;
    @BindView(R.id.line_total)
    TextView line_total;
    @BindView(R.id.point_total)
    TextView point_total;
    @BindView(R.id.mp_btn)
    Button mp_btn;
    @BindView(R.id.normal_btn)
    Button normal_btn;
    @BindView(R.id.save_btn)
    Button save_btn;
    @BindView(R.id.m1_btn)
    Button m1_btn;
    @BindView(R.id.m2_btn)
    Button m2_btn;
    @BindView(R.id.m3_btn)
    Button m3_btn;
    @BindView(R.id.tv_line_frequency)
    TextView tv_line_frequency;
    @BindView(R.id.tv_line_depth)
    TextView tv_line_depth;
    @BindView(R.id.tv_line_shot_done)
    TextView tv_line_shot_done;
    @BindView(R.id.tv_line_shot_remain)
    TextView tv_line_shot_remain;
    @BindView(R.id.tv_point_frequency)
    TextView tv_point_frequency;
    @BindView(R.id.tv_point_depth)
    TextView tv_point_depth;
    @BindView(R.id.tv_point_shot_done)
    TextView tv_point_shot_done;
    @BindView(R.id.tv_point_shot_remain)
    TextView tv_point_shot_remain;
    @BindView(R.id.ready_btn)
    Button ready_btn;
    @BindView(R.id.line_count)
    TextView line_count;
    @BindView(R.id.point_count)
    TextView point_count;
    @BindView(R.id.change_item)
    ImageView iv_change_item;

    private RequestDialog requestDialog;
    private RequestDialog notifyDialog;
    int item = -1;
    //模式锁状态,mp模式为0,默认normal模式,无锁
    int mode = -1;
    boolean isStart = false;
    private int userId;
    private LineMode lineMode;
    private PointMode pointMode;
    private ICommunicateService communicateService;
    private double spacing;
    private double length;
    private double line_power;
    private String line_frequency;
    private String line_depth;
    private double line_shot_done;
    private double speed;
    private double quantity;
    private double point_power;
    private String point_frequency;
    private String point_depth;
    private double point_shot_done;
    private double line;
    private double point;
    private double total_line;
    private double total_point;
    private int curr_line = 0;
    private int curr_point = 0;
    int plan;

    int times = 0;

    int select_type = -1;
    Map<String, Object> remarkMap = new HashMap<>();
    boolean isRelease = false;

    long lastPressTime = 0;

    ExecutorService executor = Executors.newSingleThreadExecutor();
    private CompositeDisposable mDisposables = new CompositeDisposable();

    boolean isShowP = false;
    boolean isShowL = false;

    @Override
    public int getLayoutId() {
        return R.layout.activity_work;
    }

    @Override
    protected CheckContract.Presenter initPresenter() {
        return new CheckPresenter(this);
    }

    /**
     * line:
     * space   1.5-5   0.1/each
     * length  5.0-25  1.0/each
     * power   0.5-3   0.1J/each
     * point:
     * speed       1-10    1/each
     * quantity    1-10    1/each
     * power       0-3     0.1J/each
     */
    @Override
    public void initView() {
        super.initView();
        if (Config.ifDebug) {
            select_type = 0;
        }
        userId = getIntent().getIntExtra("userId", 1);
        communicateService = SPService.getInstance();
        communicateService.startService();
        initServiceListener();
        initData();
        if (Config.ifDebug) {
            findViewById(R.id.imitate_work).setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isStart) {
            communicateService.send(Protocol.READY_PAUSE);
            isStart = !isStart;
        }
    }

    void saveData() {
        String l = line_total.getText().toString().trim();
        String p = point_total.getText().toString().trim();
        if (l.equals("--")) {
            l = "0";
        }
        if (p.equals("--")) {
            p = "0";
        }
        curr_line = Integer.parseInt(l);
        curr_point = Integer.parseInt(p);
        if (curr_line != 0) {
            Record record1 = new Record();
            record1.setUserId(userId);
            record1.setToolHead(Config.getHandle(select_type));
            record1.setCount(curr_line);
            record1.setItem(1);
            record1.setUsedDate(TimeDateUtils.getNowDateTime());
            RecordHelper.getInstance().saveRecord(record1);
            communicateService.send(Protocol.LINE_TOTAL_RESET);
        }
        if (curr_point != 0) {
            Record record2 = new Record();
            record2.setUserId(userId);
            record2.setToolHead(Config.getHandle(select_type));
            record2.setCount(curr_point);
            record2.setItem(0);
            record2.setUsedDate(TimeDateUtils.getNowDateTime());
            RecordHelper.getInstance().saveRecord(record2);
            communicateService.send(Protocol.POINT_TOTAL_RESET);
        }
        curr_line = 0;
        curr_point = 0;
    }

    void uploadData() {
        mPresenter.uploadUseTimesHistory(Config.deviceId, Config.getAllRemainTimes(), UseTimesHistoryHelper.getInstance().getNotUpload());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mPresenter.uploadUseTimesHistory(Config.deviceId, Config.getAllRemainTimes(), UseTimesHistoryHelper.getInstance().getNotUpload());
        if (isStart) {
            communicateService.send(Protocol.READY_PAUSE);
        }
        mDisposables.clear();
    }

    public void showLine(ReceivePacket packet) {
        switch (packet.getType()) {
            case ReceivePacket.TYPE_SPACING:
                spacing = packet.getData();
                spacing /= 10;
                Config.saveOrUpdateParam("spacing", spacing);
//                Log.d("spacing: ", String.valueOf(spacing));
                runOnUiThread(() -> tv_space.setText(String.format(Locale.getDefault(), "%.1f", spacing)));
                break;
            case ReceivePacket.TYPE_LINE_POWER:
                line_power = packet.getData();
                line_power /= 10;
                Config.saveOrUpdateParam("line_power", line_power);
                double finalLine_power = line_power;
//                Log.d("line power: ", String.valueOf(line_power));
                runOnUiThread(() -> tv_power.setText(String.format(Locale.getDefault(), "%.1f", finalLine_power)));
                break;
            case ReceivePacket.TYPE_LINE_SHOTS_DONE:
                line_shot_done = packet.getData();
                runOnUiThread(() -> tv_line_shot_done.setText(String.valueOf((int) line_shot_done)));
                Log.d("line shots done: ", String.valueOf(line_shot_done));
                break;
            case ReceivePacket.TYPE_LINE_SHOTS_REMAIN:
                Log.d("line remain: ", "------------>" + packet.getData());
                double remainTimes = packet.getData();
                if ((remainTimes - line_shot_done) < 500) {
                    if (remainTimes <= line_shot_done) {
                        runOnUiThread(this::notifyLife);
                    } else {
                        if (!isShowL) {
                            isShowL = true;
                            runOnUiThread(this::notifyEnough);
                        }
                    }
                    break;
                }
                if (isStart) {
                    if (Config.getRemainTimes(select_type) - 1 >= 0) {
                        UseTimesHistoryHelper.getInstance().updateTimes();
                    } else {
                        communicateService.send(Protocol.READY_PAUSE);
                    }
                }
                runOnUiThread(() -> tv_line_shot_remain.setText(String.valueOf((int) Config.getRemainTimes(select_type))));
                break;
            case ReceivePacket.TYPE_LINE:
                line = packet.getData();
                runOnUiThread(() -> line_count.setText(String.valueOf((int) line)));
//                Log.d("line", String.valueOf(line));
                break;
            case ReceivePacket.TYPE_LINE_TOTAL:
                total_line = packet.getData();
                runOnUiThread(() -> line_total.setText(String.valueOf((int) total_line)));
//                Log.d("total line", String.valueOf(total_line));
                break;
        }

    }


    public void showPoint(ReceivePacket packet) {

        switch (packet.getType()) {
            case ReceivePacket.TYPE_SPEED:
                speed = packet.getData();
                Config.saveOrUpdateParam("speed", speed);
//                Log.d("speed: ", String.valueOf(speed));
                runOnUiThread(() -> tv_speed.setText(String.valueOf((int) speed)));
                break;
            case ReceivePacket.TYPE_QUANTITY:
                quantity = packet.getData();
                Config.saveOrUpdateParam("quantity", quantity);
//                Log.d("quantity: ", String.valueOf(quantity));
                runOnUiThread(() -> tv_quantity.setText(String.valueOf((int) quantity)));
                break;
            case ReceivePacket.TYPE_POINT_POWER:
                point_power = packet.getData();
                point_power /= 10;
                Config.saveOrUpdateParam("point_power", point_power);
                runOnUiThread(() -> tv_power.setText(String.valueOf(point_power)));
                Log.d("point power: ", String.valueOf(point_power));
                break;
            case ReceivePacket.TYPE_POINT_SHOTS_DONE:
                point_shot_done = packet.getData();
                runOnUiThread(() -> tv_point_shot_done.setText(String.valueOf((int) point_shot_done)));
                Log.d("point shots done: ", String.valueOf(point_shot_done));
                break;
            case ReceivePacket.TYPE_POINT_SHOTS_REMAIN:
                double point_shot_remain = packet.getData();
                Log.d("point shot remain", "" + point_shot_remain);
                if ((point_shot_remain - point_shot_done) < 500) {
                    if (point_shot_remain <= point_shot_done) {
                        runOnUiThread(this::notifyLife);
                    } else {
                        if (!isShowP) {
                            isShowP = true;
                            runOnUiThread(this::notifyEnough);
                        }
                    }
                    break;
                }
                if (isStart) {
                    if (Config.getRemainTimes(select_type) - 1 >= 0) {
                        UseTimesHistoryHelper.getInstance().updateTimes();
                    } else {
                        communicateService.send(Protocol.READY_PAUSE);
                    }
                }
                runOnUiThread(() -> tv_point_shot_remain.setText(String.valueOf(Config.getRemainTimes(select_type))));
                Log.d("showPoint", select_type + "==========>" + Config.getRemainTimes(select_type));
                break;
            case ReceivePacket.TYPE_POINT:
                point = packet.getData();
                runOnUiThread(() -> point_count.setText(String.valueOf((int) point)));
//                Log.d("point", String.valueOf(point));
                break;
            case ReceivePacket.TYPE_POINT_TOTAL:
                total_point = packet.getData();
                runOnUiThread(() -> point_total.setText(String.valueOf((int) total_point)));
//                Log.d("total point", String.valueOf(total_point));
                break;
            default:
                break;
        }
    }

    public void initServiceListener() {
        communicateService.setListener(packet -> {
            if (!ActivityUtils.isActivityAlive(this)) {
                return;
            }
            switch (packet.getType()) {
                case ReceivePacket.TYPE_POINT_WORK:
                    short point_flag = packet.getMode();
                    isShowP = false;
                    item = 0;
//                    showItem(0);
//                    Log.d("point work status: ", String.valueOf(point_flag));
                    showConnect(point_flag);
                    break;
                case ReceivePacket.TYPE_LINE_WORK:
                    short line_flag = packet.getMode();
                    isShowL = false;
                    item = 1;
//                    showItem(1);
//                    Log.d("line work status: ", String.valueOf(line_flag));
                    showConnect(line_flag);
                    break;
                case ReceivePacket.TYPE_READY_WORK:
                    int ready_status = packet.getMode();
//                    Log.d("ready status: ", String.valueOf(ready_status));
                    showReady(ready_status);
                    break;
                case ReceivePacket.TYPE_POINT_M:
                    short i = packet.getMode();

//                    Log.d("point plan", String.valueOf(i));
                    showM(i);
                    break;
                case ReceivePacket.TYPE_POINT_MODE:
                    short pointMode = packet.getMode();
//                    Log.d("point mode", String.valueOf(pointMode));
                    showMode(pointMode);
                    break;
                case ReceivePacket.TYPE_LINE_M:
                    short k = packet.getMode();
                    Log.d("line plan", "" + k);
                    showM(k);
                    break;
                case ReceivePacket.TYPE_LINE_MODE:
                    short lineMode = packet.getMode();
                    Log.d("line mode: ", "" + lineMode);
                    showMode(lineMode);
                    break;
                case ReceivePacket.TYPE_LINE_DEPTH:
                    String line_depth = packet.getGbk();
//                    Log.d("line_depth ==> ",line_depth);
                    if (line_depth.equals("6.16")) {
                        line_depth = Config.getHandle(1);
                    }
                    Config.saveItem(1, line_depth);
                    if (item == 1) {
                        select_type = Config.getHandleTypeByKey(line_depth);
                        showItem(1);
                    }
                    break;
                case ReceivePacket.TYPE_POINT_DEPTH:
                    String point_depth = packet.getGbk();
//                    Log.d("point_depth ==> ",point_depth);
                    Config.saveItem(0, point_depth);
                    if (item == 0) {
                        select_type = Config.getHandleTypeByKey(point_depth);
                        showItem(0);
                    }
                    break;
            }
            //line
            if (item == 1) {
                showLine(packet);
            }
            //point
            if (item == 0) {
                showPoint(packet);
            }

        });
    }

    public void showConnect(int flag) {
        runOnUiThread(() -> {

            if (item == 1) {
                if (flag == 0) {
                    iv_item.setBackgroundResource(R.drawable.line_connect);
                } else {
                    if (isStart){
                        communicateService.send(Protocol.READY_PAUSE);
                        isStart = false;
                    }
                    iv_item.setBackgroundResource(R.drawable.line_unconnect);
                }
            }
            if (item == 0) {
                if (flag == 0) {
                    iv_item.setBackgroundResource(R.drawable.point_connect);
                } else {
                    if (isStart){
                        communicateService.send(Protocol.READY_PAUSE);
                        isStart = false;
                    }
                    iv_item.setBackgroundResource(R.drawable.point_unconnect);
                }
            }
        });
    }

    public void showReady(int ready_status) {
        runOnUiThread(() -> {
            if (ready_status == 0) {
                isStart = false;
                ready_btn.setBackgroundResource(R.drawable.ready_btn_unpressed);
                ready_btn.setText(getResources().getText(R.string.ready));
                saveData();
                UseTimesHistoryHelper.getInstance().setOnline();
                UseTimesHistoryHelper.getInstance().setEnd();
            }
            if (ready_status == 1) {
                isStart = true;
                ready_btn.setBackgroundResource(R.drawable.ready_btn_pressed);
                ready_btn.setText(getResources().getText(R.string.stop));
                remarkMap.put("remainTimes", Config.getRemainTimes(select_type));
                remarkMap.put("times", times);
                times = 0;
                remarkMap.put("username", UserHelper.getInstance().getUserById(userId).getUsername());
                remarkMap.put("telephone", UserHelper.getInstance().getUserById(userId).getTelephone());
                UseTimesHistoryHelper.getInstance().setWork();
                UseTimesHistoryHelper.getInstance().setStart(select_type, System.currentTimeMillis(), GsonUtils.serialize(remarkMap));
            }
        });
    }

    public void showM(int mode) {
        runOnUiThread(() -> {
            switch (mode) {
                case 1:
                    plan = 1;
                    m1_btn.setBackgroundResource(R.drawable.m1_pressed);
                    m2_btn.setBackgroundResource(R.drawable.m23_unpressed);
                    m3_btn.setBackgroundResource(R.drawable.m23_unpressed);
                    break;
                case 2:
                    plan = 2;
                    m1_btn.setBackgroundResource(R.drawable.m1_unpressed);
                    m2_btn.setBackgroundResource(R.drawable.m23_pressed);
                    m3_btn.setBackgroundResource(R.drawable.m23_unpressed);
                    break;
                case 3:
                    plan = 3;
                    m1_btn.setBackgroundResource(R.drawable.m1_unpressed);
                    m2_btn.setBackgroundResource(R.drawable.m23_unpressed);
                    m3_btn.setBackgroundResource(R.drawable.m23_pressed);
                    break;
                default:
                    plan = 0;
                    m1_btn.setBackgroundResource(R.drawable.m1_unpressed);
                    m2_btn.setBackgroundResource(R.drawable.m23_unpressed);
                    m3_btn.setBackgroundResource(R.drawable.m23_unpressed);
                    break;
            }
        });
    }

    public void showItem(int item) {
        this.item = item;
        runOnUiThread(() -> {
            switch (item) {
                case 0:
                    tv_speed.setText(Config.getParam("speed"));
                    tv_quantity.setText(Config.getParam("quantity"));
                    tv_power.setText(Config.getParam("point_power"));
                    tv_point_depth.setText(Config.getDepth(0));
                    tv_point_frequency.setText(Config.getFrequency(select_type));
                    iv_item.setBackgroundResource(R.drawable.point_connect);
                    iv_change_item.setBackgroundResource(R.drawable.point_item);
                    work_lyt_bkg.setBackgroundResource(R.drawable.bkg_point_work1);
                    item_point_btn.setBackgroundResource(R.drawable.point_btn_pressed);
                    item_line_btn.setBackgroundResource(R.drawable.line_btn_unpressed);
                    runOnUiThread(() -> {
                        tv_space.setText("--");
                        tv_length.setText("--");
                        tv_line_frequency.setText("--");
                        tv_line_depth.setText("--");
                        tv_line_shot_done.setText("--");
                        tv_line_shot_remain.setText("--");
                        line_total.setText("--");
                        line_count.setText("--");
                    });
                    break;
                case 1:
                    tv_space.setText(Config.getParam("spacing"));
                    tv_length.setText(Config.getParam("length"));
                    tv_power.setText(Config.getParam("line_power"));
                    tv_line_depth.setText(Config.getDepth(1));
                    tv_line_frequency.setText(Config.getFrequency(select_type));
                    iv_item.setBackgroundResource(R.drawable.line_connect);
                    iv_change_item.setBackgroundResource(R.drawable.line_item);
                    work_lyt_bkg.setBackgroundResource(R.drawable.bkg_line_work1);
                    item_line_btn.setBackgroundResource(R.drawable.line_btn_pressed);
                    item_point_btn.setBackgroundResource(R.drawable.point_btn_unpressed);
                    runOnUiThread(() -> {
                        tv_speed.setText("--");
                        tv_quantity.setText("--");
                        tv_point_frequency.setText("--");
                        tv_point_depth.setText("--");
                        tv_point_shot_done.setText("--");
                        tv_point_shot_remain.setText("--");
                        point_total.setText("--");
                        point_count.setText("--");
                    });
                    break;
                default:
                    break;
            }
        });
    }

    public void showMode(int flag) {
        runOnUiThread(() -> {
            if (item == 1) {
                switch (flag) {
                    case 0:
                        mode = 0;
                        normal_btn.setBackgroundResource(R.drawable.remark_btn_unselect);
                        mp_btn.setBackgroundResource(R.drawable.remark_btn_select);
                        break;
                    case 1:
                        mode = 1;
                        normal_btn.setBackgroundResource(R.drawable.remark_btn_select);
                        mp_btn.setBackgroundResource(R.drawable.remark_btn_unselect);
                        break;
                    default:
                        break;
                }
            }
            if (item == 0) {
                switch (flag) {
                    case 1:
                        mode = 1;
                        normal_btn.setBackgroundResource(R.drawable.remark_btn_unselect);
                        mp_btn.setBackgroundResource(R.drawable.remark_btn_select);
                        break;
                    case 2:
                        mode = 2;
                        normal_btn.setBackgroundResource(R.drawable.remark_btn_select);
                        mp_btn.setBackgroundResource(R.drawable.remark_btn_unselect);
                        break;
                    case 0:
                        mode = 0;
                        normal_btn.setBackgroundResource(R.drawable.remark_btn_unselect);
                        mp_btn.setBackgroundResource(R.drawable.remark_btn_unselect);
                        break;
                    default:
                        break;
                }
            }

        });
    }

    void initData() {
        uploadData();
        //默认选择line
        tv_space.setText(Config.getParam("spacing"));
        tv_length.setText(Config.getParam("length"));
        tv_power.setText(Config.getParam("line_power"));
        tv_quantity.setText(Config.getParam("quantity"));
        tv_speed.setText(Config.getParam("speed"));
        communicateService.send(Protocol.SELECT_LINE);
        item = 1;

        if (Config.ifDebug) {
            communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210600001"));
        }
        showItem(1);
        if (isStart) {
            communicateService.send(Protocol.READY_PAUSE);
        }
        plan = 0;
        if (lineMode == null) {
            lineMode = new LineMode();
        }
        lineMode.setUserId(userId);
        if (pointMode == null) {
            pointMode = new PointMode();
        }
        pointMode.setUserId(userId);
    }

    @Override
    public void stopAction() {
        super.stopAction();
    }

    @OnClick({R.id.imitate_work, R.id.btn_length_add, R.id.btn_length_reduce, R.id.return_btn, R.id.m1_btn, R.id.m2_btn, R.id.m3_btn, R.id.save_btn, R.id.ready_btn, R.id.mp_btn, R.id.normal_btn, R.id.item_point_btn, R.id.item_line_btn})
    public void onClick(View view) {
        int view_id = view.getId();
        if (view_id == R.id.ready_btn) {
            if (Config.ifDebug) {
                communicateService.imitateReceive(Protocol.hexToByteArray("5AA505821026000" + (isStart ? 0 : 1)));
                isStart = !isStart;
            }
            // 判断当前选择手柄的剩余次数，小于0则提示并return
            boolean isEnough = Config.getRemainTimes(select_type) > 0;
            if (!isEnough) {
                if (isStart) {
                    isStart = false;
                    communicateService.send(Protocol.READY_PAUSE);
                }
                if (!Config.ifDebug) {
                    showNotEnough();
                }
            }
            if (isEnough || Config.ifDebug) {
                if (item == 0) {
                    isStart = !isStart;
                    communicateService.send(Protocol.READY_PAUSE);
                }
                if (item == 1) {
                    isStart = !isStart;
                    communicateService.send(Protocol.READY_PAUSE);
                }
            }
        }
        if (!isStart) {
            switch (view_id) {
                case R.id.return_btn:
                    finish();
                    break;
                case R.id.m1_btn:
                    if (item == 1) {
                        communicateService.send(Protocol.LINE_M1_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210600001"));
                        }
                    }
                    if (item == 0) {
                        communicateService.send(Protocol.POINT_M1_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA50582106A0001"));
                        }
                    }
                    break;
                case R.id.m2_btn:
                    if (item == 1) {
                        communicateService.send(Protocol.LINE_M2_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210600002"));
                        }
                    }
                    if (item == 0) {
                        communicateService.send(Protocol.POINT_M2_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA50582106A0002"));
                        }
                    }
                    break;
                case R.id.m3_btn:
                    if (item == 1) {
                        communicateService.send(Protocol.LINE_M3_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210600003"));
                        }
                    }
                    if (item == 0) {
                        communicateService.send(Protocol.POINT_M3_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA50582106A0003"));
                        }
                    }
                    break;
                case R.id.save_btn:
                    if (item == 1) {
                        communicateService.send(Protocol.LINE_SAVE_SELECT);
                    }
                    if (item == 0) {
                        communicateService.send(Protocol.POINT_SAVE_SELECT);
                    }
                    break;
                case R.id.mp_btn:
                    if (item == 1) {
                        communicateService.send(Protocol.LINE_MP_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210920000"));
                        }
                    }
                    if (item == 0) {
                        communicateService.send(Protocol.POINT_MP_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210960001"));
                        }
                    }
                    break;
                case R.id.normal_btn:
                    if (item == 1) {
                        communicateService.send(Protocol.LINE_NORMAL_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210920001"));
                        }
                    }
                    if (item == 0) {
                        communicateService.send(Protocol.POINT_NORMAL_SELECT);
                        if (Config.ifDebug) {
                            communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210960002"));
                        }
                    }
                    break;
                case R.id.item_line_btn:
                    communicateService.send(Protocol.SELECT_LINE);
                    showItem(1);
                    if (Config.ifDebug) {
                        communicateService.imitateReceive(Protocol.LINE_CONNECTED);
                    }
                    break;
                case R.id.item_point_btn:
                    communicateService.send(Protocol.SELECT_POINT);
                    showItem(0);
                    if (Config.ifDebug) {
                        communicateService.imitateReceive(Protocol.POINT_CONNECTED);
                    }
                    break;
                default:
                    break;
            }
        }
        if (Config.ifDebug) {
            if (view_id == R.id.imitate_work) {

                UseTimesHistoryHelper.getInstance().updateTimes();

                if (item == 1) {
                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210091111"));
//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210904d342e35"));
//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA505821090362e3136"));


//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210984d312e35"));
//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210070001"));
//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210090002"));
                } else {
//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210984d312e35"));
//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA50582109844342e35"));
//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA50582109844332e30"));

//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210340001"));
//                    communicateService.imitateReceive(Protocol.hexToByteArray("5AA5058210360002"));
                }
            }
        }
        if (item == 1) {
            switch (view_id) {
                case R.id.btn_length_add:
                    double v = Double.parseDouble(tv_length.getText().toString()) + 1;
                    if (v <= WorkParam.LINE_MAX_LENGTH) {
                        Config.saveOrUpdateParam("length", v);
                        communicateService.send(lengthSend(v, "add"));
                        tv_length.setText(String.valueOf(v));
                    } else {
                        Config.saveOrUpdateParam("length", WorkParam.LINE_MIN_LENGTH);
                        communicateService.send(Protocol.LENGTH_MAX);
                        tv_length.setText(String.valueOf(WorkParam.LINE_MAX_LENGTH));
                    }
                    break;
                case R.id.btn_length_reduce:
                    double k = Double.parseDouble(tv_length.getText().toString()) - 1;
                    if (k >= WorkParam.LINE_MIN_LENGTH) {
                        communicateService.send(lengthSend(k, "reduce"));
                        Config.saveOrUpdateParam("length", k - 1);
                        tv_length.setText(String.valueOf(k - 1));
                    } else {
                        Config.saveOrUpdateParam("length", WorkParam.LINE_MIN_LENGTH);
                        communicateService.send(Protocol.LENGTH_MIN);
                        tv_length.setText(String.valueOf(WorkParam.LINE_MIN_LENGTH));
                    }
                    break;
            }
        }
    }

    public void btnShow(boolean isPressed, View view) {
        if (isPressed) {
            if (item == 1) {
                switch (view.getId()) {
                    case R.id.btn_power_reduce:
                    case R.id.btn_space_reduce:
                        findViewById(view.getId()).setBackgroundResource(R.drawable.reduce_pressed);
                        break;
                    case R.id.btn_power_add:
                    case R.id.btn_space_add:
                        findViewById(view.getId()).setBackgroundResource(R.drawable.add_pressed);
                        break;
                }
            }
            if (item == 0) {
                switch (view.getId()) {
                    case R.id.btn_power_reduce:
                    case R.id.btn_quantity_reduce:
                    case R.id.btn_speed_reduce:
                        findViewById(view.getId()).setBackgroundResource(R.drawable.reduce_pressed);
                        break;
                    case R.id.btn_power_add:
                    case R.id.btn_quantity_add:
                    case R.id.btn_speed_add:
                        findViewById(view.getId()).setBackgroundResource(R.drawable.add_pressed);
                        break;
                }
            }
        }
        if (!isPressed) {
            if (item == 1) {
                switch (view.getId()) {
                    case R.id.btn_power_reduce:
                    case R.id.btn_space_reduce:
                        findViewById(view.getId()).setBackgroundResource(R.drawable.reduce);
                        break;
                    case R.id.btn_power_add:
                    case R.id.btn_space_add:
                        findViewById(view.getId()).setBackgroundResource(R.drawable.add);
                        break;
                }
            }
            if (item == 0) {
                switch (view.getId()) {
                    case R.id.btn_power_reduce:
                    case R.id.btn_quantity_reduce:
                    case R.id.btn_speed_reduce:
                        findViewById(view.getId()).setBackgroundResource(R.drawable.reduce);
                        break;
                    case R.id.btn_power_add:
                    case R.id.btn_quantity_add:
                    case R.id.btn_speed_add:
                        findViewById(view.getId()).setBackgroundResource(R.drawable.add);
                        break;
                }
            }
        }
    }

    @OnTouch({R.id.btn_space_add, R.id.btn_space_reduce, R.id.btn_power_add, R.id.btn_power_reduce, R.id.btn_speed_add, R.id.btn_speed_reduce, R.id.btn_quantity_add, R.id.btn_quantity_reduce})
    public void onTouch(View view, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (!isStart) {
                    btnShow(true, view);
                }
                if (isRelease) {
                    lastPressTime = System.currentTimeMillis();
                    isRelease = false;
//                    Log.d("onLongTouch", "==========>" + view.getId());
                    if (item == 0 && !isStart) {
                        switch (view.getId()) {
                            case R.id.btn_speed_add:
                                executor.execute(new SendTask(Protocol.SPEED_ADD));
                                break;
                            case R.id.btn_speed_reduce:
                                executor.execute(new SendTask(Protocol.SPEED_REDUCE));
                                break;
                            case R.id.btn_quantity_add:
                                if (mode == 2) {
                                    executor.execute(new SendTask(Protocol.QUANTITY_ADD));
                                }
                                break;
                            case R.id.btn_quantity_reduce:
                                if (mode == 2) {
                                    executor.execute(new SendTask(Protocol.QUANTITY_REDUCE));
                                }
                                break;
                            case R.id.btn_power_add:
                                executor.execute(new SendTask(Protocol.POINT_POWER_ADD));
                                break;
                            case R.id.btn_power_reduce:
                                executor.execute(new SendTask(Protocol.POINT_POWER_REDUCE));
                                break;
                            default:
                                break;
                        }
                    }
                    if (item == 1 && !isStart) {
                        switch (view.getId()) {
                            case R.id.btn_space_add:
                                if (mode == 1) {
                                    executor.execute(new SendTask(Protocol.SPACING_ADD));
                                }
                                break;
                            case R.id.btn_space_reduce:
                                if (mode == 1) {
                                    executor.execute(new SendTask(Protocol.SPACING_REDUCE));
                                }
                                break;
                            case R.id.btn_power_add:
                                executor.execute(new SendTask(Protocol.LINE_POWER_ADD));
                                break;
                            case R.id.btn_power_reduce:
                                executor.execute(new SendTask(Protocol.LINE_POWER_REDUCE));
                                break;
                            default:
                                break;
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                isRelease = true;
                if (!isStart) {
                    btnShow(false, view);
                }
                long pressTime = System.currentTimeMillis() - lastPressTime;
                if (pressTime < 500) {
//                    Log.d("onShortTouch", "==========>" + view.getId());
                    if (item == 0 && !isStart) {
                        switch (view.getId()) {
                            case R.id.btn_speed_add:
                                communicateService.send(Protocol.SPEED_ADD);
                                break;
                            case R.id.btn_speed_reduce:
                                communicateService.send(Protocol.SPEED_REDUCE);
                                break;
                            case R.id.btn_quantity_add:
                                if (mode == 2) {
                                    communicateService.send(Protocol.QUANTITY_ADD);
                                }
                                break;
                            case R.id.btn_quantity_reduce:
                                if (mode == 2) {
                                    communicateService.send(Protocol.QUANTITY_REDUCE);
                                }
                                break;
                            case R.id.btn_power_add:
                                communicateService.send(Protocol.POINT_POWER_ADD);
                                break;
                            case R.id.btn_power_reduce:
                                communicateService.send(Protocol.POINT_POWER_REDUCE);
                                break;
                            default:
                                break;
                        }
                    }
                    if (item == 1 && !isStart) {
                        switch (view.getId()) {
                            case R.id.btn_length_add:
                                double v = Double.parseDouble(tv_length.getText().toString()) + 1;
                                if (v <= WorkParam.LINE_MAX_LENGTH) {
                                    Config.saveOrUpdateParam("length", v);
                                    communicateService.send(lengthSend(v, "add"));
                                    tv_length.setText(String.valueOf(v));
                                } else {
                                    Config.saveOrUpdateParam("length", WorkParam.LINE_MIN_LENGTH);
                                    communicateService.send(Protocol.LENGTH_MAX);
                                    tv_length.setText(String.valueOf(WorkParam.LINE_MAX_LENGTH));
                                }
                                break;
                            case R.id.btn_length_reduce:
                                double k = Double.parseDouble(tv_length.getText().toString()) - 1;
                                if (k >= WorkParam.LINE_MIN_LENGTH) {
                                    communicateService.send(lengthSend(k, "reduce"));
                                    Config.saveOrUpdateParam("length", k - 1);
                                    tv_length.setText(String.valueOf(k - 1));
                                } else {
                                    Config.saveOrUpdateParam("length", WorkParam.LINE_MIN_LENGTH);
                                    communicateService.send(Protocol.LENGTH_MIN);
                                    tv_length.setText(String.valueOf(WorkParam.LINE_MIN_LENGTH));
                                }
                                break;
                            case R.id.btn_space_add:
                                if (mode == 1) {
                                    communicateService.send(Protocol.SPACING_ADD);
                                }
                                break;
                            case R.id.btn_space_reduce:
                                if (mode == 1) {
                                    communicateService.send(Protocol.SPACING_REDUCE);
                                }
                                break;
                            case R.id.btn_power_add:
                                communicateService.send(Protocol.LINE_POWER_ADD);
                                break;
                            case R.id.btn_power_reduce:
                                communicateService.send(Protocol.LINE_POWER_REDUCE);
                                break;
                            default:
                                break;
                        }
                    }
                }
                break;
        }
    }

    @Override
    public void jumpToMain(boolean jump) {
        if (jump){
            navigateTo(MainActivity.class);
            finish();
        }
    }

    private class SendTask implements Runnable {

        byte[] command;

        public SendTask(byte[] command) {
            this.command = command;
        }

        @Override
        public void run() {
            try {
                while (!isRelease) {
                    if (System.currentTimeMillis() - lastPressTime > 500) {
                        communicateService.send(command);
                        Thread.sleep(300);
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }

    public byte[] lengthSend(double length, String operator) {
        if (length > WorkParam.LINE_MAX_LENGTH || length < WorkParam.LINE_MIN_LENGTH) {
            Config.saveOrUpdateParam("length", WorkParam.LINE_MAX_LENGTH);
            return Protocol.LENGTH_MAX;
        }
        int l = (int) length;
        if (operator.equals("reduce")) {
            StringBuilder s = new StringBuilder(Integer.toHexString((l - 1) * 10).toUpperCase());
            while (s.length() < 4) {
                s.insert(0, "0");
            }
//            Log.d("reduce:", s.toString());
            return Protocol.hexToByteArray("5AA50683101201" + s);
        }
        if (operator.equals("add")) {
            StringBuilder s = new StringBuilder(Integer.toHexString((l + 1) * 10).toUpperCase());
            while (s.length() < 4) {
                s.insert(0, "0");
            }
//            Log.d("add:", s.toString());
            return Protocol.hexToByteArray("5AA50683101201" + s);
        }
        return new byte[]{};
    }

    public void showNotEnough() {
        requestDialog = new RequestDialog(this, getResources().getString(R.string.remainTimes_not_enough));
        requestDialog.setQRVisible(View.VISIBLE);
        requestDialog.setCancelClickListener(v -> {
            requestDialog.dismiss();
            if (isStart) {
                communicateService.send(Protocol.READY_PAUSE);
                isStart = !isStart;
            }
        });
        requestDialog.setConfirmClickListener(v -> {
            requestDialog.dismiss();
            finish();
        });
        requestDialog.show();
    }

    public void notifyEnough() {
        notifyDialog = new RequestDialog(this, getResources().getString(R.string.lifespan_not_enough));
        notifyDialog.setCancelVisible(View.GONE);
        notifyDialog.setQRVisible(View.GONE);
        notifyDialog.setConfirmClickListener(v -> {
            notifyDialog.dismiss();
        });
        notifyDialog.show();
    }

    public void notifyLife() {
        notifyDialog = new RequestDialog(this, getResources().getString(R.string.life_not_enough));
        notifyDialog.setCancelVisible(View.VISIBLE);
        notifyDialog.setQRVisible(View.VISIBLE);
        notifyDialog.setConfirmClickListener(v -> {
            notifyDialog.dismiss();
            finish();
        });
        notifyDialog.setCancelClickListener(v->{
            notifyDialog.dismiss();
        });
        notifyDialog.show();
    }
}