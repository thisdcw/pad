package com.mxsella.youth;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.azhon.appupdate.config.UpdateConfiguration;
import com.azhon.appupdate.manager.DownloadManager;
import com.blankj.utilcode.util.LanguageUtils;
import com.mxsella.youth.bean.UpdateInfo;
import com.mxsella.youth.comm.SPService;
import com.mxsella.youth.comm.USBInterface;
import com.mxsella.youth.comm.USBService;
import com.mxsella.youth.common.MyApplication;
import com.mxsella.youth.common.base.BaseMvpActivity;
import com.mxsella.youth.common.net.DownloadListenerHelper;
import com.mxsella.youth.common.utils.AppUtils;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.Constants;
import com.mxsella.youth.common.utils.RootShellCmd;
import com.mxsella.youth.common.utils.ToastUtil;
import com.mxsella.youth.common.widget.VersionUpdateDialog;
import com.mxsella.youth.contract.MainContract;
import com.mxsella.youth.presenter.MainPresenter;
import com.mxsella.youth.service.OnlineService;
import com.mxsella.youth.service.WifiSignalService;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.io.File;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import butterknife.BindView;
import butterknife.OnClick;

public class MainActivity extends BaseMvpActivity<MainContract.Presenter>
        implements MainContract.View {

    private final int HANDLER_GET_UPDATE = 1002;
    private final int HANDLER_CONNECT_USB = 1009;

    @BindView(R.id.tv_version)
    TextView tvVersion;
    @BindView(R.id.tv_deviceId)
    TextView tvDeviceId;
    @BindView(R.id.et_password)
    EditText et_password;
    @BindView(R.id.setting_btn)
    ImageView iv_setting;
    @BindView(R.id.iv_wifi)
    ImageView iv_wifi;
    @BindView(R.id.iv_password_view)
    ImageView iv_password_view;

    DownloadManager downloadManager;

    SharedPreferences sp;
    private String currentLang;
    private String lang;
    int signalStrength;
    int signalLevel;

    int selectionStart;
    int selectionEnd;
    private BroadcastReceiver wifiSignalReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("wifi_signal")) {
                signalStrength = intent.getIntExtra("signal_strength", 0);
                Log.d("signalStrength ==> ", "" + signalStrength);
                if (signalStrength >= -50) {
                    signalLevel = 4; // 信号非常强
                    iv_wifi.setBackgroundResource(R.drawable.wifi_signal4);
                } else if (signalStrength >= -65) {
                    signalLevel = 3; // 信号较强
                    iv_wifi.setBackgroundResource(R.drawable.wifi_signal3);
                } else if (signalStrength >= -80) {
                    signalLevel = 2; // 信号一般
                    iv_wifi.setBackgroundResource(R.drawable.wifi_signal2);
                } else if (signalStrength >= -100) {
                    signalLevel = 1; // 信号较弱
                    iv_wifi.setBackgroundResource(R.drawable.wifi_signal1);
                } else {
                    signalLevel = 0; // 信号非常弱
                    iv_wifi.setBackgroundResource(R.drawable.wifi_signal0);
                }
            }
        }
    };

    @Override
    protected MainContract.Presenter initPresenter() {
        return new MainPresenter(this);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void initView() {
        super.initView();
        // 注册广播接收器
        IntentFilter intentFilter = new IntentFilter("wifi_signal");
        registerReceiver(wifiSignalReceiver, intentFilter);
        Intent wifiServiceIntent = new Intent(this, WifiSignalService.class);
        startService(wifiServiceIntent);

        currentLang = Config.getLanguage();
        if (TextUtils.isEmpty(currentLang)) {
            Config.saveLanguage(this.getResources().getConfiguration().locale.getLanguage());
            currentLang = Config.getLanguage();
        }
        lang = currentLang;
//        LanguageUtils.applyLanguage(Locale.SIMPLIFIED_CHINESE, false);
        if (Config.getCommMode().equals(Constants.MODE_USB)) {
            // 部分设备开机第一次无法连接USB
            mainHandler.sendEmptyMessageDelayed(HANDLER_CONNECT_USB, 1000);
        } else if (Config.getCommMode().startsWith("SP")) {
            SPService.getInstance().connect("/dev/" + Config.getCommMode().split("_")[1]);
        }
        tvVersion.setText(this.getResources().getString(R.string.version)+Config.versionName);
        tvDeviceId.setText(this.getResources().getString(R.string.deviceId)+Config.deviceId);


        iv_password_view.setOnTouchListener((v, event) -> {
            int action = event.getAction();
            if (v.getId() == R.id.iv_password_view) {
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        iv_password_view.setSelected(true);
                        selectionStart = et_password.getSelectionStart();
                        selectionEnd = et_password.getSelectionEnd();
                        et_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                        et_password.setSelection(selectionStart, selectionEnd);
                        break;
                    case MotionEvent.ACTION_UP:
                        iv_password_view.setSelected(false);
                        selectionStart = et_password.getSelectionStart();
                        selectionEnd = et_password.getSelectionEnd();
                        et_password.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        et_password.setSelection(selectionStart, selectionEnd);
                        break;
                }
            }
            return true;
        });

    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        mainHandler.sendEmptyMessage(HANDLER_GET_UPDATE);

        if (Build.VERSION.SDK_INT >= 23) {
            requestPermission();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Intent stopService = new Intent(MainActivity.this, OnlineService.class);
        stopService(stopService);
        // 取消广播接收器注册
        unregisterReceiver(wifiSignalReceiver);
        if (Config.getCommMode().equals(Constants.MODE_USB))
            USBService.getInstance(this).destroy();
    }

    @OnClick({R.id.login_btn, R.id.setting_btn, R.id.iv_wifi})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.login_btn:
                String password = Config.getPassword();
                String input_password = et_password.getText().toString().trim();
                if (password.equals(input_password)) {
                    navigateTo(ManageActivity.class);
                    finish();
                } else {
                    ToastUtil.showToast(this.getResources().getString(R.string.correct_password_info));
                }
                break;
            case R.id.setting_btn:
                navigateTo(SettingsActivity.class);
                break;
            case R.id.iv_wifi:
                Intent wifiIntent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                startActivity(wifiIntent);
                break;
            default:
                break;
        }
    }

    /**
     * 请求更新
     */
    private void requestUpdate() {
        Map<String, String> map = new HashMap<>();
        map.put("deviceId", Config.deviceId);
        Log.d("deviceId", Config.deviceId);
        map.put("versionCode", AppUtils.getVersionCode(MyApplication.getInstance()) + "");
        map.put("versionName", AppUtils.getVersionName(MyApplication.getInstance()));
        mPresenter.requestUpdate(map);
    }

    @SuppressLint("HandlerLeak")
    Handler mainHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case HANDLER_GET_UPDATE:
                    requestUpdate();
                    mainHandler.sendEmptyMessageDelayed(HANDLER_GET_UPDATE, 60 * 60 * 1000);
                    break;
                case HANDLER_CONNECT_USB:
                    int state = USBService.getInstance(MainActivity.this).connection();
                    if (state != USBInterface.usb_ok) {
                        sendEmptyMessageDelayed(HANDLER_CONNECT_USB, 1000);
                    }
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void showUpdateDialog(UpdateInfo updateInfo) {
        if (updateInfo.getVersionCode() != Config.getIgnoreVersionCode()) {
            VersionUpdateDialog updateDialog = new VersionUpdateDialog(this, false, updateInfo.getVersionName(), updateInfo.getVersionCode(), updateInfo.getLog());
            updateDialog.setOnUpdateClickListener(v -> {
                UpdateConfiguration configuration = new UpdateConfiguration()
                        //设置下载过程的监听
                        .setOnDownloadListener(new DownloadListenerHelper() {
                            @Override
                            public void done(File apk) {
                                RootShellCmd.install(apk.getName());
                            }

                            @Override
                            public void downloading(int max, int progress) {
                                updateDialog.setDownloadProgress((int) Math.ceil(progress * 100.0f / max));
                            }
                        });
                downloadManager = DownloadManager.getInstance(this);
                if (downloadManager == null || downloadManager.isDownloading()) {
                    return;
                }
                downloadManager.setApkName("youth.apk")
                        .setSmallIcon(R.drawable.ic_launcher)
                        .setApkUrl(updateInfo.getDownLoadUrl())
                        .setConfiguration(configuration)
                        .download();
            });
            updateDialog.setCanceledOnTouchOutside(false);
            updateDialog.show();
        }
    }

    @SuppressLint("CheckResult")
    private void requestPermission() {
        RxPermissions rxPermission = new RxPermissions(MainActivity.this);
        rxPermission.requestEach(Manifest.permission.RECEIVE_BOOT_COMPLETED,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_WIFI_STATE,
                        Manifest.permission.CHANGE_NETWORK_STATE,
                        Manifest.permission.ACCESS_WIFI_STATE,
                        Manifest.permission.ACCESS_NETWORK_STATE,
                        Manifest.permission.VIBRATE)
                .subscribe(permission -> {
                });
    }
}