package com.mxsella.youth.common.utils;

import android.util.Log;

import com.mxsella.youth.bean.BaseResponse;
import com.mxsella.youth.bean.UseTimesHistory;
import com.mxsella.youth.common.net.BaseObserver;
import com.mxsella.youth.common.net.NetworkService;
import com.mxsella.youth.common.net.RxScheduler;

import org.litepal.LitePal;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.reactivex.disposables.Disposable;

public class UseTimesHistoryHelper {

    private ExecutorService service = Executors.newSingleThreadExecutor();

    public static UseTimesHistoryHelper getInstance() {
        return Holder.INSTANCE;
    }

    private static class Holder {
        private static UseTimesHistoryHelper INSTANCE = new UseTimesHistoryHelper();
    }

    private UseTimesHistory history;

    /**
     * 开始计算手柄使用次数历史
     *
     * @param handleType 手柄类型
     * @param startTime  开始时间
     * @param remark     备注字段
     */
    public void setStart(int handleType, long startTime, String remark) {
        if (history == null) {
            history = new UseTimesHistory(UUIDUtils.getUUID(), handleType, TimeDateUtils.stampToDate(startTime), TimeDateUtils.getNowDateTime(), remark, false);
        }
    }

    /**
     * 更新次数
     */
    public void updateTimes() {
        if (history != null) {
            int type = history.getHandleType();
            HashMap map = GsonUtils.deserialize(history.getRemark(), HashMap.class);
            double times = (double) map.get("times");
            String username = (String) map.get("username");
            String telephone = (String) map.get("telephone");

            HashMap<String, Object> remark = new HashMap<>();
            Config.saveRemainTimes(type, Config.getRemainTimes(type) - 1);
            remark.put("times", times + 1);
            remark.put("remainTimes", Config.getRemainTimes(type));
            remark.put("username", username);
            remark.put("telephone", telephone);

            history.setRemark(GsonUtils.serialize(remark));
            Log.d("history", "=======================>" + history);
            saveOrUpdateNew(history);
        }
    }

    /**
     * 结束计算手柄使用次数历史
     */
    public void setEnd() {
        updateUseTimesHistory();
        history = null;
    }

    /**
     * 设置为在线状态
     */
    public void setOnline() {
        Config.onlineState = Constants.STATE_ONLINE;
        updateOnlineState();
    }

    /**
     * 设置为工作状态
     */
    public void setWork() {
        Config.onlineState = Constants.STATE_WORK;
        updateOnlineState();
    }

    public void updateOnlineState() {
        Disposable disposable = NetworkService.getApi().uploadOnlineState(Config.deviceId, Config.onlineState)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                });
    }

    public void updateUseTimesHistory() {
        if (history != null) {
            String remark = history.getRemark();
//            Log.d("remark", remark);
            HashMap hashMap = GsonUtils.deserialize(remark, HashMap.class);
            if ((Double) hashMap.get("times") <= 0)
                return;
            String historyId = history.getHistoryId();
            history.setEndTime(TimeDateUtils.stampToDate(System.currentTimeMillis()));
            saveOrUpdateNew(history);
//            Log.d("history ==> ", history.toString());
            List<UseTimesHistory> historyList = getNotUpload();
            HashMap<String, Object> map = new HashMap<>();
            map.put("remainTimes", Config.getAllRemainTimes());
            map.put("history", historyList);
//            Log.d("map ==> ", map.toString());
            Disposable disposable = NetworkService.getApi().uploadUseTimesHistory(Config.deviceId, map)
                    .compose(RxScheduler.obserThreadTransformer())
                    .subscribeWith(new BaseObserver<BaseResponse<List<Integer>>>() {
                        @Override
                        public void onSuccess(BaseResponse<List<Integer>> data) {
                            if (data.getCode() == Constants.SUCCESS) {
                                for (int i = 0; i < data.getData().size(); i++) {
//                                    Log.d("onSuccess", "==========>"+data.getData());
                                    Config.saveRemainTimes(i, data.getData().get(i));
                                }
                                for (UseTimesHistory h : historyList) {
                                    if (!h.getHistoryId().equals(historyId)) {
                                        h.setIfUpload(true);
                                        saveOrUpdate(h);
                                    }
                                }
                            }
                        }

                        @Override
                        public void onFail(String errorMsg) {
                            super.onFail(errorMsg);
//                            Log.d("onFail", "----------->"+errorMsg);
                        }
                    });
        }
    }

    private void saveOrUpdate(UseTimesHistory history) {
        service.execute(() -> history.saveOrUpdate("historyId = ?", String.valueOf(history.getHistoryId())));
    }

    /**
     * 不使用线程池更新
     *
     * @param history
     */
    private void saveOrUpdateNew(UseTimesHistory history) {
        history.saveOrUpdate("historyId = ?", String.valueOf(history.getHistoryId()));
    }

    public List<UseTimesHistory> getNotUpload() {
        return LitePal.where("ifUpload = 0").find(UseTimesHistory.class);
    }

    public void printHistory() {
        List<UseTimesHistory> useHistoryList = LitePal.findAll(UseTimesHistory.class);
        for (UseTimesHistory history : useHistoryList) {
            Log.d("UseTimesHistory", history.toString());
        }
    }
}
