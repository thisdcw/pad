package com.mxsella.youth.adapter;

import android.app.Activity;
import android.content.Context;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.mxsella.youth.R;
import com.mxsella.youth.bean.Record;
import com.mxsella.youth.bean.User;

import java.util.List;

import me.jessyan.autosize.AutoSize;

public class RecordAdapter extends BaseQuickAdapter<Record, BaseViewHolder> {

    private final Context context;
    private int size;

    private int page = 1;

    public void setPage(int page) {
        this.page = page;
    }

    public RecordAdapter(Context context, @Nullable List<Record> data, int size) {
        super(R.layout.item_record, data);
        this.context = context;
        this.size = size;
    }

    @Override
    protected void convert(BaseViewHolder helper, Record item) {
        // 部分系统因为RecyclerView复用可能导致Item大小不一
        AutoSize.autoConvertDensityOfGlobal((Activity) context);
        int position = helper.getAdapterPosition();
        helper.setText(R.id.rec_date, item.getUsedDate());
        helper.setText(R.id.rec_frequency, String.valueOf(item.getCount()));
        helper.setText(R.id.rec_head, item.getToolHead());
        if (item.getItem() == 0) {
            helper.setText(R.id.rec_item, "point");
        } else {
            helper.setText(R.id.rec_item, "line");
        }

        // 设置斑马线背景色
        if (position % 2 == 0) {
            helper.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.stop_space));
        } else {
            helper.itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.work_space));
        }
    }

}
