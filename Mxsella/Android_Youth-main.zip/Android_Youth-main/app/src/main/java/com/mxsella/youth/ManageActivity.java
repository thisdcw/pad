package com.mxsella.youth;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Paint;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mxsella.youth.adapter.UserAdapter;
import com.mxsella.youth.bean.BaseResponse;
import com.mxsella.youth.bean.Record;
import com.mxsella.youth.bean.UpdateInfo;
import com.mxsella.youth.bean.UseTimesHistory;
import com.mxsella.youth.bean.User;
import com.mxsella.youth.common.base.BaseActivity;
import com.mxsella.youth.common.base.BaseMvpActivity;
import com.mxsella.youth.common.net.BaseObserver;
import com.mxsella.youth.common.net.NetworkService;
import com.mxsella.youth.common.net.RxScheduler;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.Constants;
import com.mxsella.youth.common.utils.NavigationBarUtil;
import com.mxsella.youth.common.utils.RecordHelper;
import com.mxsella.youth.common.utils.ToastUtil;
import com.mxsella.youth.common.utils.UseTimesHistoryHelper;
import com.mxsella.youth.common.utils.UserHelper;
import com.mxsella.youth.common.widget.SoftKeyboardStateHelper;
import com.mxsella.youth.contract.CheckContract;
import com.mxsella.youth.contract.MainContract;
import com.mxsella.youth.presenter.CheckPresenter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

public class ManageActivity extends BaseMvpActivity<CheckContract.Presenter>
        implements CheckContract.View {

    public static String USER = "user";

    @BindView(R.id.edt_search)
    EditText edtSearch;
    @BindView(R.id.btn_search)
    Button btnSearch;
    @BindView(R.id.rcv_user)
    RecyclerView rcvUser;
    @BindView(R.id.tv_number_user)
    TextView tvNumberUser;
    @BindView(R.id.tv_current_page_user)
    TextView tvCurrentPageUser;
    @BindView(R.id.tv_total_page_user)
    TextView tvTotalPageUser;
    @BindView(R.id.edt_jump_user)
    EditText edtJumpUser;
    @BindView(R.id.tv_jump_user)
    TextView tvJumpUser;
    @BindView(R.id.tv_last_page_user)
    TextView tvLastPageUser;
    @BindView(R.id.tv_next_page_user)
    TextView tvNextPageUser;

    @BindView(R.id.register_btn)
    Button register_btn;

    @BindView(R.id.login_btn)
    Button login_btn;

    @BindView(R.id.return_btn)
    ImageView return_btn;
    private CompositeDisposable mDisposables = new CompositeDisposable();
    private InputMethodManager manager;

    private static final int DEFAULT_SIZE = 10;
    private String stringHaveRecords;

    private List<User> userList;

    private UserAdapter userAdapter;
    private User selectUser;

    private int selectId = -1;
    private int currentPageUser = 0;
    private int totalPageUser = 0;

    private boolean inSearch = false;
    private String keyword;

    @Override
    public int getLayoutId() {
        return R.layout.activity_manage;
    }


    @Override
    protected CheckContract.Presenter initPresenter() {
        return new CheckPresenter(this);
    }

    @Override
    public void initView() {
        super.initView();
        register_btn.setOnClickListener(v -> navigateTo(RegisterActivity.class));
        manager = ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE));
        SoftKeyboardStateHelper helper = new SoftKeyboardStateHelper(edtSearch);
        helper.addSoftKeyboardStateListener(new SoftKeyboardStateHelper.SoftKeyboardStateListener() {
            @Override
            public void onSoftKeyboardOpened(int keyboardHeightInPx) {
            }

            @Override
            public void onSoftKeyboardClosed() {
                hideBottomUIMenu();
            }
        });
        setFocusChangeListener(edtSearch);
        setFocusChangeListener(edtJumpUser);
        setEdtEnter(edtSearch, btnSearch);
        setEdtEnter(edtJumpUser, tvJumpUser);

        tvLastPageUser.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        tvNextPageUser.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        tvJumpUser.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        stringHaveRecords = getResources().getString(R.string.have_records);

        userList = UserHelper.getInstance().getUserList(1, DEFAULT_SIZE);
        tvNumberUser.setText(String.format(stringHaveRecords, UserHelper.getInstance().total()));
        totalPageUser = UserHelper.getInstance().totalPage(DEFAULT_SIZE);
        if (totalPageUser == 0)
            currentPageUser = 0;
        else
            currentPageUser = 1;
        tvTotalPageUser.setText(String.valueOf(totalPageUser));
        tvCurrentPageUser.setText(String.valueOf(currentPageUser));
        userAdapter = new UserAdapter(this, userList, DEFAULT_SIZE);
        rcvUser.setLayoutManager(new LinearLayoutManager(this));
        rcvUser.setAdapter(userAdapter);

        userAdapter.setOnItemChildClickListener((adapter, view, position) -> {
            selectUser = userList.get(position);
            selectId = selectUser.getUserId();
            if (view.getId() == R.id.btn_detail) {
                if (selectUser == null) {
                    ToastUtil.showToast(this.getResources().getString(R.string.select_user_info));
                } else {
                    Intent intent = new Intent(this, RecordActivity.class);
                    intent.putExtra("userId", selectId);
                    startActivity(intent);
                }
            }
            if (view.getId() == R.id.btn_operation) {
                Intent intent = new Intent(this, EditUserActivity.class);
                intent.putExtra(USER, selectUser);
                startActivity(intent);
                finish();
            }
        });
        userAdapter.setOnItemClickListener((adapter, view, position) -> {
            if (selectUser == null || selectUser.getUserId() != userList.get(position).getUserId()) {
                selectUser = userList.get(position);
                selectId = selectUser.getUserId();
                userAdapter.setSelectUserId(selectUser.getUserId());
            } else {
                selectUser = null;
                userAdapter.setSelectUserId(0);
            }
            userAdapter.notifyDataSetChanged();
        });

        login_btn.setOnClickListener(v -> {
            if (selectUser == null) {
                ToastUtil.showToast(this.getResources().getString(R.string.select_user_info));
            } else {
                Intent intent = new Intent(this, WorkActivity.class);
                intent.putExtra("userId", selectId);
                startActivity(intent);
            }
        });
        uploadData();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mDisposables.clear();
    }

    @OnClick(R.id.return_btn)
    public void onReturnClick() {
        navigateTo(MainActivity.class);
        finish();
    }

    @OnClick({R.id.btn_search, R.id.btn_all,
            R.id.tv_last_page_user, R.id.tv_next_page_user, R.id.tv_jump_user})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_search:
                searchKeyword();
                break;
            case R.id.btn_all:
                inSearch = false;
                userList.clear();
                userList.addAll(UserHelper.getInstance().getUserList(1, DEFAULT_SIZE));
                tvNumberUser.setText(String.format(stringHaveRecords, UserHelper.getInstance().total()));
                totalPageUser = UserHelper.getInstance().totalPage(DEFAULT_SIZE);
                if (totalPageUser == 0)
                    currentPageUser = 0;
                else
                    currentPageUser = 1;
                tvTotalPageUser.setText(String.valueOf(totalPageUser));
                tvCurrentPageUser.setText(String.valueOf(currentPageUser));
                userAdapter.notifyDataSetChanged();
                selectUser = null;
                userAdapter.setSelectUserId(0);
                break;
            case R.id.tv_last_page_user:
                if (currentPageUser <= 1)
                    return;
                refresh(currentPageUser - 1);
                if (inSearch)
                    userList.addAll(UserHelper.getInstance().getUserListByKeyword(keyword, currentPageUser, DEFAULT_SIZE));
                else
                    userList.addAll(UserHelper.getInstance().getUserList(currentPageUser, DEFAULT_SIZE));
                userAdapter.notifyDataSetChanged();
                break;
            case R.id.tv_next_page_user:
                if (currentPageUser >= totalPageUser)
                    return;
                refresh(currentPageUser + 1);
                if (inSearch)
                    userList.addAll(UserHelper.getInstance().getUserListByKeyword(keyword, currentPageUser, DEFAULT_SIZE));
                else
                    userList.addAll(UserHelper.getInstance().getUserList(currentPageUser, DEFAULT_SIZE));
                userAdapter.notifyDataSetChanged();
                break;
            case R.id.tv_jump_user:
                if (edtJumpUser.getText().toString().equals("")) {
                    ToastUtil.showToast(getString(R.string.input_correct_page));
                    return;
                }
                int pageUser = Integer.parseInt(edtJumpUser.getText().toString());
                if (pageUser < 1 || pageUser > totalPageUser) {
                    ToastUtil.showToast(getString(R.string.input_correct_page));
                    return;
                }
                if (currentPageUser != pageUser) {
                    currentPageUser = pageUser;
                    refresh(pageUser);
                    if (inSearch)
                        userList.addAll(UserHelper.getInstance().getUserListByKeyword(keyword, currentPageUser, DEFAULT_SIZE));
                    else
                        userList.addAll(UserHelper.getInstance().getUserList(currentPageUser, DEFAULT_SIZE));
                    userAdapter.notifyDataSetChanged();
                }
                break;
            default:
                break;
        }
    }

    private void refresh(int page) {
        page = Math.max(1, page);

        userList.clear();
        totalPageUser = UserHelper.getInstance().totalPageUser(DEFAULT_SIZE);

        if (totalPageUser == 0) {
            currentPageUser = 0;
        } else {
            currentPageUser = Math.min(totalPageUser, page);
            userList.addAll(UserHelper.getInstance().getUserList(currentPageUser, DEFAULT_SIZE));
        }

        tvCurrentPageUser.setText(String.valueOf(currentPageUser));

        tvTotalPageUser.setText(String.valueOf(totalPageUser));

        tvNumberUser.setText(String.format(stringHaveRecords, UserHelper.getInstance().total()));
        userAdapter.setPage(currentPageUser);
        userAdapter.notifyDataSetChanged();
    }
    void uploadData() {
        mPresenter.uploadUseTimesHistory(Config.deviceId, Config.getAllRemainTimes(), UseTimesHistoryHelper.getInstance().getNotUpload());
    }
    public void searchKeyword() {
        keyword = edtSearch.getText().toString();
        if (TextUtils.isEmpty(keyword)) {
            ToastUtil.showToast(getResources().getString(R.string.no_empty_search));
            return;
        }
        inSearch = true;
        userList.clear();
        userList.addAll(UserHelper.getInstance().getUserListByKeyword(keyword, 1, DEFAULT_SIZE));
        tvNumberUser.setText(String.format(stringHaveRecords, UserHelper.getInstance().totalByKeyword(keyword)));
        totalPageUser = UserHelper.getInstance().totalPageByKeyword(keyword, DEFAULT_SIZE);
        if (totalPageUser == 0)
            currentPageUser = 0;
        else
            currentPageUser = 1;
        tvTotalPageUser.setText(String.valueOf(totalPageUser));
        tvCurrentPageUser.setText(String.valueOf(currentPageUser));
        userAdapter.notifyDataSetChanged();

        selectUser = null;
        userAdapter.setSelectUserId(0);
    }

    @Override
    protected void onStart() {
        super.onStart();
        refresh();
    }

    public void refresh() {
        userList.clear();
        if (inSearch) {
            totalPageUser = UserHelper.getInstance().totalPageByKeyword(keyword, DEFAULT_SIZE);
            if (currentPageUser > totalPageUser) {
                currentPageUser = totalPageUser;
            }
            userList.addAll(UserHelper.getInstance().getUserListByKeyword(keyword, currentPageUser, DEFAULT_SIZE));
            tvNumberUser.setText(String.format(stringHaveRecords, UserHelper.getInstance().totalByKeyword(keyword)));
        } else {
            totalPageUser = UserHelper.getInstance().totalPage(DEFAULT_SIZE);
            if (currentPageUser > totalPageUser) {
                currentPageUser = totalPageUser;
            } else if (currentPageUser == 0 && totalPageUser > 0) {
                currentPageUser = 1;
            }
            userList.addAll(UserHelper.getInstance().getUserList(currentPageUser, DEFAULT_SIZE));
            tvNumberUser.setText(String.format(stringHaveRecords, UserHelper.getInstance().total()));
        }
        tvCurrentPageUser.setText(String.valueOf(currentPageUser));
        tvTotalPageUser.setText(String.valueOf(totalPageUser));
        userAdapter.notifyDataSetChanged();

        if (selectUser != null) {
            selectUser = UserHelper.getInstance().getUserById(selectUser.getUserId());
        }
    }

    public void setEdtEnter(EditText editText, View callView) {
        editText.setOnEditorActionListener((textView, i, keyEvent) -> {
            if (i == EditorInfo.IME_ACTION_DONE) {
                //隐藏软键盘
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
                callView.callOnClick();
            }
            return false;
        });
        editText.setOnKeyListener((view, i, keyEvent) -> {
            if (keyEvent.getAction() == KeyEvent.ACTION_UP) {
                if (i == KeyEvent.KEYCODE_NUMPAD_ENTER || i == KeyEvent.KEYCODE_ENTER) {
                    //隐藏软键盘
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
                    callView.callOnClick();
                }
            }
            return false;
        });
    }

    public void setFocusChangeListener(EditText editText) {
        editText.setOnFocusChangeListener((view, hasFocus) -> {
            if (!hasFocus) {
                if (manager != null) {
                    manager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                    hideBottomUIMenu();
                }
            }
        });
    }

    @Override
    public void jumpToMain(boolean jump) {
        if (jump){
            navigateTo(MainActivity.class);
            finish();
        }
    }
}