package com.mxsella.youth.comm;

import android.util.Log;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class Protocol {

    public static final short HEAD = 0x5AA5; // 帧头
    //    public static final short ADDR_WORK_SWITCH = 0x2905; // 工作开关地址
//    public static final short ADDR_TIME = 0x2932;
    public static final short MODE_OFF = 0; // 关闭
    public static final short MODE_ON = 1; // 开启
    public static final short MODE_END = 2; // 结束
    public static final short ADDR_WORK = 0x3510;
    public static final short ADDR_PAUSE = 0x3511;
    public static final byte DEVICE_TO_CLIENT = (byte) 0x82;
    public static final byte CLIENT_TO_DEVICE = (byte) 0x83;

    public static final short ADDR_CUSTOMER_ID = 0x1200;
    public static final short ADDR_HANDLE = 0x1001;//1为LINE,0为POINT
    public static final short ADDR_LINE_STATUS = 0x1046;//O为白色,1为黄色
    public static final short ADDR_POINT_STATUS = 0x1048;
    public static final short ADDR_SPACING = 0x1008;
    public static final short ADDR_SPACING_RESIZE = 0x1010;
    public static final short ADDR_LENGTH = 0x1012;
    public static final short ADDR_LINE_POWER = 0x1014;
    public static final short ADDR_LINE_POWER_RESIZE = 0x1108;
    public static final short ADDR_LINE_FREQUENCY = 0x1003;
    public static final short ADDR_LINE_DEPTH = 0x1090;
    public static final short ADDR_LINE_SHOTS_DONE = 0x1007;
    public static final short ADDR_LINE_SHOTS_REMAIN = 0x1009;
    public static final short ADDR_LINE_M = 0x1060;
    public static final short ADDR_SAVE = 0x1066;
    public static final short ADDR_LINE_MODE = 0x1092;
    public static final short ADDR_SPEED = 0x100A;
    public static final short ADDR_QUANTITY = 0x100E;
    public static final short ADDR_POINT_POWER = 0X101C;
    public static final short ADDR_RESIZE = 0X1104;
    public static final short ADDR_POINT_FREQUENCY = 0x1030;
    public static final short ADDR_POINT_DEPTH = 0x1098;
    public static final short ADDR_POINT_SHOTS_DONE = 0x1034;
    public static final short ADDR_POINT_SHOTS_REMAIN = 0x1036;
    public static final short ADDR_POINT_M = 0x106A;
    public static final short ADDR_POINT_M_SELECT = 0x1068;
    public static final short ADDR_POINT_SAVE = 0x106E;
    public static final short ADDR_POINT_MODE = 0x1096;
    public static final short ADDR_POINT_MODE_SELECT = 0x1094;
    public static final short ADDR_LINE = 0x100B;
    public static final short ADDR_LINE_TOTAL = 0x1020;
    public static final short ADDR_POINT = 0x100D;
    public static final short ADDR_POINT_TOTAL = 0x1022;
    public static final short ADDR_TOTAL_RESET = 0x1006;
    public static final short ADDR_READY = 0x1026;
    public static final short ADDR_SETTINGS = 0x1040;

    public static byte[] SELECT_LINE = Protocol.hexToByteArray("5AA506831001010001");//选择line手柄
    public static byte[] SELECT_POINT = Protocol.hexToByteArray("5AA506831001010002");//选择point手柄
    public static byte[] LINE_UNCONNECTED = Protocol.hexToByteArray("5AA5058210460001");//line未连接
    public static byte[] LINE_CONNECTED = Protocol.hexToByteArray("5AA5058210460000");//line已连接
    public static byte[] POINT_UNCONNECTED = Protocol.hexToByteArray("5AA5058210480001");//point未连接
    public static byte[] POINT_CONNECTED = Protocol.hexToByteArray("5AA5058210480000");//point已连接
    public static byte[] SPACING_ADD = Protocol.hexToByteArray("5AA506831010010001");//space+
    public static byte[] SPACING_REDUCE = Protocol.hexToByteArray("5AA506831010010000");//space-
    public static byte[] LENGTH_MIN = Protocol.hexToByteArray("5AA506831012010032");//length min
    public static byte[] LENGTH_MAX = Protocol.hexToByteArray("5AA5068310120100FA");//length max
    public static byte[] LINE_POWER_ADD = Protocol.hexToByteArray("5AA506831108010001");//line power+
    public static byte[] LINE_POWER_REDUCE = Protocol.hexToByteArray("5AA506831108010000");//line power-
    public static byte[] LINE_M1_SELECT = Protocol.hexToByteArray("5AA506831060010001");//选中M1
    public static byte[] LINE_M2_SELECT = Protocol.hexToByteArray("5AA506831060010002");//选中M2
    public static byte[] LINE_M3_SELECT = Protocol.hexToByteArray("5AA506831060010003");//选中M3
    public static byte[] LINE_SAVE_SELECT = Protocol.hexToByteArray("5AA506831066010001");//选中SAVE
    public static byte[] LINE_MP_SELECT = Protocol.hexToByteArray("5AA506831092010000");//选中MP
    public static byte[] LINE_NORMAL_SELECT = Protocol.hexToByteArray("5AA506831092010001");//选中NORMAL
    public static byte[] SPEED_ADD = Protocol.hexToByteArray("5AA50683101A010001");//speed+
    public static byte[] SPEED_REDUCE = Protocol.hexToByteArray("5AA50683101A010000");//speed-
    public static byte[] QUANTITY_ADD = Protocol.hexToByteArray("5AA50683101E010001");//quantity+
    public static byte[] QUANTITY_REDUCE = Protocol.hexToByteArray("5AA50683101E010000");//quantity-
    public static byte[] POINT_POWER_ADD = Protocol.hexToByteArray("5AA506831104010001");//point power+
    public static byte[] POINT_POWER_REDUCE = Protocol.hexToByteArray("5AA506831104010000");//point power-
    public static byte[] POINT_M1_SELECT = Protocol.hexToByteArray("5AA506831068010001");//选中M1
    public static byte[] POINT_M2_SELECT = Protocol.hexToByteArray("5AA506831068010002");//选中M2
    public static byte[] POINT_M3_SELECT = Protocol.hexToByteArray("5AA506831068010003");//选中M3
    public static byte[] POINT_SAVE_SELECT = Protocol.hexToByteArray("5AA50683106E010001");//选中SAVE
    public static byte[] POINT_MP_SELECT = Protocol.hexToByteArray("5AA506831094010001");//选中MP
    public static byte[] POINT_NORMAL_SELECT = Protocol.hexToByteArray("5AA506831094010002");//选中NORMAL
    public static byte[] LINE_TOTAL_RESET = Protocol.hexToByteArray("5AA506831006010001");//line total reset
    public static byte[] POINT_TOTAL_RESET = Protocol.hexToByteArray("5AA506831006010002");//point total reset
    public static byte[] READY_PAUSE = Protocol.hexToByteArray("5AA506831026010001");//ready按钮
    public static byte[] INTO_SETTINGS = Protocol.hexToByteArray("5AA506831040010001");//进入设置后台
    public static byte[] READY_IMFO = Protocol.hexToByteArray("5AA505821096");

    public static int toInt(byte[] bytes) {
        int len = bytes.length;
        byte[] byteArray = Arrays.copyOfRange(bytes, len - 2, len);
        int intValue = 0;

        for (int i = 0; i < byteArray.length; i++) {
            intValue <<= 8;  // 左移8位
            intValue |= (byteArray[i] & 0xFF);
        }
        return intValue;
    }

    /**
     * 包编码
     */
    public static byte[] encode(short address, short command) {
        // 数据长度 来源:1字节 地址:2字节 几个地址的数据: 1 字节  命令: 2字节
        byte len = 1 + 2 + 1 + 2;
        ByteBuffer buffer = ByteBuffer.allocate(9);
        buffer.putShort(HEAD); // 2字节头部
        buffer.put(len); // 1字节数据长度
        buffer.put(CLIENT_TO_DEVICE); // 客户端 到 硬件
        buffer.putShort(address); // 地址
        buffer.put((byte) 1); // 地址个数
        buffer.putShort(command); // 命令
        return buffer.array();
    }

    public static String gbkBytesToShow(byte[] gbkBytes) {

        StringBuilder format = new StringBuilder();
        for (byte gbkByte : gbkBytes) {
            format.append(String.format("%02X", gbkByte));
        }
        String result = format.toString();
        try {
            return new String(hexToByteArray(result), "GBK");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return "";  // 返回空字符串表示解码失败
        }
    }

    public static byte[] gbkToBytes(String gbkString) {
        try {
            return gbkString.getBytes("GBK");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return new byte[0];  // 返回空字节数组表示转换失败
        }
    }



    /**
     * short转字节数组
     */
    public static byte[] short2Bytes(short num) {
        byte[] bytes = new byte[2];
        bytes[0] = (byte) ((num >> 8) & 0xFF);
        bytes[1] = (byte) num;
        return bytes;
    }

    /**
     * short数组转字节数组
     */
    public static byte[] shorts2Bytes(short[] shorts) {
        byte[] bytes = new byte[shorts.length * 2];
        byte[] temp = null;
        int i = 0;
        for (short s : shorts) {
            temp = short2Bytes(s);
            bytes[i++] = temp[0];
            bytes[i++] = temp[1];
        }
        return bytes;
    }

    /**
     * 是否相等
     */
    public static boolean endWith(byte[] src, byte[] target) {
        if (target.length == 0) return false;
        if (src.length < target.length) return false;
        for (int i = 0; i < target.length; i++) {
            if (target[target.length - i - 1] != src[src.length - i - 1]) {
                return false;
            }
        }
        return true;
    }

    /**
     * 字节数组转int
     */
    public static int bytesToInt(byte[] bytes) {
        int res = 0;
        for (int i = 0; i < bytes.length; i++) {
            res = (res << 8) | (bytes[i] & 0xff);
        }
        return res;
    }

    /**
     * Hex字符串转byte
     *
     * @param inHex 待转换的Hex字符串
     * @return 转换后的byte
     */
    public static byte hexToByte(String inHex) {
        return (byte) Integer.parseInt(inHex, 16);
    }

    /**
     * hex字符串转byte数组
     *
     * @param inHex 待转换的Hex字符串
     * @return 转换后的byte数组结果
     */
    public static byte[] hexToByteArray(String inHex) {
        int hexlen = inHex.length();
        byte[] result;
        if (hexlen % 2 == 1) {
            //奇数
            hexlen++;
            result = new byte[(hexlen / 2)];
            inHex = "0" + inHex;
        } else {
            //偶数
            result = new byte[(hexlen / 2)];
        }
        int j = 0;
        for (int i = 0; i < hexlen; i += 2) {
            result[j] = hexToByte(inHex.substring(i, i + 2));
            j++;
        }
        return result;
    }

    public static String bytesToHex(byte[] bytes) {
        String strHex = "";
        StringBuilder sb = new StringBuilder("");
        for (int n = 0; n < bytes.length; n++) {
            strHex = Integer.toHexString(bytes[n] & 0xFF);
            sb.append((strHex.length() == 1) ? "0" + strHex : strHex); // 每个字节由两个字符表示，位数不够，高位补0
        }
        return sb.toString().trim();
    }
}
