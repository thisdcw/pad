package com.mxsella.youth.push;

public class PushUtils {
    public static final Object PUSH_LOCK = new Object();
    // push判断重复
    public static int pushNum = 20;
    public static int lastPushId = 0;
    public static String pushSync[] = new String[pushNum];

    /**
     * 判断收到的push是否重复
     */
    public static boolean isNeedHandle(String pushId) {
        int i;
        for (i = 0; i < pushNum; i++) {
            if (pushId.equals(pushSync[i])) {
                return false;
            }
        }
        return true;
    }
}
