package com.mxsella.youth.common;

import android.app.Application;
import android.content.res.Configuration;
import android.content.res.Resources;

import com.blankj.utilcode.util.LanguageUtils;
import com.mxsella.youth.comm.BleService;
import com.mxsella.youth.common.utils.AppUtils;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.DeviceIdUtils;

import org.litepal.LitePal;

import java.util.Locale;

import cn.jpush.android.api.JPushInterface;
import me.jessyan.autosize.AutoSizeConfig;

public class MyApplication extends Application {

    private static MyApplication instance;
    private static final String TAG = "MyApplication";


    @Override
    public void onCreate() {
        super.onCreate();

        AutoSizeConfig.getInstance().setExcludeFontScale(true).setUseDeviceSize(true);

        instance = this;

        LitePal.initialize(instance);
        BleService.getInstance().init(this);

        Config.mainSP = this.getSharedPreferences("main", 0);

        Config.versionName = AppUtils.getVersionName(this);
        Config.versionCode = AppUtils.getVersionCode(this);
        DeviceIdUtils.getDeviceId(this);
        JPushInterface.setDebugMode(false);    // 设置开启日志,发布时请关闭日志
        JPushInterface.init(this);    // 初始化 JPush
        switch (Config.getLanguage()) {
            case "zh":
                LanguageUtils.applyLanguage(Locale.SIMPLIFIED_CHINESE);
                break;
            case "en":
                LanguageUtils.applyLanguage(Locale.ENGLISH);
                break;
            case "ko":
                LanguageUtils.applyLanguage(Locale.KOREA);
                break;
        }
    }

    public static MyApplication getInstance() {
        return instance;
    }
}
