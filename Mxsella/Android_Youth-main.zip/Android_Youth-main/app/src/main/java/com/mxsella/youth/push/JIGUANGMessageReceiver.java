package com.mxsella.youth.push;

import android.content.Context;
import android.text.TextUtils;

import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.LocalLog;

import cn.jpush.android.api.CmdMessage;
import cn.jpush.android.api.CustomMessage;
import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.JPushMessage;
import cn.jpush.android.api.NotificationMessage;
import cn.jpush.android.service.JPushMessageReceiver;

public class JIGUANGMessageReceiver extends JPushMessageReceiver {
    private static final String TAG = "JIGUANGMessageReceiver";

    @Override
    public void onMessage(Context context, CustomMessage customMessage) {
        LocalLog.d(TAG, "||推送 JIGUANG [onMessage] " + customMessage);
        processCustomMessage(context, customMessage);
    }

    @Override
    public void onNotifyMessageOpened(Context context, NotificationMessage message) {
        LocalLog.d(TAG, "||推送 JIGUANG [onNotifyMessageOpened] " + message);
    }

    @Override
    public void onNotifyMessageArrived(Context context, NotificationMessage message) {
        LocalLog.d(TAG, "||推送 JIGUANG [onNotifyMessageArrived] " + message);
    }

    @Override
    public void onNotifyMessageDismiss(Context context, NotificationMessage message) {
        LocalLog.d(TAG, "||推送 JIGUANG [onNotifyMessageDismiss] " + message);
    }

    @Override
    public void onRegister(Context context, String registrationId) {
        LocalLog.d(TAG, "||推送 JIGUANG [onRegister] " + registrationId);
    }

    @Override
    public void onConnected(Context context, boolean isConnected) {
        LocalLog.d(TAG, "||推送 JIGUANG [onConnected] " + isConnected);
        if (!Config.getJPushBind() && !TextUtils.isEmpty(Config.deviceId)) {
            LocalLog.d(TAG, "||推送 JIGUANG 开始绑定别名:" + Config.deviceId);
            JPushInterface.setAlias(context, 1, Config.deviceId);
        }
    }

    @Override
    public void onCommandResult(Context context, CmdMessage cmdMessage) {
        LocalLog.d(TAG, "||推送 JIGUANG [onCommandResult] " + cmdMessage);
    }

    @Override
    public void onTagOperatorResult(Context context, JPushMessage jPushMessage) {
        LocalLog.d(TAG, "||推送 JIGUANG [onTagOperatorResult] " + jPushMessage);
        JIGUANGTagAliasOperatorHelper.getInstance().onTagOperatorResult(context, jPushMessage);
        super.onTagOperatorResult(context, jPushMessage);
    }

    @Override
    public void onCheckTagOperatorResult(Context context, JPushMessage jPushMessage) {
        LocalLog.d(TAG, "||推送 JIGUANG [onCheckTagOperatorResult] " + jPushMessage);
        JIGUANGTagAliasOperatorHelper.getInstance().onCheckTagOperatorResult(context, jPushMessage);
        super.onCheckTagOperatorResult(context, jPushMessage);
    }

    @Override
    public void onAliasOperatorResult(Context context, JPushMessage jPushMessage) {
        LocalLog.d(TAG, "||推送 JIGUANG [onAliasOperatorResult] " + jPushMessage);
        JIGUANGTagAliasOperatorHelper.getInstance().onAliasOperatorResult(context, jPushMessage);
        if (jPushMessage.getErrorCode() == 0) {
            LocalLog.i(TAG, "||推送 JIGUANG 绑定别名成功：" + jPushMessage.getAlias());
            Config.saveJPushBind(true);
        } else {
            LocalLog.e(TAG, "||推送 JIGUANG 绑定别名失败：" + jPushMessage.getErrorCode());
        }
        super.onAliasOperatorResult(context, jPushMessage);
    }

    @Override
    public void onMobileNumberOperatorResult(Context context, JPushMessage jPushMessage) {
        LocalLog.d(TAG, "||推送 JIGUANG [onMobileNumberOperatorResult] " + jPushMessage);
        JIGUANGTagAliasOperatorHelper.getInstance().onMobileNumberOperatorResult(context, jPushMessage);
        super.onMobileNumberOperatorResult(context, jPushMessage);
    }

    //send msg to MainActivity
    private void processCustomMessage(Context context, CustomMessage customMessage) {
        LocalLog.d(TAG, "||推送 JIGUANG [processCustomMessage] " + customMessage);
        MessageHandler.pushMessage(context, customMessage.message);
    }
}
