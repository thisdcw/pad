package com.mxsella.youth.common.widget;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.youth.R;
import com.mxsella.youth.common.utils.Config;
import com.mxsella.youth.common.utils.NavigationBarUtil;

// layout文件取名为dialog_update会与appupdate库冲突
public class VersionUpdateDialog extends Dialog {

    private Context mContext;
    private TextView tvNewVersion;
    private TextView tvDescription;
    private TextView tvIgnore;
    private Button btnUpdate;
    private Button btnClose;
    private ProgressBar pgbDownload;
    private boolean canIgnore;
    private String versionName;
    private int versionCode;
    private String description;

    public VersionUpdateDialog(@NonNull Context context) {
        super(context);
        this.mContext = context;
        this.canIgnore = true;
        initView();
    }

    public VersionUpdateDialog(@NonNull Context context, boolean canIgnore, String versionName, int versionCode, String description) {
        super(context);
        this.mContext = context;
        this.canIgnore = canIgnore;
        this.versionName = versionName;
        this.versionCode = versionCode;
        this.description = description;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_version_update, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));
        getWindow().setBackgroundDrawableResource(R.color.transparent);

        tvNewVersion = view.findViewById(R.id.tv_new_version);
        tvDescription = view.findViewById(R.id.tv_description);
        tvIgnore = view.findViewById(R.id.tv_ignore);
        btnUpdate = view.findViewById(R.id.btn_update);
        btnClose = view.findViewById(R.id.btn_close);
        pgbDownload = view.findViewById(R.id.pgb_download);

        tvNewVersion.setText("发现新版本V" + versionName);
        tvDescription.setText(description);
        if(!canIgnore){
            btnClose.setVisibility(View.GONE);
            tvIgnore.setVisibility(View.GONE);
        }
        tvIgnore.setOnClickListener(v -> {
            Config.saveIgnoreVersionCode(String.valueOf(versionCode));
            dismiss();
        });
        btnClose.setOnClickListener(v -> {
            dismiss();
        });
    }

    public void setWidth(int width) {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.width = width;
        getWindow().setAttributes(params);
    }

    public void setHeight(int height) {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.height = height;
        getWindow().setAttributes(params);
    }

    @Override
    public void show() {
        NavigationBarUtil.focusNotAle(getWindow());
        try {
            super.show();
        } catch (Exception e){
            e.printStackTrace();
        }

        NavigationBarUtil.hideNavigationBar(getWindow());
        NavigationBarUtil.clearFocusNotAle(getWindow());
    }

    public void setOnUpdateClickListener(View.OnClickListener listener) {
        btnUpdate.setOnClickListener(listener);
    }

    public void setDownloadProgress(int progress){
        pgbDownload.setProgress(progress);
    }
}
