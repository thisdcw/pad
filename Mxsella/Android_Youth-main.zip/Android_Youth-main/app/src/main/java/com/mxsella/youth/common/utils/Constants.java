package com.mxsella.youth.common.utils;

public class Constants {

    public static final String MODE_BLE = "Ble";
    public static final String MODE_SP_TTYS0 = "SP_ttyS0";
    public static final String MODE_USB = "USB";
    public static final int SUCCESS = 1;
    public static final int FAILURE = 0;
    public static final int STATE_OFFLINE = 0;
    public static final int STATE_ONLINE = 1;
    public static final int STATE_WORK = 2;
    public static final int STATE_AWAIT = 3;
    public static final int STATE_PAUSE = 4;
}
