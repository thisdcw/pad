package com.mxsella.m8.ui.settings;

import android.content.Context;
import android.content.Intent;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseActivity;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.ui.adpter.LanguageAdapter;
import com.mxsella.m8.utils.LanguageUtils;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class LanguageActivity extends BaseActivity {

    @Override
    public int getLayoutId() {
        return R.layout.activity_language;
    }

    @BindView(R.id.rcv_language)
    RecyclerView rcvLanguage;

    private List<String> codeList = LanguageUtils.codeList;
    private String language;
    private LanguageAdapter languageAdapter;

    public static void show(Context context) {
        Intent intent = new Intent(context, LanguageActivity.class);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();

        language = Config.getLanguage(true);

        languageAdapter = new LanguageAdapter(this, codeList);
        rcvLanguage.setLayoutManager(new LinearLayoutManager(this));
        rcvLanguage.setAdapter(languageAdapter);

        languageAdapter.setOnItemClickListener((adapter, view, position) -> {
            language = codeList.get(position);
            languageAdapter.setSelectPos(position);
            languageAdapter.notifyDataSetChanged();
        });

        languageAdapter.setSelectPos(codeList.indexOf(language));
    }

    @OnClick({R.id.tv_save})
    public void onClick(){
        LanguageUtils.applyLanguage(language, true);
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }
}