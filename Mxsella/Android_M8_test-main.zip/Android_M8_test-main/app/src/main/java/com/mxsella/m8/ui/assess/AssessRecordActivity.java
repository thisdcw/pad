package com.mxsella.m8.ui.assess;

import android.content.Context;
import android.content.Intent;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseActivity;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.ui.main.MainActivity;
import com.mxsella.m8.utils.AppManager;
import com.mxsella.m8.utils.StringUtils;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.chart.AssessRecordChartManager;
import com.mxsella.m8.view.chart.AssessRecordRadar;

import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class AssessRecordActivity extends BaseActivity {

    public static final String RECORD = "record";

    @Override
    public int getLayoutId() {
        return R.layout.activity_assess_record;
    }

    @BindView(R.id.tv_record_time)
    TextView tvRecordTime;
    @BindView(R.id.tv_grade)
    TextView tvGrade;
    @BindView(R.id.chart_all)
    LineChart chart;
    @BindView(R.id.assess_record_radar)
    AssessRecordRadar radar;
    @BindView(R.id.tv_grade_a)
    TextView tvGradeA;
    @BindView(R.id.tv_grade_b)
    TextView tvGradeB;
    @BindView(R.id.tv_grade_c)
    TextView tvGradeC;
    @BindView(R.id.tv_grade_d)
    TextView tvGradeD;

    private AssessRecord assessRecord;
    AssessRecordChartManager manager;

    public static void show(Context context, AssessRecord assessRecord) {
        Intent intent = new Intent(context, AssessRecordActivity.class);
        intent.putExtra(RECORD, assessRecord);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();

        assessRecord = (AssessRecord) getIntent().getSerializableExtra(RECORD);

        List<Float> dataPFMList = StringUtils.floatDeserialize(assessRecord.getDataAllPFM());
        manager = new AssessRecordChartManager(chart, 100.0f, 150.0f, 6, 15, dataPFMList.size() / 150f);
        manager.add(dataPFMList, 1);
        List<String> titleList = Arrays.asList(getString(R.string.assess_report_relax), getString(R.string.assess_report_endure),
                getString(R.string.assess_report_power), getString(R.string.assess_report_stable));
        List<Integer> normalList = Arrays.asList(80, 80, 80, 80);
        List<Integer> dataList = Arrays.asList(assessRecord.getGradeRelax(), assessRecord.getGradeEndure(), assessRecord.getGradePower(), assessRecord.getGradeStable());
        radar.initData(titleList, normalList, dataList);

        tvRecordTime.setText(String.format(getString(R.string.assess_report_time), assessRecord.getAssessTime()));
        tvGrade.setText(String.valueOf(assessRecord.getY()));
        tvGradeA.setText(String.valueOf(assessRecord.getYa()));
        tvGradeB.setText(String.valueOf(assessRecord.getYb()));
        tvGradeC.setText(String.valueOf(assessRecord.getYc()));
        tvGradeD.setText(String.valueOf(assessRecord.getYd()));
    }

    @OnClick(R.id.llt_enter_recovery)
    public void onClick() {
        if (Config.ifDebug || BleService.getInstance().isConnected()) {
            ((MainActivity) AppManager.getAppManager().getActivity(MainActivity.class)).goRecovery();
        } else {
            ToastUtils.showToast(getString(R.string.ble_connect_first));
        }
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }
}