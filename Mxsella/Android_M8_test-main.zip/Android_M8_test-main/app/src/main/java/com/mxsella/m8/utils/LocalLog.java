package com.mxsella.m8.utils;

import android.util.Log;

import com.mxsella.m8.helper.Config;

public class LocalLog {

    public static String TAG = "ooo";

    public static void test(String s){
        if (Config.ifLog)
            Log.d(TAG, s);
    }

    public static void varTest(Object... objects){
        if (!Config.ifLog)
            return;
        StringBuilder builder = new StringBuilder();
        for (Object o : objects) {
            builder.append(o == null ? "null" : o.toString()).append(" - ");
        }
        String logStr = builder.substring(0, builder.lastIndexOf(" - "));
        int max_str_length = 2001 - TAG.length();
        while (logStr.length() > max_str_length) {
            Log.d(TAG, logStr.substring(0, max_str_length));
            logStr = logStr.substring(max_str_length);
        }
        Log.d(TAG, logStr);
    }

    public static void d(String tag, String s){
        if (Config.ifLog)
            Log.d(tag, s);
    }

    public static void w(String tag, String s){
        if (Config.ifLog)
            Log.w(TAG, s);
    }

    public static void e(String tag, String s){
        if (Config.ifLog)
            Log.e(TAG, s);
    }

    public static void i(String tag, String s){
        if (Config.ifLog)
            Log.i(TAG, s);
    }
}
