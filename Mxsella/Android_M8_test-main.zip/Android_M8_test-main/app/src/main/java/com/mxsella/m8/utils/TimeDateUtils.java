package com.mxsella.m8.utils;

import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.os.Build;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class TimeDateUtils {

    public static String stampToDate(long ms) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Date date = new Date(ms);
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINESE);

            return format.format(date);
        }

        Date date = new Date(ms);
        java.text.SimpleDateFormat simpleDateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINESE);

        return simpleDateFormat.format(date);
    }

    public static String stampToDateMS(long ms) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Date date = new Date(ms);
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.CHINESE);

            return format.format(date);
        }

        Date date = new Date(ms);
        java.text.SimpleDateFormat simpleDateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.CHINESE);

        return simpleDateFormat.format(date);
    }

    public static String getMinBySeconds(long time) {
        int min = (int) (time / 60);
        return String.format(Locale.CHINESE, "%02d", min);
    }

    public static String getMinAndSecondBySeconds(long time) {
        int min = (int) (time / 60);
        int seconds = (int) (time % 60);
        return String.format(Locale.CHINESE, "%02d", min) + ":" + String.format(Locale.CHINESE, "%02d", seconds);
    }

    public static String getMinAndSecondByMS(long time) {
        time = time / 1000;
        int min = (int) (time / 60);
        int seconds = (int) (time % 60);
        return String.format(Locale.CHINESE, "%02d", min) + ":" + String.format(Locale.CHINESE, "%02d", seconds);
    }

    public static long getSeconds(String str) {
        String[] strings = str.split(":");
        int min = Integer.parseInt(strings[0]);
        int seconds = Integer.parseInt(strings[1]);
        return (long) min * 60 + seconds;
    }

    public static String getNowDateTime() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINESE);
            return dateFormat.format(new Date());
        }
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.YEAR) + "-"
                + format(calendar.get(Calendar.MONTH)+1) + "-"//从0计算
                + format(calendar.get(Calendar.DAY_OF_MONTH)) + "-"
                + format(calendar.get(Calendar.HOUR_OF_DAY)) + ":"
                + format(calendar.get(Calendar.MINUTE)) + ":"
                + format(calendar.get(Calendar.SECOND));
    }

    /**
     * 当前日期（到天）
     */
    public static String getNowDateTimeDay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINESE);
            return dateFormat.format(new Date());
        }
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.YEAR) + "-"
                + format(calendar.get(Calendar.MONTH)+1) + "-"//从0计算
                + format(calendar.get(Calendar.DAY_OF_MONTH));
    }

    /**
     * 日期（到天）
     */
    public static String getDateTimeDay(Date date) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.CHINESE);
            return dateFormat.format(date);
        }
        return "";
    }

    /**
     * 时间装换为毫秒
     */
    public static long timeToMs(int n) {
        return (long) n * 24 * 60 * 60 * 1000;
    }

    public static String duration(int s1, int s2, int times) {
        int seconds = times * (s1 + s2);
        int min = seconds / 60;
        int s = seconds % 60;
        return min + "min" + s + "s";
    }

    private static String format(int time) {
        return String.format(Locale.CHINESE, "%02d", time);
    }

}
