package com.mxsella.m8.utils;

import android.app.Activity;

import com.mxsella.m8.R;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.helper.Constants;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class AssessUtils {

    public static List<List<Float>> getAllBaseLine(){
        List<List<Float>> allBaseLine = new ArrayList<>();
        allBaseLine.add(getBaseLine("A-1"));
        allBaseLine.add(getBaseLine("B-1"));
        allBaseLine.add(getBaseLine("B-2"));
        allBaseLine.add(getBaseLine("B-3"));
        allBaseLine.add(getBaseLine("C-1"));
        allBaseLine.add(getBaseLine("C-2"));
        allBaseLine.add(getBaseLine("C-3"));
        allBaseLine.add(getBaseLine("C-4"));
        allBaseLine.add(getBaseLine("C-5"));
        allBaseLine.add(getBaseLine("C-6"));
        allBaseLine.add(getBaseLine("C-7"));
        allBaseLine.add(getBaseLine("C-8"));
        allBaseLine.add(getBaseLine("C-9"));
        allBaseLine.add(getBaseLine("C-10"));
        allBaseLine.add(getBaseLine("D-1"));

        return allBaseLine;
    }

    public static List<Float> getBaseLine(String s){
        List<Float> baseLine = new ArrayList<>();
        String[] stage = s.split("-");
        switch (stage[0]) {
            case "A":
                baseLine.addAll(numTimes(4, 21));
                break;
            case "B":
                switch (stage[1]) {
                    case "1":
                        baseLine.addAll(numTimes(4, 3));
                        baseLine.addAll(numTimes(40, 1));
                        baseLine.addAll(numTimes(4, 11));
                        baseLine.addAll(numTimes(40, 1));
                        baseLine.addAll(numTimes(4, 5));
                        break;
                    case "2":
                        baseLine.addAll(numTimes(4, 7));
                        baseLine.addAll(numTimes(40, 1));
                        baseLine.addAll(numTimes(4, 11));
                        baseLine.addAll(numTimes(40, 1));
                        baseLine.addAll(numTimes(4, 1));
                        break;
                    case "3":
                        baseLine.addAll(numTimes(4, 11));
                        baseLine.addAll(numTimes(40, 1));
                        baseLine.addAll(numTimes(4, 9));
                        break;
                }
                break;
            case "C":
                switch (stage[1]) {
                    case "1":
                    case "3":
                    case "5":
                    case "7":
                    case "9":
                        baseLine.addAll(numTimes(4, 11));
                        baseLine.addAll(numTimes(35, 10));
                        break;
                    case "2":
                    case "4":
                    case "6":
                    case "8":
                    case "10":
                        baseLine.addAll(numTimes(35, 11));
                        baseLine.addAll(numTimes(4, 10));
                        break;
                }
            case "D":
                baseLine.addAll(numTimes(4, 21));
                break;
        }

        return baseLine;
    }

    private static List<Float> numTimes(float num, int times){
        List<Float> list = new ArrayList<>();
        for(int i = 0; i < times; i++)
            list.add(num);
        return list;
    }

    private static Comparator<Integer> comparatorInteger = (i1, i2) -> {
        if (i1 < i2)
            return -1;
        else if (i1 > i2)
            return 1;
        return 0;
    };

    private static Comparator<Float> comparatorFloat = (i1, i2) -> {
        if (i1 < i2)
            return -1;
        else if (i1 > i2)
            return 1;
        return 0;
    };

    public static void sortList(List<Integer> list) {
        Collections.sort(list, comparatorInteger);
    }

    public static void sortListFloat(List<Float> list) {
        Collections.sort(list, comparatorFloat);
    }

    public static double avg(List<Integer> list){
        double sum = 0.0d;
        for(int l : list){
            sum += l;
        }
        return list.size() > 0 ? sum / list.size() : 0;
    }

    public static float avgFloat(List<Float> list){
        float sum = 0.0f;
        for(float d : list){
            sum += d;
        }
        return list.size() > 0 ? sum / list.size() : 0;
    }

    private static double standardDeviation(List<Integer> list, double avg) {
        int m = list.size();
        double var = 0;
        for(int l : list) {
            var += (l - avg) * (l - avg);
        }
        return Math.sqrt(var/m);
    }

    private static double standardDeviationFloat(List<Float> list, double avg) {
        int m = list.size();
        double var = 0;
        for(float l : list) {
            var += (l - avg) * (l - avg);
        }
        return Math.sqrt(var/m);
    }

    private static int max(List<Integer> list){
        int max = 0;
        for(int l : list)
            max = Math.max(max, l);
        return max;
    }

    private static int min(List<Integer> list){
        int min = list.get(0);
        for(int l : list)
            min = Math.min(min, l);
        return min;
    }

    private static float minFloat(List<Float> list){
        float min = list.get(0);
        for(float l : list)
            min = Math.min(min, l);
        return min;
    }

    public static boolean evaluate(Activity activity, List<Float> dataList, AssessRecord record) {
        DecimalFormat decimalOne=new DecimalFormat(".0");
        DecimalFormat decimalTwo=new DecimalFormat(".00");
        int maxAssessTime = Constants.MAX_ASSESS_TIME;
        int secNum = Constants.DEFAULT_SEC_NUM;
        if (dataList.size() < maxAssessTime / 2 * secNum) {
            activity.runOnUiThread(() -> {
                ToastUtils.showToast(activity.getString(R.string.toast_assess_insufficient_data));
            });
            return false;
        }

        //前静息阶段
        double pa, pa1, yPa, yPa1;
        int yA;
        pa = Double.parseDouble(decimalOne.format(avgFloat(dataList.subList(0, 10 * secNum))));
        if(pa == 0){
            pa1 = 0;
            yA = 70 + new Random().nextInt(9);
        } else {
            pa1 = Double.parseDouble(decimalTwo.format(standardDeviationFloat(dataList.subList(0, 10 * secNum), pa) / pa));
            yPa = 100 - pa * 5;
            yPa1 = 100 - pa1 * 100;
            yPa = Math.max(0, yPa);
            yPa1 = Math.max(0, yPa1);
            yA = (int) (pa < 4 ? 0.9 * yPa + 0.1 * yPa1 : 3.6 * yPa / pa + 0.1 * yPa1);
        }

        //快肌阶段
        int pb = 0;
        double pb1 = 2.5d;
        double pb2 = 2.5d;
        int yB = 0;
        int[] startPos = {11 * secNum, 18 * secNum, 23 * secNum, 29 * secNum, 35 * secNum};
        int[] intervalPos = {10 * secNum, 10 * secNum, 20 * secNum, 20 * secNum, 30 * secNum};
        for(int i = 0; i < 5; i++){
            float ppb = 0;
            double ppb1 = 2.5d;
            double ppb2 = 2.5d;
            int pos1 = startPos[i];
            int pos2 = startPos[i];
            for(int j = 0; j < secNum; j++){
                float data = dataList.get(startPos[i] + j);
                if(data > ppb){
                    ppb = data;
                    pos1 = startPos[i] + j;
                    pos2 = startPos[i] + j;
                } else if(data == ppb) {
                    pos2 = startPos[i] + j;
                }
            }
            float pbMin = minFloat(dataList.subList(intervalPos[i], intervalPos[i] + 10 * secNum));
            float startValue = ((ppb - pbMin) * 2 / 3) + pbMin;
            for(int m = 1; m < 2.5f  * secNum; m++){
                if(dataList.get(pos1 - m) < startValue) {
                    ppb1 = Double.parseDouble(decimalTwo.format(1f / secNum * m));
                    break;
                }
            }
            for(int n = 1; n < 2.5f * secNum; n++){
                if(dataList.get(pos2 + n) < startValue) {
                    ppb2 = Double.parseDouble(decimalTwo.format(1f / secNum * n));
                    break;
                }
            }
            double yPb = 2.5 * ppb;
            double yPb1 = 100 - 40 * ppb1;
            double yPb2 = 100 - 40 * ppb2;
            yPb = Math.min(100, yPb);
            yPb1 = Math.max(0, yPb1);
            yPb2 = Math.max(0, yPb2);
            yB += (int) (ppb < 20 ? 0.8 * yPb * ppb / 40 + 0.1 * yPb1 + 0.1 * yPb2 : 0.8 * yPb + 0.1 * yPb1 + 0.1 * yPb2);

            if(pb < ppb){
                pb = (int) ppb;
                pb1 = ppb1;
                pb2 = ppb2;
            }
        }
        yB = yB / 5;
        if(pb == 0){
            pb1 = 0;
            pb2 = 0;
            yB = 0;
        }
        int quickFatigue = 0;
        int p1 = 0, p2 = 0;
        for (int i = 0; i < secNum; i++) {
            p1 = (int) Math.max(p1, dataList.get(startPos[0] + i));
            p2 = (int) Math.max(p2, dataList.get(startPos[4] + i));
        }
        quickFatigue = Math.max(0, Math.min(100, 100 + p1 - p2));

        //慢肌阶段
        List<Float> pCList = new ArrayList<>();
        for(int i = 0; i < 5; i++){
            pCList.addAll(dataList.subList(45 * secNum + 20 * secNum * i, 55 * secNum + 20 * secNum * i));
        }
        double pc, pc1, yPc, yPc1;
        int yC;
        pc = Double.parseDouble(decimalOne.format(avgFloat(pCList)));
        if(pc == 0){
            pc1 = 0;
            yC = 0;
        } else {
            pc1 = Double.parseDouble(decimalTwo.format(standardDeviationFloat(pCList, pc) / pc));
            yPc = 2.5 * pc;
            yPc1 = 100 - pc1 * 100;
            yPc = Math.min(100, yPc);
            yPc1 = Math.max(0, yPc1);
            yC = (int) (0.9 * yPc +  0.1 * yPc1);
        }
        int slowFatigue = 0;
        for (int i = 0; i < 5; i++) {
            int maxPos = 0;
            float p5 = -1;
            for (int j = secNum; j < 2 * secNum; j++) {
                float value = pCList.get(i * 10 * secNum + j);
                if (value > p5) {
                    maxPos = i * 10 * secNum + j;
                    p5 = value;
                }
            }
            float p6 = pCList.get(maxPos + 7 * secNum);
            int fatigue = (int) Math.max(0, Math.min(100, 100 + p6 - p5));
            slowFatigue += fatigue;
        }
        slowFatigue = slowFatigue / 5;

        //后静息阶段
        List<Float> pDList = dataList.subList(140 * secNum, 150 * secNum);
        double pd, pd1, yPd, yPd1;
        int yD;
        pd = Double.parseDouble(decimalOne.format(avgFloat(pDList)));
        if(pd == 0){
            pd1 = 0;
            yD = 70 + new Random().nextInt(9);
        } else {
            pd1 = Double.parseDouble(decimalTwo.format(standardDeviationFloat(pDList, pd) / pd));
            yPd = 100 - 5 * pd;
            yPd1 = 100 - pd1 * 100;
            yPd = Math.max(0, yPd);
            yPd1 = Math.max(0, yPd1);
            yD = (int) (pd < 4 ? 0.9 * yPd + 0.1 * yPd1 : 3.6 * yPd / pd + 0.1 * yPd1);
        }

        double y = Double.parseDouble(decimalOne.format(0.1 * yA + 0.4 * yB + 0.4 * yC + 0.1 * yD));

        record.setPa(pa);
        record.setPa1(pa1);
        record.setPb(pb);
        record.setPb1(pb1);
        record.setPb2(pb2);
        record.setPc(pc);
        record.setPc1(pc1);
        record.setPd(pd);
        record.setPd1(pd1);
        record.setYa(yA);
        record.setYb(yB);
        record.setYc(yC);
        record.setYd(yD);
        record.setY(y);
        record.setGradeRelax((yA + yD) / 2);
        record.setGradeEndure(yC);
        record.setGradePower(yB);
        record.setGradeStable((quickFatigue + slowFatigue) / 2);
        record.setDataAllPFM(StringUtils.floatSerialize(dataList));
        try {
            record.setAssessTime(TimeDateUtils.getNowDateTime());
        } catch (Exception e){
            LocalLog.d("ooo", "Evaluate Record AssessTime Error");
        }
        return true;
    }

    public static int mse(List<Integer> list, int value) {
        if (list.size() == 0)
            return 0;
        long sum = 0;
        for (int i : list) {
            sum += (long) (i - value) * (i - value);
        }
        return (int) (Math.sqrt(sum * 1d / list.size()));
    }

    public static List<Integer> fourier(List<Integer> l) {
        // 性能不够的话难以处理傅立叶，暂时先关闭傅立叶处理
        return l;
        /*double xAvg = avg(l);
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            list.addAll(l);
        }
        List<List<Double>> yASin = new ArrayList<>();
        List<List<Double>> yACos = new ArrayList<>();
        for(int i = 0; i < 241; i++) {
            int f = 20 + i * 2;
            List<Double> sinList = new ArrayList<>();
            List<Double> cosList = new ArrayList<>();
            for (int j = 0; j < 500; j++) {
                sinList.add(list.get(j) * Math.sin(2 * Math.PI * j / (1000f / f)));
            }
            for (int j = 0; j < 500; j++) {
                cosList.add(list.get(j) * Math.cos(2 * Math.PI * j / (1000f / f)));
            }
            double p = avgDouble(sinList);
            double z = avgDouble(cosList);
            List<Double> aSin = new ArrayList<>();
            List<Double> aCos = new ArrayList<>();
            for (int j = 0; j < 100; j++) {
                aSin.add(p * Math.sin(2 * Math.PI * j / (1000f / f)));
                aCos.add(z * Math.cos(2 * Math.PI * j / (1000f / f)));
            }
            yASin.add(aSin);
            yACos.add(aCos);
        }
        List<Integer> result = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            double sum = 0;
            for (int j = 0; j < 241; j++) {
                if (j != 15) {
                    sum += (yASin.get(j).get(i) + yACos.get(j).get(i));
                }
            }
            result.add((int) Math.round(sum * 2.08f + xAvg));
        }

        return result;*/
    }

}
