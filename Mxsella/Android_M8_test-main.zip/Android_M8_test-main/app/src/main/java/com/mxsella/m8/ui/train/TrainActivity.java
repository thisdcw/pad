package com.mxsella.m8.ui.train;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.bean.TrainCourse;
import com.mxsella.m8.bean.TrainCourseItem;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.comm.ICommunicateService;
import com.mxsella.m8.comm.Protocol;
import com.mxsella.m8.comm.ReceivePacket;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.DataCollectHelper;
import com.mxsella.m8.helper.HardwareHelper;
import com.mxsella.m8.helper.RecoveryHelper;
import com.mxsella.m8.helper.ResourceHelper;
import com.mxsella.m8.utils.MediaHelper;
import com.mxsella.m8.utils.TimeDateUtils;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.chart.TrainChartManager;
import com.mxsella.m8.view.chart.TrainChartPreviewManager;
import com.mxsella.m8.view.dialog.MediaDialog;
import com.mxsella.m8.view.dialog.RequestDialog;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.OnLongClick;

public class TrainActivity extends BaseMvpActivity<TrainContract.Presenter> implements TrainContract.View {

    private static final String COURSE = "course";

    @Override
    public int getLayoutId() {
        return R.layout.activity_train;
    }

    @Override
    protected TrainContract.Presenter initPresenter() {
        return new TrainPresenter(this);
    }

    @BindView(R.id.chart_preview)
    LineChart chartPreview;
    @BindView(R.id.chart_simple)
    LineChart chartSimple;
    @BindView(R.id.tv_current)
    TextView tvCurrent;
    @BindView(R.id.tv_max)
    TextView tvMax;
    @BindView(R.id.tv_remain_time)
    TextView tvRemainTime;
    @BindView(R.id.tv_tip)
    TextView tvTip;
    @BindView(R.id.seekbar_imitate)
    SeekBar seekBarImitate;
    @BindView(R.id.btn_start)
    Button btnStart;
    @BindView(R.id.layout_train_setting)
    View layoutSetting;
    @BindView(R.id.tv_intensity)
    TextView tvIntensity;
    @BindView(R.id.seekbar_intensity)
    SeekBar seekBarIntensity;
    @BindView(R.id.tv_range)
    TextView tvRange;
    @BindView(R.id.seekbar_range)
    SeekBar seekBarRange;

    private BleService bleService;
    private ICommunicateService.DataReceiveListener bleListener;

    private TrainCourse trainCourse;
    private TrainChartManager chartManager;
    private TrainChartPreviewManager previewManager;

    private boolean isStart = false; // 是否开始
    private boolean isPause = false; // 是否暂停
    private boolean isPlaying = false; // 是否在播放音频
    private boolean firstEnter = true; //第一次进入等下发结束指令后才能开始
    private int countDown;
    private ExecutorService workThread = Executors.newSingleThreadExecutor();
    private ExecutorService imitateThread = Executors.newSingleThreadExecutor();
    private ExecutorService countDownThread = Executors.newSingleThreadExecutor();
    private int DEFAULT_SEC_NUM;
    private static int MAX_TRAIN_TIME;
    private int trainTime = 0;
    private DataCollectHelper dataCollectHelper = new DataCollectHelper(DataCollectHelper.SceneType.ASSESS);
    private List<Float> dataSimplePFM = new ArrayList<>();
    private List<Float> dataAllPFM = new ArrayList<>();
    private List<Float> dataResultPFM = new ArrayList<>();

    private MediaDialog mediaDialog;

    private int intensity = 0;
    private int rangeBase = 25;
    private int rangeMin = 25;
    private int rangeSize = 20;
    private int rangeAdjustSize = 20;
    private int trainPosition = 0;

    public static void show(Context context, TrainCourse course) {
        Intent intent = new Intent(context, TrainActivity.class);
        intent.putExtra(COURSE, course);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        DEFAULT_SEC_NUM = Constants.DEFAULT_SEC_NUM;
        tvRange.setText(String.format(getString(R.string.train_range), rangeMin, (rangeMin + rangeSize)));

        trainCourse = (TrainCourse) getIntent().getSerializableExtra(COURSE);
        RecoveryHelper.setTrainCourseItem(trainCourse);
        MAX_TRAIN_TIME = trainCourse.getTrainDuration() * 2;
        tvRemainTime.setText(TimeDateUtils.getMinAndSecondBySeconds(MAX_TRAIN_TIME / 2));

        chartManager = new TrainChartManager(chartSimple, 100, 10, 11, 10, DEFAULT_SEC_NUM);
        previewManager = new TrainChartPreviewManager(chartPreview, 100, 10);
        mediaDialog = new MediaDialog(this);

        seekBarIntensity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvIntensity.setText(String.valueOf(i));
                bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        seekBarRange.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                rangeMin = rangeBase + i;
                tvRange.setText(String.format(getString(R.string.train_range), rangeMin, (rangeMin + rangeSize)));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        if (Config.ifDebug) {
            seekBarImitate.setVisibility(View.VISIBLE);
            seekBarImitate.setMax(HardwareHelper.checkVersion(HardwareHelper.NEW_EMG_VERSION) ? 100 : 100);
        }
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        bleService = BleService.getInstance();
        bleListener = packet -> {
            if(packet.getType().equals(ReceivePacket.TYPE_ACK) && packet.getAddr() == Protocol.ADDR_DATA_SWITCH) {
                dealAirSwitchPacket(packet);
            } else if (packet.getType().equals(ReceivePacket.TYPE_DATA)) {
                if (isStart) {
                    Map<String, Object> resultMap = dataCollectHelper.dealData(DataCollectHelper.DataType.OLD, packet.getDataList());
                    if (resultMap != null) {
                        setPFM((Float) resultMap.get("pfm"));
                        setPFMTip((String) resultMap.get("pfmTip"));
                        dealPressurePacket((Float) resultMap.get("pfm"));
                    }
                }
            } else if (packet.getType().equals(ReceivePacket.TYPE_DATA_NEW)) {
                if (isStart) {
                    Map<String, Object> resultMap = dataCollectHelper.dealData(DataCollectHelper.DataType.NEW, packet.getDataList());
                    if (resultMap != null) {
                        setPFM((Float) resultMap.get("pfm"));
                        setPFMTip((String) resultMap.get("pfmTip"));
                        dealPressurePacket((Float) resultMap.get("pfm"));
                    }
                }
            }
        };
        bleService.addListener(bleListener);

        new Handler().postDelayed(()->{
            bleService.send(Protocol.ADDR_RELAY, (short) 90);
            bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
            bleService.setIfHandShake(true);
            firstEnter = false;
        }, 1000);
    }

    private void resetUI() {
        dataCollectHelper.reset();
        dataSimplePFM.clear();
        dataAllPFM.clear();
        dataResultPFM.clear();
        isStart = false;
        isPause = false;
        runOnUiThread(() -> {
            if(btnStart == null)
                return;
            chartManager.clearData();
            previewManager.clearData();
            tvRemainTime.setText(TimeDateUtils.getMinAndSecondBySeconds(MAX_TRAIN_TIME / 2));
            tvCurrent.setText("0.0");
            tvMax.setText("0.0");
            tvTip.setText("");
            btnStart.setText(getString(R.string.start));
            btnStart.setBackgroundResource(R.drawable.train_start);
        });

        if (trainTime > 0){
            TrainRecord trainRecord = new TrainRecord(0, Config.curUser.getUid(), trainCourse.getTrainId(), trainCourse.getTrainName(), TimeDateUtils.getNowDateTime(), trainTime / 2);
            showNetDialog();
            mPresenter.uploadTrainRecord(trainRecord);
            trainTime = 0;
        }
    }

    public void setPFMTip(String s) {
        runOnUiThread(()->{
            if(tvTip != null)
                tvTip.setText(s);
        });
    }

    public void setPFM(float data) {
        runOnUiThread(()->{
            if(tvCurrent == null || !isStart)
                return;
            tvCurrent.setText(String.valueOf(data));
            tvMax.setText(tvMax.getText().toString().equals("") ? String.valueOf(data) : String.valueOf(Math.max(Float.parseFloat(tvMax.getText().toString()), data)));
        });
    }

    private void dealAirSwitchPacket(ReceivePacket packet) {
        if(packet.getMode() == Protocol.MODE_OFF) {
            // resetUI();
        }
    }

    private void dealPressurePacket(float pfm) {
        if (!isStart || isPause || isPlaying) {
            return;
        }
        dataAllPFM.add(pfm);
        dataSimplePFM.add(pfm);
        runOnUiThread(() -> {
            chartManager.addData(pfm);
        });
    }

    @OnLongClick(R.id.tv_chart_all_title)
    public void onLongClick() {
        tvTip.setVisibility(tvTip.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    @OnClick({R.id.btn_start, R.id.btn_pause, R.id.btn_next, R.id.btn_minus, R.id.btn_plus})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_start:
                if(firstEnter)
                    return;
                if (!isStart) {
                    if(trainCourse.getTrainType() == 0) {
                        trainStart();
                    } else {
                        layoutSetting.setVisibility(View.VISIBLE);
                        mediaDialog.show(getString(R.string.recovery_settings_content), getString(R.string.recovery_settings), true);
                        MediaHelper.playSound(ResourceHelper.getRawByName(this, "train_setting"), mp -> {
                            mediaDialog.dismiss();
                            bleService.send(Protocol.ADDR_ELECTRIC_TIME, (short) 1800);
                            bleService.send(Protocol.ADDR_ELECTRIC_MODE, (short) 10);
                            seekBarIntensity.setProgress(5);
                            if (trainCourse.getTrainType() == 1) {
                                rangeBase = 15;
                                rangeAdjustSize = 20;
                                rangeSize = 20;
                                rangeMin = 25;
                            } else if (trainCourse.getTrainType() == 2) {
                                rangeBase = 15;
                                rangeAdjustSize = 40;
                                rangeSize = 15;
                                rangeMin = 20;
                            }
                            seekBarRange.setProgress(rangeMin - rangeBase);
                            seekBarRange.setMax(rangeAdjustSize);
                        });
                    }
                } else {
                    if(isPause) {
                        isPause = false;
                        btnStart.setText(getString(R.string.stop));
                        btnStart.setBackgroundResource(R.drawable.train_stop);
                    } else {
                        isStart = false;
                        bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
                        bleService.setIfHandShake(true);
                        resetUI();
                    }
                }
                break;
            case R.id.btn_pause:
                isPause = true;
                btnStart.setText(getString(R.string.start));
                btnStart.setBackgroundResource(R.drawable.train_start);
                break;
            case R.id.btn_next:
                intensity = seekBarIntensity.getProgress();
                seekBarIntensity.setProgress(0);
                layoutSetting.setVisibility(View.GONE);
                updateRange();
                trainStart();
                break;
            case R.id.btn_minus:
                adjustIntensity(-1);
                break;
            case R.id.btn_plus:
                adjustIntensity(1);
                break;
        }
    }

    private void updateRange() {
        if (trainCourse.getTrainType() == 1) {
            for (TrainCourseItem item : trainCourse.getItemList()) {
                if (item.getType() == 2) {
                    List<List<Entry>> entries = item.getBaseLineList();
                    entries.get(0).get(1).setY(rangeMin + rangeSize);
                    entries.get(0).get(2).setY(rangeMin + rangeSize);
                    entries.get(1).get(1).setY(rangeMin);
                    entries.get(1).get(2).setY(rangeMin);
                    entries.get(2).get(1).setY(rangeMin);
                    entries.get(2).get(2).setY(rangeMin);
                }
            }
        } else if (trainCourse.getTrainType() == 2) {
            for (TrainCourseItem item : trainCourse.getItemList()) {
                if (item.getType() == 3) {
                    List<List<Entry>> entries = item.getBaseLineList();
                    entries.get(0).get(1).setY(rangeMin + rangeSize);
                    entries.get(0).get(2).setY(rangeMin + rangeSize);
                    entries.get(1).get(1).setY(rangeMin);
                    entries.get(1).get(2).setY(rangeMin);
                    entries.get(2).get(0).setY(rangeMin + rangeSize);
                    entries.get(2).get(3).setY(rangeMin + rangeSize);
                    entries.get(2).get(4).setY(rangeMin + rangeSize);
                }
            }
        }
    }

    private void trainStart() {
        dataCollectHelper.reset();
        dataSimplePFM.clear();
        dataAllPFM.clear();
        dataResultPFM.clear();
        trainTime = 0;
        bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_ON);
        bleService.setIfHandShake(false);
        isStart = true;
        isPlaying = true;
        if(Config.ifDebug) {
            imitateThread.execute(new ImitateTask());
        }
        btnStart.setText(getString(R.string.stop));
        btnStart.setBackgroundResource(R.drawable.train_stop);
        mediaDialog.show(ResourceHelper.getStringByName(this, "train_type_name_" + trainCourse.getTrainType()),
                getString(R.string.skip_prompt), false);
        MediaHelper.playSound(ResourceHelper.getRawByName(this, "train_type_" + trainCourse.getTrainType()), mp -> {
            isPlaying = false;
            mediaDialog.dismiss();
            workThread.execute(new TrainTask());
        });
    }

    @Override
    public void uploadResult(boolean result, TrainRecord trainRecord) {
        hideNetDialog();
        if (result) {
            ToastUtils.showToast(getString(R.string.upload_train_success));
        } else {
            RequestDialog requestDialog = new RequestDialog(this, getString(R.string.upload_fail), getString(R.string.upload_train_fail),
                    getString(R.string.upload_again), getString(R.string.upload_cancel));
            requestDialog.setConfirmClickListener(view -> {
                showNetDialog();
                requestDialog.dismiss();
                mPresenter.uploadTrainRecord(trainRecord);
            });
            requestDialog.setCancelClickListener(view -> {
                requestDialog.dismiss();
            });
            requestDialog.show();
        }
    }

    private class TrainTask implements Runnable {
        @Override
        public void run() {
            try {
                operate();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        private void operate() throws InterruptedException {
            TrainCourseItem item = trainCourse.getItemList().get(trainPosition);
            TrainCourseItem nextItem = trainCourse.getItemList().get((trainPosition + 1) % trainCourse.getItemList().size());
            dataSimplePFM.clear();
            runOnUiThread(()->{
                chartManager.clearData();
                chartManager.addEntries(item.getType(), item.getDuration(), item.getBaseLineList());
                previewManager.clearData();
                previewManager.addEntries(nextItem.getDuration(), nextItem.getBaseLineList());
            });
            int pos = 0;
            int stageTime = item.getDuration();
            List<List<Float>> mediaList = item.getMediaList();
            while (dataSimplePFM.size() <= DEFAULT_SEC_NUM * stageTime) {
                if (!isStart || tvRemainTime == null) return;
                if(pos < mediaList.size() && (dataSimplePFM.size() * 1f / DEFAULT_SEC_NUM) >= mediaList.get(pos).get(0)) {
                    MediaHelper.playSound(ResourceHelper.getRawByName(TrainActivity.this, "train_tip_" + mediaList.get(pos).get(1).intValue()));
                    pos++;
                }
                if(trainTime <= MAX_TRAIN_TIME && tvRemainTime != null){
                    int time = Math.max((MAX_TRAIN_TIME - trainTime - (dataSimplePFM.size() * 2 / DEFAULT_SEC_NUM)) / 2, (MAX_TRAIN_TIME - trainTime) / 2 - stageTime);
                    if (time <= 0) {
                        trainTime = MAX_TRAIN_TIME;
                        runOnUiThread(() -> {
                            resetUI();
                        });
                        bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
                        bleService.setIfHandShake(true);
                        return;
                    }
                    runOnUiThread(() -> {
                        if (tvRemainTime != null)
                            tvRemainTime.setText(TimeDateUtils.getMinAndSecondBySeconds(time));
                    });
                }
                Thread.sleep(10);
            }
            trainTime += stageTime * 2;
            calculateElectric(item);
        }

        private void nextOperate() {
            if(trainTime < MAX_TRAIN_TIME) {
                trainPosition = (++trainPosition % trainCourse.getItemList().size());
                try {
                    operate();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        private void calculateElectric(TrainCourseItem item) {
            if(item.getType() != 2 && item.getType() != 3) {
                nextOperate();
                return;
            }
            List<Entry> entries = item.getBaseLineList().get(2);
            float xMin = entries.get(0).getX();
            float yMin = entries.get(0).getY();
            float xMax = entries.get(2).getX();
            float yMax = entries.get(2).getY();
            boolean needElectric = false;
            if (item.getType() == 2) {
                for (int i = (int) (xMin * DEFAULT_SEC_NUM); i < (int) ((xMax - 0.5f) * DEFAULT_SEC_NUM) && !needElectric; i++) {
                    if (dataSimplePFM.get(i) < yMax) {
                        needElectric = true;
                        for (int j = 0; j < (int) (0.5f * DEFAULT_SEC_NUM) && needElectric; j++) {
                            if (dataSimplePFM.get(i + j) > yMax) {
                                i = i + j;
                                needElectric = false;
                            }
                        }
                    }
                }
                /*int count = 0;
                for (int i = (int) (xMin * DEFAULT_SEC_NUM); i < (int) (xMax * DEFAULT_SEC_NUM); i++) {
                    if (dataSimplePFM.get(i) < yMax) {
                        count++;
                    }
                }
                if (count >= 2 * DEFAULT_SEC_NUM)
                    needElectric = true;*/
            } else if (item.getType() == 3) {
                /*for (int i = (int) (xMin * DEFAULT_SEC_NUM); i < (int) ((xMax - 2f) * DEFAULT_SEC_NUM) && !needElectric; i++) {
                    if (dataSimplePFM.get(i) > yMin) {
                        needElectric = true;
                        for (int j = 0; j < (int) (2f * DEFAULT_SEC_NUM) && needElectric; j++) {
                            if (dataSimplePFM.get(i + j) < yMin) {
                                i = i + j;
                                needElectric = false;
                            }
                        }
                    }
                }*/
                int count = 0;
                for (int i = (int) (xMin * DEFAULT_SEC_NUM); i < (int) (xMax * DEFAULT_SEC_NUM); i++) {
                    if (dataSimplePFM.get(i) >= yMin) {
                        count++;
                    }
                }
                if (count >= 2 * DEFAULT_SEC_NUM)
                    needElectric = true;
            }
            if (needElectric) {
                runOnUiThread(()->{
                    isPlaying = true;
                    countDownThread.execute(countDownTimer);
                });
                bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
                bleService.setIfHandShake(true);
                try {
                    Thread.sleep(50);
                    bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) intensity);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            nextOperate();
        }
    }

    private Runnable countDownTimer = () -> {
        countDown = 10;
        runOnUiThread(()->{
            mediaDialog.show(String.format(getString(R.string.train_trigger_electric), countDown), false);
        });
        while (countDown >= 0) {
            if (mediaDialog == null)
                return;
            runOnUiThread(()->{
                mediaDialog.setContent(String.format(getString(R.string.train_trigger_electric), countDown));
            });
            if (countDown <= 0) {
                try {
                    bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) 0);
                    Thread.sleep(50);
                    bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_ON);
                    bleService.setIfHandShake(false);
                    Thread.sleep(3000);
                    isPlaying = false;
                    mediaDialog.dismiss();
                } catch (Exception ignore) {

                }
                return;
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            countDown--;
        }
    };

    private class ImitateTask implements Runnable {
        boolean newEmg = HardwareHelper.checkVersion(HardwareHelper.NEW_EMG_VERSION);
        @Override
        public void run() {
            while (isStart) {
                try {
                    Thread.sleep(newEmg ? 40 : 4);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (isStart && seekBarImitate != null)
                    bleService.imitateReceive(dataCollectHelper.getImitateData(
                            newEmg ? DataCollectHelper.DataType.NEW : DataCollectHelper.DataType.OLD, seekBarImitate.getProgress()));
            }
        }
    }

    private void adjustIntensity(int i) {
        if((seekBarIntensity.getProgress() == 0 && i < 0) || (seekBarIntensity.getProgress() == 60 && i > 0))
            return;
        int value = Math.max(0, Math.min(60, seekBarIntensity.getProgress() + i));
        runOnUiThread(() -> seekBarIntensity.setProgress(value));
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        onBackPressedSupport();
    }

    @Override
    public void onBackPressedSupport() {
        if (isStart) {
            ToastUtils.showToast(getString(R.string.toast_end_work_first));
            return;
        }
        super.onBackPressedSupport();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isStart = false;
        if (bleService != null) {
            bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
            bleService.send(Protocol.ADDR_ELECTRIC_MODE, (short) 11);
            bleService.setIfHandShake(true);
            bleService.removeListener(bleListener);
        }
        MediaHelper.release();
        mediaDialog.dismiss();
    }
}