package com.mxsella.m8.net;

import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.bean.CheckUpdateResponse;
import com.mxsella.m8.bean.Record;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.bean.User;

import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import okhttp3.MultipartBody;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {

    String BASE_URL = "http://mmk.mxsella.com/Mxsella/api/v2/";
    // String BASE_URL = "http://test.mxsella.com/Mxsella/api/v2/";
    // String BASE_URL = "http://10.0.2.2:8080/Mxsella/api/v2/";
    String PRIVACY_POLICY_URL = "http://mmk.mxsella.com:8090/m8/privacy_policy.html";

    @FormUrlEncoded
    @POST("m8/check-update")
    Observable<CheckUpdateResponse> requestUpdate(@FieldMap Map<String, Object> map);

    @GET("get-verify-code")
    Observable<BaseResponse<String>> getVerifyCode(@Query("telephone") String telephone);

    @GET("check-verify-code")
    Observable<BaseResponse<Object>> checkVerifyCode(@Query("telephone") String telephone,
                                                     @Query("verifyCode") String verifyCode);

    @POST("login")
    Observable<BaseResponse<User>> login(@Query("telephone") String telephone,
                                         @Query("password") String password);

    @Multipart
    @POST("register")
    Observable<BaseResponse<User>> register(@Query("telephone") String telephone,
                                            @Query("userName") String userName,
                                            @Query("birthday") String birthday,
                                            @Query("password") String password,
                                            @Part MultipartBody.Part avatar);

    @POST("delete-account")
    Observable<BaseResponse<String>> deleteAccount(@Query("verifyCode") String verifyCode);

    @GET("get-user-info")
    Observable<BaseResponse<User>> getUserInfo();

    @Multipart
    @POST("change-user-info")
    Observable<BaseResponse<User>> changeUserInfo(@Part List<MultipartBody.Part> body);

    @POST("change-password")
    Observable<BaseResponse<String>> changePassword(@Query("oldPassword") String oldPassword,
                                                    @Query("newPassword") String newPassword);

    @POST("verify-code-change-password")
    Observable<BaseResponse<String>> verifyCodeChangePassword(@Query("telephone") String telephone,
                                                              @Query("verifyCode") String verifyCode,
                                                              @Query("password") String password);

    @POST("verify-code-change-telephone")
    Observable<BaseResponse<String>> verifyCodeChangeTelephone(@Query("telephone") String telephone,
                                                               @Query("verifyCode") String verifyCode);

    @POST("m8-assess-record/upload")
    Observable<BaseResponse<String>> uploadAssessRecord(@Body AssessRecord assessRecord);

    @GET("m8-assess-record/list/{page}/{size}")
    Observable<BaseResponse<Record<AssessRecord>>> getAssessRecord(@Path("page") int page,
                                                                   @Path("size") int size);

    @GET("m8-assess-record/delete")
    Observable<BaseResponse<String>> deleteAssessRecord(@Query("recordId") int recordId);

    @POST("m8-train-record/upload")
    Observable<BaseResponse<String>> uploadTrainRecord(@Body TrainRecord trainRecord);

    @GET("m8-train-record/list/{page}/{size}")
    Observable<BaseResponse<Record<TrainRecord>>> getTrainRecord(@Path("page") int page,
                                                                 @Path("size") int size);

    @GET("m8-train-record/list/all")
    Observable<BaseResponse<Record<TrainRecord>>> getAllTrainRecord();

    @GET("m8-train-record/delete")
    Observable<BaseResponse<String>> deleteTrainRecord(@Query("recordId") int recordId);
}
