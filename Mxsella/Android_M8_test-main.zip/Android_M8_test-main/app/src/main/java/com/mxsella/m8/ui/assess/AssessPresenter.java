package com.mxsella.m8.ui.assess;

import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.net.LoginService;
import com.mxsella.m8.net.PicService;
import com.mxsella.m8.net.RxScheduler;

public class AssessPresenter extends BasePresenter<AssessContract.View>
    implements AssessContract.Presenter {

    private static final String TAG = "AssessPresenter";

    public AssessPresenter(AssessContract.View view) {
        super(view);
    }

    @Override
    public void uploadAssessRecord(AssessRecord assessRecord) {
        addDisposable(LoginService.getApi().uploadAssessRecord(assessRecord)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        mView.uploadResult(ResponseHelper.deal("Assess uploadAssessRecord", data) && data.getCode() == Constants.SUCCESS, assessRecord);
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                        mView.uploadResult(false, assessRecord);
                    }
                }));
    }
}
