package com.mxsella.m8.ui.game;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseActivity;
import com.mxsella.m8.helper.Constants;

import butterknife.OnClick;

public class GameChooseActivity extends BaseActivity {

    @Override
    public int getLayoutId() {
        return R.layout.activity_game_choose;
    }

    public static void show(Context context) {
        context.startActivity(new Intent(context, GameChooseActivity.class));
    }

    @Override
    public void initView() {
        super.initView();
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();
    }

    @OnClick({R.id.btn_game_catch_fish, R.id.btn_game_bear_fruit})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_game_catch_fish:
                GameTrainActivity.show(this, 0);
                break;
            case R.id.btn_game_bear_fruit:
                GameTrainActivity.show(this, 1);
                break;
        }
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }
}