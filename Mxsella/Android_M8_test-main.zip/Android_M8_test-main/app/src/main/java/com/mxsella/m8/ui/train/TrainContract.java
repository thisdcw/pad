package com.mxsella.m8.ui.train;

import com.mxsella.m8.base.BaseContract;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.bean.TrainRecord;

public interface TrainContract {

    interface Presenter extends BaseContract.Presenter {

        void uploadTrainRecord(TrainRecord trainRecord);

    }

    interface View extends BaseContract.View<Presenter> {

        void uploadResult(boolean result, TrainRecord trainRecord);

    }
}
