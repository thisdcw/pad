package com.mxsella.m8.ui.login;

import com.mxsella.m8.base.BaseContract;

public interface LoginForgetContract {

    interface Presenter extends BaseContract.Presenter {

        void getVerifyCode(String telephone);

        void verifyCodeChangePassword(String telephone, String verifyCode, String password);

    }

    interface View extends BaseContract.View<Presenter> {

        void verifyCodeChangePasswordResult(boolean result, String msg);

    }
}
