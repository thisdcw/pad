package com.mxsella.m8.bean;

import java.io.Serializable;

public class RecoveryItem implements Serializable {

    private int hz;
    private int us;
    private int timeIrritate;
    private int timeUp;
    private int timeHorizontal;
    private int timeDown;
    private int timeRelax;
    private int timeSingle;
    private int timeAll;

    public RecoveryItem(int hz, int us, int timeAll) {
        this.hz = hz;
        this.us = us;
        this.timeAll = timeAll;
    }

    public int getHz() {
        return hz;
    }

    public void setHz(int hz) {
        this.hz = hz;
    }

    public int getUs() {
        return us;
    }

    public void setUs(int us) {
        this.us = us;
    }

    public int getTimeIrritate() {
        return timeIrritate;
    }

    public void setTimeIrritate(int timeIrritate) {
        this.timeIrritate = timeIrritate;
    }

    public int getTimeUp() {
        return timeUp;
    }

    public void setTimeUp(int timeUp) {
        this.timeUp = timeUp;
    }

    public int getTimeHorizontal() {
        return timeHorizontal;
    }

    public void setTimeHorizontal(int timeHorizontal) {
        this.timeHorizontal = timeHorizontal;
    }

    public int getTimeDown() {
        return timeDown;
    }

    public void setTimeDown(int timeDown) {
        this.timeDown = timeDown;
    }

    public int getTimeRelax() {
        return timeRelax;
    }

    public void setTimeRelax(int timeRelax) {
        this.timeRelax = timeRelax;
    }

    public int getTimeSingle() {
        return timeSingle;
    }

    public void setTimeSingle(int timeSingle) {
        this.timeSingle = timeSingle;
    }

    public int getTimeAll() {
        return timeAll;
    }

    public void setTimeAll(int timeAll) {
        this.timeAll = timeAll;
    }

    @Override
    public String toString() {
        return "RecoveryItem{" +
                "hz=" + hz +
                ", us=" + us +
                ", timeIrritate=" + timeIrritate +
                ", timeUp=" + timeUp +
                ", timeHorizontal=" + timeHorizontal +
                ", timeDown=" + timeDown +
                ", timeRelax=" + timeRelax +
                ", timeSingle=" + timeSingle +
                ", timeAll=" + timeAll +
                '}';
    }
}
