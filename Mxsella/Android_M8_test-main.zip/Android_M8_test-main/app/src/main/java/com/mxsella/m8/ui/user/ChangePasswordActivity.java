package com.mxsella.m8.ui.user;

import android.content.Context;
import android.content.Intent;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.utils.MD5Utils;
import com.mxsella.m8.utils.PwdCheckUtil;
import com.mxsella.m8.utils.ToastUtils;

import butterknife.BindView;
import butterknife.OnClick;

public class ChangePasswordActivity extends BaseMvpActivity<ChangePasswordContract.Presenter> implements ChangePasswordContract.View {

    @Override
    public int getLayoutId() {
        return R.layout.activity_change_password;
    }

    @Override
    protected ChangePasswordContract.Presenter initPresenter() {
        return new ChangePasswordPresenter(this);
    }

    @BindView(R.id.edt_old_password)
    EditText edtOldPassword;
    @BindView(R.id.edt_new_password)
    EditText edtNewPassword;
    @BindView(R.id.edt_confirm_password)
    EditText edtConfirmPassword;
    @BindView(R.id.btn_old_password_state)
    Button btnOldPasswordState;
    @BindView(R.id.btn_new_password_state)
    Button btnNewPasswordState;
    @BindView(R.id.btn_confirm_password_state)
    Button btnConfirmPasswordState;

    private InputMethodManager manager;

    private boolean showOldPassword = false;
    private boolean showNewPassword = false;
    private boolean showConfirmPassword = false;

    public static void show(Context context) {
        Intent intent = new Intent(context, ChangePasswordActivity.class);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();

        manager = ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE));
        setFocusChangeListener(edtOldPassword);
        setFocusChangeListener(edtNewPassword);
        setFocusChangeListener(edtConfirmPassword);
    }

    private void toggleOldPasswordState() {
        showOldPassword = !showOldPassword;
        edtOldPassword.setInputType(InputType.TYPE_CLASS_TEXT | (showOldPassword ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
        edtOldPassword.setSelection(edtOldPassword.getText().length());
        btnOldPasswordState.setBackgroundResource(showOldPassword ? R.drawable.login_password_hide : R.drawable.login_password_show);
    }

    private void toggleNewPasswordState() {
        showNewPassword = !showNewPassword;
        edtNewPassword.setInputType(InputType.TYPE_CLASS_TEXT | (showNewPassword ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
        edtNewPassword.setSelection(edtNewPassword.getText().length());
        btnNewPasswordState.setBackgroundResource(showNewPassword ? R.drawable.login_password_hide : R.drawable.login_password_show);
    }

    private void toggleConfirmPasswordState() {
        showConfirmPassword = !showConfirmPassword;
        edtConfirmPassword.setInputType(InputType.TYPE_CLASS_TEXT | (showConfirmPassword ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
        edtConfirmPassword.setSelection(edtConfirmPassword.getText().length());
        btnConfirmPasswordState.setBackgroundResource(showConfirmPassword ? R.drawable.login_password_hide : R.drawable.login_password_show);
    }

    @OnClick({R.id.btn_old_password_state, R.id.btn_new_password_state, R.id.btn_confirm_password_state, R.id.btn_confirm})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_old_password_state:
                toggleOldPasswordState();
                break;
            case R.id.btn_new_password_state:
                toggleNewPasswordState();
                break;
            case R.id.btn_confirm_password_state:
                toggleConfirmPasswordState();
                break;
            case R.id.btn_confirm:
                if(edtOldPassword.getText().toString().length() < 8) {
                    ToastUtils.showToast(getString(R.string.toast_enter_valid_password));
                    return;
                }
                if (!PwdCheckUtil.normalCheck(edtOldPassword.getText().toString())) {
                    ToastUtils.showToast(getString(R.string.toast_enter_valid_password));
                    return;
                }
                if(edtNewPassword.getText().toString().length() < 8) {
                    ToastUtils.showToast(getString(R.string.toast_enter_valid_password));
                    return;
                }
                if (!PwdCheckUtil.normalCheck(edtNewPassword.getText().toString())) {
                    ToastUtils.showToast(getString(R.string.toast_enter_valid_password));
                    return;
                }
                if(!edtConfirmPassword.getText().toString().equals(edtNewPassword.getText().toString())) {
                    ToastUtils.showToast(getString(R.string.toast_password_inconsistent));
                    return;
                }
                mPresenter.changePassword(MD5Utils.encrypt(edtOldPassword.getText().toString()), MD5Utils.encrypt(edtNewPassword.getText().toString()));
                break;
        }
    }

    @Override
    public void changePasswordResult(boolean result, String msg) {
        ToastUtils.showToast(msg);
        if(result) {
            Config.logout();
        }
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }

    public void setFocusChangeListener(EditText editText){
        editText.setOnFocusChangeListener((view, b) -> {
            if(!b){
                if (manager != null) {
                    manager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
            }
        });
    }
}