package com.mxsella.m8.ui.adpter;

import android.content.Context;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.mxsella.m8.R;
import com.mxsella.m8.helper.ResourceHelper;

import java.util.List;

public class LanguageAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    private final Context context;
    private int selectPos = -1;

    public LanguageAdapter(Context context, @Nullable List<String> data) {
        super(R.layout.item_language, data);
        this.context = context;
    }

    @Override
    protected void convert(BaseViewHolder helper, String item) {
        int position = helper.getAbsoluteAdapterPosition();
        helper.setVisible(R.id.img_check, position == selectPos);
        helper.setText(R.id.tv_language, ResourceHelper.getStringByName(context, "language_" + item));
    }

    public void setSelectPos(int selectPos) {
        this.selectPos = selectPos;
    }
}
