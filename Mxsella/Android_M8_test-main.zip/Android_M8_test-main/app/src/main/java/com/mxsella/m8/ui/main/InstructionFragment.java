package com.mxsella.m8.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.view.View;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseFragment;
import com.mxsella.m8.ui.instruction.InstructionNoteActivity;
import com.mxsella.m8.ui.instruction.QuickUseGuideActivity;

import butterknife.OnClick;

public class InstructionFragment extends BaseFragment {
    
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_instruction;
    }

    @OnClick({R.id.btn_note, R.id.btn_use_guide})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_note:
                InstructionNoteActivity.show(_mActivity);
                break;
            case R.id.btn_use_guide:
                /*String url = "http://imgmmk.mxsella.com/common/M8_quick_use_guide.pdf";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(Intent.createChooser(intent, "Browse with"));*/
                QuickUseGuideActivity.show(_mActivity);
                break;
        }
    }
}
