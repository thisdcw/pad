package com.mxsella.m8.ui.instruction;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseActivity;
import com.mxsella.m8.utils.LocalLog;

import java.io.InputStream;

import butterknife.BindView;
import butterknife.OnClick;

public class QuickUseGuideActivity extends BaseActivity {

    @Override
    public int getLayoutId() {
        return R.layout.activity_quick_use_guide;
    }

    @BindView(R.id.img_guide)
    ImageView imgGuide;

    public static void show(Context context) {
        context.startActivity(new Intent(context, QuickUseGuideActivity.class));
    }

    @Override
    public void initView() {
        super.initView();

        new Thread(()->{
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("assets/quick_use_guide.jpg");
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            if (imgGuide == null)
                return;
            runOnUiThread(()-> {
                RequestOptions requestOptions = new RequestOptions()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .override(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL)  //加载原始大小
                        .format(DecodeFormat.PREFER_RGB_565);  // 去掉透明度通道，减少内存占有
                Glide.with(this)
                        .setDefaultRequestOptions(requestOptions)
                        .load(bitmap)
                        .into(imgGuide);
                // imgGuide.setImageBitmap(bitmap);
            });
        }).start();
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }
}