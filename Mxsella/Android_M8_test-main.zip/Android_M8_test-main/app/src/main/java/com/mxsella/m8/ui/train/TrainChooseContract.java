package com.mxsella.m8.ui.train;

import com.mxsella.m8.base.BaseContract;
import com.mxsella.m8.bean.TrainRecord;

import java.util.List;

public interface TrainChooseContract {

    interface Presenter extends BaseContract.Presenter {

        void getAllTrainRecord();

    }

    interface View extends BaseContract.View<Presenter> {

        void showTrainRecord(List<TrainRecord> recordList);

    }
}
