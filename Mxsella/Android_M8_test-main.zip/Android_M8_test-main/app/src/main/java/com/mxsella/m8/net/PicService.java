package com.mxsella.m8.net;

import com.mxsella.m8.application.MyApplication;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.utils.LocalLog;

import java.io.File;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class PicService {

    private volatile static PicService instance;
    private final ApiService mService;
    private String uid;
    private String token;

    private PicService(String u, String t) {
        final Cache cache = new Cache(new File(MyApplication.getInstance().getCacheDir(), "HttpCache"),
                1024*1024*1024);

        final OkHttpClient client = new OkHttpClient.Builder()
                .cache(cache)
                .addInterceptor(chain -> {
                    Request original = chain.request();
                    Request.Builder builder = original.newBuilder();
                    builder.addHeader("Content-SceneType","image/png;charset=utf-8")
                            .addHeader("uid", uid)
                            .addHeader("X-Token", token);
                    Request newRequest = builder.build();
                    return chain.proceed(newRequest);
                })
                .addInterceptor(getLoggerInterceptor())
                .writeTimeout(30*1000, TimeUnit.MILLISECONDS)
                .readTimeout(20*1000, TimeUnit.MILLISECONDS)
                .connectTimeout(6*1000, TimeUnit.MILLISECONDS)
                .retryOnConnectionFailure(true)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(client)
                .baseUrl(ApiService.BASE_URL)
                .build();
        mService = retrofit.create(ApiService.class);
    }

    public static ApiService getApi() {
        String u = Config.curUser == null ? "" : Config.curUser.getUid();
        String t = Config.curUser == null ? "" : Config.curUser.getToken();

        if (instance == null || !u.equals(instance.uid) || !t.equals(instance.token)) {
            synchronized(ApiService.class) {
                if (instance == null || !u.equals(instance.uid) || !t.equals(instance.token)) {
                    instance = new PicService(u, t);
                }
            }
        }

        return instance.mService;
    }

    public final static HttpLoggingInterceptor getLoggerInterceptor() {
        HttpLoggingInterceptor.Level level = HttpLoggingInterceptor.Level.HEADERS;

        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor(message -> {
            if(Config.ifHttpLog)
                LocalLog.d("ApiUrl", "----->"+message);
        });
        loggingInterceptor.setLevel(level);
        return loggingInterceptor;
    }
}
