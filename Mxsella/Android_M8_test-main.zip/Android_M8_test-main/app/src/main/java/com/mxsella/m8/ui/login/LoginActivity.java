package com.mxsella.m8.ui.login;

import android.content.Context;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mxsella.m8.R;
import com.mxsella.m8.application.MyApplication;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.net.ApiService;
import com.mxsella.m8.ui.main.MainActivity;
import com.mxsella.m8.ui.user.UserInfoActivity;
import com.mxsella.m8.utils.MD5Utils;
import com.mxsella.m8.utils.PwdCheckUtil;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.dialog.PrivacyPolicyDialog;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import butterknife.BindView;
import butterknife.OnClick;

public class LoginActivity extends BaseMvpActivity<LoginContract.Presenter> implements LoginContract.View {

    @Override
    public int getLayoutId() {
        return R.layout.activity_login;
    }

    @Override
    protected LoginContract.Presenter initPresenter() {
        return new LoginPresenter(this);
    }

    @BindView(R.id.edt_telephone)
    EditText edtTelephone;
    @BindView(R.id.edt_verify_code)
    EditText edtVerifyCode;
    @BindView(R.id.llt_verify_code)
    LinearLayout lltVerifyCode;
    @BindView(R.id.edt_password)
    EditText edtPassword;
    @BindView(R.id.btn_password_state)
    Button btnPasswordState;
    @BindView(R.id.llt_password)
    LinearLayout lltPassword;
    @BindView(R.id.tv_get_verify_code)
    TextView tvGetVerifyCode;
    @BindView(R.id.tv_login_way)
    TextView tvLoginWay;
    @BindView(R.id.checkbox)
    CheckBox checkBox;

    private InputMethodManager manager;
    private ExecutorService verifyCodeThread = Executors.newSingleThreadExecutor();

    private boolean showPassword = false;
    private boolean passwordLogin = true;
    private String sendAgainFormat;
    private int sendAgainTime = 0;

    @Override
    public void initView() {
        super.initView();

        checkReadPrivacyPolicy();

        manager = ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE));
        setFocusChangeListener(edtTelephone);
        setFocusChangeListener(edtVerifyCode);
        setFocusChangeListener(edtPassword);

        setPrivacy();
        setPasswordLogin(passwordLogin);
        sendAgainFormat = getString(R.string.login_send_verify_time);
    }

    private void checkReadPrivacyPolicy() {
        if (!Config.getReadPrivacyPolicy()) {
            findViewById(R.id.view_mask).setVisibility(View.VISIBLE);
            PrivacyPolicyDialog policyDialog = new PrivacyPolicyDialog(this);
            policyDialog.setPrivacyPolicyClickListener(view -> {
                WebViewActivity.show(this, getString(R.string.privacy_policy_title), ApiService.PRIVACY_POLICY_URL);
            });
            policyDialog.setConfirmClickListener(view -> {
                findViewById(R.id.view_mask).setVisibility(View.GONE);
                Config.saveReadPrivacyPolicy(true);
                policyDialog.dismiss();
                MyApplication.getInstance().init();
            });
            policyDialog.setCancelClickListener(view -> {
                this.finish();
            });
            policyDialog.show();
        } else {
            if (Config.getLoginUser() != null) {
                MainActivity.show(this);
                finish();
            }
        }
    }

    private void setPasswordLogin(boolean b) {
        edtVerifyCode.setText("");
        edtPassword.setText("");
        lltVerifyCode.setVisibility(b ? View.GONE : View.VISIBLE);
        lltPassword.setVisibility(b ? View.VISIBLE : View.GONE);
        tvLoginWay.setText(b ? getString(R.string.login_way_verify) : getString(R.string.login_way_password));
        passwordLogin = b;
    }

    private void setPrivacy() {
        String loginPrivacy = getString(R.string.login_privacy);
        String privacy = getString(R.string.privacy_policy);
        SpannableString spannableString = new SpannableString(loginPrivacy);

        ForegroundColorSpan blackColorSpan = new ForegroundColorSpan(getResources().getColor(R.color.black));
        spannableString.setSpan(blackColorSpan, 0, loginPrivacy.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        ForegroundColorSpan themeColorSpan = new ForegroundColorSpan(getResources().getColor(R.color.theme_color));
        spannableString.setSpan(themeColorSpan, loginPrivacy.indexOf(privacy), loginPrivacy.indexOf(privacy) + privacy.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        ((TextView) findViewById(R.id.tv_privacy_policy)).setText(spannableString);
    }

    private void togglePasswordState() {
        showPassword = !showPassword;
        edtPassword.setInputType(InputType.TYPE_CLASS_TEXT | (showPassword ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
        edtPassword.setSelection(edtPassword.getText().length());
        btnPasswordState.setBackgroundResource(showPassword ? R.drawable.login_password_hide : R.drawable.login_password_show);
    }

    @OnClick({R.id.btn_password_state, R.id.tv_get_verify_code, R.id.tv_login_forget, R.id.tv_login_way, R.id.btn_login, R.id.tv_privacy_policy})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_password_state:
                togglePasswordState();
                break;
            case R.id.tv_get_verify_code:
                if(edtTelephone.getText().toString().length() != 11) {
                    ToastUtils.showToast(getString(R.string.toast_enter_valid_telephone));
                    return;
                }
                mPresenter.getVerifyCode(edtTelephone.getText().toString());
                tvGetVerifyCode.setEnabled(false);
                sendAgainTime = 60;
                verifyCodeThread.execute(verifyCodeTimer);
                break;
            case R.id.tv_login_forget:
                LoginForgetActivity.show(this);
                break;
            case R.id.tv_login_way:
                setPasswordLogin(!passwordLogin);
                break;
            case R.id.btn_login:
                if (!checkBox.isChecked()) {
                    ToastUtils.showToast(getString(R.string.toast_check_first));
                    return;
                }
                if(edtTelephone.getText().toString().length() != 11) {
                    ToastUtils.showToast(getString(R.string.toast_enter_valid_telephone));
                    return;
                }
                if(passwordLogin) {
                    if(edtPassword.getText().toString().length() < 8) {
                        ToastUtils.showToast(getString(R.string.toast_enter_valid_password));
                        return;
                    }
                    if (!PwdCheckUtil.normalCheck(edtPassword.getText().toString())) {
                        ToastUtils.showToast(getString(R.string.toast_enter_valid_password));
                        return;
                    }
                    showNetDialog();
                    mPresenter.login(edtTelephone.getText().toString(), MD5Utils.encrypt(edtPassword.getText().toString()));
                } else {
                    if(edtVerifyCode.getText().toString().length() < 6) {
                        ToastUtils.showToast(getString(R.string.toast_enter_valid_verify));
                        return;
                    }
                    showNetDialog();
                    mPresenter.checkVerifyCode(edtTelephone.getText().toString(), edtVerifyCode.getText().toString());
                }
                break;
            case R.id.tv_privacy_policy:
                WebViewActivity.show(this, getString(R.string.privacy_policy_title), ApiService.PRIVACY_POLICY_URL);
                break;
        }
    }

    @Override
    public void checkResult(boolean result, boolean newUser, String msg, String telephone) {
        hideNetDialog();
        if (!TextUtils.isEmpty(msg))
            ToastUtils.showToast(msg);
        if(result) {
            if (newUser) {
                UserInfoActivity.showRegister(this, telephone);
            } else {
                MainActivity.show(this);
            }
        }
    }

    @Override
    public void loginResult(boolean result, String msg) {
        hideNetDialog();
        if (!TextUtils.isEmpty(msg))
            ToastUtils.showToast(msg);
        if(result){
            MainActivity.show(this);
        }
    }

    private Runnable verifyCodeTimer = () -> {
        while (sendAgainTime > 0) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (tvGetVerifyCode == null)
                return;
            sendAgainTime--;
            if (sendAgainTime <= 0) {
                runOnUiThread(()->{
                    sendAgainTime = 0;
                    tvGetVerifyCode.setEnabled(true);
                    tvGetVerifyCode.setText(getString(R.string.login_send_verify));
                });
                return;
            }
            runOnUiThread(()->{
                if (tvGetVerifyCode != null) {
                    tvGetVerifyCode.setText(String.format(sendAgainFormat, sendAgainTime));
                }
            });
        }
    };

    public void setFocusChangeListener(EditText editText){
        editText.setOnFocusChangeListener((view, b) -> {
            if(!b){
                if (manager != null) {
                    manager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
            }
        });
    }
}