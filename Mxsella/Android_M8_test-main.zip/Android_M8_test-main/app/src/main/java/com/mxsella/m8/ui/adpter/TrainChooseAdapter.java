package com.mxsella.m8.ui.adpter;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.mxsella.m8.R;
import com.mxsella.m8.bean.TrainCourse;

import java.util.List;

public class TrainChooseAdapter extends BaseQuickAdapter<TrainCourse, BaseViewHolder> {

    public TrainChooseAdapter(@Nullable List<TrainCourse> data) {
        super(R.layout.item_train_choose, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, TrainCourse item) {
        helper.setText(R.id.tv_course_id, String.format(mContext.getString(R.string.train_course), item.getTrainId()));
        helper.setText(R.id.tv_finish_time, String.format(mContext.getString(R.string.train_finish_times), item.getFinishTimes()));
        helper.setText(R.id.tv_course_name, item.getTrainName());
        helper.setText(R.id.tv_course_duration, String.format(mContext.getString(R.string.train_duration), item.getTrainDuration() / 60));
        helper.setBackgroundRes(R.id.llt_bkg, R.drawable.bkg_rc_white);
    }
}
