package com.mxsella.m8.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;
import com.mxsella.m8.utils.DensityUtil;

public class RequestDialog extends Dialog {

    private final Context context;
    private String title;
    private String content;
    private String textConfirm;
    private String textCancel;
    private int position;

    private TextView tvTitle;
    private TextView tvContent;
    private Button btnConfirm;
    private Button btnCancel;

    public RequestDialog(@NonNull Context context, String title) {
        super(context, R.style.Dialog);
        this.context = context;
        this.title = title;
        this.content = "";
        this.textConfirm = context.getString(R.string.confirm);
        this.textCancel = context.getString(R.string.cancel);
    }

    public RequestDialog(@NonNull Context context, String title, String content, String textConfirm, String textCancel) {
        super(context, R.style.Dialog);
        this.context = context;
        this.title = title;
        this.content = content;
        this.textConfirm = textConfirm;
        this.textCancel = textCancel;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_request, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        tvTitle = findViewById(R.id.tv_title);
        tvContent = findViewById(R.id.tv_content);
        btnConfirm = view.findViewById(R.id.btn_confirm);
        btnCancel = view.findViewById(R.id.btn_cancel);

        tvTitle.setText(title);
        tvContent.setText(content);
        tvContent.setVisibility(TextUtils.isEmpty(content) ? View.GONE : View.VISIBLE);
        btnConfirm.setText(textConfirm);
        btnCancel.setText(textCancel);
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public void setConfirmClickListener(View.OnClickListener listener) {
        btnConfirm.setOnClickListener(listener);
    }

    public void setCancelClickListener(View.OnClickListener listener) {
        btnCancel.setOnClickListener(listener);
    }

    /*@Override
    public void show() {
        try {
            super.show();
            setWidth(DensityUtil.dip2px(context, 756));
            setHeight(DensityUtil.dip2px(context, 636));
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void setWidth(int width) {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.width = width;
        getWindow().setAttributes(params);
    }

    public void setHeight(int height) {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.height = height;
        getWindow().setAttributes(params);
    }*/
}
