package com.mxsella.m8.base;

import android.content.Context;

import io.reactivex.disposables.Disposable;

public interface BaseContract {

    interface Model {

    }

    interface Presenter {

        /**
         *  view销毁操作
         */
        void detach();


        /**
         *  将网络请求的每一个Disposable加入集合
         */
        void addDisposable(Disposable disposable);

        /**
         *  销毁所有的Disposable
         */
        void unDisposable();
    }

    interface View<T extends Presenter> {

        /**
         *  显示错误信息　
         */
        default void showErrorMessage(int code) {

        }

        /**
         * 设置Presenter
         */
        void setPresenter(T presenter);

        /**
         * 得到上下文
         */
        Context getContext();
    }
}
