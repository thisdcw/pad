package com.mxsella.m8.bean;

import java.io.Serializable;
import java.util.List;

public class TrainCourse implements Serializable {

    private int trainId;
    private String trainName;
    private int trainDuration;
    private int trainType;  // 0：生物反馈，1：帮助性电刺激，2：奖励性电刺激
    private int finishTimes;
    private List<TrainCourseItem> itemList;

    public TrainCourse() {
    }

    public TrainCourse(int trainId, String trainName, int trainDuration, int trainType) {
        this.trainId = trainId;
        this.trainName = trainName;
        this.trainDuration = trainDuration;
        this.trainType = trainType;
    }

    public int getTrainId() {
        return trainId;
    }

    public void setTrainId(int trainId) {
        this.trainId = trainId;
    }

    public String getTrainName() {
        return trainName;
    }

    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }

    public int getTrainDuration() {
        return trainDuration;
    }

    public void setTrainDuration(int trainDuration) {
        this.trainDuration = trainDuration;
    }

    public int getTrainType() {
        return trainType;
    }

    public void setTrainType(int trainType) {
        this.trainType = trainType;
    }

    public int getFinishTimes() {
        return finishTimes;
    }

    public void setFinishTimes(int finishTimes) {
        this.finishTimes = finishTimes;
    }

    public List<TrainCourseItem> getItemList() {
        return itemList;
    }

    public void setItemList(List<TrainCourseItem> itemList) {
        this.itemList = itemList;
    }

    @Override
    public String toString() {
        return "TrainCourse{" +
                "trainId=" + trainId +
                ", trainName='" + trainName + '\'' +
                ", trainDuration=" + trainDuration +
                ", trainType=" + trainType +
                ", finishTimes=" + finishTimes +
                ", itemList=" + itemList +
                '}';
    }
}
