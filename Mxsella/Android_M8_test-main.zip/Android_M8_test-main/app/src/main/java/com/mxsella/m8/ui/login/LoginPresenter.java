package com.mxsella.m8.ui.login;

import com.google.gson.Gson;
import com.mxsella.m8.R;
import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.User;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;
import com.mxsella.m8.utils.ToastUtils;

public class LoginPresenter extends BasePresenter<LoginContract.View>
    implements LoginContract.Presenter {

    private static final String TAG = "LoginPresenter";

    public LoginPresenter(LoginContract.View view) {
        super(view);
    }

    @Override
    public void getVerifyCode(String telephone) {
        addDisposable(NormalService.getApi().getVerifyCode(telephone)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("Login getVerifyCode", data) && data.getCode() == Constants.SUCCESS) {
                            ToastUtils.showToast(data.getData());
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }

    @Override
    public void checkVerifyCode(String telephone, String verifyCode) {
        addDisposable(NormalService.getApi().checkVerifyCode(telephone, verifyCode)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<Object>>() {
                    @Override
                    public void onSuccess(BaseResponse<Object> data) {
                        if (ResponseHelper.deal("Login checkVerifyCode", data) && data.getCode() == Constants.SUCCESS) {
                            Gson gson = new Gson();
                            if(data.getData() != null) {
                                String json = gson.toJson(data.getData());
                                Config.saveLoginUser(gson.fromJson(json, User.class));
                                mView.checkResult(true, false, mView.getContext().getString(R.string.toast_login_success), telephone);
                            } else {
                                mView.checkResult(true, true, "", telephone);
                            }
                        } else {
                            mView.checkResult(false, false, "", telephone);
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                        mView.checkResult(false, false, "", telephone);
                    }
                }));
    }

    @Override
    public void login(String telephone, String password) {
        addDisposable(NormalService.getApi().login(telephone, password)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<User>>() {
                    @Override
                    public void onSuccess(BaseResponse<User> data) {
                        if (ResponseHelper.deal("Login login", data) && data.getCode() == Constants.SUCCESS) {
                            Config.saveLoginUser(data.getData());
                            mView.loginResult(true, mView.getContext().getString(R.string.toast_login_success));
                        } else {
                            mView.loginResult(false, "");
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                        mView.loginResult(false, "");
                    }
                }));
    }
}
