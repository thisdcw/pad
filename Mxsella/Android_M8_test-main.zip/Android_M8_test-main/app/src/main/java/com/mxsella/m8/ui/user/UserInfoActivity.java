package com.mxsella.m8.ui.user;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

import com.bigkoo.pickerview.builder.TimePickerBuilder;
import com.bigkoo.pickerview.view.TimePickerView;
import com.bumptech.glide.Glide;
import com.luck.picture.lib.basic.PictureSelectionModel;
import com.luck.picture.lib.entity.LocalMedia;
import com.luck.picture.lib.interfaces.OnPermissionsInterceptListener;
import com.luck.picture.lib.interfaces.OnRequestPermissionListener;
import com.luck.picture.lib.interfaces.OnResultCallbackListener;
import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.bean.User;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.ui.main.MainActivity;
import com.mxsella.m8.utils.AvatarSelectorUtils;
import com.mxsella.m8.utils.MD5Utils;
import com.mxsella.m8.utils.PwdCheckUtil;
import com.mxsella.m8.utils.TimeDateUtils;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.dialog.RequestDialog;
import com.tbruyelle.rxpermissions2.Permission;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;

import butterknife.BindView;
import butterknife.OnClick;

public class UserInfoActivity extends BaseMvpActivity<UserInfoContract.Presenter> implements UserInfoContract.View {

    public static final String TYPE = "type";
    public static final int TYPE_REGISTER = 0;
    public static final int TYPE_EDIT = 1;
    public static final String TELEPHONE = "telephone";

    @Override
    public int getLayoutId() {
        return R.layout.activity_user_info;
    }

    @Override
    protected UserInfoContract.Presenter initPresenter() {
        return new UserInfoPresenter(this);
    }

    @BindView(R.id.img_avatar)
    ImageView imgAvatar;
    @BindView(R.id.edt_user_name)
    EditText edtUserName;
    @BindView(R.id.edt_birthday)
    EditText edtBirthday;
    @BindView(R.id.llt_password)
    View lltPassword;
    @BindView(R.id.edt_password)
    EditText edtPassword;
    @BindView(R.id.edt_confirm_password)
    EditText edtConfirmPassword;

    private InputMethodManager manager;

    private int type;
    private User user;
    private File avatar;
    private String telephone;
    private Calendar curDate = Calendar.getInstance();

    public static void showRegister(Context context, String telephone) {
        Intent intent = new Intent(context, UserInfoActivity.class);
        intent.putExtra(TYPE, TYPE_REGISTER);
        intent.putExtra(TELEPHONE, telephone);
        context.startActivity(intent);
    }

    public static void showEdit(Context context) {
        Intent intent = new Intent(context, UserInfoActivity.class);
        intent.putExtra(TYPE, TYPE_EDIT);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();

        manager = ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE));
        setFocusChangeListener(edtUserName);
        setFocusChangeListener(edtBirthday);
        setFocusChangeListener(edtPassword);
        setFocusChangeListener(edtConfirmPassword);

        type = getIntent().getIntExtra(TYPE, TYPE_REGISTER);
        if (type == TYPE_REGISTER) {
            telephone = getIntent().getStringExtra(TELEPHONE);
            lltPassword.setVisibility(View.VISIBLE);
        } else if (type == TYPE_EDIT) {
            user = Config.curUser;
            edtUserName.setText(user.getUserName());
            edtBirthday.setText(user.getBirthday());
            lltPassword.setVisibility(View.GONE);

            if (user.getAvatar() != null && !user.getAvatar().isEmpty())
                Glide.with(this).load(user.getAvatar()).into(imgAvatar);
        }
        edtBirthday.setEnabled(false);

        if (!TextUtils.isEmpty(edtBirthday.getText().toString())) {
            String[] array = edtBirthday.getText().toString().split("-");
            int year = Integer.parseInt(array[0]);
            int month = Integer.parseInt(array[1]) - 1;
            int day = Integer.parseInt(array[2]);
            curDate.set(year, month, day);
        }
    }

    @OnClick({R.id.img_avatar, R.id.tv_birthday_select, R.id.btn_confirm})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_avatar:
                PictureSelectionModel selectionModel = AvatarSelectorUtils.getPictureSelectionModel(this);
                selectionModel.setPermissionsInterceptListener(new OnPermissionsInterceptListener() {
                    @Override
                    public void requestPermission(Fragment fragment, String[] permissionArray, OnRequestPermissionListener call) {
                        if (fragment.getActivity() == null || permissionArray.length == 0) {
                            call.onCall(permissionArray, false);
                        } else {
                            boolean ifCamera = permissionArray[0].equals("android.permission.CAMERA");
                            RequestDialog requestDialog = new RequestDialog(fragment.getActivity(),
                                    getString(ifCamera ? R.string.permission_storage_title : R.string.permission_storage_content),
                                    getString(ifCamera ? R.string.permission_camera_title : R.string.permission_camera_content),
                                    getString(R.string.permission_on), getString(R.string.cancel));
                            requestDialog.setConfirmClickListener(view -> {
                                RxPermissions rxPermission = new RxPermissions(fragment.getActivity());
                                rxPermission.requestEachCombined(permissionArray)
                                        .subscribe(new BaseObserver<Permission>() {
                                            @Override
                                            public void onSuccess(Permission data) {
                                                call.onCall(permissionArray, data.granted);
                                            }
                                        });
                                requestDialog.dismiss();
                            });
                            requestDialog.setCancelClickListener(view -> {
                                call.onCall(permissionArray, false);
                                requestDialog.dismiss();
                            });
                            requestDialog.show();
                        }
                    }

                    @Override
                    public boolean hasPermissions(Fragment fragment, String[] permissionArray) {
                        return false;
                    }
                });
                selectionModel.forResult(new OnResultCallbackListener<LocalMedia>() {
                    @Override
                    public void onResult(ArrayList<LocalMedia> result) {
                        avatar = new File(result.get(0).getAvailablePath());
                        runOnUiThread(()->{
                            Glide.with(UserInfoActivity.this).load(result.get(0).getAvailablePath()).into(imgAvatar);
                        });
                    }

                    @Override
                    public void onCancel() {

                    }
                });
                break;
            case R.id.tv_birthday_select:
                Calendar startDate = Calendar.getInstance();
                startDate.set(1900, 0, 1);
                Calendar endDate = Calendar.getInstance();
                TimePickerView pvTime = new TimePickerBuilder(this, (date, v) -> {
                    curDate.setTime(date);
                    edtBirthday.setText(TimeDateUtils.getDateTimeDay(date));
                }).setTimeSelectChangeListener(date -> {
                        })
                        .setType(new boolean[]{true, true, true, false, false, false})
                        .setItemVisibleCount(6)
                        .setLineSpacingMultiplier(2.0f)
                        .isAlphaGradient(true)
                        .setTitleText("")
                        .setTitleSize(16)
                        .setSubCalSize(16)
                        .setContentTextSize(20)
                        .setRangDate(startDate, endDate)
                        .setDate(curDate)
                        .build();
                pvTime.show();
                break;
            case R.id.btn_confirm:
                if(edtUserName.getText().toString().length() == 0) {
                    ToastUtils.showToast(getString(R.string.toast_enter_name));
                    return;
                }
                if(edtBirthday.getText().toString().length() == 0) {
                    ToastUtils.showToast(getString(R.string.toast_choose_birthday));
                    return;
                }
                if (type == TYPE_REGISTER) {
                    if(edtPassword.getText().toString().length() < 8) {
                        ToastUtils.showToast(getString(R.string.toast_enter_valid_password));
                        return;
                    }
                    if (!PwdCheckUtil.normalCheck(edtPassword.getText().toString())) {
                        ToastUtils.showToast(getString(R.string.toast_enter_valid_password));
                        return;
                    }
                    if(!edtConfirmPassword.getText().toString().equals(edtPassword.getText().toString())) {
                        ToastUtils.showToast(getString(R.string.toast_password_inconsistent));
                        return;
                    }
                    mPresenter.register(telephone, edtUserName.getText().toString(), edtBirthday.getText().toString(), MD5Utils.encrypt(edtPassword.getText().toString()), avatar);
                } else if (type == TYPE_EDIT) {
                    try {
                        User changeUser = (User) user.clone();
                        changeUser.setUserName(edtUserName.getText().toString());
                        changeUser.setBirthday(edtBirthday.getText().toString());
                        mPresenter.changeUserInfo(changeUser, avatar);
                    } catch (CloneNotSupportedException ignore) {

                    }
                }
                break;
        }
    }

    @Override
    public void registerResult(boolean result) {
        if(result) {
            MainActivity.show(this);
        }
    }

    @Override
    public void changeResult(boolean result) {
        if(result) {
            ToastUtils.showToast(getString(R.string.toast_modify_user_info_success));
        }
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }

    public void setFocusChangeListener(EditText editText){
        editText.setOnFocusChangeListener((view, b) -> {
            if(!b){
                if (manager != null) {
                    manager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
            }
        });
    }
}