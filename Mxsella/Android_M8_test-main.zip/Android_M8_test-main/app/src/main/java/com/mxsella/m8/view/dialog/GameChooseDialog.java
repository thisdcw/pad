package com.mxsella.m8.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;

import java.util.Arrays;
import java.util.List;

import butterknife.BindView;

public class GameChooseDialog extends Dialog implements View.OnClickListener {

    private Context context;
    private int position;

    @BindView(R.id.btn_easy)
    Button btnEasy;
    @BindView(R.id.btn_normal)
    Button btnNormal;
    @BindView(R.id.btn_difficult)
    Button btnDifficult;
    private Button btnConfirm;

    private List<Button> btnList;

    public GameChooseDialog(@NonNull Context context) {
        super(context, R.style.Dialog);
        this.context = context;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_game_choose, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        btnEasy = view.findViewById(R.id.btn_easy);
        btnNormal = view.findViewById(R.id.btn_normal);
        btnDifficult = view.findViewById(R.id.btn_difficult);
        btnConfirm = view.findViewById(R.id.btn_confirm);

        btnList = Arrays.asList(btnEasy, btnNormal, btnDifficult);

        btnEasy.setOnClickListener(this);
        btnNormal.setOnClickListener(this);
        btnDifficult.setOnClickListener(this);
        findViewById(R.id.llt_easy).setOnClickListener(this);
        findViewById(R.id.llt_normal).setOnClickListener(this);
        findViewById(R.id.llt_difficult).setOnClickListener(this);

        setPosition(0);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_easy:
            case R.id.llt_easy:
                setPosition(0);
                break;
            case R.id.btn_normal:
            case R.id.llt_normal:
                setPosition(1);
                break;
            case R.id.btn_difficult:
            case R.id.llt_difficult:
                setPosition(2);
                break;
        }
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        for (int i = 0; i < btnList.size(); i++) {
            btnList.get(i).setSelected(position == i);
        }
        this.position = position;
    }

    public void setConfirmClickListener(View.OnClickListener listener) {
        btnConfirm.setOnClickListener(listener);
    }
}
