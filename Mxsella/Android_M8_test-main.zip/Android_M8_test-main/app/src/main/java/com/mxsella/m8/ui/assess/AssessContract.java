package com.mxsella.m8.ui.assess;

import com.mxsella.m8.base.BaseContract;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.bean.User;

import java.io.File;

public interface AssessContract {

    interface Presenter extends BaseContract.Presenter {

        void uploadAssessRecord(AssessRecord assessRecord);

    }

    interface View extends BaseContract.View<Presenter> {

        void uploadResult(boolean result, AssessRecord assessRecord);

    }
}
