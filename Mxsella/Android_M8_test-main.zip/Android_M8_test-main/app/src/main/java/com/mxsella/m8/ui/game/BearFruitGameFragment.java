package com.mxsella.m8.ui.game;

import com.mxsella.m8.R;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.view.game.BearFruitSurfaceView;

import butterknife.BindView;

public class BearFruitGameFragment extends BaseGameFragment<BearFruitSurfaceView> {

    @BindView(R.id.surfaceview_bear_fruit)
    BearFruitSurfaceView fruitSurfaceView;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_train_bear_fruit;
    }

    @Override
    protected BearFruitSurfaceView getCommon() {
        return fruitSurfaceView;
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();
    }
}
