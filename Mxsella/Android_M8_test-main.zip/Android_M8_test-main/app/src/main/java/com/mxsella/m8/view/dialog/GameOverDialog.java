package com.mxsella.m8.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;

public class GameOverDialog extends Dialog {

    private final Context context;

    private int score;

    private TextView tvScore, tvKnow;

    public GameOverDialog(@NonNull Context context, int score) {
        super(context, R.style.Dialog);
        this.context = context;
        this.score = score;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_game_over, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        tvScore = view.findViewById(R.id.tv_score);

        tvScore.setText(String.valueOf(score));
    }
}
