package com.mxsella.m8.ui.train;

import android.content.Context;
import android.content.Intent;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.bean.TrainCourse;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.helper.RecoveryHelper;
import com.mxsella.m8.ui.adpter.TrainChooseAdapter;

import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class TrainChooseActivity extends BaseMvpActivity<TrainChooseContract.Presenter> implements TrainChooseContract.View {

    @Override
    public int getLayoutId() {
        return R.layout.activity_train_choose;
    }

    @Override
    protected TrainChoosePresenter initPresenter() {
        return new TrainChoosePresenter(this);
    }

    @BindView(R.id.rcv_recovery_choose)
    RecyclerView rcv;

    private List<TrainCourse> courseList;
    private TrainChooseAdapter chooseAdapter;

    public static void show(Context context) {
        context.startActivity(new Intent(context, TrainChooseActivity.class));
    }

    @Override
    public void initView() {
        super.initView();

        courseList = RecoveryHelper.getAllTrainCourse(this);
        chooseAdapter = new TrainChooseAdapter(courseList);
        rcv.setLayoutManager(new LinearLayoutManager(this));
        rcv.setAdapter(chooseAdapter);

        chooseAdapter.setOnItemClickListener((adapter, view, position) -> {
            TrainActivity.show(this, courseList.get(position));
        });
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        mPresenter.getAllTrainRecord();
    }

    @Override
    public void showTrainRecord(List<TrainRecord> recordList) {
        for (TrainCourse course : courseList) {
            for (TrainRecord record : recordList) {
                if (record.getTrainId() == course.getTrainId() && record.getTrainDuration() >= (course.getTrainDuration() * 2 / 3)) {
                    course.setFinishTimes(course.getFinishTimes() + 1);
                }
            }
        }
        chooseAdapter.notifyDataSetChanged();
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }
}