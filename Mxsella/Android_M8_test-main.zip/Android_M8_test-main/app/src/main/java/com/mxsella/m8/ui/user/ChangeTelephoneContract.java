package com.mxsella.m8.ui.user;

import com.mxsella.m8.base.BaseContract;

public interface ChangeTelephoneContract {

    interface Presenter extends BaseContract.Presenter {

        void getVerifyCode(String telephone);

        void verifyCodeChangeTelephone(String telephone, String verifyCode);

    }

    interface View extends BaseContract.View<Presenter> {

        void verifyCodeChangeTelephoneResult(boolean result, String msg);

    }
}
