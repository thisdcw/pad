package com.mxsella.m8.helper;

import android.content.Context;

import com.github.mikephil.charting.data.Entry;
import com.mxsella.m8.R;
import com.mxsella.m8.application.MyApplication;
import com.mxsella.m8.bean.RecoveryCourse;
import com.mxsella.m8.bean.TrainCourse;
import com.mxsella.m8.bean.TrainCourseItem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RecoveryHelper {

    public static List<RecoveryCourse> getAllRecoveryCourse(Context context) {
        List<RecoveryCourse> result = new ArrayList<>();
        if (HardwareHelper.checkVersion(HardwareHelper.NEW_EMG_VERSION)) {
            result.add(new RecoveryCourse(1, context.getString(R.string.train_name_1), 1800, Arrays.asList(Arrays.asList(5), Arrays.asList(4))));
            result.add(new RecoveryCourse(2, context.getString(R.string.train_name_2), 1800, Arrays.asList(Arrays.asList(5), Arrays.asList(50))));
            result.add(new RecoveryCourse(3, context.getString(R.string.train_name_3), 1800, Arrays.asList(Arrays.asList(30), Arrays.asList(50))));
            result.add(new RecoveryCourse(4, context.getString(R.string.train_name_4), 1800, Arrays.asList(Arrays.asList(50, 4), Arrays.asList(30))));
            result.add(new RecoveryCourse(5, context.getString(R.string.train_name_5), 1800, Arrays.asList(Arrays.asList(50), Arrays.asList(30))));
            result.add(new RecoveryCourse(6, context.getString(R.string.train_name_6), 1800, Arrays.asList(Arrays.asList(5, 75), Arrays.asList(4))));
            result.add(new RecoveryCourse(7, context.getString(R.string.train_name_7), 1800, Arrays.asList(Arrays.asList(105, 10, 4), Arrays.asList(50))));
            result.add(new RecoveryCourse(8, context.getString(R.string.train_name_8), 1800, Arrays.asList(Arrays.asList(50))));
            result.add(new RecoveryCourse(9, context.getString(R.string.train_name_9), 1800, Arrays.asList(Arrays.asList(5), Arrays.asList(30))));
            result.add(new RecoveryCourse(10, context.getString(R.string.train_name_10), 1800, Arrays.asList(Arrays.asList(40), Arrays.asList(5))));
        } else {
            result.add(new RecoveryCourse(1, context.getString(R.string.train_name_1), 1800, Arrays.asList(Arrays.asList(5), Arrays.asList(2))));
            result.add(new RecoveryCourse(2, context.getString(R.string.train_name_2), 1800, Arrays.asList(Arrays.asList(50), Arrays.asList(2))));
            result.add(new RecoveryCourse(3, context.getString(R.string.train_name_3), 1800, Arrays.asList(Arrays.asList(25), Arrays.asList(2))));
            result.add(new RecoveryCourse(4, context.getString(R.string.train_name_4), 1800, Arrays.asList(Arrays.asList(10, 15, 20, 30, 50), Arrays.asList(2), Arrays.asList(5))));
            result.add(new RecoveryCourse(5, context.getString(R.string.train_name_5), 1800, Arrays.asList(Arrays.asList(25), Arrays.asList(2))));
            result.add(new RecoveryCourse(6, context.getString(R.string.train_name_6), 1800, Arrays.asList(Arrays.asList(50), Arrays.asList(2), Arrays.asList(5), Arrays.asList(10))));
            result.add(new RecoveryCourse(7, context.getString(R.string.train_name_7), 1800, Arrays.asList(Arrays.asList(50), Arrays.asList(2), Arrays.asList(5), Arrays.asList(10))));
            result.add(new RecoveryCourse(8, context.getString(R.string.train_name_8), 1800, Arrays.asList(Arrays.asList(50), Arrays.asList(2))));
            result.add(new RecoveryCourse(9, context.getString(R.string.train_name_9), 1800, Arrays.asList(Arrays.asList(35), Arrays.asList(10), Arrays.asList(2))));
            result.add(new RecoveryCourse(10, context.getString(R.string.train_name_10), 1800, Arrays.asList(Arrays.asList(50), Arrays.asList(2))));
        }

        return result;
    }

    public static List<TrainCourse> getAllTrainCourse(Context context) {
        List<TrainCourse> result = new ArrayList<>();
        result.add(new TrainCourse(11, context.getString(R.string.train_name_11), 1800, 0));
        result.add(new TrainCourse(12, context.getString(R.string.train_name_12), 1800, 0));
        result.add(new TrainCourse(13, context.getString(R.string.train_name_13), 1800, 1));
        result.add(new TrainCourse(14, context.getString(R.string.train_name_14), 1800, 0));
        result.add(new TrainCourse(15, context.getString(R.string.train_name_15), 1800, 2));
        result.add(new TrainCourse(16, context.getString(R.string.train_name_16), 1800, 0));
        result.add(new TrainCourse(17, context.getString(R.string.train_name_17), 1800, 0));
        result.add(new TrainCourse(18, context.getString(R.string.train_name_18), 1800, 0));
        result.add(new TrainCourse(19, context.getString(R.string.train_name_19), 1800, 0));
        result.add(new TrainCourse(20, context.getString(R.string.train_name_20), 1800, 0));
        result.add(new TrainCourse(21, context.getString(R.string.train_name_21), 1800, 0));
        result.add(new TrainCourse(22, context.getString(R.string.train_name_22), 1800, 0));

        return result;
    }

    public static void setTrainCourseItem(TrainCourse trainCourse) {
        TrainCourseItem itemStatic = new TrainCourseItem(0, 10);
        itemStatic.setBaseLineList(new float[][][]{
                { {0, 10}, {10, 10} }
        });
        int id = trainCourse.getTrainId();
        if(id == 11) {
            TrainCourseItem item1 = new TrainCourseItem(1, 10);
            item1.setBaseLineList(new float[][][]{
                    { {0, 0}, {2, 55}, {8, 55}, {10, 0} },
                    { {1.5f, 0}, {3, 35}, {7, 35}, {8.5f, 0} }
            });
            item1.setMediaList(new float[][]{
                    {2, 1}, {8, 0}
            });
            TrainCourseItem item2 = new TrainCourseItem(1, 10);
            item2.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 85}, {9, 85}, {10, 0} },
                    { {1, 0}, {2, 65}, {8, 65}, {9, 0} }
            });
            item2.setMediaList(new float[][]{
                    {1, 1}, {9, 0}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1, itemStatic, item2));
        }
        else if (id == 12) {
            TrainCourseItem item1 = new TrainCourseItem(0, 10);
            item1.setBaseLineList(new float[][][]{
                    { {0, 0}, {2, 0}, {2.5f, 40}, {3, 0}, {4, 0}, {4.5f, 60}, {5, 0}, {6, 0}, {6.5f, 80}, {7, 0}, {8, 0}, {8.5f, 80}, {9, 0}, {10, 0} }
            });
            item1.setMediaList(new float[][]{
                    {2, 2}, {4, 2}, {6, 2}, {8, 2}
            });
            TrainCourseItem item2 = new TrainCourseItem(0, 11);
            item2.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 0}, {1.5f, 100}, {2, 0}, {3, 0}, {3.5f, 100}, {4, 0}, {5, 0}, {5.5f, 100}, {6, 0}, {7, 0}, {7.5f, 100}, {8, 0}, {9, 0}, {9.5f, 100}, {10, 0}, {11, 0} }
            });
            item2.setMediaList(new float[][]{
                    {1, 2}, {3, 2}, {5, 2}, {7, 2}, {9, 2}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1, itemStatic, item2));
        }
        else if (id == 13) {
            TrainCourseItem item1 = new TrainCourseItem(2, 10);
            item1.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 50}, {9, 50}, {10, 0} },
                    { {1, 0}, {2, 35}, {8, 35}, {9, 0} },
                    { {2, 0}, {2, 35}, {8, 35}, {8, 0}, {2, 0} }
            });
            item1.setMediaList(new float[][]{
                    {1, 1}, {9, 0}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1));
        }
        else if (id == 14) {
            TrainCourseItem item1 = new TrainCourseItem(1, 10);
            item1.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 85}, {9, 85}, {10, 0} },
                    { {1, 0}, {2, 65}, {8, 65}, {9, 0} }
            });
            item1.setMediaList(new float[][]{
                    {1, 1}, {9, 0}
            });
            TrainCourseItem item2 = new TrainCourseItem(0, 11);
            item2.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 0}, {1.5f, 100}, {2, 0}, {3, 0}, {3.5f, 100}, {4, 0}, {5, 0}, {5.5f, 100}, {6, 0}, {7, 0}, {7.5f, 100}, {8, 0}, {9, 0}, {9.5f, 100}, {10, 0}, {11, 0} }
            });
            item2.setMediaList(new float[][]{
                    {1, 2}, {3, 2}, {5, 2}, {7, 2}, {9, 2}
            });
            TrainCourseItem item3 = new TrainCourseItem(0, 12);
            item3.setBaseLineList(new float[][][]{
                    { {0, 0}, {2, 0}, {2.5f, 80}, {3, 0}, {5, 0}, {5, 70}, {11.99f, 70}, {11.99f, 0} }
            });
            item3.setMediaList(new float[][]{
                    {2, 2}, {5, 1}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1, itemStatic, item2, itemStatic, item3));
        }
        else if (id == 15) {
            TrainCourseItem item1 = new TrainCourseItem(3, 10);
            item1.setBaseLineList(new float[][][]{
                    { {0, 0}, {2, 70}, {8, 70}, {10, 0} },
                    { {1.5f, 0}, {3, 55}, {7, 55}, {8.5f, 0} },
                    { {2, 70}, {2, 100}, {8, 100}, {8, 70}, {2, 70} }
            });
            item1.setMediaList(new float[][]{
                    {2, 1}, {8, 0}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1));
        }
        else if (id == 16 || id == 19) {
            TrainCourseItem item1 = new TrainCourseItem(1, 12);
            item1.setBaseLineList(new float[][][]{
                    { {0, 10}, {2, 10}, {8, 60}, {8, 15}, {11.99f, 15}, {11.99f, 0} },
                    { {3, 0}, {7, 30}, {7, 0}, {12, 0} }
            });
            item1.setMediaList(new float[][]{
                    {2, 3}, {8, 0}
            });
            TrainCourseItem item2 = new TrainCourseItem(1, 10);
            item2.setBaseLineList(new float[][][]{
                    { {0, 0}, {3, 80}, {10, 0} },
                    { {1.5f, 0}, {3.5f, 50}, {8, 0}, {10, 0} }
            });
            item2.setMediaList(new float[][]{
                    {0, 3}, {3, 0}
            });
            TrainCourseItem item3 = new TrainCourseItem(0, 12);
            item3.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 0}, {1.5f, 80}, {2, 0}, {3, 0}, {3.5f, 80}, {4, 0}, {5, 0}, {5, 60}, {11.99f, 60}, {11.99f, 0} }
            });
            item3.setMediaList(new float[][]{
                    {1, 2}, {3, 2}, {5, 1}, {10, 0}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1, itemStatic, item2, itemStatic, item3));
        }
        else if (id == 17) {
            TrainCourseItem item1 = new TrainCourseItem(1, 10);
            item1.setBaseLineList(new float[][][]{
                    { {0, 5}, {10, 55} },
                    { {2, 0}, {10, 40} }
            });
            item1.setMediaList(new float[][]{
                    {0, 3}
            });
            TrainCourseItem item2 = new TrainCourseItem(1, 10);
            item2.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 85}, {9, 85}, {10, 0} },
                    { {1, 0}, {2, 65}, {8, 65}, {9, 0} }
            });
            item2.setMediaList(new float[][]{
                    {1, 1}, {9, 0}
            });
            TrainCourseItem item3 = new TrainCourseItem(1, 10);
            item3.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 60}, {4, 60}, {5, 80}, {9, 80}, {10, 0} },
                    { {1.2f, 0}, {2, 45}, {4.5f, 45}, {5.5f, 60}, {7.7f, 60}, {8.5f, 0}, {10, 0} }
            });
            item3.setMediaList(new float[][]{
                    {0, 1}, {4, 1}, {9, 0}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1, itemStatic, item2, itemStatic, item3));
        } else if (id == 18) {
            TrainCourseItem item1 = new TrainCourseItem(0, 11);
            item1.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 0}, {1.5f, 70}, {2, 0}, {3, 0}, {3.5f, 70}, {4, 0}, {5, 0}, {5.5f, 90}, {6, 0}, {7, 0}, {7.5f, 70}, {8, 0}, {9, 0}, {9.5f, 70}, {10, 0}, {11, 0} }
            });
            item1.setMediaList(new float[][]{
                    {1, 2}, {3, 2}, {5, 2}, {7, 2}, {9, 2}
            });
            TrainCourseItem item2 = new TrainCourseItem(0, 10);
            item2.setBaseLineList(new float[][][]{
                    { {0, 0}, {2, 0}, {2.5f, 40}, {3, 0}, {4, 0}, {4.5f, 60}, {5, 0}, {6, 0}, {6.5f, 80}, {7, 0}, {8, 0}, {8.5f, 80}, {9, 0}, {10, 0} }
            });
            item2.setMediaList(new float[][]{
                    {2, 2}, {4, 2}, {6, 2}, {8, 2}
            });
            TrainCourseItem item3 = new TrainCourseItem(0, 11);
            item3.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 0}, {1.5f, 100}, {2, 0}, {3, 0}, {3.5f, 100}, {4, 0}, {5, 0}, {5.5f, 100}, {6, 0}, {7, 0}, {7.5f, 100}, {8, 0}, {9, 0}, {9.5f, 100}, {10, 0}, {11, 0} }
            });
            item3.setMediaList(new float[][]{
                    {1, 2}, {3, 2}, {5, 2}, {7, 2}, {9, 2}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1, itemStatic, item2, itemStatic, item3));
        } else if (id == 20) {
            TrainCourseItem item1 = new TrainCourseItem(1, 10);
            item1.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 40}, {4, 40}, {5, 100}, {6, 40}, {9, 40}, {10, 0} },
                    { {1.5f, 0}, {2, 20}, {8, 20}, {8.5f, 0}, {10, 0} }
            });
            item1.setMediaList(new float[][]{
                    {1, 1}, {4, 2}, {9, 0}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1));
        } else if (id == 21) {
            TrainCourseItem item1 = new TrainCourseItem(1, 20);
            item1.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 50}, {3, 50}, {4, 100}, {5, 50}, {6, 50}, {7, 100}, {8, 50}, {9, 50}, {10, 100}, {11, 50}, {12, 50}, {13, 100}, {14, 50}, {15, 50}, {16, 100}, {17, 50}, {19, 50}, {20, 0} },
                    { {2, 0}, {3, 30}, {17, 30}, {18, 0}, {20, 0} }
            });
            item1.setMediaList(new float[][]{
                    {0, 1}, {3, 2}, {6, 2}, {9, 2}, {12, 2}, {15, 2}, {19, 0}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1));
        } else if (id == 22) {
            TrainCourseItem item1 = new TrainCourseItem(1, 20);
            item1.setBaseLineList(new float[][][]{
                    { {0, 10}, {3, 10}, {5, 60}, {20, 60} },
                    { {4.7f, 0}, {6.5f, 40}, {20, 40} }
            });
            item1.setMediaList(new float[][]{
                    {3, 1}, {20, 0}
            });
            TrainCourseItem item2 = new TrainCourseItem(1, 10);
            item2.setBaseLineList(new float[][][]{
                    { {0, 0}, {3, 100}, {10, 0} },
                    { {2, 0}, {4, 60}, {8, 0} }
            });
            item2.setMediaList(new float[][]{
                    {0, 3}, {3, 0}
            });
            TrainCourseItem item3 = new TrainCourseItem(0, 17);
            item3.setBaseLineList(new float[][][]{
                    { {0, 0}, {1, 100}, {2, 0}, {3, 100}, {4, 0}, {5, 100}, {6, 0}, {7, 100}, {8, 0}, {9, 100}, {10, 0}, {11, 100}, {12, 0}, {13, 100}, {14, 0}, {15, 100}, {16, 0}, {17, 0} }
            });
            item3.setMediaList(new float[][]{
                    {0, 2}, {2, 2}, {4, 2}, {6, 2}, {8, 2}, {10, 2}, {12, 2}, {14, 2}
            });
            trainCourse.setItemList(Arrays.asList(itemStatic, item1, itemStatic, item2, itemStatic, item3));
        }
    }
}





















