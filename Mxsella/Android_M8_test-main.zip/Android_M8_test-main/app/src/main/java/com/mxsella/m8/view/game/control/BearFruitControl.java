package com.mxsella.m8.view.game.control;

import android.graphics.Bitmap;
import android.graphics.RectF;

import com.mxsella.m8.utils.DensityUtil;
import com.mxsella.m8.view.game.bean.Role;
import com.mxsella.m8.view.game.utils.GameDataUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

public class BearFruitControl {

    public static int ROLE_SIZE = 8;
    public static float PLAYER_SCALE = 0.3f;
    public static float ROLE_SCALE = 0.2f;

    private List<Role> roleList = new CopyOnWriteArrayList<>();
    private int screenW, screenH;
    private Role.RoleSize playerSize;
    private List<Role.RoleSize> roleSizeList;
    private float playerCenterX, playerCenterY;
    private float speed = DensityUtil.dip2px(3);
    private RoleListener roleListener;
    private boolean isProduce = false;
    private boolean isPause = false;
    private int dataPosition = 0;
    private List<Integer> gameDataList = GameDataUtils.getFruitData();

    public interface RoleListener {
        void touch(Role role, int score);
    }

    public void initValue() {
        roleList.clear();
        isPause = false;
        dataPosition = 0;
    }

    public BearFruitControl(int screenW, int screenH, Bitmap playerBitmap, Bitmap[] roleBitmaps) {
        this.screenW = screenW;
        this.screenH = screenH;
        playerSize = new Role.RoleSize(playerBitmap.getWidth() * PLAYER_SCALE, playerBitmap.getHeight() * PLAYER_SCALE);
        playerCenterX = screenW / 2f;
        playerCenterY = screenH - playerSize.getHeight() / 2 - DensityUtil.dip2px(40);
        roleSizeList = new ArrayList<>();
        for (Bitmap b : roleBitmaps) {
            roleSizeList.add(new Role.RoleSize(b.getWidth() * ROLE_SCALE, b.getHeight() * ROLE_SCALE));
        }
    }

    public synchronized void calculateRoleRect() {
        for (int size = roleList.size() - 1; size >= 0; size--) {
            Role role = roleList.get(size);
            if (role.getCenterY() - role.getSize().getHeight() / 2 + speed > screenH) {
                roleList.remove(size);
            } else if (!isTouch(role)) {
                role.setCenterY((int) (role.getCenterY() + speed));
            } else {
                roleList.remove(size);
                if (roleListener != null) {
                    roleListener.touch(role, 20);
                }
            }
        }
        if (!isProduce) {
            isProduce = true;
            new Thread(productTask).start();
        }
    }

    private Runnable productTask = new Runnable() {
        @Override
        public void run() {
            while (isProduce) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (isPause) continue;
                Role role = new Role();
                dataPosition = (dataPosition + 1) % gameDataList.size();
                int rand = gameDataList.get(dataPosition);
                int type = new Random().nextInt(ROLE_SIZE);
                role.setSize(roleSizeList.get(type));
                role.setCenterX(screenW * (rand * 2 + 1) / 6f);
                role.setCenterY(role.getSize().getHeight() / 2);
                role.setType(type);
                roleList.add(role);
            }
        }
    };

    public void setPause(boolean pause) {
        isPause = pause;
    }

    public void resetGame() {
        isProduce = false;
        isPause = false;
        playerCenterX = screenW / 2f;
        roleList.clear();
        dataPosition = 0;
    }

    public List<Role> getRoleList() {
        return roleList;
    }

    public void setPercentLocation(float percent) {
        playerCenterX = screenW * (4 * percent + 1) / 6f;
    }

    public RectF getPlayerRect() {
        return new RectF(playerCenterX - playerSize.getWidth() / 2, playerCenterY - playerSize.getHeight() / 2,
                playerCenterX + playerSize.getWidth() / 2, playerCenterY + playerSize.getHeight() / 2);
    }

    public void setRoleListener(RoleListener roleListener) {
        this.roleListener = roleListener;
    }

    private boolean isTouch(Role role) {
        float playerLeft = playerCenterX - playerSize.getWidth() * 0.25f;
        float playerRight = playerCenterX + playerSize.getWidth() * 0.25f;
        float playerTop = playerCenterY;
        float playerBottom = playerCenterY + playerSize.getHeight() * 0.2f;
        boolean isXTouch = !(role.getCenterX() + role.getSize().getWidth() / 2 < playerLeft || role.getCenterX() - role.getSize().getWidth() / 2 > playerRight);
        boolean isYTouch = !(role.getCenterY() + role.getSize().getHeight() / 2 < playerTop || role.getCenterY() - role.getSize().getHeight() / 2 > playerBottom);
        return isXTouch && isYTouch;
    }
}
