package com.mxsella.m8.ui.main;

import android.view.View;
import android.widget.Button;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseFragment;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.comm.Protocol;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.ui.assess.AssessActivity;
import com.mxsella.m8.ui.game.GameChooseActivity;
import com.mxsella.m8.ui.recovery.RecoveryChooseActivity;
import com.mxsella.m8.ui.train.TrainChooseActivity;
import com.mxsella.m8.utils.ToastUtils;

import butterknife.BindView;
import butterknife.OnClick;

public class HomeFragment extends BaseFragment {
    
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_home;
    }

    @BindView(R.id.btn_game)
    View btnGame;

    @Override
    protected void initView(View view) {
        super.initView(view);

        if (!BleService.getInstance().isConnected())
            btnGame.setVisibility(View.GONE);
    }

    @OnClick({R.id.btn_assess, R.id.btn_recovery, R.id.btn_train, R.id.btn_game})
    public void onClick(View view) {
        if (!Config.ifDebug && !BleService.getInstance().isConnected()) {
            ToastUtils.showToast(getString(R.string.ble_connect_first));
            return;
        }
        switch (view.getId()) {
            case R.id.btn_assess:
                AssessActivity.show(_mActivity);
                break;
            case R.id.btn_recovery:
                RecoveryChooseActivity.show(_mActivity, true);
                break;
            case R.id.btn_train:
                TrainChooseActivity.show(_mActivity);
                // BleService.getInstance().imitateReceive(Protocol.IMITATE_LOW_POWER);
                break;
            case R.id.btn_game:
                GameChooseActivity.show(_mActivity);
                // BleService.getInstance().imitateReceive(Protocol.IMITATE_QUERY_STATE);
                break;
        }
    }

    public void showGame() {
        btnGame.setVisibility(View.VISIBLE);
    }
}
