package com.mxsella.m8.ui.main;

import androidx.annotation.NonNull;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.azhon.appupdate.listener.OnDownloadListener;
import com.azhon.appupdate.manager.DownloadManager;
import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.bean.UpdateInfo;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.comm.Protocol;
import com.mxsella.m8.comm.ReceivePacket;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.RecoveryHelper;
import com.mxsella.m8.ui.adpter.MainPagerAdapter;
import com.mxsella.m8.ui.main.contract.MainContract;
import com.mxsella.m8.ui.main.presenter.MainPresenter;
import com.mxsella.m8.ui.recovery.RecoveryActivity;
import com.mxsella.m8.ui.recovery.RecoveryChooseActivity;
import com.mxsella.m8.utils.AppManager;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.dialog.LowChargeDialog;
import com.mxsella.m8.view.dialog.RequestDialog;
import com.mxsella.m8.view.dialog.VersionUpdateDialog;
import com.tencent.bugly.crashreport.CrashReport;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;

public class MainActivity extends BaseMvpActivity<MainContract.Presenter> implements MainContract.View {

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    protected MainContract.Presenter initPresenter() {
        return new MainPresenter(this);
    }

    @BindView(R.id.tv_main_title)
    TextView tvTitle;
    @BindView(R.id.main_viewpager)
    ViewPager2 viewpager;
    @BindView(R.id.main_radio_group)
    RadioGroup radioGroup;
    @BindView(R.id.tab_home)
    RadioButton tabHome;
    @BindView(R.id.tab_history)
    RadioButton tabHistory;
    @BindView(R.id.tab_instruction)
    RadioButton tabInstruction;
    @BindView(R.id.tab_settings)
    RadioButton tabSettings;

    private MainPagerAdapter mainPagerAdapter;
    private List<RadioButton> tabList;
    private HomeFragment homeFragment;
    private HistoryFragment historyFragment;

    private BleService bleService;
    private RequestDialog oldWorkDialog;
    private LowChargeDialog lowChargeDialog;

    public static void show(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();
        AppManager.getAppManager().finishAllActivity(this);
        Config.ifDebug = Config.curUser != null && Config.curUser.getRole() != null &&
                (Config.curUser.getRole().equals("debugger") || Config.curUser.getRole().equals("reviewer"));
        if (Config.ifDebug) {
            CrashReport.closeCrashReport();
        }

        tabList = Arrays.asList(tabHome, tabHistory, tabInstruction, tabSettings);

        viewpager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                tabList.get(position).setChecked(true);
            }
        });
        viewpager.setUserInputEnabled(false);
        viewpager.setOffscreenPageLimit(3);

        radioGroup.setOnCheckedChangeListener((radioGroup1, i) -> {
            switch (i) {
                case R.id.tab_home:
                    viewpager.setCurrentItem(0, false);
                    tvTitle.setText("Mxsella M8");
                    break;
                case R.id.tab_history:
                    viewpager.setCurrentItem(1, false);
                    historyFragment.initData();
                    tvTitle.setText(getString(R.string.main_tab_history));
                    break;
                case R.id.tab_instruction:
                    viewpager.setCurrentItem(2, false);
                    tvTitle.setText(getString(R.string.main_tab_instruction));
                    break;
                case R.id.tab_settings:
                    viewpager.setCurrentItem(3, false);
                    tvTitle.setText(getString(R.string.main_tab_settings));
                    break;
                default:
                    break;
            }
        });
        mainPagerAdapter = new MainPagerAdapter(this);
        viewpager.setAdapter(mainPagerAdapter);
        homeFragment = new HomeFragment();
        mainPagerAdapter.addFragment(homeFragment);
        historyFragment = new HistoryFragment();
        mainPagerAdapter.addFragment(historyFragment);
        mainPagerAdapter.addFragment(new InstructionFragment());
        mainPagerAdapter.addFragment(new SettingsFragment());
        viewpager.setCurrentItem(0);

        lowChargeDialog = new LowChargeDialog(this);
        lowChargeDialog.setConfirmClickListener(view -> {
            Config.ifJumpLowPower = true;
            lowChargeDialog.dismiss();
            if (oldWorkDialog != null && !oldWorkDialog.isShowing()) {
                oldWorkDialog.show();
            }
        });
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        mPresenter.requestUpdate();
        mPresenter.getUserInfo();

        bleService = BleService.getInstance();
        bleService.addListener(packet -> {
            if (packet.getType().equals(ReceivePacket.TYPE_QUERY_STATE)) {
                List<Integer> dataList = packet.getDataList();
                if(dataList.get(1) == 0) {
                    // ToastUtils.showToast("当前暂无工作");
                    bleService.send(Protocol.ADDR_ELECTRIC_MODE, (short) 11);
                } else {
                    LocalLog.test("微电模式值:" + dataList.get(0) + " - 能量值:" + dataList.get(1) + " - 工作时间:" + dataList.get(2) + " - 微电频率值:" + dataList.get(3));
                    if (dataList.get(0) >= 10)
                        return;
                    runOnUiThread(()->{
                        oldWorkDialog = new RequestDialog(this, getString(R.string.dialog_old_work), "",
                                getString(R.string.dialog_old_work_continue), getString(R.string.dialog_old_work_stop));
                        oldWorkDialog.setConfirmClickListener(v -> {
                            RecoveryActivity.show(this, RecoveryHelper.getAllRecoveryCourse(this).get(dataList.get(0)), dataList.get(1), dataList.get(2), dataList.get(3));
                            oldWorkDialog.dismiss();
                        });
                        oldWorkDialog.setCancelClickListener(v -> {
                            bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) 0);
                            oldWorkDialog.dismiss();
                        });
                        oldWorkDialog.setOnDismissListener(dialogInterface -> {
                            oldWorkDialog.dismiss();
                            oldWorkDialog = null;
                        });
                        oldWorkDialog.setCanceledOnTouchOutside(false);
                        if (!lowChargeDialog.isShowing())
                            oldWorkDialog.show();
                    });
                }
            } else if (packet.getType().equals(ReceivePacket.TYPE_LOW_CHARGE)) {
                if (packet.getDataList().get(0) == 1 && !Config.ifJumpLowPower && !lowChargeDialog.isShowing()) {
                    runOnUiThread(()-> lowChargeDialog.show());
                }
            }
        });
        autoBleConnect();
    }

    public void goRecovery() {
        AppManager.getAppManager().returnToActivity(MainActivity.class);
        radioGroup.check(R.id.tab_home);
        RecoveryChooseActivity.show(this, true);
    }

    @Override
    public void bleConnect() {
        super.bleConnect();

        runOnUiThread(()-> homeFragment.showGame());
    }

    DownloadManager downloadManager;

    @Override
    public void showUpdateDialog(UpdateInfo updateInfo) {
        VersionUpdateDialog updateDialog = new VersionUpdateDialog(this, getString(R.string.update_new_version) + updateInfo.getVersionName());
        updateDialog.setOnUpdateClickListener(v -> {
            OnDownloadListener listener = new OnDownloadListener() {
                @Override
                public void start() {

                }

                @Override
                public void downloading(int i, int i1) {
                    updateDialog.setDownloadProgress((int) Math.ceil(i1 * 100.0f / i));
                }

                @Override
                public void done(@NonNull File file) {

                }

                @Override
                public void cancel() {

                }

                @Override
                public void error(@NonNull Throwable throwable) {

                }
            };
            if (downloadManager == null) {
                downloadManager = new DownloadManager.Builder(this)
                        .apkName("m8.apk")
                        .smallIcon(R.mipmap.ic_launcher_round)
                        .apkUrl(updateInfo.getDownLoadUrl())
                        .onDownloadListener(listener)
                        .build();
                downloadManager.download();
                updateDialog.startDownload();
            }
        });
        updateDialog.setOnDismissListener(dialogInterface -> {
            if (downloadManager != null)
                downloadManager.cancel();
        });
        updateDialog.setCanceledOnTouchOutside(false);
        updateDialog.show();
    }

    private long pressTime = 0;
    @Override
    public void onBackPressedSupport() {
        if (System.currentTimeMillis() - pressTime < 2000) {
            super.onBackPressedSupport();
        } else {
            pressTime = System.currentTimeMillis();
            ToastUtils.showToast(getString(R.string.toast_exit_app));
        }
    }
}