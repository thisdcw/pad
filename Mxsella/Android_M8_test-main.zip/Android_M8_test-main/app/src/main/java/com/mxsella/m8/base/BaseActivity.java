package com.mxsella.m8.base;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import androidx.annotation.Nullable;

import com.clj.fastble.BleManager;
import com.clj.fastble.callback.BleScanCallback;
import com.clj.fastble.data.BleDevice;
import com.mxsella.m8.R;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.comm.IBleConnectStateCallback;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.ui.ble.BleActivity;
import com.mxsella.m8.ui.login.LoginActivity;
import com.mxsella.m8.utils.AppManager;
import com.mxsella.m8.utils.AppUtils;
import com.mxsella.m8.utils.LanguageUtils;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.dialog.MediaDialog;
import com.mxsella.m8.view.dialog.ProgressDialog;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.Unbinder;
import me.yokeyword.fragmentation.SupportActivity;

public abstract class BaseActivity extends SupportActivity {

    protected Unbinder unBinder;

    private Button btnBle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (this instanceof LoginActivity) {
            Config.ifKilled = false;
        } else if (Config.ifKilled) {
            AppUtils.restartApp(this, 0, false);
            return;
        }

        transparentStatusBar(getWindow());
        doBeforeSetContentView();
        setContentView(this.getLayoutId());
        unBinder = ButterKnife.bind(this);
        initView();
        initEventAndData();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        // 多语言
        LanguageUtils.attachBaseContext(newBase);
        super.attachBaseContext(newBase);
    }

    public void doBeforeSetContentView() {
        AppManager.getAppManager().addActivity(this);
        registerBroadcastReceiver();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        if (btnBle != null) {
            btnBle.setOnClickListener(view -> {
                if (!BleManager.getInstance().isSupportBle()) {
                    ToastUtils.showToast(getResources().getString(R.string.ble_unsupported));
                    return;
                }
                BleActivity.show(this);
            });
            if (BleService.getInstance().isConnected()) {
                btnBle.setBackgroundResource(R.drawable.ic_ble);
            }
        }
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(timeBroadcastReceiver);
        if (this.unBinder != null) {
            this.unBinder.unbind();
        }
        AppManager.getAppManager().removeActivity(this);
        super.onDestroy();
    }

    /**
     * 设置布局
     */
    public abstract int getLayoutId();

    /**
     * 初始化视图
     */
    public void initView() {
        btnBle = (Button) findViewById(R.id.btn_ble);
    }

    /**
     * 初始化事件监听器
     */
    protected void initEventAndData() {
    }


    private TimeBroadcastReceiver timeBroadcastReceiver;
    private MediaDialog mediaDialog;
    private ProgressDialog netDialog;

    private void registerBroadcastReceiver() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Config.BLE_CONNECT);
        intentFilter.addAction(Config.BLE_DISCONNECT);
        timeBroadcastReceiver = new TimeBroadcastReceiver();
        registerReceiver(timeBroadcastReceiver, intentFilter);
    }

    class TimeBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()) {
                case Config.BLE_CONNECT:
                    if (btnBle != null) {
                        btnBle.setBackgroundResource(R.drawable.ic_ble);
                    }
                    bleConnect();
                    break;
                case Config.BLE_DISCONNECT:
                    if (btnBle != null) {
                        btnBle.setBackgroundResource(R.drawable.ic_ble_disconnect);
                    }
                    bleDisconnect();
                    break;
            }
        }
    }

    public void bleConnect() {

    }

    public void bleDisconnect() {

    }

    public void autoBleConnect() {
        if (BleService.getInstance().isEnable() && !BleService.getInstance().isConnected() && !Config.getBleAddress().equals("")) {
            try {
                showBleDialog(getString(R.string.ble_connecting));
                BleManager.getInstance().scan(new BleScanCallback() {
                    @Override
                    public void onScanFinished(List<BleDevice> scanResultList) {

                        try {
                            BleService.getInstance().connect(Config.getBleAddress(), new IBleConnectStateCallback() {
                                @Override
                                public void startConnect() {
                                }

                                @Override
                                public void connectSuccess() {
                                    sendBroadcast(new Intent(Config.BLE_CONNECT));
                                    ToastUtils.showToast(getString(R.string.ble_connect_success));
                                    hideBleDialog();
                                }

                                @Override
                                public void connectFailure(String msg) {
                                    ToastUtils.showToast(getString(R.string.ble_connect_fail) + msg);
                                    hideBleDialog();
                                    // showDialog(getString(R.string.ble_connect_fail));
                                }

                                @Override
                                public void disConnect() {
                                    sendBroadcast(new Intent(Config.BLE_DISCONNECT));
                                }
                            });
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onScanStarted(boolean success) {

                    }

                    @Override
                    public void onScanning(BleDevice bleDevice) {

                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void showBleDialog(String msg) {
        runOnUiThread(()-> {
            if (mediaDialog == null) {
                mediaDialog = new MediaDialog(this);
            }
            mediaDialog.show(msg, false);
        });
    }

    private void hideBleDialog() {
        runOnUiThread(()-> {
            if (mediaDialog != null && mediaDialog.isShowing()) {
                mediaDialog.dismiss();
            }
        });
    }

    public void showNetDialog() {
        runOnUiThread(()-> {
            if (netDialog == null) {
                netDialog = new ProgressDialog(this);
            }
            netDialog.show();
        });
    }

    public void hideNetDialog() {
        runOnUiThread(()-> {
            if (netDialog != null && netDialog.isShowing()) {
                netDialog.dismiss();
            }
        });
    }

    // 全屏显示
    public void transparentStatusBar(Window window) {
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        int systemUiVisibility = window.getDecorView().getSystemUiVisibility();
        systemUiVisibility = systemUiVisibility | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        window.getDecorView().setSystemUiVisibility(systemUiVisibility);
        window.setStatusBarColor(Color.TRANSPARENT);

        //设置状态栏文字颜色
        setStatusBarTextColor(window, (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
    }

    public void setStatusBarTextColor(Window window, boolean light) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int systemUiVisibility = window.getDecorView().getSystemUiVisibility();
            if (light) {
                systemUiVisibility = systemUiVisibility & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            } else {
                systemUiVisibility = systemUiVisibility | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            window.getDecorView().setSystemUiVisibility(systemUiVisibility);
        }
    }

    public void setFullScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    // setExcludeFontScale(true)在Fragment中可能无效，重写该方法
    /*@Override
    public Resources getResources() {
        Resources res = super.getResources();
        Configuration config=new Configuration();
        config.setToDefaults();
        res.updateConfiguration(config,res.getDisplayMetrics());
        return res;
    }*/
}
