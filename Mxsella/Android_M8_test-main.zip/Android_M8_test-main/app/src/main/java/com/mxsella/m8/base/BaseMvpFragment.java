package com.mxsella.m8.base;

import android.view.View;

public abstract class BaseMvpFragment<T extends BaseContract.Presenter>
        extends BaseFragment implements BaseContract.View<T> {

    protected T mPresenter;

    @Override
    protected void initView(View view) {
        initPresenter();
    }

    @Override
    public void setPresenter(T presenter) {
        this.mPresenter = presenter;
    }

    @Override
    public void onDestroy() {
        if (mPresenter != null) {
            mPresenter.detach();
        }
        super.onDestroy();
    }

    /**
     * 初始化Presenter
     */
    protected abstract T initPresenter();

    /**
     * 加载事件和数据
     */
    @Override
    protected void initEventAndData() {}
}
