package com.mxsella.m8.utils;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;

import com.mxsella.m8.application.MyApplication;

import java.io.IOException;

public class BackgroundMediaHelper {

    private static MediaPlayer mPlayer;
    private static boolean isPause = false;

    public static void playSound(String filePath, MediaPlayer.OnCompletionListener listener) {
        if (mPlayer == null) {
            mPlayer = new MediaPlayer();
        } else {
            mPlayer.reset();
        }
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setOnCompletionListener(listener);
        mPlayer.setOnErrorListener((mp, what, extra) -> {
            mPlayer.reset();
            return false;
        });
        try {
            mPlayer.setDataSource(filePath);
            mPlayer.prepare();
        } catch (IllegalArgumentException | SecurityException | IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException("读取文件异常：" + e.getMessage());
        }
        mPlayer.start();
        isPause = false;
    }

    public static void playSound(int id, boolean isLooping,
                                 Context context, MediaPlayer.OnCompletionListener listener) {
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.stop();
            mPlayer.reset();
            mPlayer.release();
            mPlayer = null;
        }
        mPlayer = MediaPlayer.create(context, id);
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setOnCompletionListener(listener);
        mPlayer.setLooping(isLooping);
        mPlayer.setOnErrorListener((mp, what, extra) -> {
            mPlayer.reset();
            return false;
        });
        try {
            mPlayer.prepare();
        } catch (IllegalArgumentException | SecurityException | IllegalStateException e) {
        } catch (IOException e) {
            throw new RuntimeException("读取文件异常：" + e.getMessage());
        }
        mPlayer.start();
        isPause = false;
    }

    public static void playSound(int id, MediaPlayer.OnCompletionListener listener) {
        playSound(id, false, MyApplication.getInstance(), listener);
    }

    public static void playSound(int id, boolean isLooping) {
        playSound(id, isLooping, MyApplication.getInstance(), mp -> {});
    }

    public static void playSound(int id, Context context) {
        playSound(id, false, context,  mp -> {});
    }

    public static void pause() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.pause();
            isPause = true;
        }
    }

    public static void resume() {
        if (mPlayer != null && isPause) {
            mPlayer.start();
            isPause = false;
        }
    }

    public static void release() {
        pause();
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }
    }
}
