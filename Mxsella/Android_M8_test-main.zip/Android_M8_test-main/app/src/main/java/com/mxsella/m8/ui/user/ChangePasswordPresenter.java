package com.mxsella.m8.ui.user;

import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;

public class ChangePasswordPresenter extends BasePresenter<ChangePasswordContract.View>
    implements ChangePasswordContract.Presenter {

    private static final String TAG = "ChangePasswordPresenter";

    public ChangePasswordPresenter(ChangePasswordContract.View view) {
        super(view);
    }

    @Override
    public void changePassword(String oldPassword, String newPassword) {
        addDisposable(NormalService.getApi().changePassword(oldPassword, newPassword)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("ChangePassword changePassword", data)) {
                            mView.changePasswordResult(data.getCode() == Constants.SUCCESS, data.getData());
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }
}
