package com.mxsella.m8.ui.assess;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.comm.ICommunicateService;
import com.mxsella.m8.comm.Protocol;
import com.mxsella.m8.comm.ReceivePacket;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.DataCollectHelper;
import com.mxsella.m8.helper.HardwareHelper;
import com.mxsella.m8.helper.ResourceHelper;
import com.mxsella.m8.utils.AssessUtils;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.MediaHelper;
import com.mxsella.m8.utils.TimeDateUtils;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.chart.AssessChartManager;
import com.mxsella.m8.view.dialog.MediaDialog;
import com.mxsella.m8.view.dialog.RequestDialog;
import com.shuyu.gsyvideoplayer.GSYVideoManager;
import com.shuyu.gsyvideoplayer.builder.GSYVideoOptionBuilder;
import com.shuyu.gsyvideoplayer.listener.GSYSampleCallBack;
import com.shuyu.gsyvideoplayer.utils.OrientationUtils;
import com.shuyu.gsyvideoplayer.video.StandardGSYVideoPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.OnLongClick;

public class AssessActivity extends BaseMvpActivity<AssessContract.Presenter> implements AssessContract.View {

    @Override
    public int getLayoutId() {
        return R.layout.activity_assess;
    }

    @Override
    protected AssessContract.Presenter initPresenter() {
        return new AssessPresenter(this);
    }

    @BindView(R.id.llt_assess_title)
    View lltTitle;
    @BindView(R.id.vedio_player)
    StandardGSYVideoPlayer videoPlayer;
    @BindView(R.id.chart_simple)
    LineChart chartSimple;
    @BindView(R.id.chart_all)
    LineChart chartAll;
    @BindView(R.id.tv_current)
    TextView tvCurrent;
    @BindView(R.id.tv_max)
    TextView tvMax;
    @BindView(R.id.tv_remain_time)
    TextView tvRemainTime;
    @BindView(R.id.tv_tip)
    TextView tvTip;
    @BindView(R.id.seekbar_imitate)
    SeekBar seekBarImitate;
    @BindView(R.id.tv_start)
    TextView tvStart;

    private BleService bleService;
    private ICommunicateService.DataReceiveListener bleListener;

    AssessChartManager managerSimple;
    AssessChartManager managerAll;
    private boolean isStart = false; // 是否开始
    private boolean isPlaying = false; // 是否在播放音频
    private boolean firstEnter = true; //第一次进入等下发结束指令后才能开始
    private ExecutorService workThread = Executors.newSingleThreadExecutor();
    private ExecutorService imitateThread = Executors.newSingleThreadExecutor();
    private int DEFAULT_SEC_NUM;
    private int MAX_ASSESS_TIME;
    private int assessTime = 0;
    private DataCollectHelper dataCollectHelper = new DataCollectHelper(DataCollectHelper.SceneType.ASSESS);
    private List<Float> dataSimplePFM = new ArrayList<>();
    private List<Float> dataAllPFM = new ArrayList<>();
    private List<Float> dataResultPFM = new ArrayList<>();
    private List<List<Float>> allBaseLine = new ArrayList<>();
    private AssessRecord record;

    private MediaDialog mediaDialog;
    private OrientationUtils orientationUtils;

    public static void show(Context context) {
        context.startActivity(new Intent(context, AssessActivity.class));
    }

    @Override
    public void initView() {
        super.initView();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        DEFAULT_SEC_NUM = Constants.DEFAULT_SEC_NUM;
        MAX_ASSESS_TIME = Constants.MAX_ASSESS_TIME;

        managerSimple = new AssessChartManager(chartSimple, 100.0f, 10.0f, 6, 10, DEFAULT_SEC_NUM);
        managerAll = new AssessChartManager(chartAll, 100.0f, 150.0f, 6, 15, DEFAULT_SEC_NUM);
        mediaDialog = new MediaDialog(this);
        allBaseLine = AssessUtils.getAllBaseLine();

        if (Config.ifDebug) {
            seekBarImitate.setVisibility(View.VISIBLE);
            seekBarImitate.setMax(HardwareHelper.checkVersion(HardwareHelper.NEW_EMG_VERSION) ? 100 : 100);
        }
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        bleService = BleService.getInstance();
        bleListener = packet -> {
            if(packet.getType().equals(ReceivePacket.TYPE_ACK) && packet.getAddr() == Protocol.ADDR_DATA_SWITCH) {
                dealAirSwitchPacket(packet);
            } else if (packet.getType().equals(ReceivePacket.TYPE_DATA)) {
                if (isStart) {
                    Map<String, Object> resultMap = dataCollectHelper.dealData(DataCollectHelper.DataType.OLD, packet.getDataList());
                    if (resultMap != null) {
                        setPFM((Float) resultMap.get("pfm"));
                        setPFMTip((String) resultMap.get("pfmTip"));
                        dealPressurePacket((Float) resultMap.get("pfm"));
                    }
                }
            } else if (packet.getType().equals(ReceivePacket.TYPE_DATA_NEW)) {
                if (isStart) {
                    Map<String, Object> resultMap = dataCollectHelper.dealData(DataCollectHelper.DataType.NEW, packet.getDataList());
                    if (resultMap != null) {
                        setPFM((Float) resultMap.get("pfm"));
                        setPFMTip((String) resultMap.get("pfmTip"));
                        dealPressurePacket((Float) resultMap.get("pfm"));
                    }
                }
            }
        };
        bleService.addListener(bleListener);

        new Handler().postDelayed(()->{
            bleService.send(Protocol.ADDR_RELAY, (short) 90);
            bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
            firstEnter = false;
        }, 1000);

        initVideoPlay();
    }

    private void initVideoPlay() {
        String url = "android.resource://" + getPackageName() + "/" + R.raw.assess_video;
        // String url = RawResourceDataSource.buildRawResourceUri(R.raw.assess_video).toString();
        ImageView imageCover = new ImageView(this);
        imageCover.setScaleType(ImageView.ScaleType.FIT_XY);
        imageCover.setImageResource(R.drawable.assess_video_cover);

        videoPlayer.getTitleTextView().setVisibility(View.GONE);
        videoPlayer.getBackButton().setVisibility(View.GONE);
        orientationUtils = new OrientationUtils(this, videoPlayer);

        GSYVideoOptionBuilder gsyVideoOption = new GSYVideoOptionBuilder();
        gsyVideoOption
                .setThumbImageView(imageCover)
                .setIsTouchWiget(true)
                .setRotateViewAuto(false)
                .setLockLand(false)
                .setAutoFullWithSize(true)
                .setNeedShowWifiTip(false)
                .setShowFullAnimation(false)
                .setNeedLockFull(true)
                .setUrl(url)
                .setCacheWithPlay(true)
                .setVideoTitle("演示视频")
                .setLooping(true)
                .setVideoAllCallBack(new GSYSampleCallBack() {
                    @Override
                    public void onPrepared(String url, Object... objects) {
                        super.onPrepared(url, objects);
                        //开始播放了才能旋转和全屏
                        orientationUtils.setEnable(true);
                    }

                    @Override
                    public void onQuitFullscreen(String url, Object... objects) {
                        super.onQuitFullscreen(url, objects);
                        if (orientationUtils != null) {
                            orientationUtils.backToProtVideo();
                        }
                    }
                }).build(videoPlayer);
        videoPlayer.getFullscreenButton().setOnClickListener(v -> {
            orientationUtils.resolveByClick();
            videoPlayer.startWindowFullscreen(this, true, true);
        });
        videoPlayer.getBackButton().setOnClickListener(v -> {
            if (orientationUtils != null) {
                orientationUtils.backToProtVideo();
            }
        });
        ///不需要屏幕旋转
        videoPlayer.setNeedOrientationUtils(false);
        // videoPlayer.startPlayLogic();
    }

    private void resetUI() {
        dataCollectHelper.reset();
        dataSimplePFM.clear();
        dataAllPFM.clear();
        dataResultPFM.clear();
        assessTime = 0;
        isStart = false;
        runOnUiThread(() -> {
            if(tvStart == null)
                return;
            managerSimple.clearData();
            managerAll.clearData();
            tvRemainTime.setText(TimeDateUtils.getMinAndSecondBySeconds(MAX_ASSESS_TIME / 2));
            tvCurrent.setText("0.0");
            tvMax.setText("0.0");
            tvTip.setText("");
            tvStart.setText(getString(R.string.assess_start));
        });
    }

    public void setPFMTip(String s) {
        runOnUiThread(()->{
            if(tvTip != null)
                tvTip.setText(s);
        });
    }

    public void setPFM(float data) {
        runOnUiThread(()->{
            if(tvCurrent == null || !isStart)
                return;
            tvCurrent.setText(String.valueOf(data));
            tvMax.setText(tvMax.getText().toString().equals("") ? String.valueOf(data) : String.valueOf(Math.max(Float.parseFloat(tvMax.getText().toString()), data)));
        });
    }

    private void dealAirSwitchPacket(ReceivePacket packet) {
        if(packet.getMode() == Protocol.MODE_OFF) {
            resetUI();
        }
    }

    private void dealPressurePacket(float pfm) {
        if (!isStart || isPlaying) {
            return;
        }
        dataAllPFM.add(pfm);
        dataSimplePFM.add(pfm);
        runOnUiThread(() -> {
            managerSimple.addEntry(pfm, 1);
            managerAll.addEntry(pfm, 1);
        });
    }

    @OnLongClick(R.id.tv_chart_all_title)
    public void onLongClick() {
        tvTip.setVisibility(tvTip.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    @OnClick({R.id.llt_before_start, R.id.tv_start})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llt_before_start:
                findViewById(R.id.llt_assess_before).setVisibility(View.GONE);
                ((TextView) findViewById(R.id.tv_title)).setText(getString(R.string.assess_title));
                GSYVideoManager.releaseAllVideos();
                break;
            case R.id.tv_start:
                if(firstEnter)
                    return;
                if (!isStart) {
                    dataCollectHelper.reset();
                    dataSimplePFM.clear();
                    dataAllPFM.clear();
                    dataResultPFM.clear();
                    assessTime = 0;
                    bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_ON);
                    bleService.setIfHandShake(false);
                    // bleService.startCount(115);
                    isStart = true;
                    isPlaying = true;
                    if(Config.ifDebug) {
                        imitateThread.execute(new ImitateTask());
                    }
                    tvStart.setText(getString(R.string.assess_stop));
                    mediaDialog.show(getString(R.string.assess_stage_0), false);
                    MediaHelper.playSound(ResourceHelper.getRawByName(this, "assess_start"), mp -> {
                        mediaDialog.dismiss();
                        mediaDialog.show(getString(R.string.assess_stage_1), true);
                        MediaHelper.playSound(ResourceHelper.getRawByName(this, "assess_a"), mp1 -> {
                            isPlaying = false;
                            mediaDialog.dismiss();
                            workThread.execute(new AssessTask(1));
                        });
                    });
                } else {
                    isStart = false;
                    bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
                    bleService.setIfHandShake(true);
                    resetUI();
                }
                break;
        }
    }

    @Override
    public void uploadResult(boolean result, AssessRecord assessRecord) {
        hideNetDialog();
        if (result) {
            ToastUtils.showToast(getString(R.string.upload_assess_success));
            AssessRecordActivity.show(AssessActivity.this, record);
        } else {
            RequestDialog requestDialog = new RequestDialog(this, getString(R.string.upload_fail), getString(R.string.upload_assess_fail),
                    getString(R.string.upload_again), getString(R.string.upload_cancel));
            requestDialog.setConfirmClickListener(view -> {
                showNetDialog();
                requestDialog.dismiss();
                mPresenter.uploadAssessRecord(assessRecord);
            });
            requestDialog.setCancelClickListener(view -> {
                requestDialog.dismiss();
                AssessRecordActivity.show(AssessActivity.this, record);
            });
            requestDialog.show();
        }
    }

    private class ImitateTask implements Runnable {
        boolean newEmg = HardwareHelper.checkVersion(HardwareHelper.NEW_EMG_VERSION);
        @Override
        public void run() {
            while (isStart) {
                try {
                    Thread.sleep(newEmg ? 40 : 4);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (isStart && seekBarImitate != null)
                    bleService.imitateReceive(dataCollectHelper.getImitateData(
                        newEmg ? DataCollectHelper.DataType.NEW : DataCollectHelper.DataType.OLD, seekBarImitate.getProgress()));
            }
        }
    }

    private class AssessTask implements Runnable {

        private final int stageTask;

        public AssessTask(int stage) {
            stageTask = stage;
        }

        @Override
        public void run() {
            switch (stageTask){
                case 1:
                    StageA();
                    break;
                case 2:
                    StageB();
                    break;
                case 3:
                    StageC();
                    break;
                case 4:
                    StageD();
                    break;
                case 5:
                    EndAssess();
                    break;
            }
        }

        // A阶段/前静息评估阶段
        private void StageA(){
            try {
                managerSimple.add(allBaseLine.get(0), 0);
                operate(20, getString(R.string.assess_relax));
                logResult("A-1", 1);

                Message message = new Message();
                message.what = 2;
                handler.sendMessage(message);
            } catch (Exception e){
                e.printStackTrace();
            }
        }

        // B阶段/快肌阶段
        private void StageB(){
            try {
                operate(11, getString(R.string.assess_quick));
                operate(9, getString(R.string.assess_quick));
                logResult("B-1", 2);

                operate(3, "");
                operate(12, getString(R.string.assess_quick));
                operate(5, getString(R.string.assess_quick));
                logResult("B-2", 3);

                operate(7, "");
                operate(13, getString(R.string.assess_quick));
                logResult("B-3", 4);

                Message message = new Message();
                message.what = 3;
                handler.sendMessage(message);
            } catch (Exception e){
                e.printStackTrace();
            }
        }

        // C阶段/慢肌阶段
        private void StageC(){
            try {
                operate(7, "");
                operate(13, getString(R.string.assess_shrink));
                logResult("C-1", 5);

                operate(7, "");
                operate(13, getString(R.string.assess_relax));
                logResult("C-2", 6);

                operate(7, "");
                operate(13, getString(R.string.assess_shrink));
                logResult("C-3", 7);

                operate(7, "");
                operate(13, getString(R.string.assess_relax));
                logResult("C-4", 8);

                operate(7, "");
                operate(13, getString(R.string.assess_shrink));
                logResult("C-5", 9);

                operate(7, "");
                operate(13, getString(R.string.assess_relax));
                logResult("C-6", 10);

                operate(7, "");
                operate(13, getString(R.string.assess_shrink));
                logResult("C-7", 11);

                operate(7, "");
                operate(13, getString(R.string.assess_relax));
                logResult("C-8", 12);

                operate(7, "");
                operate(13, getString(R.string.assess_shrink));
                logResult("C-9", 13);

                operate(7, "");
                operate(13, getString(R.string.assess_relax));
                logResult("C-10", 14);

                Message message = new Message();
                message.what = 4;
                handler.sendMessage(message);
            } catch (Exception e){
                e.printStackTrace();
            }
        }

        // F阶段/后静息评估阶段
        private void StageD(){
            try {
                operate(20, getString(R.string.assess_relax));
                logResult("D-1", -1);

                Message message = new Message();
                message.what = 5;
                handler.sendMessage(message);
            } catch (Exception e){
                e.printStackTrace();
            }
        }

        public void clearChart(int baseLineNum){
            dataSimplePFM.clear();
            runOnUiThread(() -> {
                managerSimple.clearData();
                if(baseLineNum >= 0)
                    managerSimple.add(allBaseLine.get(baseLineNum), 0);
            });
        }

        private void operate(int halfSeconds, String str) throws InterruptedException {
            if(!isStart)
                return;
            if (str.contains(getString(R.string.assess_relax))) {
                MediaHelper.playSound(ResourceHelper.getRawByName(AssessActivity.this, "relax"));
            } else if (str.contains(getString(R.string.assess_shrink))) {
                MediaHelper.playSound(ResourceHelper.getRawByName(AssessActivity.this, "shrink"));
            } else if (str.contains(getString(R.string.assess_quick))){
                MediaHelper.playSound(ResourceHelper.getRawByName(AssessActivity.this, "quick"));
            }
            int size = dataSimplePFM.size();
            while (dataSimplePFM.size() - size <= (halfSeconds * DEFAULT_SEC_NUM / 2)) {
                if (tvRemainTime == null || !isStart) return;
                runOnUiThread(() -> {
                    if(isStart && assessTime <= MAX_ASSESS_TIME && tvRemainTime != null){
                        int time = Math.max((MAX_ASSESS_TIME - assessTime - ((dataSimplePFM.size() - size) * 2 / DEFAULT_SEC_NUM)) / 2, (MAX_ASSESS_TIME - assessTime - halfSeconds) / 2);
                        tvRemainTime.setText(TimeDateUtils.getMinAndSecondBySeconds(time));
                    }
                });
                Thread.sleep(10);
            }
            assessTime += halfSeconds;
        }

        private int sizePFM = 0;

        public void logResult(String stage, int baseLineNum){
            List<Float> tempPFMList = new ArrayList<>();
            tempPFMList.addAll(dataSimplePFM);
            sizePFM = tempPFMList.size();
            if(sizePFM < DEFAULT_SEC_NUM * 10 && sizePFM > 0){
                while (sizePFM < DEFAULT_SEC_NUM * 10){
                    tempPFMList.add(0, tempPFMList.get(0));
                    sizePFM++;
                }
            } else if(sizePFM > DEFAULT_SEC_NUM * 10){
                while(sizePFM > DEFAULT_SEC_NUM * 10) {
                    tempPFMList.remove(0);
                    sizePFM--;
                }
            }
            dataResultPFM.addAll(tempPFMList);

            clearChart(baseLineNum);
        }

        private void EndAssess(){
            isPlaying = true;
            MediaHelper.playSound(ResourceHelper.getRawByName(AssessActivity.this, "assess_end"), mp -> {
                isPlaying = false;
                record = new AssessRecord();
                if (bleService != null) {
                    bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
                    bleService.setIfHandShake(true);
                }
                if(!evaluate()) {
                    LocalLog.d("ooo", "Evaluate Fail");
                }
                if (isStart) {
                    isStart = false;
                    runOnUiThread(AssessActivity.this::resetUI);
                }
            });
        }

        private boolean evaluate() {
            List<Float> resultPFM = new ArrayList<>();
            resultPFM.addAll(dataResultPFM);

            LocalLog.test("----resultPFM size: " + resultPFM.size());
            if (AssessUtils.evaluate(AssessActivity.this, resultPFM, record)) {
                // 上传评估记录
                if (record != null) {
                    if(Config.curUser != null){
                        record.setUid(Config.curUser.getUid());
                        showNetDialog();
                        mPresenter.uploadAssessRecord(record);
                    }
                    return true;
                }
                return false;
            }
            return false;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        videoPlayer.onVideoPause();
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        GSYVideoManager.releaseAllVideos();
        if (orientationUtils != null)
            orientationUtils.releaseListener();
        isStart = false;
        if (bleService != null) {
            bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
            bleService.setIfHandShake(true);
            bleService.removeListener(bleListener);
        }
        handler.removeCallbacksAndMessages(null);
        MediaHelper.release();
        mediaDialog.dismiss();
    }

    Handler handler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(Message msg) {
            if(!isStart)
                return;
            switch (msg.what){
                case 2:
                    isPlaying = true;
                    mediaDialog.show(getString(R.string.assess_stage_2), true);
                    MediaHelper.playSound(ResourceHelper.getRawByName(AssessActivity.this, "assess_b"), mp -> {
                        mediaDialog.dismiss();
                        isPlaying = false;
                        workThread.execute(new AssessTask(2));
                    });
                    break;
                case 3:
                    isPlaying = true;
                    mediaDialog.show(getString(R.string.assess_stage_3), true);
                    MediaHelper.playSound(ResourceHelper.getRawByName(AssessActivity.this, "assess_c"), mp -> {
                        mediaDialog.dismiss();
                        isPlaying = false;
                        workThread.execute(new AssessTask(3));
                    });
                    break;
                case 4:
                    isPlaying = true;
                    mediaDialog.show(getString(R.string.assess_stage_4), true);
                    MediaHelper.playSound(ResourceHelper.getRawByName(AssessActivity.this, "assess_d"), mp -> {
                        mediaDialog.dismiss();
                        isPlaying = false;
                        workThread.execute(new AssessTask(4));
                    });
                    break;
                case 5:
                    workThread.execute(new AssessTask(5));
                    break;
            }
        }
    };
}