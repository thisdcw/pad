package com.mxsella.m8.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;

public class DeleteAccountDialog extends Dialog {

    private final Context context;

    private EditText edtVerifyCode;
    private TextView tvGetVerifyCode;
    private Button btnConfirm;

    public DeleteAccountDialog(@NonNull Context context) {
        super(context, R.style.Dialog);
        this.context = context;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_delete_accout, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        edtVerifyCode = view.findViewById(R.id.edt_verify_code);
        tvGetVerifyCode = view.findViewById(R.id.tv_get_verify_code);
        btnConfirm = view.findViewById(R.id.btn_confirm);
    }

    public String getVerifyCode() {
        return edtVerifyCode.getText().toString();
    }

    public void updateGetVerifyCodeState(Boolean enable) {
        tvGetVerifyCode.setEnabled(enable);
    }

    public void updateGetVerifyCode(String text) {
        tvGetVerifyCode.setText(text);
    }

    public void setGetVerifyCodeClickListener(View.OnClickListener listener) {
        tvGetVerifyCode.setOnClickListener(listener);
    }

    public void setConfirmClickListener(View.OnClickListener listener) {
        btnConfirm.setOnClickListener(listener);
    }
}
