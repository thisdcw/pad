package com.mxsella.m8.ui.recovery;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.bean.RecoveryCourse;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.helper.RecoveryHelper;
import com.mxsella.m8.helper.ResourceHelper;
import com.mxsella.m8.ui.adpter.RecoveryChooseAdapter;
import com.mxsella.m8.ui.adpter.RecoveryDescriptionAdapter;
import com.mxsella.m8.ui.train.TrainChooseContract;
import com.mxsella.m8.ui.train.TrainChoosePresenter;
import com.mxsella.m8.view.dialog.RecoveryInfoDialog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class RecoveryChooseActivity extends BaseMvpActivity<TrainChooseContract.Presenter> implements TrainChooseContract.View {

    private static final String SHOW_BEFORE = "show_before";

    @Override
    public int getLayoutId() {
        return R.layout.activity_recovery_choose;
    }

    @Override
    protected TrainChoosePresenter initPresenter() {
        return new TrainChoosePresenter(this);
    }

    @BindView(R.id.llt_recovery_choose_before)
    LinearLayout lltBefore;
    @BindView(R.id.rcv_recovery_description)
    RecyclerView rcvDescription;
    @BindView(R.id.rcv_recovery_choose)
    RecyclerView rcvChoose;

    private List<List<String>> descriptionList = new ArrayList<>();
    private RecoveryDescriptionAdapter descriptionAdapter;
    private List<RecoveryCourse> courseList;
    private RecoveryChooseAdapter chooseAdapter;

    public static void show(Context context, boolean showBefore) {
        Intent intent = new Intent(context, RecoveryChooseActivity.class);
        intent.putExtra(SHOW_BEFORE, showBefore);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();

        boolean showBefore = getIntent().getBooleanExtra(SHOW_BEFORE, true);
        lltBefore.setVisibility(showBefore ? View.VISIBLE : View.GONE);

        for (int i = 0; i < 10; i++) {
            descriptionList.add(Arrays.asList(ResourceHelper.getStringByName(this, "train_name_" + (i + 1)) + ": ",
                    ResourceHelper.getStringByName(this, "recovery_desc_" + (i + 1))));
        }
        descriptionAdapter = new RecoveryDescriptionAdapter(descriptionList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this){
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        rcvDescription.setLayoutManager(layoutManager);
        rcvDescription.setAdapter(descriptionAdapter);

        courseList = RecoveryHelper.getAllRecoveryCourse(this);
        chooseAdapter = new RecoveryChooseAdapter(courseList);
        rcvChoose.setLayoutManager(new LinearLayoutManager(this));
        rcvChoose.setAdapter(chooseAdapter);

        chooseAdapter.setOnItemClickListener((adapter, view, position) -> {
            RecoveryActivity.show(this, courseList.get(position));
        });
        chooseAdapter.setOnItemChildClickListener((adapter, view, position) -> {
            if (view.getId() == R.id.img_course_info) {
                RecoveryInfoDialog infoDialog = new RecoveryInfoDialog(this, ResourceHelper.getStringByName(this, "recovery_info_" + courseList.get(position).getTrainId()));
                infoDialog.show();
            }
        });
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        mPresenter.getAllTrainRecord();
    }

    @Override
    public void showTrainRecord(List<TrainRecord> recordList) {
        for (RecoveryCourse course : courseList) {
            for (TrainRecord record : recordList) {
                if (record.getTrainId() == course.getTrainId() && record.getTrainDuration() >= (course.getTrainDuration() * 2 / 3)) {
                    course.setFinishTimes(course.getFinishTimes() + 1);
                }
            }
        }
        chooseAdapter.notifyDataSetChanged();
    }

    @OnClick({R.id.llt_enter})
    public void onEnterClick() {
        lltBefore.setVisibility(View.GONE);
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }
}