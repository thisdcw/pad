package com.mxsella.m8.base;


import java.lang.ref.WeakReference;

import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

public class BasePresenter<T extends BaseContract.View> implements BaseContract.Presenter {

    protected T mView;

    /**
     * 统一Disposable管理
     */
    private CompositeDisposable mDisposables;

    public BasePresenter(T view) {
        if (view != null) {
            WeakReference<T> reference = new WeakReference<>(view);
            this.mView = reference.get();
            this.mView.setPresenter(this);
        }
    }

    /**
     * 给子类获取View进行操作
     */
    protected final T getView() {
        return mView;
    }

    @Override
    public void detach() {
        unDisposable();
        this.mView = null;
    }

    @Override
    public void addDisposable(Disposable disposable) {
        if (mDisposables == null || mDisposables.isDisposed()) {
            mDisposables = new CompositeDisposable();
        }
        mDisposables.add(disposable);
    }

    @Override
    public void unDisposable() {
        if (mDisposables != null) {
            mDisposables.clear();
        }
    }
}
