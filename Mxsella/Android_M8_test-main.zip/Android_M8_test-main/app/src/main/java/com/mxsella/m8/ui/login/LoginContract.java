package com.mxsella.m8.ui.login;

import com.mxsella.m8.base.BaseContract;

public interface LoginContract {

    interface Presenter extends BaseContract.Presenter {

        void getVerifyCode(String telephone);

        void checkVerifyCode(String telephone, String verifyCode);

        void login(String telephone, String password);

    }

    interface View extends BaseContract.View<Presenter> {

        void checkResult(boolean result, boolean newUser, String msg, String telephone);

        void loginResult(boolean result, String msg);

    }
}
