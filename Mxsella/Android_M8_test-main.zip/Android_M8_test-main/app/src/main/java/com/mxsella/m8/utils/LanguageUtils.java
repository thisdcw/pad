package com.mxsella.m8.utils;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mxsella.m8.application.MyApplication;
import com.mxsella.m8.helper.Config;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class LanguageUtils {

    public static final String AUTO = "auto";
    public static final String DEFAULT_LANGUAGE = "zh_hans";

    public static final List<String> codeList = Arrays.asList(AUTO, "zh_hans", "en");

    public static final Map<String, Locale> localeMap = new HashMap<String, Locale>() {{
        put(codeList.get(0), null);
        put(codeList.get(1), Locale.SIMPLIFIED_CHINESE);
        put(codeList.get(2), Locale.ENGLISH);
    }};

    /**
     * Apply the system language.
     */
    public static void applySystemLanguage() {
        applySystemLanguage(false);
    }

    /**
     * Apply the system language.
     *
     * @param isRelaunchApp True to relaunch app, false to recreate all activities.
     */
    public static void applySystemLanguage(final boolean isRelaunchApp) {
        applyLanguageReal(AUTO, isRelaunchApp);
    }

    public static void applyLanguage(final String language) {
        applyLanguage(language, false);
    }

    public static void applyLanguage(final String language,
                                     final boolean isRelaunchApp) {
        applyLanguageReal(language, isRelaunchApp);
    }

    private static void applyLanguageReal(final String language,
                                          final boolean isRelaunchApp) {
        if (TextUtils.isEmpty(language) || AUTO.equals(language)) {
            Config.removeLanguage();
        } else {
            Config.saveLanguage(language);
        }

        Locale locale = localeMap.get(language);

        Locale destLocal = locale == null ? getLocal(Resources.getSystem().getConfiguration()) : locale;
        updateAppContextLanguage(destLocal, (Consumer<Boolean>) success -> {
            if (success) {
                restart(isRelaunchApp);
            } else {
                // use relaunch app
                AppUtils.restartApp(AppManager.getAppManager().currentActivity(), 0 ,false);
            }
        });
    }

    private static void restart(final boolean isRelaunchApp) {
        if (isRelaunchApp) {
            AppUtils.restartApp(AppManager.getAppManager().currentActivity(), 0 ,false);
        } else {
            AppManager.getAppManager().recreateAllActivity();
        }
    }

    /**
     * Return whether applied the language by {@link LanguageUtils}.
     *
     * @return {@code true}: yes<br>{@code false}: no
     */
    public static boolean isAppliedLanguage() {
        return getAppliedLanguage() != null;
    }

    /**
     * Return whether applied the language by {@link LanguageUtils}.
     *
     * @param locale The locale.
     * @return {@code true}: yes<br>{@code false}: no
     */
    public static boolean isAppliedLanguage(@NonNull Locale locale) {
        Locale appliedLocale = getAppliedLanguage();
        if (appliedLocale == null) {
            return false;
        }
        return isSameLocale(locale, appliedLocale);
    }

    /**
     * Return the applied locale.
     *
     * @return the applied locale
     */
    public static Locale getAppliedLanguage() {
        final String spLocaleStr = Config.getLanguage(true);
        if (TextUtils.isEmpty(spLocaleStr) || AUTO.equals(spLocaleStr)) {
            return null;
        }
        return string2Locale(spLocaleStr);
    }

    /**
     * Return the locale of context.
     *
     * @return the locale of context
     */
    public static Locale getContextLanguage(Context context) {
        return getLocal(context.getResources().getConfiguration());
    }

    /**
     * Return the locale of applicationContext.
     *
     * @return the locale of applicationContext
     */
    public static Locale getAppContextLanguage() {
        return getContextLanguage(MyApplication.getInstance());
    }

    /**
     * Return the locale of system
     *
     * @return the locale of system
     */
    public static Locale getSystemLanguage() {
        return getLocal(Resources.getSystem().getConfiguration());
    }

    /**
     * Update the locale of applicationContext.
     *
     * @param destLocale The dest locale.
     * @param consumer   The consumer.
     */
    public static void updateAppContextLanguage(@NonNull Locale destLocale, @Nullable Consumer<Boolean> consumer) {
        pollCheckAppContextLocal(destLocale, 0, consumer);
    }

    static void pollCheckAppContextLocal(final Locale destLocale, final int index, final Consumer<Boolean> consumer) {
        Resources appResources = MyApplication.getInstance().getResources();
        Configuration appConfig = appResources.getConfiguration();
        Locale appLocal = getLocal(appConfig);

        setLocal(appConfig, destLocale);

        MyApplication.getInstance().getResources().updateConfiguration(appConfig, appResources.getDisplayMetrics());

        if (consumer == null) return;

        if (isSameLocale(appLocal, destLocale)) {
            consumer.accept(true);
        } else {
            if (index < 20) {
                new Thread(() -> {
                    try {
                        Thread.sleep(16);
                        AppManager.getAppManager().currentActivity().runOnUiThread(() -> {
                            pollCheckAppContextLocal(destLocale, index + 1, consumer);
                        });
                    } catch (Exception ignore) {

                    }
                }).start();
                return;
            }
            Log.e("LanguageUtils", "appLocal didn't update.");
            consumer.accept(false);
        }
    }

    /**
     * @param context The baseContext.
     * @return the context with language
     */
    public static Context attachBaseContext(Context context) {
        String language = Config.getLanguage(true);
        if (TextUtils.isEmpty(language) || AUTO.equals(language)) {
            return context;
        }

        Locale settingsLocale = localeMap.get(language);
        if (settingsLocale == null)
            return context;

        Resources resources = context.getResources();
        Configuration config = resources.getConfiguration();

        setLocal(config, settingsLocale);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return context.createConfigurationContext(config);
        } else {
            resources.updateConfiguration(config, resources.getDisplayMetrics());
            return context;
        }
    }

    static void applyLanguage(final Activity activity) {
        String spLocale = Config.getLanguage(true);
        if (TextUtils.isEmpty(spLocale)) {
            return;
        }

        Locale destLocal;
        if (AUTO.equals(spLocale)) {
            destLocal = getLocal(Resources.getSystem().getConfiguration());
        } else {
            destLocal = string2Locale(spLocale);
        }

        if (destLocal == null) return;

        updateConfiguration(activity, destLocal);
        updateConfiguration(MyApplication.getInstance(), destLocal);
    }

    private static void updateConfiguration(Context context, Locale destLocal) {
        Resources resources = context.getResources();
        Configuration config = resources.getConfiguration();
        setLocal(config, destLocal);
        resources.updateConfiguration(config, resources.getDisplayMetrics());
    }

    private static String locale2String(Locale locale) {
        String localLanguage = locale.getLanguage(); // this may be empty
        String localCountry = locale.getCountry(); // this may be empty
        return localLanguage + "$" + localCountry;
    }

    private static Locale string2Locale(String str) {
        Locale locale = string2LocaleReal(str);
        if (locale == null) {
            Config.removeLanguage();
            Log.e("LanguageUtils", "The string of " + str + " is not in the correct format.");
        }
        return locale;
    }

    private static Locale string2LocaleReal(String str) {
        if (!isRightFormatLocalStr(str)) {
            return null;
        }

        try {
            int splitIndex = str.indexOf("$");
            return new Locale(str.substring(0, splitIndex), str.substring(splitIndex + 1));
        } catch (Exception ignore) {
            return null;
        }
    }

    private static boolean isRightFormatLocalStr(String localStr) {
        char[] chars = localStr.toCharArray();
        int count = 0;
        for (char c : chars) {
            if (c == '$') {
                if (count >= 1) {
                    return false;
                }
                ++count;
            }
        }
        return count == 1;
    }

    private static boolean isSameLocale(Locale l0, Locale l1) {
        return l1.getLanguage().equals(l0.getLanguage()) && l1.getCountry().equals(l0.getCountry());
    }

    private static Locale getLocal(Configuration configuration) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return configuration.getLocales().get(0);
        } else {
            return configuration.locale;
        }
    }

    private static void setLocal(Configuration configuration, Locale locale) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            configuration.setLocale(locale);
        } else {
            configuration.locale = locale;
        }
    }

    public interface Consumer<T> {
        void accept(T t);
    }
}
