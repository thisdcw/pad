package com.mxsella.m8.ui.game;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseFragment;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.comm.ICommunicateService;
import com.mxsella.m8.comm.Protocol;
import com.mxsella.m8.comm.ReceivePacket;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.DataCollectHelper;
import com.mxsella.m8.helper.HardwareHelper;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.MediaHelper;
import com.mxsella.m8.utils.TimeDateUtils;
import com.mxsella.m8.view.dialog.GameChooseDialog;
import com.mxsella.m8.view.dialog.GameOverDialog;
import com.mxsella.m8.view.dialog.MediaDialog;
import com.mxsella.m8.view.dialog.RequestDialog;

import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.OnLongClick;

public abstract class BaseGameFragment<T extends GameCallback.ICommon> extends BaseFragment {

    private static String TAG = "BaseGameFragment";

    T common;
    @BindView(R.id.tv_mode)
    TextView tvMode;
    @BindView(R.id.tv_score)
    TextView tvScore;
    @BindView(R.id.tv_tip)
    TextView tvTip;
    @BindView(R.id.seekbar_imitate)
    SeekBar seekBarImitate;
    @BindView(R.id.tv_countdown)
    TextView tvCountdown;
    @BindView(R.id.btn_start)
    Button btnStart;
    int totalScore = 0;
    private boolean isStart = false, isPause = false;
    private BleService bleService;
    private ICommunicateService.DataReceiveListener bleListener;
    private Thread countdownThread, playMusicThread;
    private Thread imitateThread;
    private SoundPool soundPool;
    private int soundId, streamId;

    private static int DEFAULT_TIME = 330 * 1000;
    private int time = DEFAULT_TIME;
    private boolean isPlaying = false; // 是否在播放音频
    private MediaDialog mediaDialog;
    private DataCollectHelper dataCollectHelper = new DataCollectHelper(DataCollectHelper.SceneType.GAME);
    private int maxGrade = 30;
    private GameChooseDialog gameChooseDialog;

    private void setCommon(T common) {
        this.common = common;
    }

    protected abstract T getCommon();

    @Override
    protected void initView(View view) {
        super.initView(view);
        setCommon(getCommon());

        tvScore.setText(String.valueOf(totalScore));
        tvMode.setText(String.format(getString(R.string.game_mode_title), getString(R.string.game_mode_1)));

        gameChooseDialog = new GameChooseDialog(_mActivity);
        gameChooseDialog.setCanceledOnTouchOutside(false);
        gameChooseDialog.setPosition(1);
        gameChooseDialog.setConfirmClickListener(v -> {
            switch (gameChooseDialog.getPosition()) {
                case 0:
                    maxGrade = 20;
                    tvMode.setText(String.format(getString(R.string.game_mode_title), getString(R.string.game_mode_0)));
                    break;
                case 1:
                    maxGrade = 30;
                    tvMode.setText(String.format(getString(R.string.game_mode_title), getString(R.string.game_mode_1)));
                    break;
                case 2:
                    maxGrade = 50;
                    tvMode.setText(String.format(getString(R.string.game_mode_title), getString(R.string.game_mode_2)));
                    break;
            }
            gameChooseDialog.dismiss();
        });
        gameChooseDialog.show();

        if (Config.ifDebug) {
            seekBarImitate.setVisibility(View.VISIBLE);
            seekBarImitate.setMax(HardwareHelper.checkVersion(HardwareHelper.NEW_EMG_VERSION) ? 100 : 512);
        }
    }

    private void initTouchMusic() {
        this.soundPool=new  SoundPool(100, AudioManager.STREAM_MUSIC,0);//构建对象
        this.soundId =soundPool.load(getContext(), R.raw.game_score,1);//加载资源，得到soundId
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        bleService = BleService.getInstance();
        bleListener = packet -> {
            if (packet.getType().equals(ReceivePacket.TYPE_DATA)) {
                if (isStart) {
                    Map<String, Object> resultMap = dataCollectHelper.dealData(DataCollectHelper.DataType.OLD, packet.getDataList());
                    if (resultMap != null) {
                        setPFMTip((String) resultMap.get("pfmTip"));
                        dealPressurePacket((Float) resultMap.get("pfm"));
                    }
                }
            } else if (packet.getType().equals(ReceivePacket.TYPE_DATA_NEW)) {
                if (isStart) {
                    Map<String, Object> resultMap = dataCollectHelper.dealData(DataCollectHelper.DataType.NEW, packet.getDataList());
                    if (resultMap != null) {
                        setPFMTip((String) resultMap.get("pfmTip"));
                        dealPressurePacket((Float) resultMap.get("pfm"));
                    }
                }
            }
        };
        bleService.addListener(bleListener);

        new Handler().postDelayed(()->{
            bleService.send(Protocol.ADDR_RELAY, (short) 90);
            bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
        }, 1000);

        common.setCallback(new GameCallback.IProcess() {
            @Override
            public void init() {
                totalScore = 0;
            }

            @Override
            public void end() {
            }

            @Override
            public void score(int score) {
                if (score != 0) {
                    playTouchEffect();
                }
                totalScore += score;
                _mActivity.runOnUiThread(() -> {
                    if (tvScore != null) {
                        tvScore.setText(String.valueOf(totalScore));
                    }
                });
            }
        });
        initBgMusic();
        initTouchMusic();

        mediaDialog = new MediaDialog(_mActivity);
    }

    private void playTouchEffect() {
        if (soundPool != null) {
            if (streamId != 0) {
                soundPool.stop(streamId);
            }
            BaseGameFragment.this.streamId = soundPool.play(soundId,
                    1,1,1,0,1);
        }
    }

    protected void initBgMusic() {
        if (playMusicThread == null) {
            playMusicThread = new BgMusicThread();
            playMusicThread.start();
        }
    }

    public void endGame(){
        if (common != null)
            common.reset();
        if (common != null && common.isPause()) {
            if (isAdded() && isVisible()) {
                _mActivity.runOnUiThread(() -> btnStart.setBackground(getResources().getDrawable(R.drawable.game_start)));
                showResultDialog();
            }
        } else {
            isStart = false;
            if (countdownThread != null && countdownThread.isAlive()) {
                countdownThread.interrupt();
            }
            if (countdownThread != null && countdownThread.isAlive()) {
                countdownThread.interrupt();
            }
            showResultDialog();
        }
    }

    private void dealPressurePacket(float pfm) {
        if(common != null) {
            if(pfm < maxGrade / 3f) {
                common.setLocation(0);
            } else if(pfm < maxGrade * 2 / 3f) {
                common.setLocation(50);
            } else {
                common.setLocation(100);
            }
        }
    }

    public void setPFMTip(String s) {
        _mActivity.runOnUiThread(()->{
            if(tvTip != null)
                tvTip.setText(s);
        });
    }

    @OnLongClick(R.id.tv_countdown)
    public void onLongClick() {
        tvTip.setVisibility(tvTip.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    @OnClick(R.id.img_game_return)
    public void onReturnClick() {
        if (isStart && !isPause) {
            startOrPause();
        }

        RequestDialog exitDialog = new RequestDialog(_mActivity, getString(R.string.game_exit_tip), "", getString(R.string.confirm), getString(R.string.cancel));
        exitDialog.setConfirmClickListener(view -> {
            isStart = false;
            if (countdownThread != null && countdownThread.isAlive()) {
                countdownThread.interrupt();
            }
            _mActivity.finish();
            exitDialog.dismiss();
        });
        exitDialog.setCancelClickListener(view -> {
            exitDialog.dismiss();
        });
        exitDialog.show();
    }

    private void showResultDialog() {
        _mActivity.runOnUiThread(() -> {
            GameOverDialog overDialog = new GameOverDialog(_mActivity, totalScore);
            if (!_mActivity.isFinishing()) {
                overDialog.show();
            }
            reset();
        });
    }

    private void reset() {
        if(!isVisible()){
            return;
        }
        isStart = false;
        isPause = false;
        totalScore = 0;
        _mActivity.runOnUiThread(() -> {
            if (tvScore != null) {
                tvScore.setText(String.valueOf(totalScore));
            }
            if (tvTip != null) {
                tvTip.setText("");
            }
            if (tvCountdown != null) {
                tvCountdown.setText(TimeDateUtils.getMinAndSecondByMS(DEFAULT_TIME));
                time = DEFAULT_TIME;
            }
            if (btnStart != null) {
                btnStart.setBackground(getResources().getDrawable(R.drawable.game_start));
            }
        });
        if (countdownThread != null) {
            countdownThread.interrupt();
            countdownThread = null;
        }
        if (common != null) {
            common.setPause(true);
        }
    }

    private void startOrPause() {
        if (common.isPause()) {
            btnStart.setBackgroundResource(R.drawable.game_pause);
            common.setPause(false);
            isPause = false;
        } else {
            btnStart.setBackgroundResource(R.drawable.game_start);
            common.setPause(true);
            isPause = true;
        }
    }

    @OnClick({R.id.tv_mode, R.id.btn_start, R.id.btn_end})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_mode:
                if(isStart)
                    return;
                if(!gameChooseDialog.isShowing()) {
                    gameChooseDialog.show();
                }
                break;
            case R.id.btn_start:
                LocalLog.test("onClick start");
                if (!isStart) {
                    btnStart.setBackgroundResource(R.drawable.game_pause);
                    tvCountdown.setText(TimeDateUtils.getMinAndSecondByMS(DEFAULT_TIME));
                    time = DEFAULT_TIME;
                    // 开始游戏
                    //common.start();
                    // 发送游戏模式包
                    bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_ON);
                    bleService.setIfHandShake(false);
                    isStart = true;
                    isPause = false;
                    isPlaying = true;
                    if(playMusicThread != null)
                        playMusicThread.interrupt();
                    mediaDialog.show(getString(R.string.assess_stage_0), false);
                    if(Config.ifDebug) {
                        imitateThread = new Thread(new ImitateTask());
                        imitateThread.start();
                    }
                    MediaHelper.playSound(common.getTestMedia(), mp -> {
                        mediaDialog.dismiss();
                        isPlaying = false;
                        //initBgMusic();
                        playMusicThread = new BgMusicThread();
                        playMusicThread.start();
                        countdownThread = new Thread(timer);
                        countdownThread.start();
                        common.start();
                    });
                } else {
                    startOrPause();
                }
                break;
            case R.id.btn_end:
                if (!isStart) return;
                bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
                isStart = false;
                endGame();
                break;
            default: break;
        }
    }

    private class ImitateTask implements Runnable {
        boolean newEmg = HardwareHelper.checkVersion(HardwareHelper.NEW_EMG_VERSION);
        @Override
        public void run() {
            while (isStart) {
                try {
                    Thread.sleep(newEmg ? 100 : 10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                bleService.imitateReceive(dataCollectHelper.getImitateData(
                        newEmg ? DataCollectHelper.DataType.NEW : DataCollectHelper.DataType.OLD, seekBarImitate.getProgress()));
            }
        }
    }

    private Runnable timer = () -> {
        while (isStart) {
            if (isPause) continue;
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (tvCountdown == null) break;
            time -= 500;
            if (time <= 0) {
                isStart = false;
                endGame();
                bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
                bleService.setIfHandShake(true);
                reset();
                break;
            }
            _mActivity.runOnUiThread(() -> {
                if (tvCountdown != null) {
                    tvCountdown.setText(TimeDateUtils.getMinAndSecondByMS(time));
                }
            });
        }
    };

    static class BgMusicThread extends Thread {

        @Override
        public void run() {
            if(!interrupted()){
                try {
                    Thread.sleep(2000);
                    MediaHelper.playSound(R.raw.game_bgm, true);
                } catch (Exception ignored) {
                }
            }
        }
    }


    @Override
    public void onDestroy() {
        isStart = false;
        if (common != null) {
            common.finish();
        }
        if (bleService != null) {
            bleService.send(Protocol.ADDR_DATA_SWITCH, Protocol.MODE_OFF);
            bleService.send(Protocol.ADDR_ELECTRIC_MODE, (short) 11);
            bleService.setIfHandShake(true);
            bleService.removeListener(bleListener);
        }
        if (playMusicThread != null) {
            playMusicThread.interrupt();
            playMusicThread = null;
        }
        if (soundPool != null) {
            soundPool.stop(streamId);
            soundPool.release();
        }
        MediaHelper.release();
        super.onDestroy();
    }
}
