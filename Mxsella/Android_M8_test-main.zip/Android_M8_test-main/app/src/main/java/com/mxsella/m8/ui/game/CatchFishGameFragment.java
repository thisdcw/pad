package com.mxsella.m8.ui.game;

import com.mxsella.m8.R;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.view.game.CatchFishSurfaceView;

import butterknife.BindView;

public class CatchFishGameFragment extends BaseGameFragment<CatchFishSurfaceView> {

    private static final String TAG = "CatchFishGameFragment";

    @BindView(R.id.surfaceview_catch_fish)
    CatchFishSurfaceView catchFishSurfaceView;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_train_catch_fish;
    }

    @Override
    protected CatchFishSurfaceView getCommon() {
        return catchFishSurfaceView;
    }
}
