package com.mxsella.m8.net;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mxsella.m8.application.MyApplication;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.utils.LocalLog;

import java.io.File;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginService {

    private volatile static LoginService instance;
    private ApiService mService;
    private String uid;
    private String token;

    private LoginService(String u, String t) {
        final Cache cache = new Cache(new File(MyApplication.getInstance().getCacheDir(), "HttpCache"),
                1024*1024*1024);

        this.uid = u;
        this.token = t;
        OkHttpClient client = new OkHttpClient.Builder()
                .cache(cache)
                .addInterceptor(chain -> {
                    Request original = chain.request();
                    Request.Builder builder = original.newBuilder();
                    builder.addHeader("Content-Type","application/json")
                            .addHeader("uid", uid)
                            .addHeader("X-Token", token);
                    Request newRequest = builder.build();
                    return chain.proceed(newRequest);
                })
                .addInterceptor(getLoggerInterceptor())
                .writeTimeout(30*1000, TimeUnit.MILLISECONDS)
                .readTimeout(20*1000, TimeUnit.MILLISECONDS)
                .connectTimeout(6*1000, TimeUnit.MILLISECONDS)
                .retryOnConnectionFailure(true)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create(getGson()))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(client)
                .baseUrl(ApiService.BASE_URL)
                .build();
        mService = retrofit.create(ApiService.class);
    }

    public static ApiService getApi() {
        String u = (Config.curUser == null || Config.curUser.getUid() == null) ? "" : Config.curUser.getUid();
        String t = (Config.curUser == null || Config.curUser.getToken() == null) ? "" : Config.curUser.getToken();

        if (instance == null || !u.equals(instance.uid) || !t.equals(instance.token)) {
            synchronized(ApiService.class) {
                if (instance == null || !u.equals(instance.uid) || !t.equals(instance.token)) {
                    instance = new LoginService(u, t);
                }
            }
        }

        return instance.mService;
    }

    public final static HttpLoggingInterceptor getLoggerInterceptor() {
        HttpLoggingInterceptor.Level level = HttpLoggingInterceptor.Level.BODY;

        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor(message -> {
            if(Config.ifHttpLog)
                LocalLog.d("ApiUrl", "----->"+message);
        });
        loggingInterceptor.setLevel(level);
        return loggingInterceptor;
    }

    // 定制GsonBuilder
    public static Gson getGson(){
        GsonBuilder mGsonBuilder = new GsonBuilder();
        // mGsonBuilder.serializeNulls();  // 输出Null值
        return mGsonBuilder.create();
    }
}
