package com.mxsella.m8.ui.train;

import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.Record;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.net.LoginService;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;

public class TrainChoosePresenter extends BasePresenter<TrainChooseContract.View>
    implements TrainChooseContract.Presenter {

    private static final String TAG = "TrainChoosePresenter";

    public TrainChoosePresenter(TrainChooseContract.View view) {
        super(view);
    }

    @Override
    public void getAllTrainRecord() {
        addDisposable(LoginService.getApi().getAllTrainRecord()
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<Record<TrainRecord>>>() {
                    @Override
                    public void onSuccess(BaseResponse<Record<TrainRecord>> data) {
                        mView.showTrainRecord(data.getData().getRecords());
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }
}
