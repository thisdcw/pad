package com.mxsella.m8.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;

public class PrivacyPolicyDialog extends Dialog {

    private final Context context;
    private TextView tvPrivacyPolicy;
    private Button btnConfirm;
    private Button btnCancel;

    public PrivacyPolicyDialog(@NonNull Context context) {
        super(context, R.style.Dialog);
        this.context = context;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_privacy_policy, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        tvPrivacyPolicy = view.findViewById(R.id.tv_privacy_policy);
        btnConfirm = view.findViewById(R.id.btn_confirm);
        btnCancel = view.findViewById(R.id.btn_cancel);
    }

    public void setPrivacyPolicyClickListener(View.OnClickListener listener) {
        tvPrivacyPolicy.setOnClickListener(listener);
    }

    public void setConfirmClickListener(View.OnClickListener listener) {
        btnConfirm.setOnClickListener(listener);
    }

    public void setCancelClickListener(View.OnClickListener listener) {
        btnCancel.setOnClickListener(listener);
    }
}
