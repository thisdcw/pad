package com.mxsella.m8.helper;

import android.text.TextUtils;

import java.util.List;
import java.util.Locale;

public class HardwareHelper {

    private static final String DEFAULT_VERSION = "0.0.0.0";
    public static final String NEW_EMG_VERSION = "1.0.0.0";

    public static void configByVersion() {
        if (checkVersion(NEW_EMG_VERSION)) {

        }
    }

    public static void saveVersion(List<Integer> dataList) {
        Config.saveHardwareVersion(String.format(Locale.CHINESE, "%d.%d.%d.%d", dataList.get(0), dataList.get(1), dataList.get(2), dataList.get(3)));
        configByVersion();
    }

    public static String getVersion() {
        String version = Config.getHardwareVersion();
        return TextUtils.isEmpty(version) ? DEFAULT_VERSION : version;
    }

    /**
     * 固件版本是否不低于指定版本
     * @param check 指定版本
     * @return 是否不低于
     */
    public static boolean checkVersion(String check) {
        String version = getVersion();
        if (TextUtils.isEmpty(version) || TextUtils.isEmpty(check))
            return false;
        String[] versionArr = version.split("\\.");
        String[] checkArr = check.split("\\.");
        try {
            for (int i = 0; i < checkArr.length; i++) {
                if (Integer.parseInt(versionArr[i]) > Integer.parseInt(checkArr[i]))
                    return true;
                else if (Integer.parseInt(versionArr[i]) < Integer.parseInt(checkArr[i]))
                    return false;
            }
            return true;
        } catch (Exception ignore) {

        }
        return false;
    }
}
