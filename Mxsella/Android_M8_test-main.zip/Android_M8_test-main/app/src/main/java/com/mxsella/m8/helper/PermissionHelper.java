package com.mxsella.m8.helper;

import android.content.pm.PackageManager;

import androidx.core.app.ActivityCompat;

import com.mxsella.m8.application.MyApplication;

public class PermissionHelper {

    public static boolean checkPermission(String permission) {
        return ActivityCompat.checkSelfPermission(MyApplication.getInstance(), permission) == PackageManager.PERMISSION_GRANTED;
    }
}
