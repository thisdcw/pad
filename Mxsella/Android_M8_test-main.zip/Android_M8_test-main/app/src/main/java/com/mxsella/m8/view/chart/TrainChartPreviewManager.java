package com.mxsella.m8.view.chart;

import android.graphics.Color;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.mxsella.m8.R;
import com.mxsella.m8.application.MyApplication;
import com.mxsella.m8.utils.DensityUtil;

import java.util.List;

public class TrainChartPreviewManager {

    private LineChart lineChart;
    private int themeColor = MyApplication.getInstance().getResources().getColor(R.color.chart);
    private int baseLineColor = MyApplication.getInstance().getResources().getColor(R.color.chart_base_line);

    public TrainChartPreviewManager(LineChart lineChart, float yf, float xf) {
        this.lineChart = lineChart;
        setLineChart(yf, xf);
    }

    private void setLineChart(float yf, float xf) {
        lineChart.getDescription().setEnabled(false);
        lineChart.setTouchEnabled(false);
        lineChart.setDragEnabled(false);
        lineChart.setScaleEnabled(false);
        lineChart.setDrawGridBackground(false);
        lineChart.setPinchZoom(false);
        lineChart.setExtraBottomOffset(5);
        LineData lineData = new LineData();
        lineChart.setData(lineData);
        Legend legend = lineChart.getLegend();
        legend.setEnabled(false);
        setXAxis(xf);
        setYAxis(yf);

        // 设置背景透明
        lineChart.setBackgroundColor(Color.parseColor("#00000000"));
    }

    private void setYAxis(float f) {
        YAxis axisLeft = lineChart.getAxisLeft();
        axisLeft.setAxisLineColor(themeColor);
        axisLeft.setTextColor(themeColor); // 设置Y轴文本颜色
        axisLeft.setTextSize(12);
        axisLeft.setAxisLineWidth(1.5f); // 设置Y轴宽度
        axisLeft.setAxisMaximum(f);
        axisLeft.setAxisMinimum(0.0f);
        axisLeft.setDrawGridLines(true);
        axisLeft.setGridColor(themeColor);
        lineChart.getAxisRight().setEnabled(false);
        // Y零轴线 (相当于X轴)
        setYZeroLine(axisLeft);
        axisLeft.setDrawLabels(false);
        axisLeft.setLabelCount(2);
    }

    private void setYZeroLine(YAxis axis) {
        //是否启用绘制零线:设置为true后才有后面的操作
        axis.setDrawZeroLine(true);
        //设置绘制零线宽度
        axis.setZeroLineWidth(1);
        //绘制零线颜色
        axis.setZeroLineColor(themeColor);
    }

    private void setXAxis(float xf) {
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setAxisMinimum(0.0f);
        xAxis.setAxisMaximum(10.0f);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(true);
        xAxis.setGridColor(themeColor);
        // 设置x轴起点和终点label不超出屏幕
        xAxis.setAvoidFirstLastClipping(true);
        xAxis.setTextColor(themeColor);
        xAxis.setTextSize(12);
        xAxis.setAxisMaximum(xf);
        xAxis.setDrawLabels(false);
        xAxis.setEnabled(true);
    }

    public void addEntries(int duration, List<List<Entry>> data){
        LineData lineData = lineChart.getData();
        if (lineData != null) {
            XAxis xAxis = lineChart.getXAxis();
            xAxis.setAxisMaximum(duration);
            xAxis.setLabelCount(duration);
            lineData.addDataSet(createBaseLineSet());
            lineData.addDataSet(createBaseLineSet());
            for(int i = 0; i < data.size(); i++) {
                for (Entry val : data.get(i)) {
                    lineData.addEntry(val, i);
                }
            }
            lineData.notifyDataChanged();
            lineChart.notifyDataSetChanged();
        }
    }

    public void clearData() {
        LineData lineData = lineChart.getLineData();
        lineData.clearValues();
        lineChart.invalidate();
    }

    private ILineDataSet createBaseLineSet() {
        LineDataSet lineDataSet = new LineDataSet(null, null);
        lineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        lineDataSet.setColor(baseLineColor);
        lineDataSet.setLineWidth(1);
        lineDataSet.setFillAlpha(0);
        lineDataSet.setFillColor(Color.BLUE);
        lineDataSet.setValueTextColor(baseLineColor);
        lineDataSet.setValueTextSize(12);
        lineDataSet.setDrawValues(false);
        lineDataSet.setDrawFilled(false);
        lineDataSet.setDrawCircles(false);
        lineDataSet.setMode(LineDataSet.Mode.LINEAR);
        return lineDataSet;
    }
}
