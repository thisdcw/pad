package com.mxsella.m8.bean;

import java.io.Serializable;

public class AssessRecord implements Serializable, Cloneable {

    private int recordId;
    private String uid;
    private String assessTime;
    private double pa;
    private double pa1;
    private double pb;
    private double pb1;
    private double pb2;
    private double pc;
    private double pc1;
    private double pd;
    private double pd1;
    private int ya;
    private int yb;
    private int yc;
    private int yd;
    private double y;
    private int gradeRelax;
    private int gradeEndure;
    private int gradePower;
    private int gradeStable;
    private String dataAllPFM;

    @Override
    public AssessRecord clone() {
        try {
            AssessRecord clone = (AssessRecord) super.clone();
            // TODO: copy mutable state here, so the clone can't change the internals of the original
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getAssessTime() {
        return assessTime;
    }

    public void setAssessTime(String assessTime) {
        this.assessTime = assessTime;
    }

    public double getPa() {
        return pa;
    }

    public void setPa(double pa) {
        this.pa = pa;
    }

    public double getPa1() {
        return pa1;
    }

    public void setPa1(double pa1) {
        this.pa1 = pa1;
    }

    public double getPb() {
        return pb;
    }

    public void setPb(double pb) {
        this.pb = pb;
    }

    public double getPb1() {
        return pb1;
    }

    public void setPb1(double pb1) {
        this.pb1 = pb1;
    }

    public double getPb2() {
        return pb2;
    }

    public void setPb2(double pb2) {
        this.pb2 = pb2;
    }

    public double getPc() {
        return pc;
    }

    public void setPc(double pc) {
        this.pc = pc;
    }

    public double getPc1() {
        return pc1;
    }

    public void setPc1(double pc1) {
        this.pc1 = pc1;
    }

    public double getPd() {
        return pd;
    }

    public void setPd(double pd) {
        this.pd = pd;
    }

    public double getPd1() {
        return pd1;
    }

    public void setPd1(double pd1) {
        this.pd1 = pd1;
    }

    public int getYa() {
        return ya;
    }

    public void setYa(int ya) {
        this.ya = ya;
    }

    public int getYb() {
        return yb;
    }

    public void setYb(int yb) {
        this.yb = yb;
    }

    public int getYc() {
        return yc;
    }

    public void setYc(int yc) {
        this.yc = yc;
    }

    public int getYd() {
        return yd;
    }

    public void setYd(int yd) {
        this.yd = yd;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public int getGradeRelax() {
        return gradeRelax;
    }

    public void setGradeRelax(int gradeRelax) {
        this.gradeRelax = gradeRelax;
    }

    public int getGradeEndure() {
        return gradeEndure;
    }

    public void setGradeEndure(int gradeEndure) {
        this.gradeEndure = gradeEndure;
    }

    public int getGradePower() {
        return gradePower;
    }

    public void setGradePower(int gradePower) {
        this.gradePower = gradePower;
    }

    public int getGradeStable() {
        return gradeStable;
    }

    public void setGradeStable(int gradeStable) {
        this.gradeStable = gradeStable;
    }

    public String getDataAllPFM() {
        return dataAllPFM;
    }

    public void setDataAllPFM(String dataAllPFM) {
        this.dataAllPFM = dataAllPFM;
    }

    @Override
    public String toString() {
        return "AssessRecord{" +
                "recordId=" + recordId +
                ", uid='" + uid + '\'' +
                ", assessTime='" + assessTime + '\'' +
                ", pa=" + pa +
                ", pa1=" + pa1 +
                ", pb=" + pb +
                ", pb1=" + pb1 +
                ", pb2=" + pb2 +
                ", pc=" + pc +
                ", pc1=" + pc1 +
                ", pd=" + pd +
                ", pd1=" + pd1 +
                ", ya=" + ya +
                ", yb=" + yb +
                ", yc=" + yc +
                ", yd=" + yd +
                ", y=" + y +
                ", gradeRelax=" + gradeRelax +
                ", gradeEndure=" + gradeEndure +
                ", gradePower=" + gradePower +
                ", gradeStable=" + gradeStable +
                ", dataAllPFM='" + dataAllPFM + '\'' +
                '}';
    }
}
