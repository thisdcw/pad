package com.mxsella.m8.ui.user;

import com.mxsella.m8.base.BaseContract;

public interface ChangePasswordContract {

    interface Presenter extends BaseContract.Presenter {

        void changePassword(String oldPassword, String newPassword);

    }

    interface View extends BaseContract.View<Presenter> {

        void changePasswordResult(boolean result, String msg);

    }
}
