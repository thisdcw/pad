package com.mxsella.m8.application;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;

import com.mxsella.m8.R;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.utils.AppUtils;
import com.scwang.smart.refresh.footer.ClassicsFooter;
import com.scwang.smart.refresh.header.ClassicsHeader;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;
import com.shuyu.gsyvideoplayer.player.PlayerFactory;
import com.tencent.bugly.crashreport.CrashReport;

import java.util.List;

import me.jessyan.autosize.AutoSizeConfig;
import tv.danmaku.ijk.media.exo2.Exo2PlayerManager;

public class MyApplication extends Application {

    private static MyApplication instance;
    private static final String TAG = "MyApplication";

    @Override
    public void onCreate() {
        super.onCreate();
        // 禁止跟随系统文字大小而改变
        AutoSizeConfig.getInstance().setExcludeFontScale(true).setUseDeviceSize(true);
        instance = this;

        Config.versionName = AppUtils.getVersionName(this);
        Config.versionCode = AppUtils.getVersionCode(this);
        // 读取文件,如果没有则会创建
        Config.mainSP = this.getSharedPreferences("main", 0);

        if (Config.getReadPrivacyPolicy()) {
            init();
        }
    }

    public void init() {
        String processName = getProcessName(this);
        if (processName != null) {
            if (processName.equals(Config.packageName)) {
                // 初始化蓝牙
                BleService.getInstance().init(this);

                CrashReport.initCrashReport(this, "f042c169f3", !Config.ifDebug);
                // ijk内核，默认模式
                PlayerFactory.setPlayManager(Exo2PlayerManager.class);
            }
        }
    }

    private String getProcessName(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningApps = am.getRunningAppProcesses();
        if (runningApps == null) {
            return null;
        }
        for (ActivityManager.RunningAppProcessInfo proInfo : runningApps) {
            if (proInfo.pid == android.os.Process.myPid()) {
                if (proInfo.processName != null) {
                    return proInfo.processName;
                }
            }
        }
        return null;
    }

    //static 代码段可以防止内存泄露(SmartRefreshLayout)
    static {
        //设置全局的Header构建器
        SmartRefreshLayout.setDefaultRefreshHeaderCreator((context, layout) -> {
            layout.setPrimaryColorsId(R.color.transparent, R.color.black);
            ClassicsHeader header = new ClassicsHeader(context);
            header.setTextSizeTitle(15);
            header.setTextSizeTime(10);
            header.setDrawableSize(15);
            return header;
        });
        //设置全局的Footer构建器
        SmartRefreshLayout.setDefaultRefreshFooterCreator((context, layout) -> {
            layout.setPrimaryColorsId(R.color.transparent, R.color.black);
            ClassicsFooter footer = new ClassicsFooter(context);
            footer.setTextSizeTitle(15);
            footer.setDrawableSize(15);
            return footer;
        });
    }

    public static MyApplication getInstance() {
        return instance;
    }
}
