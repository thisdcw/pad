package com.mxsella.m8.view.chart;

import android.graphics.Color;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.mxsella.m8.R;
import com.mxsella.m8.application.MyApplication;
import com.mxsella.m8.utils.DensityUtil;

import java.util.List;

public class TrainChartManager {

    private LineChart lineChart;
    private int yLabelCount = 10;
    private int xLabelCount = 10;
    private float secUnit = 1.0f;
    private int themeColor = MyApplication.getInstance().getResources().getColor(R.color.chart);
    private int dataColor = MyApplication.getInstance().getResources().getColor(R.color.theme_color);
    private int fillColor = MyApplication.getInstance().getResources().getColor(R.color.theme_color);
    private int baseLineColor = MyApplication.getInstance().getResources().getColor(R.color.chart_base_line);

    public TrainChartManager(LineChart lineChart, float yf, float xf, int yLabelCount, int xLabelCount) {
        this.lineChart = lineChart;
        this.yLabelCount = yLabelCount;
        this.xLabelCount = xLabelCount;
        setLineChart(yf, xf);
    }

    public TrainChartManager(LineChart lineChart, float yf, float xf, int yLabelCount, int xLabelCount, float secUnit) {
        this.lineChart = lineChart;
        this.yLabelCount = yLabelCount;
        this.xLabelCount = xLabelCount;
        this.secUnit = secUnit;
        setLineChart(yf, xf);
    }

    private void setLineChart(float yf, float xf) {
        lineChart.getDescription().setEnabled(false);
        lineChart.setTouchEnabled(false);
        lineChart.setDragEnabled(false);
        lineChart.setScaleEnabled(false);
        lineChart.setDrawGridBackground(false);
        lineChart.setPinchZoom(false);
        lineChart.setExtraBottomOffset(5);
        LineData lineData = new LineData();
        lineChart.setData(lineData);
        Legend legend = lineChart.getLegend();
        legend.setEnabled(false);
        setXAxis(xf, xLabelCount);
        setYAxis(yf);

        // 设置背景透明
        lineChart.setBackgroundColor(Color.parseColor("#00000000"));
    }

    private void setYAxis(float f) {
        YAxis axisLeft = lineChart.getAxisLeft();
        axisLeft.setAxisLineColor(themeColor);
        axisLeft.setTextColor(themeColor); // 设置Y轴文本颜色
        axisLeft.setTextSize(8);
        axisLeft.setAxisLineWidth(1.5f); // 设置Y轴宽度
        axisLeft.setAxisMaximum(f);
        axisLeft.setAxisMinimum(0.0f);
        axisLeft.setDrawGridLines(true);
        axisLeft.setGridColor(themeColor);
        lineChart.getAxisRight().setEnabled(false);
        // Y零轴线 (相当于X轴)
        setYZeroLine(axisLeft);
        axisLeft.setLabelCount(yLabelCount, true);
    }

    private void setYZeroLine(YAxis axis) {
        //是否启用绘制零线:设置为true后才有后面的操作
        axis.setDrawZeroLine(true);
        //设置绘制零线宽度
        axis.setZeroLineWidth(1);
        //绘制零线颜色
        axis.setZeroLineColor(themeColor);
    }

    private void setXAxis(float xf, int xLabelCount) {
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setAxisMinimum(0.0f);
        xAxis.setAxisMaximum(10.0f);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(true);
        xAxis.setGridColor(themeColor);
        // 设置x轴起点和终点label不超出屏幕
        xAxis.setAvoidFirstLastClipping(true);
        xAxis.setTextColor(themeColor);
        xAxis.setTextSize(8);
        xAxis.setAxisMaximum(xf);
        xAxis.setLabelCount(xLabelCount);
        xAxis.setEnabled(true);
    }

    public void addData(float f) {
        LineData lineData = lineChart.getData();
        if (lineData != null) {
            int index = lineData.getDataSetCount() - 1;
            if(index <= 0)
                return;
            ILineDataSet iLineDataSet = lineData.getDataSetByIndex(index);
            lineData.addEntry(new Entry((iLineDataSet.getEntryCount() - 1) / secUnit, f), index);
            lineData.notifyDataChanged();

            lineChart.notifyDataSetChanged();
            lineChart.moveViewToX(lineData.getEntryCount());
        }
    }

    public void addEntries(int type, int duration, List<List<Entry>> data){
        LineData lineData = lineChart.getData();
        if (lineData != null) {
            XAxis xAxis = lineChart.getXAxis();
            xAxis.setAxisMaximum(duration);
            xAxis.setLabelCount(duration);
            switch (type) {
                case 0:
                    lineData.addDataSet(createBaseLineSet());
                    break;
                case 1:
                    lineData.addDataSet(createBaseLineSet());
                    lineData.addDataSet(createBaseLineSet());
                    break;
                case 2:
                    lineData.addDataSet(createBaseLineSet());
                    lineData.addDataSet(createBaseLineSet());
                    lineData.addDataSet(createAreaSet(Color.RED));
                    break;
                case 3:
                    lineData.addDataSet(createBaseLineSet());
                    lineData.addDataSet(createBaseLineSet());
                    lineData.addDataSet(createAreaSet(Color.BLUE));
                    break;
            }
            lineData.addDataSet(createDataSet());
            for(int i = 0; i < data.size(); i++) {
                for (Entry val : data.get(i)) {
                    lineData.addEntry(val, i);
                }
            }
            lineData.notifyDataChanged();
            lineChart.notifyDataSetChanged();
        }
    }

    public void clearData() {
        LineData lineData = lineChart.getLineData();
        lineData.clearValues();
        lineChart.invalidate();
    }

    private ILineDataSet createDataSet() {
        LineDataSet lineDataSet = new LineDataSet(null, null);
        lineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        lineDataSet.setColor(dataColor);
        lineDataSet.setLineWidth(2f);
        lineDataSet.setFillAlpha(128);
        lineDataSet.setFillColor(fillColor);
        lineDataSet.setValueTextColor(themeColor);
        lineDataSet.setValueTextSize(8);
        lineDataSet.setDrawValues(false);
        lineDataSet.setDrawFilled(true);
        lineDataSet.setDrawCircles(false);
        lineDataSet.setMode(LineDataSet.Mode.LINEAR);
        return lineDataSet;
    }

    private ILineDataSet createBaseLineSet() {
        LineDataSet lineDataSet = new LineDataSet(null, null);
        lineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        lineDataSet.setColor(baseLineColor);
        lineDataSet.setLineWidth(2f);
        lineDataSet.setFillAlpha(0);
        lineDataSet.setFillColor(Color.BLUE);
        lineDataSet.setValueTextColor(baseLineColor);
        lineDataSet.setValueTextSize(8);
        lineDataSet.setDrawValues(false);
        lineDataSet.setDrawFilled(false);
        lineDataSet.setDrawCircles(false);
        lineDataSet.setMode(LineDataSet.Mode.LINEAR);
        return lineDataSet;
    }

    private ILineDataSet createAreaSet(int fillColor) {
        LineDataSet lineDataSet = new LineDataSet(null, null);
        lineDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        lineDataSet.setColor(fillColor);
        lineDataSet.setLineWidth(2f);
        lineDataSet.setFillAlpha(255);
        lineDataSet.setFillColor(fillColor);
        lineDataSet.setValueTextColor(fillColor);
        lineDataSet.setValueTextSize(8);
        lineDataSet.setDrawValues(false);
        lineDataSet.setDrawFilled(true);
        lineDataSet.setDrawCircles(false);
        lineDataSet.setMode(LineDataSet.Mode.LINEAR);
        return lineDataSet;
    }
}
