package com.mxsella.m8.comm;

public interface ICommunicateService {

    void send(byte[] bytes);
    void send(String str);
    void send(short address, short command);
    void imitateReceive(byte[] bytes);

    boolean isConnected();
    boolean isEnable();
    void startService();
    void stopService();
    void restartService();

    void destroy();

    void addListener(DataReceiveListener mListener);
    void removeListener(DataReceiveListener mListener);

    interface DataReceiveListener {
        void onReceive(ReceivePacket packet);
    }
}
