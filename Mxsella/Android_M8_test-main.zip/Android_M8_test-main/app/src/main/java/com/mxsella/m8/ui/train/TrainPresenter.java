package com.mxsella.m8.ui.train;

import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.net.LoginService;
import com.mxsella.m8.net.PicService;
import com.mxsella.m8.net.RxScheduler;

public class TrainPresenter extends BasePresenter<TrainContract.View>
    implements TrainContract.Presenter {

    private static final String TAG = "TrainPresenter";

    public TrainPresenter(TrainContract.View view) {
        super(view);
    }

    @Override
    public void uploadTrainRecord(TrainRecord trainRecord) {
        addDisposable(LoginService.getApi().uploadTrainRecord(trainRecord)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        mView.uploadResult(ResponseHelper.deal("Train uploadTrainRecord", data) && data.getCode() == Constants.SUCCESS, trainRecord);
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                        mView.uploadResult(false, trainRecord);
                    }
                }));
    }
}
