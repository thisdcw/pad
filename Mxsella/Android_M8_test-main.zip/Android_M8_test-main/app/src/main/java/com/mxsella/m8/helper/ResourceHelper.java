package com.mxsella.m8.helper;

import android.content.Context;

public class ResourceHelper {

    public static int getImageRidByName(Context context, String name) {
        return context.getResources().getIdentifier(name, "drawable", context.getPackageName());
    }

    public static int getRawByName(Context context, String name) {
        return context.getResources().getIdentifier(name + "_" + Config.getLanguage(false), "raw", context.getPackageName());
    }

    /**
     * 通过资源名获取字符串
     */
    public static String getStringByName(Context context, String name) {
        int rid = context.getResources().getIdentifier(name, "string", context.getPackageName());
        try {
            return context.getString(rid);
        } catch (Exception ignore) {

        }
        return "";
    }

    public static int getIdByName(Context context, String name) {
        return context.getResources().getIdentifier(name, "id", context.getPackageName());
    }
}
