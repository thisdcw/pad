package com.mxsella.m8.bean;

import com.github.mikephil.charting.data.Entry;
import com.mxsella.m8.utils.LocalLog;

import java.util.ArrayList;
import java.util.List;

public class TrainCourseItem {

    private int type; // 0：单曲线，1：双曲线，2：帮助性电刺激，3：奖励性电刺激
    private int duration;
    private List<List<Entry>> baseLineList = new ArrayList<>();
    private List<List<Float>> mediaList = new ArrayList<>();

    public TrainCourseItem(int type, int duration) {
        this.type = type;
        this.duration = duration;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public List<List<Entry>> getBaseLineList() {
        return baseLineList;
    }

    public List<List<Float>> getMediaList() {
        return mediaList;
    }

    public void setBaseLineList(float[][][] entries) {
        baseLineList = new ArrayList<>();
        for (float[][] e1 : entries) {
            List<Entry> entryList = new ArrayList<>();
            for (float[] e2 : e1) {
                entryList.add(new Entry(e2[0], e2[1]));
            }
            baseLineList.add(entryList);
        }
    }

    public void setMediaList(float[][] medias) {
        mediaList = new ArrayList<>();
        /*List<Float> timeList = new ArrayList<>();
        List<Float> resList = new ArrayList<>();
        for (float[] m : medias) {
            timeList.add(Math.max(0, m[0] - 1));
            resList.add(m[1]);
        }
        mediaList.add(timeList);
        mediaList.add(resList);*/
        for (float[] m : medias) {
            List<Float> list = new ArrayList<>();
            list.add(Math.max(0, m[0] - 1));
            list.add(m[1]);
            mediaList.add(list);
        }
    }
}
