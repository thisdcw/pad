package com.mxsella.m8.ui.main;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpFragment;
import com.mxsella.m8.bean.UpdateInfo;
import com.mxsella.m8.bean.User;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.HardwareHelper;
import com.mxsella.m8.helper.ResourceHelper;
import com.mxsella.m8.net.ApiService;
import com.mxsella.m8.ui.login.WebViewActivity;
import com.mxsella.m8.ui.main.contract.SettingsContract;
import com.mxsella.m8.ui.main.presenter.SettingsPresenter;
import com.mxsella.m8.ui.settings.FeedbackActivity;
import com.mxsella.m8.ui.settings.LanguageActivity;
import com.mxsella.m8.ui.settings.ParamsAdjustActivity;
import com.mxsella.m8.ui.user.AccountSecurityActivity;
import com.mxsella.m8.ui.user.UserInfoActivity;
import com.mxsella.m8.utils.AppUtils;
import com.mxsella.m8.view.CircleLoadingView;
import com.mxsella.m8.view.dialog.HardwareDialog;
import com.mxsella.m8.view.dialog.RequestDialog;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.OnLongClick;

public class SettingsFragment extends BaseMvpFragment<SettingsContract.Presenter> implements SettingsContract.View {
    
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_settings;
    }

    @Override
    protected SettingsContract.Presenter initPresenter() {
        return new SettingsPresenter(this);
    }

    @BindView(R.id.img_avatar)
    ImageView imgAvatar;
    @BindView(R.id.tv_username)
    TextView tvUsername;
    @BindView(R.id.tv_birthday)
    TextView tvBirthday;
    @BindView(R.id.tv_language)
    TextView tvLanguage;
    @BindView(R.id.tv_hardware)
    TextView tvHardware;
    @BindView(R.id.clv)
    CircleLoadingView clv;

    @Override
    protected void initView(View view) {
        super.initView(view);

        // tvLanguage.setText(getResources().getIdentifier("language_" + Config.getLanguage(), "string", _mActivity.getPackageName()));
        tvLanguage.setText(ResourceHelper.getStringByName(_mActivity, "language_" + Config.getLanguage(true)));
        tvHardware.setText("V" + HardwareHelper.getVersion());
    }

    @Override
    public void onResume() {
        super.onResume();

        User user = Config.curUser;
        if (user != null) {
            if (user.getAvatar() != null && !user.getAvatar().isEmpty())
                Glide.with(_mActivity).load(user.getAvatar()).into(imgAvatar);
            tvUsername.setText(user.getUserName());
            tvBirthday.setText(user.getBirthday());
        }
        tvHardware.setText("V" + HardwareHelper.getVersion());
    }

    @OnLongClick(R.id.llt_hardware)
    public void onLongClick() {
        if (Config.ifDebug) {
            HardwareDialog hardwareDialog = new HardwareDialog(_mActivity);
            hardwareDialog.setConfirmClickListener(v -> {
                Config.saveHardwareVersion(hardwareDialog.getHardware());
                tvHardware.setText("V" + HardwareHelper.getVersion());
                hardwareDialog.dismiss();
            });
            hardwareDialog.show();
        }
    }

    @OnClick({R.id.llt_user_info, R.id.llt_account_security, R.id.llt_language, R.id.llt_param_adjust, R.id.llt_feedback, R.id.llt_privacy_policy, R.id.llt_check_update, R.id.btn_logout})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llt_user_info:
                UserInfoActivity.showEdit(_mActivity);
                break;
            case R.id.llt_account_security:
                AccountSecurityActivity.show(_mActivity);
                break;
            case R.id.llt_language:
                LanguageActivity.show(_mActivity);
                break;
            case R.id.llt_param_adjust:
                ParamsAdjustActivity.show(_mActivity);
                break;
            case R.id.llt_feedback:
                FeedbackActivity.show(_mActivity);
                break;
            case R.id.llt_privacy_policy:
                WebViewActivity.show(_mActivity, getString(R.string.privacy_policy_title), ApiService.PRIVACY_POLICY_URL);
                break;
            case R.id.llt_check_update:
                clv.setVisibility(View.VISIBLE);
                clv.start();
                new Handler(Looper.getMainLooper()).postDelayed(()-> mPresenter.requestUpdate(), 2000);
                break;
            case R.id.btn_logout:
                RequestDialog logoutDialog = new RequestDialog(_mActivity, getString(R.string.settings_log_out_tip), "", getString(R.string.confirm), getString(R.string.cancel));
                logoutDialog.setConfirmClickListener(v -> {
                    logoutDialog.dismiss();
                    Config.logout();
                });
                logoutDialog.setCancelClickListener(v -> {
                    logoutDialog.dismiss();
                });
                logoutDialog.show();
                break;
        }
    }

    @Override
    public void showUpdateDialog(boolean haveUpdate, UpdateInfo updateInfo) {
        clv.setVisibility(View.GONE);
        clv.stop();
        if (haveUpdate)
            ((MainActivity) _mActivity).showUpdateDialog(updateInfo);
    }
}
