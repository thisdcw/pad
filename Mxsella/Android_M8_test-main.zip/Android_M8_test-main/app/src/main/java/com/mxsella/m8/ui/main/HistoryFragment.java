package com.mxsella.m8.ui.main;

import android.graphics.Color;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpFragment;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.ui.adpter.RecordAssessAdapter;
import com.mxsella.m8.ui.adpter.RecordTrainAdapter;
import com.mxsella.m8.ui.assess.AssessRecordActivity;
import com.mxsella.m8.ui.main.contract.HistoryContract;
import com.mxsella.m8.ui.main.presenter.HistoryPresenter;
import com.mxsella.m8.view.dialog.RequestDialog;
import com.scwang.smart.refresh.layout.SmartRefreshLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class HistoryFragment extends BaseMvpFragment<HistoryContract.Presenter> implements HistoryContract.View {
    
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_history;
    }

    @Override
    protected HistoryContract.Presenter initPresenter() {
        return new HistoryPresenter(this);
    }

    @BindView(R.id.tv_record_train)
    TextView tvTrain;
    @BindView(R.id.tv_record_train_under)
    View tvTrainUnder;
    @BindView(R.id.tv_record_assess)
    TextView tvAssess;
    @BindView(R.id.tv_record_assess_under)
    View tvAssessUnder;
    @BindView(R.id.llt_record_train)
    LinearLayout lltTrain;
    @BindView(R.id.llt_record_train_empty)
    LinearLayout lltTrainEmpty;
    @BindView(R.id.llt_record_assess)
    LinearLayout lltAssess;
    @BindView(R.id.llt_record_assess_empty)
    LinearLayout lltAssessEmpty;
    @BindView(R.id.refresh_train)
    SmartRefreshLayout refreshTrain;
    @BindView(R.id.rcv_record_train)
    RecyclerView rcvTrain;
    @BindView(R.id.refresh_assess)
    SmartRefreshLayout refreshAssess;
    @BindView(R.id.rcv_record_assess)
    RecyclerView rcvAssess;

    private List<TextView> tvList;
    private List<View> tvUnderList;
    private List<LinearLayout> lltList;
    private int recordType = -1;

    private RecordTrainAdapter trainAdapter;
    private List<TrainRecord> trainRecordList;
    private RecordAssessAdapter assessAdapter;
    private List<AssessRecord> assessRecordList;

    private int curPageTrain = 1;
    private int curPageAssess = 1;

    @Override
    protected void initView(View view) {
        super.initView(view);

        tvList = Arrays.asList(tvTrain ,tvAssess);
        tvUnderList = Arrays.asList(tvTrainUnder, tvAssessUnder);
        lltList = Arrays.asList(lltTrain, lltAssess);

        setRecordType(0);

        trainRecordList = new ArrayList<>();
        trainAdapter = new RecordTrainAdapter(trainRecordList);
        rcvTrain.setLayoutManager(new LinearLayoutManager(_mActivity));
        rcvTrain.setAdapter(trainAdapter);
        trainAdapter.setOnItemLongClickListener((adapter, v, position) -> {
            RequestDialog deleteDialog = new RequestDialog(_mActivity, getString(R.string.history_delete_title), getString(R.string.history_delete_train), getString(R.string.confirm), getString(R.string.cancel));
            deleteDialog.setConfirmClickListener(view1 -> {
                mPresenter.deleteTrainRecord(trainRecordList.get(position).getRecordId(), position);
                deleteDialog.dismiss();
            });
            deleteDialog.setCancelClickListener(view1 -> {
                deleteDialog.dismiss();
            });
            deleteDialog.show();
            return true;
        });

        assessRecordList = new ArrayList<>();
        assessAdapter = new RecordAssessAdapter(assessRecordList);
        rcvAssess.setLayoutManager(new LinearLayoutManager(_mActivity));
        rcvAssess.setAdapter(assessAdapter);
        assessAdapter.setOnItemClickListener((adapter, v, position) -> {
            AssessRecordActivity.show(_mActivity, assessRecordList.get(position));
        });
        assessAdapter.setOnItemLongClickListener((adapter, v, position) -> {
            RequestDialog deleteDialog = new RequestDialog(_mActivity, getString(R.string.history_delete_title), getString(R.string.history_delete_assess), getString(R.string.confirm), getString(R.string.cancel));
            deleteDialog.setConfirmClickListener(view1 -> {
                mPresenter.deleteAssessRecord(assessRecordList.get(position).getRecordId(), position);
                deleteDialog.dismiss();
            });
            deleteDialog.setCancelClickListener(view1 -> {
                deleteDialog.dismiss();
            });
            deleteDialog.show();
            return true;
        });
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        refreshTrain.setOnRefreshListener(r -> {
            refreshTrain();
            r.finishRefresh(2000/*,false*/);
        });
        refreshTrain.setOnLoadMoreListener(r -> {
            mPresenter.getTrainRecord(curPageTrain++);
            r.finishLoadMore(2000);
        });

        refreshAssess.setOnRefreshListener(r -> {
            refreshAssess();
            r.finishRefresh(2000/*,false*/);
        });
        refreshAssess.setOnLoadMoreListener(r -> {
            mPresenter.getAssessRecord(curPageAssess++);
            r.finishLoadMore(2000);
        });
    }

    public void initData() {
        refreshTrain();
        refreshAssess();
    }

    @OnClick({R.id.llt_record_train_title, R.id.llt_record_assess_title})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.llt_record_train_title:
                setRecordType(0);
                break;
            case R.id.llt_record_assess_title:
                setRecordType(1);
                break;
        }
    }

    private void setRecordType(int type) {
        if(type != recordType) {
            for(TextView t : tvList) {
                t.setTextColor(Color.parseColor("#AAAAAA"));
            }
            for(View t : tvUnderList) {
                t.setBackgroundColor(_mActivity.getResources().getColor(R.color.transparent));
            }
            for(LinearLayout l : lltList) {
                l.setVisibility(View.GONE);
            }
            tvList.get(type).setTextColor(_mActivity.getResources().getColor(R.color.theme_color));
            tvUnderList.get(type).setBackgroundColor(_mActivity.getResources().getColor(R.color.theme_color));
            lltList.get(type).setVisibility(View.VISIBLE);
        }
    }

    public void refreshTrain() {
        curPageTrain = 1;
        trainRecordList.clear();
        trainAdapter.notifyDataSetChanged();
        mPresenter.getTrainRecord(curPageTrain++);
    }

    @Override
    public void showTrainRecord(List<TrainRecord> recordList) {
        if(trainRecordList == null)
            return;

        trainRecordList.addAll(recordList);
        trainAdapter.notifyDataSetChanged();
        lltTrainEmpty.setVisibility(trainRecordList.isEmpty() ? View.VISIBLE : View.GONE);
        rcvTrain.setVisibility(trainRecordList.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public void showDeleteResultTrain(Boolean result, int position) {
        trainRecordList.remove(position);
        trainAdapter.notifyItemRemoved(position);
        lltTrainEmpty.setVisibility(trainRecordList.isEmpty() ? View.VISIBLE : View.GONE);
        rcvTrain.setVisibility(trainRecordList.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public void showNoMoreDataTrain() {
        refreshTrain.setNoMoreData(true);
    }

    @Override
    public void loadMoreFinishedTrain() {
        refreshTrain.finishLoadMore();
    }

    public void refreshAssess() {
        curPageAssess = 1;
        assessRecordList.clear();
        assessAdapter.notifyDataSetChanged();
        mPresenter.getAssessRecord(curPageAssess++);
    }

    @Override
    public void showAssessRecord(List<AssessRecord> recordList) {
        if(assessRecordList == null)
            return;

        assessRecordList.addAll(recordList);
        assessAdapter.notifyDataSetChanged();
        lltAssessEmpty.setVisibility(assessRecordList.isEmpty() ? View.VISIBLE : View.GONE);
        rcvAssess.setVisibility(assessRecordList.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public void showDeleteResultAssess(Boolean result, int position) {
        assessRecordList.remove(position);
        assessAdapter.notifyItemRemoved(position);
        lltAssessEmpty.setVisibility(assessRecordList.isEmpty() ? View.VISIBLE : View.GONE);
        rcvAssess.setVisibility(assessRecordList.isEmpty() ? View.GONE : View.VISIBLE);
    }

    @Override
    public void showNoMoreDataAssess() {
        refreshAssess.setNoMoreData(true);
    }

    @Override
    public void loadMoreFinishedAssess() {
        refreshAssess.finishLoadMore();
    }
}
