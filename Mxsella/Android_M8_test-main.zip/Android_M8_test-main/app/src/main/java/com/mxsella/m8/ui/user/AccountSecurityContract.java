package com.mxsella.m8.ui.user;

import com.mxsella.m8.base.BaseContract;
import com.mxsella.m8.bean.User;

import java.io.File;

public interface AccountSecurityContract {

    interface Presenter extends BaseContract.Presenter {

        void getVerifyCode(String telephone);

        void deleteAccount(String verifyCode);

    }

    interface View extends BaseContract.View<Presenter> {

    }
}
