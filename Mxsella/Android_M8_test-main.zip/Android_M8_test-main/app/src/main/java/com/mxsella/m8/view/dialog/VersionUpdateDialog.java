package com.mxsella.m8.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;
import com.mxsella.m8.utils.DensityUtil;

//dialog_update会与appupdate库冲突
public class VersionUpdateDialog extends Dialog {

    private Context mContext;
    private String title;

    private TextView tvTitle;
    private TextView tvContent;
    private ProgressBar pgbDownload;
    private Button btnUpdateLater;
    private Button btnUpdateNow;

    public VersionUpdateDialog(@NonNull Context context, String title) {
        super(context);
        this.mContext = context;
        this.title = title;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_version_update, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));
        getWindow().setBackgroundDrawableResource(R.color.transparent);

        tvTitle = view.findViewById(R.id.tv_title);
        tvContent = view.findViewById(R.id.tv_content);
        pgbDownload = view.findViewById(R.id.pgb_download);
        btnUpdateLater = view.findViewById(R.id.btn_update_later);
        btnUpdateNow = view.findViewById(R.id.btn_update_now);

        tvTitle.setText(title);
        btnUpdateLater.setOnClickListener(v -> {
            dismiss();
        });
    }

    public void setOnUpdateClickListener(View.OnClickListener listener) {
        btnUpdateNow.setOnClickListener(listener);
    }

    public void startDownload() {
        tvContent.setVisibility(View.GONE);
        pgbDownload.setVisibility(View.VISIBLE);
    }

    public void setDownloadProgress(int progress){
        pgbDownload.setProgress(progress);
    }
}
