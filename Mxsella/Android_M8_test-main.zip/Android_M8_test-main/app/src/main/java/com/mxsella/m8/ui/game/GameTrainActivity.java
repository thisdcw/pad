package com.mxsella.m8.ui.game;

import android.content.Context;
import android.content.Intent;
import android.view.WindowManager;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseActivity;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.ui.train.TrainActivity;

import me.jessyan.autosize.internal.CustomAdapt;

public class GameTrainActivity extends BaseActivity implements CustomAdapt {

    private static final String GAME = "game";

    @Override
    public int getLayoutId() {
        return R.layout.activity_game_train;
    }

    public static void show(Context context, int game) {
        Intent intent = new Intent(context, GameTrainActivity.class);
        intent.putExtra(GAME, game);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_FULLSCREEN);

        int game = getIntent().getIntExtra(GAME, 0);
        if(game == 0){
            loadRootFragment(R.id.container, new CatchFishGameFragment());
        } else if (game == 1){
            loadRootFragment(R.id.container, new BearFruitGameFragment());
        }
    }

    @Override
    public boolean isBaseOnWidth() {
        return false;
    }

    @Override
    public float getSizeInDp() {
        return 375;
    }
}