package com.mxsella.m8.ui.main.contract;

import com.mxsella.m8.base.BaseContract;
import com.mxsella.m8.bean.UpdateInfo;
import com.mxsella.m8.bean.User;

public interface MainContract {

    interface Presenter extends BaseContract.Presenter {

        void requestUpdate();

        void getUserInfo();

    }

    interface View extends BaseContract.View<Presenter> {

        void showUpdateDialog(UpdateInfo updateInfo);

    }
}
