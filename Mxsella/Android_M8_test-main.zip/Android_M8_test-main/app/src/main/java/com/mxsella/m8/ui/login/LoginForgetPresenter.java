package com.mxsella.m8.ui.login;

import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;
import com.mxsella.m8.utils.ToastUtils;

public class LoginForgetPresenter extends BasePresenter<LoginForgetContract.View>
    implements LoginForgetContract.Presenter {

    private static final String TAG = "LoginForgetPresenter";

    public LoginForgetPresenter(LoginForgetContract.View view) {
        super(view);
    }

    @Override
    public void getVerifyCode(String telephone) {
        addDisposable(NormalService.getApi().getVerifyCode(telephone)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("LoginForget getVerifyCode", data) && data.getCode() == Constants.SUCCESS) {
                            ToastUtils.showToast(data.getData());
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }

    @Override
    public void verifyCodeChangePassword(String telephone, String verifyCode, String password) {
        addDisposable(NormalService.getApi().verifyCodeChangePassword(telephone, verifyCode, password)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("LoginForget verifyCodeChangePassword", data)) {
                            mView.verifyCodeChangePasswordResult(data.getCode() == Constants.SUCCESS, data.getData());
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }
}
