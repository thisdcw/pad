package com.mxsella.m8.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatRadioButton;

import com.mxsella.m8.R;
import com.mxsella.m8.utils.DensityUtil;

public class MainRadioButton extends AppCompatRadioButton {

    private float imgWidth, imgHeight;

    public MainRadioButton(Context context) {
        super(context);
    }

    public MainRadioButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray t = context.obtainStyledAttributes(attrs, R.styleable.MainRadioButton);
        imgWidth = t.getDimension(R.styleable.MainRadioButton_imgWidth, 32);
        imgHeight = t.getDimension(R.styleable.MainRadioButton_imgHeight, 32);
        t.recycle();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        Drawable drawableLeft = this.getCompoundDrawables()[0];//获得文字左侧图片
        Drawable drawableTop = this.getCompoundDrawables()[1];//获得文字顶部图片
        Drawable drawableRight = this.getCompoundDrawables()[2];//获得文字右侧图片
        Drawable drawableBottom = this.getCompoundDrawables()[3];//获得文字底部图片
        if (drawableLeft != null) {
            drawableLeft.setBounds(0, 0, (int) imgWidth, (int) imgHeight);
            this.setCompoundDrawables(drawableLeft, null, null, null);
        }
        if (drawableRight != null) {
            drawableRight.setBounds(0, 0, (int) imgWidth, (int) imgHeight);
            this.setCompoundDrawables(null, null, drawableRight, null);
        }
        if (drawableTop != null) {
            drawableTop.setBounds(0, 0, (int) imgWidth, (int) imgHeight);
            this.setCompoundDrawables(null, drawableTop, null, null);
        }
        if (drawableBottom != null) {
            drawableBottom.setBounds(0, 0, (int) imgWidth, (int) imgHeight);
            this.setCompoundDrawables(null, null, null, drawableBottom);
        }
    }
}
