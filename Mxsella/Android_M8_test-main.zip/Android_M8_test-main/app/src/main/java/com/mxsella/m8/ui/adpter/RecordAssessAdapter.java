package com.mxsella.m8.ui.adpter;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.mxsella.m8.R;
import com.mxsella.m8.bean.AssessRecord;

import java.util.List;

public class RecordAssessAdapter extends BaseQuickAdapter<AssessRecord, BaseViewHolder> {

    public RecordAssessAdapter(@Nullable List<AssessRecord> data) {
        super(R.layout.item_record_assess, data);
    }

    @Override
    protected void convert(BaseViewHolder holder, AssessRecord item) {
        holder.setText(R.id.tv_assess_time, String.format(mContext.getString(R.string.assess_report_time), item.getAssessTime()));
        holder.setText(R.id.tv_assess_grade, String.valueOf(item.getY()));
    }
}
