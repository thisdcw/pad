package com.mxsella.m8.ui.user;

import com.mxsella.m8.base.BaseContract;
import com.mxsella.m8.bean.User;

import java.io.File;

public interface UserInfoContract {

    interface Presenter extends BaseContract.Presenter {

        void register(String telephone, String userName, String birthday, String password, File avatar);

        void changeUserInfo(User user, File avatar);

    }

    interface View extends BaseContract.View<Presenter> {

        void registerResult(boolean result);

        void changeResult(boolean result);

    }
}
