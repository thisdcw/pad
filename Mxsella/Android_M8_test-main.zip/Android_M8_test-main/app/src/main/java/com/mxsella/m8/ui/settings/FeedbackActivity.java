package com.mxsella.m8.ui.settings;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseActivity;

import butterknife.OnClick;

public class FeedbackActivity extends BaseActivity {

    @Override
    public int getLayoutId() {
        return R.layout.activity_feedback;
    }

    public static void show(Context context) {
        Intent intent = new Intent(context, FeedbackActivity.class);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();
    }

    @OnClick({R.id.llt_telephone})
    public void onClick(){
        Intent intent = new Intent(Intent.ACTION_DIAL);
        Uri data = Uri.parse("tel:" + "4009667655");
        intent.setData(data);
        startActivity(intent);
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }
}