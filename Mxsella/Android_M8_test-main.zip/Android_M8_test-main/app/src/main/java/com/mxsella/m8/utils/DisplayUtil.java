package com.mxsella.m8.utils;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.view.Display;

public class DisplayUtil {
    public DisplayUtil() {
    }

    public static int px2dip(Context context, float pxValue) {
        return (int) ((pxValue / context.getResources().getDisplayMetrics().density) + 0.5f);
    }

    public static int dip2px(Context context, float dipValue) {
        return (int) ((dipValue * context.getResources().getDisplayMetrics().density) + 0.5f);
    }

    public static int px2sp(Context context, float pxValue) {
        return (int) ((pxValue / context.getResources().getDisplayMetrics().scaledDensity) + 0.5f);
    }

    public static int sp2px(Context context, float spValue) {
        return (int) ((spValue * context.getResources().getDisplayMetrics().scaledDensity) + 0.5f);
    }

    public static void printResolution(Context context) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        int height = dm.heightPixels;
        int width = dm.widthPixels;
        int sw = context.getResources().getConfiguration().smallestScreenWidthDp;
        LocalLog.test("屏幕分辨率:" + width + "*" + height + ", dpi:" + dm.densityDpi + ", sw:" + sw);
    }

    //获得手机的宽度和高度像素单位为px
    // 通过WindowManager获取
    public static void getScreenDensity_ByWindowManager(Context context){
        DisplayMetrics mDisplayMetrics = new DisplayMetrics();//屏幕分辨率容器
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(mDisplayMetrics);
        int width = mDisplayMetrics.widthPixels;
        int height = mDisplayMetrics.heightPixels;
        float density = mDisplayMetrics.density;
        int densityDpi = mDisplayMetrics.densityDpi;
        LocalLog.test("Screen Ratio: ["+width+"x"+height+"],density="+density+",densityDpi="+densityDpi);
    }
    // 通过Resources获取
    public static void getScreenDensity_ByResources(Context context){
        DisplayMetrics mDisplayMetrics = context.getResources().getDisplayMetrics();
        int width = mDisplayMetrics.widthPixels;
        int height = mDisplayMetrics.heightPixels;
        float density = mDisplayMetrics.density;
        int densityDpi = mDisplayMetrics.densityDpi;
        LocalLog.test("Screen Ratio: ["+width+"x"+height+"],density="+density+",densityDpi="+densityDpi);

    }
    // 获取屏幕的默认分辨率
    public static void getDefaultScreenDensity(Context context){
        Display mDisplay = ((Activity) context).getWindowManager().getDefaultDisplay();
        int width = mDisplay.getWidth();
        int height = mDisplay.getHeight();
        LocalLog.test("Screen Default Ratio: ["+width+"x"+height+"]");
    }
}

