package com.mxsella.m8.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;

public class RecoveryInfoDialog extends Dialog {

    private final Context context;

    private String info;

    private TextView tvInfo, tvKnow;

    public RecoveryInfoDialog(@NonNull Context context, String info) {
        super(context, R.style.Dialog);
        this.context = context;
        this.info = info;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_recovery_info, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        tvInfo = view.findViewById(R.id.tv_info);
        tvKnow = view.findViewById(R.id.tv_know);

        tvInfo.setText(info);
        tvKnow.setOnClickListener(v -> dismiss());
    }
}
