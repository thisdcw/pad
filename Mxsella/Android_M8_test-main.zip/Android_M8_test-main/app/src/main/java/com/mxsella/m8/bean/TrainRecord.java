package com.mxsella.m8.bean;

import java.io.Serializable;

public class TrainRecord implements Serializable {

    private int recordId;
    private String uid;
    private int trainId;
    private String trainName;
    private String trainTime;
    private int trainDuration;

    public TrainRecord() {
    }

    public TrainRecord(int recordId, String uid, int trainId, String trainName, String trainTime, int trainDuration) {
        this.recordId = recordId;
        this.uid = uid;
        this.trainId = trainId;
        this.trainName = trainName;
        this.trainTime = trainTime;
        this.trainDuration = trainDuration;
    }

    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public int getTrainId() {
        return trainId;
    }

    public void setTrainId(int trainId) {
        this.trainId = trainId;
    }

    public String getTrainName() {
        return trainName;
    }

    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }

    public String getTrainTime() {
        return trainTime;
    }

    public void setTrainTime(String trainTime) {
        this.trainTime = trainTime;
    }

    public int getTrainDuration() {
        return trainDuration;
    }

    public void setTrainDuration(int trainDuration) {
        this.trainDuration = trainDuration;
    }

    @Override
    public String toString() {
        return "TrainRecord{" +
                "recordId=" + recordId +
                ", uid='" + uid + '\'' +
                ", trainId=" + trainId +
                ", trainName='" + trainName + '\'' +
                ", trainTime='" + trainTime + '\'' +
                ", trainDuration=" + trainDuration +
                '}';
    }
}
