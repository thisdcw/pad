package com.mxsella.m8.ui.user;

import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;
import com.mxsella.m8.utils.ToastUtils;

public class ChangeTelephonePresenter extends BasePresenter<ChangeTelephoneContract.View>
    implements ChangeTelephoneContract.Presenter {

    private static final String TAG = "ChangeTelephonePresenter";

    public ChangeTelephonePresenter(ChangeTelephoneContract.View view) {
        super(view);
    }

    @Override
    public void getVerifyCode(String telephone) {
        addDisposable(NormalService.getApi().getVerifyCode(telephone)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("ChangeTelephone getVerifyCode", data) && data.getCode() == Constants.SUCCESS) {
                            ToastUtils.showToast(data.getData());
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }

    @Override
    public void verifyCodeChangeTelephone(String telephone, String verifyCode) {
        addDisposable(NormalService.getApi().verifyCodeChangeTelephone(telephone, verifyCode)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("ChangeTelephone verifyCodeChangeTelephone", data)) {
                            mView.verifyCodeChangeTelephoneResult(data.getCode() == Constants.SUCCESS, data.getData());
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }
}
