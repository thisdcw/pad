package com.mxsella.m8.helper;

import com.mxsella.m8.comm.Protocol;
import com.mxsella.m8.utils.AssessUtils;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.StringUtils;

import java.nio.ByteBuffer;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataCollectHelper {

    public enum DataType {
        OLD, NEW
    }

    public enum SceneType {
        ASSESS, GAME
    }

    private float pfmTimes = 1.0f;
    private boolean ifMinusZero = false;
    private NewDataHelper newDataHelper = new NewDataHelper();
    private OldDataHelper oldDataHelper = new OldDataHelper();

    private DecimalFormat decimalOne = new DecimalFormat(".0");

    public DataCollectHelper(SceneType sceneType) {
        switch (sceneType) {
            case ASSESS:
                pfmTimes = Config.getParameterAssess();
                break;
            case GAME:
                pfmTimes = Config.getParameterAssess();
                break;
        }
    }

    public byte[] getImitateData(DataType dataType, int data) {
        if (dataType == DataType.NEW) {
            ByteBuffer buffer = ByteBuffer.allocate(12);
            buffer.put(Protocol.short2Bytes(Protocol.HEAD));
            buffer.put((byte) 9);
            buffer.put((byte) Protocol.DEVICE_TO_CLIENT);
            buffer.put(Protocol.short2Bytes(Protocol.ADDR_COLLECT_DATA_NEW));
            buffer.put(StringUtils.hexToByteArray(String.format("%04X", 0)));
            for (int i = 0; i < 2; i++) {
                buffer.put(StringUtils.hexToByteArray(String.format("%04X", data)));
            }
            return buffer.array();
        } else if (dataType == DataType.OLD) {
            ByteBuffer buffer = ByteBuffer.allocate(26);
            buffer.put(Protocol.short2Bytes(Protocol.HEAD));
            buffer.put((byte) 23);
            buffer.put((byte) Protocol.DEVICE_TO_CLIENT);
            buffer.put(Protocol.short2Bytes(Protocol.ADDR_COLLECT_DATA));
            for (int i = 0; i < 10; i++) {
                buffer.put(StringUtils.hexToByteArray(String.format("%04X", 512 + data)));
            }
            return buffer.array();
        }
        return null;
    }

    public Map<String, Object> dealData(DataType dataType, List<Integer> dataList) {
        if (dataType == DataType.NEW) {
            return newDataHelper.dealData(dataList);
        } else if (dataType == DataType.OLD) {
            return oldDataHelper.dealData(dataList);
        }
        return null;
    }

    public void reset() {
        newDataHelper.reset();
        oldDataHelper.reset();
    }

    private class NewDataHelper {
        private static final int DEFAULT_AVG_NUM = 3;
        private List<Float> dataAvgPFM = new ArrayList<>();

        public void reset() {
            dataAvgPFM.clear();
        }

        public Map<String, Object> dealData(List<Integer> dataList) {
            Map<String, Object> resultMap = new HashMap<>();

            int basePfm = dataList.get(0);
            int pfm1 = dataList.get(1);
            int pfm2 = dataList.get(2);

            float pfm = Math.max(0, Float.parseFloat(decimalOne.format((pfm1 + pfm2) / 2 - (ifMinusZero ? basePfm : 0)))) * pfmTimes;
            pfm = Math.min(100, pfm);
            while (dataAvgPFM.size() >= DEFAULT_AVG_NUM) {
                dataAvgPFM.remove(0);
            }
            dataAvgPFM.add(pfm);
            float finalPfm = Float.parseFloat(decimalOne.format(AssessUtils.avgFloat(dataAvgPFM)));

            resultMap.put("pfm", finalPfm);
            resultMap.put("pfmTip", basePfm + " - " + pfm1 + " - " + pfm2 + " - " + pfmTimes + " - " + finalPfm);

            return resultMap;
        }
    }

    private class OldDataHelper {

        private boolean isTest = true; // 是否在计算RMS
        private boolean isStatic = false; // 是否在测静息压

        private int rmsJumpSize = 1000;
        private int staticSize = 200;
        private float rmsPFM = -1;
        private float staticPFM = -1;
        private static final int DEFAULT_AVG_NUM = 8;  // 每秒大概接收80组数据
        private List<Integer> rmsList = new ArrayList<>();
        private List<Integer> tempDataList = new ArrayList<>();
        private List<Integer> staticList = new ArrayList<>();
        private List<Float> dataAvg = new ArrayList<>();

        public void reset() {
            dataAvg.clear();
            rmsList.clear();
            tempDataList.clear();
            staticList.clear();
            rmsJumpSize = 1000;
            rmsPFM = -1;
            staticPFM = -1;

            isTest = true;
            isStatic = false;
        }

        public Map<String, Object> dealData(List<Integer> dataList) {
            if(isTest) {
                if(!isStatic) {
                    // 开始后一段时间数据可能有问题，跳过下
                    /*if(rmsList.size() < 1000 + rmsJumpSize) {
                        rmsList.addAll(dataList.subList(0, 10));
                    }
                    if(rmsList.size() == 1000 + rmsJumpSize && rmsPFM == -1) {
                        LocalLog.test("rms pfm list - " + rmsList.subList(rmsJumpSize, 1000 + rmsJumpSize));
                        int sum = 0;
                        for(int i : rmsList.subList(rmsJumpSize, 1000 + rmsJumpSize)) {
                            sum += (i * i);
                        }
                        rmsPFM = (float) Math.sqrt(sum / 1000d);
                        isStatic = true;
                    }*/
                    if (rmsJumpSize == 0) {
                        if(rmsList.size() < 1000) {
                            rmsList.addAll(dataList.subList(0, 10));
                        }
                        if(rmsList.size() == 1000 && rmsPFM == -1) {
                            LocalLog.test("rms pfm list - " + rmsList.subList(0, 1000));
                            AssessUtils.sortList(rmsList);
                            rmsPFM = (int) AssessUtils.avg(rmsList.subList(100, 900));
                            isStatic = true;
                        }
                    } else {
                        rmsJumpSize -= 10;
                    }
                } else {
                    staticList.addAll(dataList.subList(0, 10));
                    if(staticList.size() == staticSize && staticPFM == -1) {
                        LocalLog.test("static pfm list - " + staticList);
                        List<Float> list = new ArrayList<>();
                        for (int i = 0; i < staticSize / 10; i++) {
                            int sum = 0;
                            for (int j = 0; j < 10; j++) {
                                sum += Math.abs(staticList.get(i * 10 + j) - 512);
                            }
                            list.add(sum / 10f);
                        }
                        AssessUtils.sortListFloat(list);
                        staticPFM =  Float.parseFloat(decimalOne.format(AssessUtils.avgFloat(list.subList(10, staticSize / 10 - 10)) * 0.9f));
                        LocalLog.test("static - " + staticPFM);
                        isTest = false;
                        isStatic = false;
                    }
                }
            } else {
                /*float sumPFM = 0;
                for(int i : dataList.subList(0, 10)) {
                    sumPFM += Math.abs(i - 512);
                }
                float resPFM = (float) (Math.sqrt(sumPFM / 10d) * pfmTimes);

                if(dataAvg.size() == DEFAULT_AVG_NUM) {
                    float finalPfm = Float.parseFloat(decimalOne.format(Math.min(100, Math.max(0, AssessUtils.avgFloat(dataAvg) - (ifMinusZero ? staticPFM : 0)))));
                    dataAvg.clear();

                    Map<String, Object> resultMap = new HashMap<>();
                    resultMap.put("pfm", finalPfm);
                    resultMap.put("pfmTip", rmsPFM + " - " + pfmTimes + " - " + staticPFM + " - " + finalPfm);

                    return resultMap;
                } else {
                    dataAvg.add(resPFM);
                }*/
                float sumPFM = 0;
                for(int i : dataList.subList(0, 10)) {
                    sumPFM += Math.abs(i - 512);
                }
                float resPFM = (float) ((sumPFM / 10d - staticPFM) * pfmTimes);

                if(dataAvg.size() == DEFAULT_AVG_NUM) {
                    float finalPfm = Float.parseFloat(decimalOne.format(Math.min(100, Math.max(0, AssessUtils.avgFloat(dataAvg)))));
                    dataAvg.clear();

                    Map<String, Object> resultMap = new HashMap<>();
                    resultMap.put("pfm", finalPfm);
                    resultMap.put("pfmTip", rmsPFM + " - " + pfmTimes + " - " + staticPFM + " - " + finalPfm);

                    return resultMap;
                } else {
                    dataAvg.add(resPFM);
                }
            }
            return null;
        }
    }

}
