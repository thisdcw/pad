package com.mxsella.m8.ui.main.presenter;

import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.bean.Record;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.net.LoginService;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;
import com.mxsella.m8.ui.main.contract.HistoryContract;

public class HistoryPresenter extends BasePresenter<HistoryContract.View>
    implements HistoryContract.Presenter {

    private static final String TAG = "HistoryPresenter";

    public HistoryPresenter(HistoryContract.View view) {
        super(view);
    }

    private static final int DEFAULT_SIZE = 10;
    private int totalPagesAssess = -1;
    private int totalPagesTrain = -1;

    @Override
    public void getAssessRecord(int page) {
        if (totalPagesAssess != -1 && page > totalPagesAssess) {
            mView.showNoMoreDataAssess();
            return;
        }
        addDisposable(LoginService.getApi().getAssessRecord(page, DEFAULT_SIZE)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<Record<AssessRecord>>>() {
                    @Override
                    public void onSuccess(BaseResponse<Record<AssessRecord>> data) {
                        mView.loadMoreFinishedAssess();
                        if (ResponseHelper.deal("History getAssessRecord", data) && data.getCode() == Constants.SUCCESS) {
                            mView.showAssessRecord(data.getData().getRecords());
                            totalPagesAssess = data.getData().getPages();
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                        mView.loadMoreFinishedAssess();
                    }
                }));
    }

    @Override
    public void deleteAssessRecord(int recordId, int position) {
        addDisposable(LoginService.getApi().deleteAssessRecord(recordId)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("History deleteAssessRecord", data) && data.getCode() == Constants.SUCCESS) {
                            mView.showDeleteResultAssess(data.getCode() == Constants.SUCCESS, position);
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }

    @Override
    public void getTrainRecord(int page) {
        if (totalPagesTrain != -1 && page > totalPagesTrain) {
            mView.showNoMoreDataTrain();
            return;
        }
        addDisposable(LoginService.getApi().getTrainRecord(page, DEFAULT_SIZE)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<Record<TrainRecord>>>() {
                    @Override
                    public void onSuccess(BaseResponse<Record<TrainRecord>> data) {
                        mView.loadMoreFinishedTrain();
                        if (ResponseHelper.deal("History getTrainRecord", data) && data.getCode() == Constants.SUCCESS) {
                            mView.showTrainRecord(data.getData().getRecords());
                            totalPagesTrain = data.getData().getPages();
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                        mView.loadMoreFinishedTrain();
                    }
                }));
    }

    @Override
    public void deleteTrainRecord(int recordId, int position) {
        addDisposable(LoginService.getApi().deleteTrainRecord(recordId)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("History deleteTrainRecord", data) && data.getCode() == Constants.SUCCESS) {
                            mView.showDeleteResultTrain(data.getCode() == Constants.SUCCESS, position);
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }
}
