package com.mxsella.m8.view.game.control;

import android.graphics.Rect;

import java.util.ArrayList;
import java.util.List;

public class BgControl {

    // 背景图位图宽高
    private int bgWidth, bgHeight;
    // 源Rect列表
    private List<Rect> srcList = new ArrayList<>();
    // 目标Rect列表
    private List<Rect> dstList = new ArrayList<>();
    // 屏幕宽高
    private int screenW, screenH;
    // 速度
    private float speed = 5;
    // 偏移距离
    private float offset;

    public BgControl(int bgWidth, int bgHeight, int screenW, int screenH,
                     float offset) {
        this.bgWidth = bgWidth;
        this.bgHeight = bgHeight;
        this.screenW = screenW;
        this.screenH = screenH;
        this.offset = offset;
    }

    public void initValue() {
        this.offset = 0.0f;
        this.srcList.clear();
        this.dstList.clear();
    }

    public void calculateBgRect() {
        this.srcList.clear();
        this.dstList.clear();
        // 绘制时实际截取的宽度: 位图高度 * 屏幕宽高比
        int real = (screenW * Math.min(bgWidth, bgHeight)) / screenH ;
        offset %= bgWidth;
        if (offset + (float) real <= bgWidth) {
            // 当截取屏幕宽度的背景图在背景图的内部区域时
            srcList.add(new Rect((int)offset, 0, (int)(offset + (float) real), bgHeight));
            dstList.add(new Rect(0, 0, screenW, screenH));
        } else {
            // 当截取屏幕宽度的背景图的区域到达边界时 则需要截取两部分
            // 一部分从偏移位置->图片最右边, 一部分从图片左边开始截取->真实需要截取的宽度-(图片右边界-当前偏移)
            srcList.add(new Rect((int)offset, 0, bgWidth, bgHeight));
            dstList.add(new Rect(0, 0, (int) ((bgWidth - offset) * screenH / bgHeight), screenH));

            srcList.add(new Rect(0, 0, (int) ((float) real - (bgWidth - offset)), bgHeight));
            dstList.add(new Rect((int) ((bgWidth - offset) * screenH / bgHeight), 0, screenW, screenH));
        }
        offset += speed;
    }

    public int getBgWidth() {
        return bgWidth;
    }

    public void setBgWidth(int bgWidth) {
        this.bgWidth = bgWidth;
    }

    public int getBgHeight() {
        return bgHeight;
    }

    public void setBgHeight(int bgHeight) {
        this.bgHeight = bgHeight;
    }

    public List<Rect> getSrcList() {
        return srcList;
    }

    public void setSrcList(List<Rect> srcList) {
        this.srcList = srcList;
    }

    public List<Rect> getDstList() {
        return dstList;
    }

    public void setDstList(List<Rect> dstList) {
        this.dstList = dstList;
    }

    public int getScreenW() {
        return screenW;
    }

    public void setScreenW(int screenW) {
        this.screenW = screenW;
    }

    public int getScreenH() {
        return screenH;
    }

    public void setScreenH(int screenH) {
        this.screenH = screenH;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    public float getOffset() {
        return offset;
    }

    public void setOffset(float offset) {
        this.offset = offset;
    }
}
