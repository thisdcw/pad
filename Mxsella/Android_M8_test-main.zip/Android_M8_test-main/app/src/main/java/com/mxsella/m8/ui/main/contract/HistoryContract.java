package com.mxsella.m8.ui.main.contract;

import com.mxsella.m8.base.BaseContract;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.bean.TrainRecord;

import java.util.List;

public interface HistoryContract {

    interface Presenter extends BaseContract.Presenter {

        void getTrainRecord(int page);

        void deleteTrainRecord(int recordId, int position);

        void getAssessRecord(int page);

        void deleteAssessRecord(int recordId, int position);

    }

    interface View extends BaseContract.View<Presenter> {

        void showAssessRecord(List<AssessRecord> recordList);

        void showDeleteResultAssess(Boolean result, int position);

        void showNoMoreDataAssess();

        void loadMoreFinishedAssess();

        void showTrainRecord(List<TrainRecord> recordList);

        void showDeleteResultTrain(Boolean result, int position);

        void showNoMoreDataTrain();

        void loadMoreFinishedTrain();

    }
}
