package com.mxsella.m8.ui.recovery;

import android.content.Context;
import android.content.Intent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.bean.RecoveryCourse;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.comm.ICommunicateService;
import com.mxsella.m8.comm.Protocol;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.ResourceHelper;
import com.mxsella.m8.ui.train.TrainContract;
import com.mxsella.m8.ui.train.TrainPresenter;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.MediaHelper;
import com.mxsella.m8.utils.StringUtils;
import com.mxsella.m8.utils.TimeDateUtils;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.dialog.MediaDialog;
import com.mxsella.m8.view.dialog.RequestDialog;

import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.OnTouch;

public class RecoveryActivity extends BaseMvpActivity<TrainContract.Presenter> implements TrainContract.View {

    private static final String COURSE = "course";
    private static final String WORK_INTENSITY = "work_intensity";
    private static final String WORK_TIME = "work_time";
    private static final String WORK_HZ = "work_hz";

    @Override
    public int getLayoutId() {
        return R.layout.activity_recovery;
    }

    @Override
    protected TrainContract.Presenter initPresenter() {
        return new TrainPresenter(this);
    }

    @BindView(R.id.layout_recovery_setting)
    View layoutSetting;
    @BindView(R.id.seekbar_intensity)
    SeekBar seekBar;
    @BindView(R.id.tv_pre_stage)
    TextView tvPreStage;
    @BindView(R.id.tv_pre_intensity)
    TextView tvPreIntensity;
    @BindView(R.id.tv_pre_hz)
    TextView tvPreHz;
    @BindView(R.id.btn_next)
    Button btnNext;
    @BindView(R.id.tv_course_name)
    TextView tvCourseName;
    @BindView(R.id.tv_time)
    TextView tvTime;
    @BindView(R.id.tv_intensity)
    TextView tvIntensity;
    @BindView(R.id.img_recovery_work)
    ImageView imgWork;
    @BindView(R.id.btn_minus_5)
    Button btnMinus5;
    @BindView(R.id.btn_minus_1)
    Button btnMinus1;
    @BindView(R.id.btn_plus_1)
    Button btnPlus1;
    @BindView(R.id.btn_plus_5)
    Button btnPlus5;
    @BindView(R.id.tv_hz)
    TextView tvHz;
    @BindView(R.id.tv_us)
    TextView tvUs;
    @BindView(R.id.btn_start)
    Button btnStart;

    private BleService bleService;
    private ICommunicateService.DataReceiveListener bleListener;
    private RecoveryCourse recoveryCourse;
    private boolean isOldWork;
    private int intensity = 0;
    private int trainTime = 0;

    private boolean isStart;
    private boolean isPause;
    private boolean isRelease = true;
    private long lastPressTime = 0;
    private boolean ifGif = false;
    private ExecutorService gifThread = Executors.newSingleThreadExecutor();
    private ExecutorService imitateThread = Executors.newSingleThreadExecutor();
    private ExecutorService pressThread = Executors.newSingleThreadExecutor();
    private Map<String, Integer> intensityMap = new HashMap<>();
    private int hzPos = 0;

    public static void show(Context context, RecoveryCourse course) {
        Intent intent = new Intent(context, RecoveryActivity.class);
        intent.putExtra(COURSE, course);
        context.startActivity(intent);
    }

    public static void show(Context context, RecoveryCourse course, int workIntensity, int workTime, int workHz) {
        Intent intent = new Intent(context, RecoveryActivity.class);
        intent.putExtra(COURSE, course);
        intent.putExtra(WORK_INTENSITY, workIntensity);
        intent.putExtra(WORK_TIME, workTime);
        intent.putExtra(WORK_HZ, workHz);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        recoveryCourse = (RecoveryCourse) getIntent().getSerializableExtra(COURSE);
        tvCourseName.setText(String.format(getString(R.string.recovery_time_left), recoveryCourse.getTrainName()));

        bleService = BleService.getInstance();
        bleListener = packet -> {
            switch (packet.getAddr()) {
                case Protocol.ADDR_ELECTRIC_HZ:
                    runOnUiThread(()->{
                        if (!isStart)
                            return;
                        int hz = packet.getDataList().get(0);
                        if (!tvHz.getText().toString().equals(String.valueOf(hz))) {
                            tvHz.setText(String.valueOf(packet.getDataList().get(0)));
                            tvUs.setText("200");
                            for (String key : intensityMap.keySet()) {
                                for (String s : key.split(",")) {
                                    if (s.equals(String.valueOf(hz))) {
                                        intensity = intensityMap.get(key);
                                    }
                                }
                            }
                            tvIntensity.setText(String.valueOf(intensity));
                            bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) intensity);
                        }
                    });
                    break;
                case Protocol.ADDR_ELECTRIC_POWER:
                    runOnUiThread(()->{
                        if (!isStart)
                            return;
                        intensity = packet.getDataList().get(0);
                        tvIntensity.setText(String.valueOf(intensity));
                        for (String key : intensityMap.keySet()) {
                            for (String s : key.split(",")) {
                                if (s.equals(tvHz.getText().toString())) {
                                    intensityMap.put(key, intensity);
                                }
                            }
                        }
                    });
                    break;
                case Protocol.ADDR_ELECTRIC_TIME:
                    if (packet.getDataList().get(0) == 0 && isStart) {
                        trainTime = recoveryCourse.getTrainDuration();
                        resetUI();
                    }
                    runOnUiThread(()->{
                        if (!isStart)
                            return;
                        tvTime.setText(TimeDateUtils.getMinAndSecondBySeconds(packet.getDataList().get(0)));
                    });
                    break;
                case Protocol.ADDR_ELECTRIC_IRRITATE:
                    if (!ifGif) {
                        ifGif = true;
                        runOnUiThread(()-> {
                            if (!isStart)
                                return;
                            setEnable(true);
                        });
                        gifThread.execute(gifTimer);
                    }
                    break;
                case Protocol.ADDR_ELECTRIC_RELAX:
                    if (ifGif) {
                        ifGif = false;
                        runOnUiThread(()-> {
                            if (!isStart)
                                return;
                            setEnable(false);
                        });
                    }
                    break;
            }
        };
        bleService.addListener(bleListener);
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvPreIntensity.setText(String.valueOf(i));
                bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) i);
                if (i > 0) {
                    btnNext.setEnabled(true);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        int workIntensity = getIntent().getIntExtra(WORK_INTENSITY, 0);
        if (workIntensity != 0) {
            isOldWork = true;
            intensity = workIntensity;
            // tvIntensity.setText(String.valueOf(intensity));
            tvTime.setText(TimeDateUtils.getMinAndSecondBySeconds(getIntent().getIntExtra(WORK_TIME, 0)));
            // tvHz.setText(String.valueOf(getIntent().getIntExtra(WORK_HZ, 0)));

            /*btnStart.setText(getString(R.string.stop));
            btnStart.setBackgroundResource(R.drawable.bkg_button_selected);*/
            bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) 0);
            if(Config.ifDebug) {
                imitateThread.execute(imitateTimer);
            }
        } else {
            tvTime.setText(TimeDateUtils.getMinAndSecondBySeconds(recoveryCourse.getTrainDuration()));
        }
        bleService.send(Protocol.ADDR_ELECTRIC_TIME, (short) TimeDateUtils.getSeconds(tvTime.getText().toString()));

        bleService.send(Protocol.ADDR_ELECTRIC_MODE, (short) 10);
        bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) 0);
        MediaDialog mediaDialog = new MediaDialog(this);
        mediaDialog.show(getString(R.string.recovery_settings_content), getString(R.string.recovery_settings), true);
        MediaHelper.playSound(ResourceHelper.getRawByName(this, "train_setting"), mp -> {
            mediaDialog.dismiss();
            setHzIntensity(0);
        });
    }

    private void resetUI() {
        if(btnStart == null)
            return;
        isPause = false;
        isStart = false;
        ifGif = false;
        runOnUiThread(() -> {
            btnStart.setText(getString(R.string.start));
            btnStart.setBackgroundResource(R.drawable.train_start);
            tvTime.setText(TimeDateUtils.getMinAndSecondBySeconds(recoveryCourse.getTrainDuration()));
            intensity = 0;
            tvIntensity.setText(String.valueOf(intensity));
            setEnable(false);
        });
        bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) 0);
        bleService.send(Protocol.ADDR_ELECTRIC_TIME, (short) 0);

        if (trainTime > 0){
            TrainRecord trainRecord = new TrainRecord(0, Config.curUser.getUid(), recoveryCourse.getTrainId(), recoveryCourse.getTrainName(), TimeDateUtils.getNowDateTime(), trainTime);
            showNetDialog();
            mPresenter.uploadTrainRecord(trainRecord);
            trainTime = 0;
        }
    }

    @OnClick({R.id.btn_next, R.id.btn_start, R.id.btn_pause})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_next:
                /*for (int hz : recoveryCourse.getHzList().get(hzPos)) {
                    intensityMap.put(hz, seekBar.getProgress());
                }*/
                intensityMap.put(StringUtils.integerSerialize(recoveryCourse.getHzList().get(hzPos)), seekBar.getProgress());
                if (hzPos < recoveryCourse.getHzList().size() - 1) {
                    setHzIntensity(hzPos + 1);
                } else {
                    imgWork.setVisibility(View.INVISIBLE);
                    ifGif = false;
                    layoutSetting.setVisibility(View.GONE);
                    bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) 0);
                }
                break;
            case R.id.btn_start:
                if(!isStart) {
                    isStart = true;
                    btnStart.setText(getString(R.string.stop));
                    btnStart.setBackgroundResource(R.drawable.train_stop);
                    bleService.send(Protocol.ADDR_ELECTRIC_MODE, (short) (recoveryCourse.getTrainId() - 1));
                    bleService.send(Protocol.ADDR_ELECTRIC_TIME, (short) TimeDateUtils.getSeconds(tvTime.getText().toString()));
                    if(Config.ifDebug) {
                        imitateThread.execute(imitateTimer);
                    }
                } else {
                    if(isPause) {
                        isPause = false;
                        bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) intensity);
                        btnStart.setText(getString(R.string.stop));
                        btnStart.setBackgroundResource(R.drawable.train_stop);
                    } else {
                        ifGif = false;
                        setEnable(false);
                        bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) 0);
                        trainTime = (int) (recoveryCourse.getTrainDuration() - TimeDateUtils.getSeconds(tvTime.getText().toString()));
                        resetUI();
                    }
                }
                break;
            case R.id.btn_pause:
                if(isStart && !isPause) {
                    isPause = true;
                    ifGif = false;
                    setEnable(false);
                    bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) 0);
                    btnStart.setText(getString(R.string.start));
                    btnStart.setBackgroundResource(R.drawable.train_start);
                }
                break;
        }
    }

    private void setHzIntensity(int position) {
        tvPreStage.setText(String.format(getString(R.string.recovery_stage_num), position + 1));
        hzPos = position;
        int hz = recoveryCourse.getHzList().get(hzPos).get(0);
        tvPreHz.setText(String.valueOf(hz));
        bleService.send(Protocol.ADDR_PRE_HZ, (short) hz);
        seekBar.setProgress(1);
    }

    private void setEnable(boolean enable) {
        imgWork.setVisibility(enable ? View.VISIBLE : View.INVISIBLE);
        // btnMinus5.setEnabled(enable);
        // btnMinus1.setEnabled(enable);
        // btnPlus1.setEnabled(enable);
        // btnPlus5.setEnabled(enable);
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        onBackPressedSupport();
    }

    @Override
    public void onBackPressedSupport() {
        if (isStart) {
            ToastUtils.showToast(getString(R.string.toast_end_work_first));
            return;
        }
        if (isOldWork) {
            RecoveryChooseActivity.show(this, false);
            finish();
        } else {
            super.onBackPressedSupport();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(bleService != null) {
            bleService.send(Protocol.ADDR_ELECTRIC_MODE, (short) 11);
            bleService.send(Protocol.ADDR_ELECTRIC_TIME, (short) 1800);
            bleService.removeListener(bleListener);
        }
    }

    private final Runnable imitateTimer = () -> {
        int pos = 0;
        int hzPos = 0;
        while (isStart) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            if(!isPause && intensity > 0) {
                ByteBuffer buffer = ByteBuffer.allocate(8);
                buffer.put(Protocol.IMITATE_ELECTRIC_TIME_FORMAT);
                if (tvTime != null) {
                    if (pos == 0) {
                        bleService.imitateReceive(ifGif ? Protocol.IMITATE_ELECTRIC_RELAX : Protocol.IMITATE_ELECTRIC_IRRITATE);
                        bleService.imitateReceive(StringUtils.hexToByteArray(String.format("5AA505825522%04X", recoveryCourse.getHzList().get(hzPos).get(0))));
                        hzPos = ((hzPos + 1) % recoveryCourse.getHzList().size());
                    }
                    pos = ((pos + 1) % 5);
                    buffer.put(StringUtils.hexToByteArray(String.format("%04X", (int) (TimeDateUtils.getSeconds(tvTime.getText().toString()) - 1))));
                    bleService.imitateReceive(buffer.array());
                }
            }
        }
    };

    private final Runnable gifTimer = () -> {
        int pos = 0;
        while (ifGif) {
            int finalPos = pos;
            runOnUiThread(()->{
                if (imgWork == null)
                    return;
                imgWork.setImageResource(ResourceHelper.getImageRidByName(this, "recovery_work_" + finalPos));
            });
            pos = ((pos + 1) % 6);
            try {
                Thread.sleep(50);
            } catch (InterruptedException ignore) {

            }
        }
    };

    @OnTouch({R.id.btn_minus, R.id.btn_plus, R.id.btn_minus_5, R.id.btn_minus_1, R.id.btn_plus_1, R.id.btn_plus_5})
    public boolean onTouch(View view, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (isRelease) {
                    this.lastPressTime = System.currentTimeMillis();
                    this.isRelease = false;
                    if (pressThread != null) {
                        view.setSelected(true);
                        if (view.getId() == R.id.btn_minus) {
                            pressThread.execute(new QuickPreIntensityTask(-1));
                        } else if (view.getId() == R.id.btn_plus) {
                            pressThread.execute(new QuickPreIntensityTask(1));
                        } else if (view.getId() == R.id.btn_minus_5) {
                            pressThread.execute(new QuickIntensityTask(-5));
                        } else if (view.getId() == R.id.btn_minus_1) {
                            pressThread.execute(new QuickIntensityTask(-1));
                        } else if (view.getId() == R.id.btn_plus_1) {
                            pressThread.execute(new QuickIntensityTask(1));
                        } else if (view.getId() == R.id.btn_plus_5) {
                            pressThread.execute(new QuickIntensityTask(5));
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                this.isRelease = true;
                long time = System.currentTimeMillis() - lastPressTime;

                view.setSelected(false);

                // 时间小于等于500ms响应普通点击逻辑
                if (time < 500) {
                    if (view.getId() == R.id.btn_minus) {
                        adjustPreIntensity(-1);
                    } else if (view.getId() == R.id.btn_plus) {
                        adjustPreIntensity(1);
                    } else if (view.getId() == R.id.btn_minus_5) {
                        adjustIntensity(-5);
                    } else if (view.getId() == R.id.btn_minus_1) {
                        adjustIntensity(-1);
                    } else if (view.getId() == R.id.btn_plus_1) {
                        adjustIntensity(1);
                    } else if (view.getId() == R.id.btn_plus_5) {
                        adjustIntensity(5);
                    }
                }
                break;
        }
        return true;
    }

    private void adjustIntensity(int i) {
        if(!isStart || (intensity == 0 && i < 0) || (intensity == 60 && i > 0))
            return;
        if(!isPause || i < 0 || (intensity == 0 && i > 0)) {
            intensity = Math.max(0, Math.min(60, intensity + i));
            runOnUiThread(() -> tvIntensity.setText(String.valueOf(intensity)));
            int hz = Integer.parseInt(tvHz.getText().toString());
            for (String key : intensityMap.keySet()) {
                for (String s : key.split(",")) {
                    if (s.equals(String.valueOf(hz))) {
                        intensityMap.put(key, intensity);
                    }
                }
            }
            bleService.send(Protocol.ADDR_ELECTRIC_POWER, (short) intensity);
        }
    }

    private void adjustPreIntensity(int i) {
        if((seekBar.getProgress() == 0 && i < 0) || (seekBar.getProgress() == 60 && i > 0))
            return;
        int value = Math.max(1, Math.min(60, seekBar.getProgress() + i));
        runOnUiThread(() -> seekBar.setProgress(value));
    }

    @Override
    public void uploadResult(boolean result, TrainRecord trainRecord) {
        hideNetDialog();
        if (result) {
            ToastUtils.showToast(getString(R.string.upload_train_success));
        } else {
            RequestDialog requestDialog = new RequestDialog(this, getString(R.string.upload_fail), getString(R.string.upload_train_fail),
                    getString(R.string.upload_again), getString(R.string.upload_cancel));
            requestDialog.setConfirmClickListener(view -> {
                showNetDialog();
                requestDialog.dismiss();
                mPresenter.uploadTrainRecord(trainRecord);
            });
            requestDialog.setCancelClickListener(view -> {
                requestDialog.dismiss();
            });
            requestDialog.show();
        }
    }

    private class QuickIntensityTask implements Runnable {

        private final int value;

        public QuickIntensityTask(int value) {
            this.value = value;
        }

        @Override
        public void run() {
            try {
                while (!isRelease) {
                    if (System.currentTimeMillis() - lastPressTime > 500) {
                        adjustIntensity(value);
                        Thread.sleep(60);
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }

    private class QuickPreIntensityTask implements Runnable {

        private final int value;

        public QuickPreIntensityTask(int value) {
            this.value = value;
        }

        @Override
        public void run() {
            try {
                while (!isRelease) {
                    if (System.currentTimeMillis() - lastPressTime > 500) {
                        adjustPreIntensity(value);
                        Thread.sleep(60);
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }
}