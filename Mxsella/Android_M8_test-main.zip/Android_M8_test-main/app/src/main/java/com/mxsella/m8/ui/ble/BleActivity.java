package com.mxsella.m8.ui.ble;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.clj.fastble.BleManager;
import com.clj.fastble.callback.BleScanCallback;
import com.clj.fastble.data.BleDevice;
import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseActivity;
import com.mxsella.m8.bean.BleDeviceInfo;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.comm.IBleConnectStateCallback;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.PermissionHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.ui.adpter.BleAdapter;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.dialog.BleDialog;
import com.mxsella.m8.view.dialog.RequestDialog;
import com.tbruyelle.rxpermissions2.Permission;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class BleActivity extends BaseActivity {

    private static final int CODE = 0x88;

    @Override
    public int getLayoutId() {
        return R.layout.activity_ble;
    }

    @BindView(R.id.btn_ble_switch)
    Button btnBleSwitch;
    @BindView(R.id.rcv_ble)
    RecyclerView rcvBle;

    private List<BleDeviceInfo> bleList = new ArrayList<>();
    private BleAdapter bleAdapter;
    private BleDialog bleDialog;

    public static void show(Context context) {
        context.startActivity(new Intent(context, BleActivity.class));
    }

    @Override
    public void initView() {
        super.initView();

        bleAdapter = new BleAdapter(bleList);
        rcvBle.setLayoutManager(new LinearLayoutManager(this));
        rcvBle.setAdapter(bleAdapter);

        bleAdapter.setOnItemClickListener((adapter, view, position) -> {
            BleDeviceInfo device = bleList.get(position);
            if (BleManager.getInstance().isConnected(device.getDeviceAddress())) {
                ToastUtils.showToast(getResources().getString(R.string.ble_connected));
                return;
            }
            bleDialog = new BleDialog(this, device.getDeviceName());
            bleDialog.setCancelClickListener(v -> {
                bleDialog.dismiss();
            });
            bleDialog.setPairClickListener(v -> {
                if(BleService.getInstance().isConnected()) {
                    for(int i = 0; i< bleList.size(); i++) {
                        if(bleList.get(i).getDeviceAddress().equals(BleService.getInstance().getCurDevice().getMac())) {
                            bleList.get(i).setConnectState(false);
                            bleAdapter.notifyItemChanged(i);
                        }
                    }
                }
                BleManager.getInstance().cancelScan();
                BleManager.getInstance().disconnectAllDevice();
                BleService.getInstance().connect(device.getDeviceAddress(), new IBleConnectStateCallback() {
                    @Override
                    public void startConnect() {
                        bleDialog.setPair();
                    }

                    @Override
                    public void connectSuccess() {
                        sendBroadcast(new Intent(Config.BLE_CONNECT));
                        Config.saveBleAddress(device.getDeviceAddress());
                        Config.saveBleName(device.getDeviceName());
                        ToastUtils.showToast(getResources().getString(R.string.ble_connect_success));
                        bleList.get(position).setConnectState(true);
                        bleAdapter.notifyItemChanged(position);
                        bleDialog.dismiss();
                    }

                    @Override
                    public void connectFailure(String msg) {
                        ToastUtils.showToast(getResources().getString(R.string.ble_connect_fail) + msg);
                        bleDialog.dismiss();
                    }

                    @Override
                    public void disConnect() {
                        sendBroadcast(new Intent(Config.BLE_DISCONNECT));
                        if(bleList.size() > 0) {
                            bleList.get(position).setConnectState(false);
                            bleAdapter.notifyItemChanged(position);
                        }
                    }
                });
            });
            bleDialog.show();
        });

        /*if (BleService.getInstance().isEnable()) {
            btnBleSwitch.setBackgroundResource(R.drawable.ic_ble_on);
            bleScan();
        }*/
        btnBleSwitch.setBackgroundResource(BleService.getInstance().isEnable() ? R.drawable.ic_ble_on : R.drawable.ic_ble_off);
        showPermissionDialog();
    }

    private void checkBleEnable() {
        if (!BleService.getInstance().isEnable()) {
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            if (Build.VERSION.SDK_INT >= 31 && ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                RxPermissions rxPermission = new RxPermissions(BleActivity.this);
                rxPermission.requestEach(Manifest.permission.BLUETOOTH_CONNECT)
                        .subscribe(new BaseObserver<Permission>() {
                            @Override
                            public void onSuccess(Permission permission) {
                                if (permission.granted) {
                                    if (ActivityCompat.checkSelfPermission(BleActivity.this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)
                                        startActivityForResult(intent, CODE);
                                } else if (permission.shouldShowRequestPermissionRationale) {
                                    finish();
                                } else {
                                    finish();
                                }
                            }
                        });
            } else {
                startActivityForResult(intent, CODE);
            }
        } else {
            requestBleScan();
        }
    }

    private void bleScan() {
        if (Build.VERSION.SDK_INT >= 31 && (!PermissionHelper.checkPermission(Manifest.permission.BLUETOOTH_SCAN) ||
                !PermissionHelper.checkPermission(Manifest.permission.BLUETOOTH_CONNECT))) {
            ToastUtils.showToast(getString(R.string.ble_permission_connect));
            finish();
            return;
        }
        if (!PermissionHelper.checkPermission(Manifest.permission.ACCESS_COARSE_LOCATION) || !PermissionHelper.checkPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            ToastUtils.showToast(getString(R.string.ble_permission_location));
            finish();
            return;
        }
        BleManager.getInstance().scan(bleScanCallback);
    }

    private void showPermissionDialog() {
        if (!PermissionHelper.checkPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ||
                !PermissionHelper.checkPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
                (Build.VERSION.SDK_INT >= 31 && (!PermissionHelper.checkPermission(Manifest.permission.BLUETOOTH_SCAN) ||
                        !PermissionHelper.checkPermission(Manifest.permission.BLUETOOTH_CONNECT)))) {
            RequestDialog requestDialog = new RequestDialog(this, getString(R.string.permission_ble_title),
                    getString(R.string.permission_ble_content), getString(R.string.permission_on), getString(R.string.cancel));
            requestDialog.setConfirmClickListener(view -> {
                checkBleEnable();
                requestDialog.dismiss();
            });
            requestDialog.setCancelClickListener(view -> {
                bleScan();
            });
            requestDialog.show();
        } else {
            bleScan();
        }
    }

    private void requestBleScan() {
        RxPermissions rxPermission = new RxPermissions(this);
        if (Build.VERSION.SDK_INT >= 31) {
            rxPermission.requestEachCombined(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                    .subscribe(new BaseObserver<Permission>() {
                        @Override
                        public void onSuccess(Permission data) {
                            bleScan();
                        }
                    });
        } else {
            rxPermission.requestEachCombined(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
                    .subscribe(new BaseObserver<Permission>() {
                        @Override
                        public void onSuccess(Permission data) {
                            bleScan();
                        }
                    });
        }
    }

    @OnClick({R.id.btn_ble_switch})
    public void onClick() {
        if (!BleService.getInstance().isEnable()) {
            checkBleEnable();
        } else {
            BleManager.getInstance().disableBluetooth();
            btnBleSwitch.setBackgroundResource(R.drawable.ic_ble_off);
            bleList.clear();
            bleAdapter.notifyDataSetChanged();
        }
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }

    private BleScanCallback bleScanCallback = new BleScanCallback() {
        @Override
        public void onScanFinished(List<BleDevice> scanResultList) {
            List<BleDeviceInfo> deviceInfoList = new ArrayList<>();
            BleDevice curDevice = BleService.getInstance().getCurDevice();
            if (curDevice != null) {
                BleDeviceInfo bleDeviceInfo = new BleDeviceInfo();
                bleDeviceInfo.setDeviceName(Config.getBleName());
                bleDeviceInfo.setDeviceAddress(Config.getBleAddress());
                bleDeviceInfo.setConnectState(true);
                deviceInfoList.add(bleDeviceInfo);
            }
            if (curDevice == null && scanResultList.size() == 0) {
                ToastUtils.showToast(getResources().getString(R.string.ble_search_no_device));
            } else {
                for (int i = 0;i < scanResultList.size();i++) {
                    BleDeviceInfo bleDeviceInfo = new BleDeviceInfo();
                    BleDevice device = scanResultList.get(i);
                    bleDeviceInfo.setDeviceName(device.getName());
                    bleDeviceInfo.setDeviceAddress(device.getMac());
                    if(device.getName() != null)
                        deviceInfoList.add(bleDeviceInfo);
                }
                bleList.clear();
                bleList.addAll(deviceInfoList);
                bleAdapter.notifyDataSetChanged();
            }
        }

        @Override
        public void onScanStarted(boolean success) {

        }

        @Override
        public void onScanning(BleDevice bleDevice) {

        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == CODE) {
            if (resultCode == RESULT_OK) {
                btnBleSwitch.setBackgroundResource(R.drawable.ic_ble_on);
                requestBleScan();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}