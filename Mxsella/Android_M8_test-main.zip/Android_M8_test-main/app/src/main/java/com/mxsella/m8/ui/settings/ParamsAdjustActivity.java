package com.mxsella.m8.ui.settings;

import android.content.Context;
import android.content.Intent;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseActivity;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.utils.ToastUtils;

import butterknife.BindView;
import butterknife.OnClick;

public class ParamsAdjustActivity extends BaseActivity {

    @Override
    public int getLayoutId() {
        return R.layout.activity_params_adjust;
    }

    @BindView(R.id.edt_parameter_assess)
    EditText edtAssess;
    @BindView(R.id.btn_change)
    Button btnChange;

    private InputMethodManager manager;

    public static void show(Context context) {
        Intent intent = new Intent(context, ParamsAdjustActivity.class);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();

        manager = ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE));
        setFocusChangeListener(edtAssess);

        edtAssess.setText(String.valueOf(Config.getParameterAssess()));
    }

    @OnClick({R.id.btn_change})
    public void onChangeClick(){
        try {
            float assessTimes = Float.parseFloat(edtAssess.getText().toString());
            Config.saveParameterAssess(assessTimes);
            ToastUtils.showToast(getString(R.string.settings_parameter_modify_success));
        } catch (Exception e){
            ToastUtils.showToast(getString(R.string.settings_input_parameter_error));
        }
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }

    public void setFocusChangeListener(EditText editText){
        editText.setOnFocusChangeListener((view, b) -> {
            if(!b){
                if (manager != null) {
                    manager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
            }
        });
    }
}