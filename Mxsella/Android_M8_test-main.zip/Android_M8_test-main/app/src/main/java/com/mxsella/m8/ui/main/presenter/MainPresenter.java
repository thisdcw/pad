package com.mxsella.m8.ui.main.presenter;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.bean.CheckUpdateResponse;
import com.mxsella.m8.bean.User;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.net.LoginService;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;
import com.mxsella.m8.ui.main.contract.MainContract;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.ToastUtils;

import java.util.HashMap;
import java.util.Map;

public class MainPresenter extends BasePresenter<MainContract.View>
    implements MainContract.Presenter {

    private static final String TAG = "MainPresenter";

    public MainPresenter(MainContract.View view) {
        super(view);
    }

    @Override
    public void requestUpdate() {
        Map<String, Object> map = new HashMap<>();
        map.put("versionBranch", Config.versionBranch);
        map.put("versionCode", Config.versionCode);
        map.put("versionName", Config.versionName);
        addDisposable(NormalService.getApi().requestUpdate(map)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<CheckUpdateResponse>() {
                    @Override
                    public void onSuccess(CheckUpdateResponse data) {
                        LocalLog.test("Main requestUpdate" + data.toString());
                        if (data.getCode() == Constants.SUCCESS) {
                            mView.showUpdateDialog(data.getData());
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                        // ToastUtils.showToast(mView.getContext().getString(R.string.update_no_data));
                    }
                }));
    }

    @Override
    public void getUserInfo() {
        addDisposable(LoginService.getApi().getUserInfo()
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<User>>() {
                    @Override
                    public void onSuccess(BaseResponse<User> data) {
                        LocalLog.test("requestUpdate" + data.toString());
                        if (ResponseHelper.deal("Main getUserInfo", data) && data.getCode() == Constants.SUCCESS) {
                            Config.saveLoginUser(data.getData());
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }
}
