package com.mxsella.m8.bean;

import java.io.Serializable;

public class CheckUpdateResponse implements Serializable {


    private int code;

    private String message;

    private UpdateInfo data;


    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public UpdateInfo getData() {
        return data;
    }

    public void setData(UpdateInfo data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "CheckUpdateResponse{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}
