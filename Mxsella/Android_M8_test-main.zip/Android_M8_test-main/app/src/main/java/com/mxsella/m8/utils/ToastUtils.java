package com.mxsella.m8.utils;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.mxsella.m8.R;
import com.mxsella.m8.application.MyApplication;

public class ToastUtils {

    public static void showToast(String info) {
        showToast(MyApplication.getInstance(), info, Toast.LENGTH_SHORT);
    }

    public static void showLongToast(String info) {
        showToast(MyApplication.getInstance(), info, Toast.LENGTH_LONG);
    }

    public static void showToast(Context context, String info, int duration) {
        if (info == null)
            return;
        if (context != null) {
            Toast toast = Toast.makeText(context, info, duration);
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
            View v = layoutInflater.inflate(R.layout.dialog_toast, null);
            ((TextView) v.findViewById(R.id.tv_toast)).setText(info);
            toast.setView(v);
            toast.show();
        }
    }

}
