package com.mxsella.m8.net;

import android.net.ParseException;
import android.util.Log;

import com.google.gson.JsonParseException;
import com.mxsella.m8.utils.ToastUtils;

import org.json.JSONException;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import io.reactivex.observers.ResourceObserver;
import retrofit2.HttpException;

public abstract class BaseObserver<T> extends ResourceObserver<T> {

    @Override
    public void onNext(T t) {
        onSuccess(t);
        onFinish();
    }

    @Override
    public void onError(Throwable e) {
        if (e == null) {
            e = new Throwable("错误");
        }
        e.printStackTrace();
        boolean isHttpError = false;
        String error="";
        //网络超时
        if (e instanceof SocketTimeoutException) {
            Log.e("TAG", "网络连接异常: " + e.getMessage());
            error = "网络连接异常";
            //均视为网络错误
        } else if (e instanceof ConnectException) {
            Log.e("TAG", "网络连接异常: " + e.getMessage());

            error = "网络连接异常";
            //均视为解析错误
        } else if (e instanceof JsonParseException
                || e instanceof JSONException
                || e instanceof ParseException) {
            Log.e("TAG", "数据解析异常: " + e.getMessage());
            error = "数据解析异常";
            //服务器返回的错误信息
        } else if (e instanceof HttpException) {
            isHttpError = true;
            int code = ((HttpException) e).code();
            error = "Http服务器错误";
        } else if (e instanceof UnknownHostException) {
            Log.e("TAG", "网络连接异常: " + e.getMessage());
            error = "网络连接异常";
        } else if (e instanceof IllegalArgumentException) {
            Log.e("TAG", "网络连接异常: " + e.getMessage());
            error = "网络连接异常";
        } else {//未知错误
            try {
                Log.e("TAG", "错误: " + e.getMessage());
            } catch (Exception e1) {
                Log.e("TAG", "未知错误Debug调试 ");
            }
            error = "错误";
        }
        onFail(error);
        onFinish();
    }

    @Override
    public void onComplete() {

    }

    /**
     * 服务器响应成功返回的数据
     */
    abstract public void onSuccess(T data);

    /**
     *  服务器响应失败返回的响应码
     */
    public void onFail(String errorMsg) {
        ToastUtils.showToast(errorMsg);
    }

    public void onFinish() { }

}
