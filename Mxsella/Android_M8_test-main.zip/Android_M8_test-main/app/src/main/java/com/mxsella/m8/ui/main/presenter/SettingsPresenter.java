package com.mxsella.m8.ui.main.presenter;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.CheckUpdateResponse;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;
import com.mxsella.m8.ui.main.contract.SettingsContract;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.ToastUtils;

import java.util.HashMap;
import java.util.Map;

public class SettingsPresenter extends BasePresenter<SettingsContract.View>
    implements SettingsContract.Presenter {

    private static final String TAG = "SettingsPresenter";

    public SettingsPresenter(SettingsContract.View view) {
        super(view);
    }

    @Override
    public void requestUpdate() {
        Map<String, Object> map = new HashMap<>();
        map.put("versionBranch", Config.versionBranch);
        map.put("versionCode", Config.versionCode);
        map.put("versionName", Config.versionName);
        addDisposable(NormalService.getApi().requestUpdate(map)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<CheckUpdateResponse>() {
                    @Override
                    public void onSuccess(CheckUpdateResponse data) {
                        LocalLog.test("Settings requestUpdate" + data.toString());
                        if (data.getCode() == Constants.SUCCESS) {
                            mView.showUpdateDialog(true, data.getData());
                        } else {
                            ToastUtils.showToast(mView.getContext().getString(R.string.update_version_latest));
                            mView.showUpdateDialog(false, null);
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                        ToastUtils.showToast(mView.getContext().getString(R.string.update_no_data));
                        mView.showUpdateDialog(false, null);
                    }
                }));
    }
}
