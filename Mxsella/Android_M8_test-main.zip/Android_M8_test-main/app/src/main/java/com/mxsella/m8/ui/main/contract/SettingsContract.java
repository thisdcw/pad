package com.mxsella.m8.ui.main.contract;

import com.mxsella.m8.base.BaseContract;
import com.mxsella.m8.bean.UpdateInfo;

public interface SettingsContract {

    interface Presenter extends BaseContract.Presenter {

        void requestUpdate();

    }

    interface View extends BaseContract.View<Presenter> {

        void showUpdateDialog(boolean haveUpdate, UpdateInfo updateInfo);

    }
}
