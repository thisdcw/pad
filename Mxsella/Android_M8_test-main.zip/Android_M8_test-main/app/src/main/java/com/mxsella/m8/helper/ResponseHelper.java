package com.mxsella.m8.helper;

import android.text.TextUtils;

import com.mxsella.m8.R;
import com.mxsella.m8.application.MyApplication;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.ToastUtils;

public class ResponseHelper {

    public static <T> boolean deal(String name, BaseResponse<T> data) {
        LocalLog.varTest(name, data.toString());
        // 登录过期
        if (data.getCode() == Constants.UNAUTHORIZED) {
            ToastUtils.showToast(MyApplication.getInstance().getString(R.string.toast_login_expire));
            Config.logout();
            return false;
        }
        if (!TextUtils.isEmpty(data.getMessage())) {
            ToastUtils.showToast(data.getMessage());
        }
        return true;
    }

}
