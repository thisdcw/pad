package com.mxsella.m8.view.dialog;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.mxsella.m8.utils.DensityUtil;

import me.jessyan.autosize.AutoSize;

public class DateChooseDialog extends DatePickerDialog {

    private Context context;

    public DateChooseDialog(@NonNull Context context, int themeResId, @Nullable OnDateSetListener listener, int year, int monthOfYear, int dayOfMonth) {
        super(context, themeResId, listener, year, monthOfYear, dayOfMonth);
        this.context = context;
    }

    /*private Context mContext;

    private NumberPicker yearPicker;
    private NumberPicker monthPicker;
    private NumberPicker dayPicker;

    public DateChooseDialog(Context context) {
        super(context);
        this.mContext = context;
        Calendar calendar = Calendar.getInstance();
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_date_choose, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        Calendar calendar = Calendar.getInstance();
        int yearNow = calendar.get(Calendar.YEAR);
        int monthNow = calendar.get(Calendar.MONTH) + 1;
        int dayNow = calendar.get(Calendar.DAY_OF_MONTH);

        yearPicker = (NumberPicker) findViewById(R.id.number_picker_year);
        monthPicker = (NumberPicker) findViewById(R.id.number_picker_month);
        dayPicker = (NumberPicker) findViewById(R.id.number_picker_day);

        // 设置年份范围为当前年份至前100年
        yearPicker.setMaxValue(yearNow);
        yearPicker.setMinValue(yearNow - 100);
        yearPicker.setValue(yearNow);
        yearPicker.setWrapSelectorWheel(false);

        // 设置月份范围为1-12
        monthPicker.setMinValue(1);
        monthPicker.setMaxValue(12);
        monthPicker.setValue(monthNow);
        monthPicker.setWrapSelectorWheel(true);

        // 根据年月计算当前天数范围
        dayPicker.setMinValue(1);
        dayPicker.setMaxValue(calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        dayPicker.setValue(dayNow);
        dayPicker.setWrapSelectorWheel(true);

        //为年份和月份设置监听
        yearPicker.setOnValueChangedListener(this);
        monthPicker.setOnValueChangedListener(this);

        findViewById(R.id.date_choose_confirm).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        *//*if (mDateSetListener != null) {
                            mDatePicker.clearFocus();
                            mDateSetListener.onDateSet(mDatePicker, mDatePicker.getYear(),
                                    mDatePicker.getMonth(), mDatePicker.getDayOfMonth());
                        }*//*
                    }
                });
        findViewById(R.id.date_choose_cancel).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dismiss();
                    }
                });
    }

    @Override
    public void onValueChange(NumberPicker numberPicker, int i, int i1) {
        String dateStr = String.format(Locale.CHINA, "%d-%d", yearPicker.getValue(), monthPicker.getValue());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM", Locale.CHINA);
        Calendar calendar = Calendar.getInstance();
        try {
            calendar.setTime(simpleDateFormat.parse(dateStr));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        int dateValue = dayPicker.getValue();
        int maxValue = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        dayPicker.setMaxValue(maxValue);
        //重设日期值，防止月份变动时超过最大值
        dayPicker.setValue(Math.min(dateValue, maxValue));
    }

    public void setWidth(int width) {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.width = width;
        getWindow().setAttributes(params);
    }

    public void setHeight(int height) {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.height = height;
        getWindow().setAttributes(params);
    }*/
}
