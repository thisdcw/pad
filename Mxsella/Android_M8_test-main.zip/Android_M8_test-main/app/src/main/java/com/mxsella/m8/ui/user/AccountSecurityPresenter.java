package com.mxsella.m8.ui.user;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.net.LoginService;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;
import com.mxsella.m8.utils.ToastUtils;

public class AccountSecurityPresenter extends BasePresenter<AccountSecurityContract.View>
    implements AccountSecurityContract.Presenter {

    private static final String TAG = "AccountSecurityPresenter";

    public AccountSecurityPresenter(AccountSecurityContract.View view) {
        super(view);
    }

    @Override
    public void getVerifyCode(String telephone) {
        addDisposable(NormalService.getApi().getVerifyCode(telephone)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("AccountSecurity getVerifyCode", data) && data.getCode() == Constants.SUCCESS) {
                            ToastUtils.showToast(data.getData());
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }

    @Override
    public void deleteAccount(String verifyCode) {
        addDisposable(LoginService.getApi().deleteAccount(verifyCode)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<String>>() {
                    @Override
                    public void onSuccess(BaseResponse<String> data) {
                        if (ResponseHelper.deal("AccountSecurity deleteAccount", data) && data.getCode() == Constants.SUCCESS) {
                            ToastUtils.showToast(mView.getContext().getString(R.string.toast_delete_account_success));
                            Config.logout();
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }
}
