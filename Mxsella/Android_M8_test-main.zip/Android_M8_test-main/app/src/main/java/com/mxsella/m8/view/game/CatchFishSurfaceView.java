package com.mxsella.m8.view.game;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

import com.mxsella.m8.R;
import com.mxsella.m8.helper.ResourceHelper;
import com.mxsella.m8.ui.game.GameCallback;
import com.mxsella.m8.view.game.bean.Role;
import com.mxsella.m8.view.game.control.CatchFishControl;

public class CatchFishSurfaceView extends SurfaceView
        implements SurfaceHolder.Callback, Runnable, GameCallback.ICommon {

    private static final String TAG = "CatchFishSurfaceView";

    private  Context mContext;

    private Canvas mCanvas;
    private SurfaceHolder mHolder;
    private boolean isStop = true;
    private boolean isPause = true;
    private Paint mPaint;
    private int screenW, screenH;
    private Bitmap bgBitmap, sharkBitmap;
    private Bitmap[] fishBitmaps;
    private CatchFishControl fishControl = null;
    private GameCallback.IProcess callback = null;
    private Thread workThread;
    private long refreshTime = 50;

    public CatchFishSurfaceView(Context context) {
        super(context);
        init(context);
    }

    public CatchFishSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public CatchFishSurfaceView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        this.mContext = context;

        this.mHolder = getHolder();
        mHolder.addCallback(this);
        this.mPaint = new Paint();
    }

    public void setCallback(GameCallback.IProcess callback) {
        this.callback = callback;
    }

    public void setLocation(int data) {
        if (isPause) return;
        if (fishControl != null && sharkBitmap != null) {
            fishControl.setPercentLocation(data / 100f);
        }
    }

    @Override
    public int getTestMedia() {
        return ResourceHelper.getRawByName(mContext, "game_test_fish");
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        workThread = new Thread(this);
        workThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        this.screenW = width;
        this.screenH = height;
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        isStop = true;
        isPause = true;
        if (workThread != null) {
            workThread.interrupt();
            workThread = null;
        }
        if (bgBitmap != null) {
            bgBitmap.recycle();
            bgBitmap = null;
        }
        if (sharkBitmap != null) {
            sharkBitmap.recycle();
            sharkBitmap = null;
        }
        if(fishBitmaps != null) {
            for(Bitmap bitmap : fishBitmaps)
                bitmap.recycle();
            fishBitmaps = null;
        }
    }

    public void start() {
        this.isStop = false;
        this.isPause = false;
        if (fishControl != null) {
            fishControl.initValue();
        }
    }

    @Override
    public void reset() {
        if (fishControl != null) {
            fishControl.resetGame();
        }
    }

    public void finish() {
        if (callback != null) {
            callback.end();
        }
        if (mHolder != null) {
            surfaceDestroyed(mHolder);
            mHolder.removeCallback(this);
        }
        setVisibility(View.GONE);
    }

    public void setPause(boolean pause) {
        isPause = pause;
        if (fishControl != null) {
            fishControl.setPause(pause);
        }
    }

    public boolean isPause() {
        return isPause;
    }

    @Override
    public void run() {
        try {
            while (isStop) {
                this.mCanvas = mHolder.lockCanvas();
                try {
                    if (bgBitmap == null || bgBitmap.isRecycled()) {
                        bgBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ico_fish_bg);
                    }
                    mCanvas.drawBitmap(bgBitmap, new Rect(0, 0, bgBitmap.getWidth(), bgBitmap.getHeight()),
                            new Rect(0, 0, screenW, screenH), mPaint);
                    drawShark();
                } finally {
                    if (mCanvas != null) {
                        mHolder.unlockCanvasAndPost(mCanvas);
                    }
                }
                Thread.sleep(refreshTime * 10);
            }
            callback.init();
            while (!isStop) {
                long t1 = System.currentTimeMillis();
                draw();
                long t2 = System.currentTimeMillis() - t1;
                if (t2 < refreshTime) {
                    Thread.sleep(refreshTime - t2);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void draw() {
        if (isStop) return;
        this.mCanvas = mHolder.lockCanvas();
        try {
            logic();
        } finally {
            if (mCanvas != null) {
                mHolder.unlockCanvasAndPost(mCanvas);
            }
        }
    }

    private void logic() {
        if (mCanvas != null) {
            drawBg();
            drawFish();
            drawShark();
        }
    }

    private void drawBg() {
        if (bgBitmap == null || bgBitmap.isRecycled()) {
            bgBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ico_fish_bg);
        }
        mCanvas.drawBitmap(bgBitmap, new Rect(0, 0, bgBitmap.getWidth(), bgBitmap.getHeight()),
                new Rect(0, 0, screenW, screenH), mPaint);
    }

    private void drawShark() {
        if (sharkBitmap == null || sharkBitmap.isRecycled()) {
            sharkBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ico_fish_shark);
        }
        if(fishBitmaps == null || fishBitmaps[0].isRecycled()) {
            fishBitmaps = new Bitmap[CatchFishControl.ROLE_SIZE];
            for(int i = 0; i < CatchFishControl.ROLE_SIZE; i++) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("ico_fish_list_" + i, "mipmap", mContext.getPackageName()));
                fishBitmaps[i] = bitmap;
            }
        }
        if (fishControl == null) {
            fishControl = new CatchFishControl(screenW, screenH, sharkBitmap, fishBitmaps);
            fishControl.setRoleListener(new CatchFishControl.RoleListener() {
                @Override
                public void touch(Role role, int score) {
                    if (callback != null) {
                        callback.score(score);
                    }
                }
            });
        }
        mCanvas.drawBitmap(sharkBitmap, new Rect(0, 0, sharkBitmap.getWidth(), sharkBitmap.getHeight()), fishControl.getPlayerRect(), mPaint);
    }

    private void drawFish() {
        if (fishControl == null || isStop) return;
        if (!isPause)
            fishControl.calculateRoleRect();
        for (Role role : fishControl.getRoleList()) {
            if (isStop) return;
            Bitmap bitmap = fishBitmaps[role.getType()];
            RectF rectF = new RectF(role.getCenterX() - role.getSize().getWidth() / 2, role.getCenterY() - role.getSize().getHeight() / 2,
                    role.getCenterX() + role.getSize().getWidth() / 2, role.getCenterY() + role.getSize().getHeight() / 2);
            mCanvas.drawBitmap(bitmap, new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight()), rectF, mPaint);
        }
    }

}
