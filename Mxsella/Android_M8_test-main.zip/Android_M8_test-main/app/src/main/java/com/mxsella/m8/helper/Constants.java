package com.mxsella.m8.helper;

public class Constants {

    public static final int SUCCESS = 200;
    public static final int FAIL = 400;
    public static final int UNAUTHORIZED = 401;

    public static final int DEFAULT_SEC_NUM = 10;
    public static final int MAX_ASSESS_TIME = 150 * 2;
}
