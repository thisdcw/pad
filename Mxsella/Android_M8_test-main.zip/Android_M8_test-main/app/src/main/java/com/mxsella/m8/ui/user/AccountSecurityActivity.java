package com.mxsella.m8.ui.user;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.utils.StringUtils;
import com.mxsella.m8.utils.ToastUtils;
import com.mxsella.m8.view.dialog.DeleteAccountDialog;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import butterknife.BindView;
import butterknife.OnClick;

public class AccountSecurityActivity extends BaseMvpActivity<AccountSecurityContract.Presenter> implements AccountSecurityContract.View {

    @Override
    public int getLayoutId() {
        return R.layout.activity_accout_security;
    }

    @Override
    protected AccountSecurityContract.Presenter initPresenter() {
        return new AccountSecurityPresenter(this);
    }

    @BindView(R.id.tv_telephone)
    TextView tvTelephone;

    private ExecutorService verifyCodeThread = Executors.newSingleThreadExecutor();

    private DeleteAccountDialog deleteAccountDialog;
    private String sendAgainFormat;
    private int sendAgainTime = 0;

    public static void show(Context context) {
        Intent intent = new Intent(context, AccountSecurityActivity.class);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();

        tvTelephone.setText(StringUtils.encryptTelephone(Config.curUser.getTelephone()));

        deleteAccountDialog = new DeleteAccountDialog(this);
        deleteAccountDialog.setGetVerifyCodeClickListener(v -> {
            mPresenter.getVerifyCode(Config.curUser.getTelephone());
            deleteAccountDialog.updateGetVerifyCodeState(false);
            sendAgainTime = 60;
            verifyCodeThread.execute(verifyCodeTimer);
        });
        deleteAccountDialog.setConfirmClickListener(v -> {
            if(deleteAccountDialog.getVerifyCode().length() < 6) {
                ToastUtils.showToast(getString(R.string.toast_enter_valid_verify));
            } else {
                mPresenter.deleteAccount(deleteAccountDialog.getVerifyCode());
            }
        });
        sendAgainFormat = getString(R.string.login_send_verify_time);
    }

    @OnClick({ R.id.llt_change_telephone, R.id.llt_change_password, R.id.llt_delete_account })
    public void onClick(View view){
        switch (view.getId()) {
            case R.id.llt_change_telephone:
                ChangeTelephoneActivity.show(this);
                break;
            case R.id.llt_change_password:
                ChangePasswordActivity.show(this);
                break;
            case R.id.llt_delete_account:
                if (deleteAccountDialog != null && !deleteAccountDialog.isShowing())
                    deleteAccountDialog.show();
                break;
        }
    }

    private Runnable verifyCodeTimer = () -> {
        while (sendAgainTime > 0) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (deleteAccountDialog == null)
                return;
            sendAgainTime--;
            if (sendAgainTime <= 0) {
                runOnUiThread(()->{
                    sendAgainTime = 0;
                    deleteAccountDialog.updateGetVerifyCodeState(true);
                    deleteAccountDialog.updateGetVerifyCode(getString(R.string.login_send_verify));
                });
                return;
            }
            runOnUiThread(()->{
                if (deleteAccountDialog != null) {
                    deleteAccountDialog.updateGetVerifyCode(String.format(sendAgainFormat, sendAgainTime));
                }
            });
        }
    };

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }
}