package com.mxsella.m8.ui.adpter;

import android.graphics.Color;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.mxsella.m8.R;
import com.mxsella.m8.bean.BleDeviceInfo;

import java.util.List;

public class BleAdapter extends BaseQuickAdapter<BleDeviceInfo, BaseViewHolder> {

    public BleAdapter(@Nullable List<BleDeviceInfo> data) {
        super(R.layout.item_ble, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, BleDeviceInfo item) {
        int position = helper.getAdapterPosition();
        helper.setText(R.id.tv_ble_name, item.getDeviceName());
        helper.setTextColor(R.id.tv_ble_name, mContext.getResources().getColor(item.getConnectState() ? R.color.theme_color : R.color.black));
        helper.setText(R.id.tv_ble_state, item.getConnectState() ? mContext.getString(R.string.ble_connected) : mContext.getString(R.string.ble_not_connected));
        helper.setTextColor(R.id.tv_ble_state, item.getConnectState() ? mContext.getResources().getColor(R.color.theme_color) : Color.parseColor("#7f7f7f"));
    }
}
