package com.mxsella.m8.ui.user;

import com.google.gson.Gson;
import com.mxsella.m8.base.BasePresenter;
import com.mxsella.m8.bean.User;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.Constants;
import com.mxsella.m8.helper.ResponseHelper;
import com.mxsella.m8.net.BaseObserver;
import com.mxsella.m8.bean.BaseResponse;
import com.mxsella.m8.net.LoginService;
import com.mxsella.m8.net.NormalService;
import com.mxsella.m8.net.RxScheduler;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class UserInfoPresenter extends BasePresenter<UserInfoContract.View>
    implements UserInfoContract.Presenter {

    private static final String TAG = "UserInfoPresenter";

    public UserInfoPresenter(UserInfoContract.View view) {
        super(view);
    }

    @Override
    public void register(String telephone, String userName, String birthday, String password, File avatar) {
        RequestBody requestBody = avatar == null ? RequestBody.create(MediaType.parse("multipart/form-data"), new byte[]{}) :
                RequestBody.create(MediaType.parse("multipart/form-data"), avatar);
        MultipartBody.Part body = MultipartBody.Part.createFormData("avatar", "avatar.jpg", requestBody);
        addDisposable(NormalService.getApi().register(telephone, userName, birthday, password, body)
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<User>>() {
                    @Override
                    public void onSuccess(BaseResponse<User> data) {
                        if (ResponseHelper.deal("UserInfo register", data) && data.getCode() == Constants.SUCCESS) {
                            Config.saveLoginUser(data.getData());
                            mView.registerResult(true);
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }

    @Override
    public void changeUserInfo(User user, File avatar) {
        RequestBody requestBody = avatar == null ? RequestBody.create(MediaType.parse("multipart/form-data"), new byte[]{}) :
                RequestBody.create(MediaType.parse("multipart/form-data"), avatar);
        MultipartBody.Builder builder = new MultipartBody.Builder();
        builder.addFormDataPart("user", new Gson().toJson(user));
        builder.addFormDataPart("avatar", "avatar.jpg", requestBody);
        addDisposable(LoginService.getApi().changeUserInfo(builder.build().parts())
                .compose(RxScheduler.obserThreadTransformer())
                .subscribeWith(new BaseObserver<BaseResponse<User>>() {
                    @Override
                    public void onSuccess(BaseResponse<User> data) {
                        if (ResponseHelper.deal("UserInfo changeUserInfo", data) && data.getCode() == Constants.SUCCESS) {
                            Config.saveLoginUser(data.getData());
                            mView.changeResult(true);
                        }
                    }

                    @Override
                    public void onFail(String errorMsg) {
                        super.onFail(errorMsg);
                    }
                }));
    }
}
