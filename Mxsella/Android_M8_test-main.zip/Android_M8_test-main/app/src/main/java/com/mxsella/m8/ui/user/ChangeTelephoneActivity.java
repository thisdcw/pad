package com.mxsella.m8.ui.user;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseMvpActivity;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.utils.ToastUtils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import butterknife.BindView;
import butterknife.OnClick;

public class ChangeTelephoneActivity extends BaseMvpActivity<ChangeTelephoneContract.Presenter> implements ChangeTelephoneContract.View {

    @Override
    public int getLayoutId() {
        return R.layout.activity_change_telephone;
    }

    @Override
    protected ChangeTelephoneContract.Presenter initPresenter() {
        return new ChangeTelephonePresenter(this);
    }

    @BindView(R.id.edt_telephone)
    EditText edtTelephone;
    @BindView(R.id.edt_verify_code)
    EditText edtVerifyCode;
    @BindView(R.id.tv_get_verify_code)
    TextView tvGetVerifyCode;

    private InputMethodManager manager;
    private ExecutorService verifyCodeThread = Executors.newSingleThreadExecutor();

    private String sendAgainFormat;
    private int sendAgainTime = 0;

    public static void show(Context context) {
        Intent intent = new Intent(context, ChangeTelephoneActivity.class);
        context.startActivity(intent);
    }

    @Override
    public void initView() {
        super.initView();

        manager = ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE));
        setFocusChangeListener(edtTelephone);
        setFocusChangeListener(edtVerifyCode);

        sendAgainFormat = getString(R.string.login_send_verify_time);
    }

    @OnClick({R.id.tv_get_verify_code, R.id.btn_confirm})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_get_verify_code:
                if(edtTelephone.getText().toString().length() != 11) {
                    ToastUtils.showToast(getString(R.string.toast_enter_valid_telephone));
                    return;
                }
                mPresenter.getVerifyCode(edtTelephone.getText().toString());
                tvGetVerifyCode.setEnabled(false);
                sendAgainTime = 60;
                verifyCodeThread.execute(verifyCodeTimer);
                break;
            case R.id.btn_confirm:
                if(edtTelephone.getText().toString().length() != 11) {
                    ToastUtils.showToast(getString(R.string.toast_enter_valid_telephone));
                    return;
                }
                if(edtVerifyCode.getText().toString().length() < 6) {
                    ToastUtils.showToast(getString(R.string.toast_enter_valid_password));
                    return;
                }
                mPresenter.verifyCodeChangeTelephone(edtTelephone.getText().toString(), edtVerifyCode.getText().toString());
                break;
        }
    }

    @Override
    public void verifyCodeChangeTelephoneResult(boolean result, String msg) {
        ToastUtils.showToast(msg);
        if(result) {
            Config.logout();
        }
    }

    private Runnable verifyCodeTimer = () -> {
        while (sendAgainTime > 0) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (tvGetVerifyCode == null)
                return;
            sendAgainTime--;
            if (sendAgainTime <= 0) {
                runOnUiThread(()->{
                    sendAgainTime = 0;
                    tvGetVerifyCode.setEnabled(true);
                    tvGetVerifyCode.setText(getString(R.string.login_send_verify));
                });
                return;
            }
            runOnUiThread(()->{
                if (tvGetVerifyCode != null) {
                    tvGetVerifyCode.setText(String.format(sendAgainFormat, sendAgainTime));
                }
            });
        }
    };

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }

    public void setFocusChangeListener(EditText editText){
        editText.setOnFocusChangeListener((view, b) -> {
            if(!b){
                if (manager != null) {
                    manager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
            }
        });
    }
}