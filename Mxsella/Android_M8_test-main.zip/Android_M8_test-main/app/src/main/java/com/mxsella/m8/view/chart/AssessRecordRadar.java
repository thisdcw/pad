package com.mxsella.m8.view.chart;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.Layout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

import com.mxsella.m8.R;
import com.mxsella.m8.utils.DensityUtil;

import java.util.ArrayList;
import java.util.List;

public class AssessRecordRadar extends View {

    private Context context;

    private float width = 0;
    private float height = 0;
    private float titleSize;
    private Path path;
    private Paint titlePaint, chartPaint, normalPaint, dataPaint;
    private TextPaint textPaint;
    private List<String> titleList = new ArrayList<>();
    private List<Integer> normalList = new ArrayList<>();
    private List<Integer> dataList = new ArrayList<>();

    public AssessRecordRadar(Context context) {
        super(context);
        this.context = context;
        init();
    }

    public AssessRecordRadar(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        init();
    }

    public AssessRecordRadar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        init();
    }

    private void init() {
        path = new Path();

        titlePaint = new Paint();
        titlePaint.setAntiAlias(true);
        titlePaint.setPathEffect(null);
        titlePaint.setStyle(Paint.Style.FILL);
        titlePaint.setColor(context.getResources().getColor(R.color.theme_color));
        titlePaint.setAlpha(255);

        chartPaint = new Paint();
        chartPaint.setAntiAlias(true);
        chartPaint.setPathEffect(null);
        chartPaint.setStyle(Paint.Style.STROKE);
        chartPaint.setStrokeWidth(DensityUtil.dip2px(context, 1f));
        chartPaint.setColor(context.getResources().getColor(R.color.assess_record_radar_line));

        normalPaint = new Paint();
        normalPaint.setAntiAlias(true);
        normalPaint.setPathEffect(null);
        normalPaint.setStrokeWidth(DensityUtil.dip2px(context, 1f));
        normalPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        normalPaint.setColor(context.getResources().getColor(R.color.assess_record_radar_1));
        normalPaint.setAlpha(128);

        dataPaint = new Paint();
        dataPaint.setAntiAlias(true);
        dataPaint.setPathEffect(null);
        dataPaint.setStrokeWidth(DensityUtil.dip2px(context, 2f));
        dataPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        dataPaint.setColor(context.getResources().getColor(R.color.assess_record_radar_2));
        dataPaint.setAlpha(51);

        textPaint = new TextPaint();
        textPaint.setAntiAlias(true);
        textPaint.setPathEffect(null);
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void initData(List<String> titleList, List<Integer> normalList, List<Integer> dataList){
        this.titleList = titleList;
        this.normalList = normalList;
        this.dataList = dataList;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        width = getMeasuredWidth();
        height = getMeasuredHeight();
        titleSize = DensityUtil.dip2px(context, 45);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        drawTitle(canvas);
        drawNet(canvas);
        drawLine(canvas);
        drawNormal(canvas);
        drawData(canvas);
    }

    private void drawTitle(Canvas canvas) {
        if(titleList.size() != 4) {
            return;
        }
        float offset;
        float bpW = DensityUtil.dip2px(32f) / 2f;
        float bpH = DensityUtil.dip2px(14f) / 2f;
        for(int i = 0; i < 4; i++) {
            float centerX = 0f;
            float centerY = 0f;

            switch (i) {
                case 0:
                    centerX = titleSize / 2;
                    centerY = height / 2;
                    break;
                case 1:
                    centerX = width / 2;
                    centerY = titleSize / 2;
                    break;
                case 2:
                    centerX = width - titleSize / 2;
                    centerY = height / 2;
                    break;
                case 3:
                    centerX = width / 2;
                    centerY = height - titleSize / 2;
                    break;
            }
            offset = (i == 1 ? -1 : 1) * DensityUtil.dip2px(8f);

            textPaint.setTextSize(DensityUtil.dip2px(context, 12f));
            textPaint.setColor(Color.BLACK);
            canvas.drawText(titleList.get(i), centerX, centerY - offset + getDistance(textPaint), textPaint);
            canvas.drawRoundRect(centerX - bpW, centerY - bpH + offset, centerX + bpW, centerY + bpH + offset,
                    DensityUtil.dip2px(context, 2f), DensityUtil.dip2px(context, 2f), titlePaint);
            textPaint.setTextSize(DensityUtil.dip2px(context, 10f));
            textPaint.setColor(Color.WHITE);
            canvas.drawText(String.valueOf(dataList.get(i)), centerX, centerY + offset + getDistance(textPaint), textPaint);
        }
    }

    private void drawNormal(Canvas canvas) {
        normalPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        normalPaint.setAlpha(128);
        if(normalList.size() != 4) {
            return;
        }
        for(int i = 0; i < 5; i++) {
            pathToGrade(path, i, normalList.get(i % 4));
        }
        canvas.drawPath(path, normalPaint);
    }

    private void drawNet(Canvas canvas) {
        normalPaint.setStyle(Paint.Style.STROKE);
        normalPaint.setAlpha(255);
        for (int i = 0; i < 5; i++) {
            for(int j = 0; j < 5; j++) {
                pathToGrade(path, j, (i + 1) * 20);
            }
            canvas.drawPath(path, normalPaint);
        }
    }

    private void drawLine(Canvas canvas) {
        path.reset();
        canvas.drawLine(titleSize, height / 2, width - titleSize, height / 2, chartPaint);
        canvas.drawLine(width / 2, titleSize, width / 2, height - titleSize, chartPaint);
    }

    private void drawData(Canvas canvas) {
        if(dataList.size() != 4) {
            return;
        }
        dataPaint.setColor(context.getResources().getColor(R.color.assess_record_radar_2));
        dataPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        dataPaint.setAlpha(51);
        for(int i = 0; i < 5; i++) {
            pathToGrade(path, i, dataList.get(i % 4));
        }
        canvas.drawPath(path, dataPaint);

        dataPaint.setColor(context.getResources().getColor(R.color.theme_color));
        dataPaint.setStyle(Paint.Style.STROKE);
        dataPaint.setAlpha(255);
        for(int i = 0; i < 5; i++) {
            pathToGrade(path, i, dataList.get(i % 4));
        }
        canvas.drawPath(path, dataPaint);

        for(int i = 0; i < 4; i++) {
            circleOfGrade(canvas, dataPaint, i, dataList.get(i));
        }
    }

    private void pathToGrade(Path path, int type, float grade) {
        float data = (width / 2 - titleSize) * grade / 100;
        switch (type) {
            case 0:
                path.reset();
                path.moveTo(width / 2 - data, height / 2);
                break;
            case 1:
                path.lineTo(width / 2, height / 2 - data);
                break;
            case 2:
                path.lineTo(width / 2 + data, height / 2);
                break;
            case 3:
                path.lineTo(width / 2, height / 2 + data);
                break;
            case 4:
                path.lineTo(width / 2 - data, height / 2);
                break;
        }
    }

    private void circleOfGrade(Canvas canvas, Paint paint, int type, float grade) {
        float data = (width / 2 - titleSize) * grade / 100;
        float x = 0f;
        float y = 0f;
        switch (type) {
            case 0:
                x = width / 2 - data;
                y = height / 2;
                break;
            case 1:
                x = width / 2;
                y = height / 2 - data;
                break;
            case 2:
                x = width / 2 + data;
                y = height / 2;
                break;
            case 3:
                x = width / 2;
                y = height / 2 + data;
                break;
        }
        Paint whitePaint = new Paint();
        whitePaint.setStyle(Paint.Style.FILL);
        whitePaint.setColor(Color.WHITE);
        // canvas.drawCircle(x, y, DensityUtil.dip2px(2.5f), whitePaint);
        canvas.drawCircle(x, y, DensityUtil.dip2px(2.5f), paint);
    }

    private static int getDistance(Paint paint){
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        return (int) ((fontMetrics.bottom - fontMetrics.top) / 2 - fontMetrics.bottom);
    }
}
