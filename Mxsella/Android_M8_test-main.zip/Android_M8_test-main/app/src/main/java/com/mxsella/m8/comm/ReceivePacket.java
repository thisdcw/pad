package com.mxsella.m8.comm;

import com.mxsella.m8.helper.HardwareHelper;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.utils.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ReceivePacket {

    private static final String TAG = "ReceivePacket";
    public static final String TYPE_ACK = "ack";
    public static final String TYPE_HARDWARE = "hardware";
    public static final String TYPE_DATA = "data";
    public static final String TYPE_DATA_NEW = "data new";
    public static final String TYPE_QUERY_STATE = "query state";
    public static final String TYPE_ELECTRIC_HZ = "electric hz";
    public static final String TYPE_ELECTRIC_POWER = "electric power";
    public static final String TYPE_ELECTRIC_TIME = "electric time";
    public static final String TYPE_ELECTRIC_IRRITATE = "electric irritate";
    public static final String TYPE_ELECTRIC_RELAX = "electric relax";
    public static final String TYPE_LOW_CHARGE = "low charge";
    public static final String TYPE_UNKNOWN = "unknown";
    private byte[] bytes;
    private String type;
    private byte from;
    private int len;
    private short mode;
    private short addr;
    private List<Integer> dataList = new ArrayList<>();

    public ReceivePacket(byte[] bytes) {
        this.bytes = bytes;
        this.from = bytes[0];
        this.len = bytes.length;
        this.addr = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes, 1, 3));
        boolean isAck = Protocol.endWith(Arrays.copyOfRange(bytes, len - 2, len), Protocol.short2Bytes(Protocol.ACK));
        if (isAck) {
            this.type = TYPE_ACK;
            if (len < 7) return;
            this.mode = (short) Protocol.bytesToInt(Arrays.copyOfRange(bytes,3, 5));
        } else {
            if(from == Protocol.DEVICE_TO_CLIENT) {
                if (addr == Protocol.ADDR_HARDWARE){
                    this.type = TYPE_HARDWARE;
                    for(int i = 0; i < 4; i++) {
                        dataList.add(Protocol.bytesToInt(Arrays.copyOfRange(bytes, 3 + i, 3 + i + 1)));
                    }
                    HardwareHelper.saveVersion(dataList);
                }
                if (addr == Protocol.ADDR_COLLECT_DATA) {
                    this.type = TYPE_DATA;
                    for(int i = 0; i < 10; i++) {
                        dataList.add(Protocol.bytesToInt(Arrays.copyOfRange(bytes, 3 + i * 2, 3 + i * 2 + 2)));
                    }
                } else if (Protocol.endWith(Arrays.copyOfRange(bytes, 1, 3), Protocol.short2Bytes(Protocol.ADDR_COLLECT_DATA_NEW))) {
                    this.type = TYPE_DATA_NEW;
                    for(int i = 0; i < 3; i++) {
                        dataList.add(Protocol.bytesToInt(Arrays.copyOfRange(bytes, 3 + i * 2, 3 + i * 2 + 2)));
                    }
                } else if (addr == Protocol.ADDR_QUERY_STATE) {
                    this.type = TYPE_QUERY_STATE;
                    for(int i = 0; i < 4; i++) {
                        dataList.add(Protocol.bytesToInt(Arrays.copyOfRange(bytes, 3 + i * 2, 3 + i * 2 + 2)));
                    }
                } else if (addr == Protocol.ADDR_LOW_CHARGE) {
                    this.type = TYPE_LOW_CHARGE;
                    dataList.add(Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len)));
                } else if (addr == Protocol.ADDR_ELECTRIC_HZ) {
                    this.type = TYPE_ELECTRIC_HZ;
                    dataList.add(Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len)));
                } else if (addr == Protocol.ADDR_ELECTRIC_POWER) {
                    // 部分固件指令有误（5810发成5510）
                    if (len == 7) {
                        this.type = TYPE_HARDWARE;
                        for(int i = 0; i < 4; i++) {
                            dataList.add(Protocol.bytesToInt(Arrays.copyOfRange(bytes, 3 + i, 3 + i + 1)));
                        }
                        HardwareHelper.saveVersion(dataList);
                    } else {
                        this.type = TYPE_ELECTRIC_POWER;
                        dataList.add(Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len)));
                    }
                } else if (addr == Protocol.ADDR_ELECTRIC_TIME) {
                    this.type = TYPE_ELECTRIC_TIME;
                    dataList.add(Protocol.bytesToInt(Arrays.copyOfRange(bytes, len - 2, len)));
                } else if (addr == Protocol.ADDR_ELECTRIC_IRRITATE) {
                    this.type = TYPE_ELECTRIC_IRRITATE;
                } else if (addr == Protocol.ADDR_ELECTRIC_RELAX) {
                    this.type = TYPE_ELECTRIC_RELAX;
                }
            }
        }
        if (type == null) {
            type = TYPE_UNKNOWN;
        }
    }

    public byte[] getBytes() {
        return bytes;
    }

    public void setBytes(byte[] bytes) {
        this.bytes = bytes;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public byte getFrom() {
        return from;
    }

    public void setFrom(byte from) {
        this.from = from;
    }

    public int getLen() {
        return len;
    }

    public void setLen(int len) {
        this.len = len;
    }

    public short getMode() {
        return mode;
    }

    public void setMode(short mode) {
        this.mode = mode;
    }

    public short getAddr() {
        return addr;
    }

    public void setAddr(short addr) {
        this.addr = addr;
    }

    public List<Integer> getDataList() {
        return dataList;
    }

    public void setDataList(List<Integer> dataList) {
        this.dataList = dataList;
    }
}
