package com.mxsella.m8.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;
import com.mxsella.m8.utils.DensityUtil;
import com.mxsella.m8.utils.MediaHelper;

public class MediaDialog extends Dialog {

    private final Context context;

    private TextView tvStage, tvSkip;
    private boolean canSkip;

    public MediaDialog(@NonNull Context context) {
        super(context, R.style.Dialog);
        this.context = context;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_media, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        tvStage = view.findViewById(R.id.tv_stage);
        tvSkip = view.findViewById(R.id.tv_skip);
    }

    @Override
    public boolean onTouchEvent(@NonNull MotionEvent event) {
        if (isShowing()) {
            //dismiss();
            if(canSkip)
                MediaHelper.skip();
        }
        return super.onTouchEvent(event);
    }

    public void setContent(String content) {
        tvStage.setText(content);
    }

    public void show(String stage, boolean canSkip) {
        this.canSkip = canSkip;
        tvStage.setText(stage);
        tvSkip.setVisibility(canSkip ? View.VISIBLE : View.GONE);
        setCanceledOnTouchOutside(canSkip);
        setCancelable(false);
        show();
    }

    public void show(String stage, String skipText, boolean canSkip) {
        tvSkip.setText(skipText);
        show(stage, canSkip);
    }
}
