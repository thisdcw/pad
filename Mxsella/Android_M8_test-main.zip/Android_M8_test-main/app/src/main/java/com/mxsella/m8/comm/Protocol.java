package com.mxsella.m8.comm;

import com.mxsella.m8.utils.StringUtils;

import java.nio.ByteBuffer;

public class Protocol {

    public static final byte DEVICE_TO_CLIENT = (byte) 0x82;
    public static final byte CLIENT_TO_DEVICE = (byte) 0x83;

    public static final short ACK = 0x4F4B;

    public static final short HEAD = 0x5AA5; // 帧头
    public static final short ADDR_HARDWARE = 0x5810; // 固件版本地址
    public static final short ADDR_DATA_SWITCH = 0x3000; // 肌电采集开关地址
    public static final short ADDR_RELAY = 0x4100; // 继电器地址
    public static final short MODE_OFF = 0; // 关
    public static final short MODE_ON = 1; // 开

    public static final short ADDR_COLLECT_DATA = 0x2500; // 采集数据地址
    public static final short ADDR_COLLECT_DATA_NEW = 0x7000; // 新采集数据地址

    public static final short ADDR_QUERY_STATE = 0x5530;  // 状态查询
    public static final short ADDR_LOW_CHARGE = 0x5540;  // 电量不足
    public static final short ADDR_ELECTRIC_POWER = 0x5510;  // 微电能量
    public static final short ADDR_ELECTRIC_MODE = 0x5512;  // 微电模式
    public static final short ADDR_ELECTRIC_TIME = 0x5514;  // 微电工作时间
    public static final short ADDR_ELECTRIC_IRRITATE = 0x5516;  // 刺激状态反馈
    public static final short ADDR_ELECTRIC_RELAX = 0x5518;  // 休息状态反馈
    public static final short ADDR_PRE_HZ = 0x5520;  // 微电预设频率
    public static final short ADDR_ELECTRIC_HZ = 0x5522;  // 微电工作频率

    public static byte[] HAND_SHAKE = StringUtils.hexToByteArray( "5AA50184");
    public static byte[] QUERY_STATE = StringUtils.hexToByteArray( "5AA50683550001005A");
    public static byte[] QUERY_HARDWARE = StringUtils.hexToByteArray( "5AA50683580001005A");

    public static byte[] IMITATE_QUERY_STATE = StringUtils.hexToByteArray("5AA50B8255300002001005000005");
    public static byte[] IMITATE_LOW_POWER = StringUtils.hexToByteArray("5AA5058255400001");
    public static byte[] IMITATE_ELECTRIC_TIME_FORMAT = StringUtils.hexToByteArray("5AA505825514");
    public static byte[] IMITATE_ELECTRIC_IRRITATE = StringUtils.hexToByteArray("5AA503825516");
    public static byte[] IMITATE_ELECTRIC_RELAX = StringUtils.hexToByteArray("5AA503825518");

    public static byte[] encode(short address, short command) {
        StringBuilder sb = new StringBuilder();
        byte len = 1 + 2 + 1 + 2;
        ByteBuffer buffer = ByteBuffer.allocate(9);
        buffer.putShort(HEAD);
        buffer.put(len);
        buffer.put(CLIENT_TO_DEVICE);
        buffer.putShort(address);
        buffer.put((byte) 1);
        buffer.putShort(command);
        sb.append(Integer.toHexString(HEAD))
                .append(String.format("%02x", len))
                .append(String.format("%02x", CLIENT_TO_DEVICE))
                .append(String.format("%04x", address))
                .append(String.format("%02x",  1))
                .append(String.format("%04x", command));
        return buffer.array();
    }

    /**
     * short转字节数组
     */
    public static byte[] short2Bytes(short num) {
        byte[] bytes = new byte[2];
        bytes[0] =  (byte)((num>>8) & 0xFF);
        bytes[1] = (byte)num;
        return bytes;
    }

    /**
     * short数组转字节数组
     */
    public static byte[] shorts2Bytes(short[] shorts) {
        byte[] bytes = new byte[shorts.length * 2];
        byte[] temp = null;
        int i = 0;
        for (short s : shorts) {
            temp = short2Bytes(s);
            bytes[i++] = temp[0];
            bytes[i++] = temp[1];
        }
        return bytes;
    }

    /**
     * 是否相等
     */
    public static boolean endWith(byte[] src, byte[] target) {
        if (target.length == 0) return false;
        if (src.length < target.length) return false;
        for (int i = 0;i < target.length;i++) {
            if (target[target.length - i - 1] != src[src.length - i - 1]) {
                return false;
            }
        }
        return true;
    }

    /**
     * 字节数组转int
     */
    public static int bytesToInt(byte[] bytes) {
        int res = 0;
        for (int i = 0; i < bytes.length; i++) {
            res = (res << 8) | (bytes[i] & 0xff);
        }
        return res;
    }
}
