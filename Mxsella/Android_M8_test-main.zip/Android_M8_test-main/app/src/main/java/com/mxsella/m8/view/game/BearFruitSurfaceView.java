package com.mxsella.m8.view.game;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

import com.mxsella.m8.R;
import com.mxsella.m8.helper.ResourceHelper;
import com.mxsella.m8.ui.game.GameCallback;
import com.mxsella.m8.utils.LocalLog;
import com.mxsella.m8.view.game.bean.Role;
import com.mxsella.m8.view.game.control.BearFruitControl;

public class BearFruitSurfaceView extends  SurfaceView implements
        SurfaceHolder.Callback, Runnable, GameCallback.ICommon {

    private static final String TAG = "BearFruitSurfaceView";

    private  Context mContext;

    private Canvas mCanvas;
    private SurfaceHolder mHolder;
    private boolean isStop = true;
    private boolean isPause = true;
    private Paint mPaint;
    private int screenW, screenH;
    private Bitmap bgBitmap, bearBitmap;
    private Bitmap[] fruitBitmaps;
    private BearFruitControl bearControl = null;
    private GameCallback.IProcess callback = null;
    private Thread workThread;
    private long refreshTime = 50;

    public BearFruitSurfaceView(Context context) {
        super(context);
        init(context);
    }

    public BearFruitSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public BearFruitSurfaceView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        this.mContext = context;

        this.mHolder = getHolder();
        mHolder.addCallback(this);
        this.mPaint = new Paint();
    }

    @Override
    public void setCallback(GameCallback.IProcess processCallback) {
        this.callback = processCallback;
    }

    @Override
    public void setLocation(int data) {
        if (isPause) return;
        if (bearControl != null && bearBitmap != null) {
            bearControl.setPercentLocation(data / 100f);
        }
    }

    @Override
    public int getTestMedia() {
        return ResourceHelper.getRawByName(mContext, "game_test_fruit");
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        workThread = new Thread(this);
        workThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        this.screenW = width;
        this.screenH = height;
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        isStop = true;
        isPause = true;
        if (workThread != null) {
            workThread.interrupt();
            workThread = null;
        }
        if (bgBitmap != null) {
            bgBitmap.recycle();
            bgBitmap = null;
        }
        if (bearBitmap != null) {
            bearBitmap.recycle();
            bearBitmap = null;
        }
        if(fruitBitmaps != null) {
            for(Bitmap bitmap : fruitBitmaps)
                bitmap.recycle();
            fruitBitmaps = null;
        }
    }

    @Override
    public void start() {
        this.isStop = false;
        this.isPause = false;
        if (bearControl != null) {
            bearControl.initValue();
        }
    }

    @Override
    public void reset() {
        if (bearControl != null) {
            bearControl.resetGame();
        }
    }

    @Override
    public void finish() {
        if (callback != null) {
            callback.end();
        }
        if (mHolder != null) {
            surfaceDestroyed(mHolder);
            mHolder.removeCallback(this);
        }
        setVisibility(View.GONE);
    }

    @Override
    public void setPause(boolean pause) {
        this.isPause = pause;
        if (bearControl != null) {
            bearControl.setPause(pause);
        }
    }

    @Override
    public boolean isPause() {
        return isPause;
    }

    @Override
    public void run() {
        try {
            while (isStop) {
                this.mCanvas = mHolder.lockCanvas();
                try {
                    drawBg();
                    drawBear();
                } finally {
                    if (mCanvas != null) {
                        mHolder.unlockCanvasAndPost(mCanvas);
                    }
                }
                Thread.sleep(refreshTime * 10);
            }
            callback.init();
            while (!isStop) {
                long t1 = System.currentTimeMillis();
                draw();
                long t2 = System.currentTimeMillis() - t1;
                if (t2 < refreshTime) {
                    Thread.sleep(refreshTime - t2);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void draw() {
        if (isStop) return;
        this.mCanvas = mHolder.lockCanvas();
        try {
            logic();
        } finally {
            if (mCanvas != null) {
                mHolder.unlockCanvasAndPost(mCanvas);
            }
        }
    }

    private void logic() {
        if (mCanvas != null) {
            drawBg();
            drawBear();
            drawFruit();
        }
    }

    private void drawBg() {
        if (bgBitmap == null || bgBitmap.isRecycled()) {
            bgBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ico_fruit_bg);
        }
        mCanvas.drawBitmap(bgBitmap, new Rect(0, 0, bgBitmap.getWidth(), bgBitmap.getHeight()),
                new Rect(0, 0, screenW, screenH), mPaint);
    }

    private void drawBear() {
        if (bearBitmap == null || bearBitmap.isRecycled()) {
            bearBitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ico_fruit_bear);
        }
        if(fruitBitmaps == null || fruitBitmaps[0].isRecycled()) {
            fruitBitmaps = new Bitmap[BearFruitControl.ROLE_SIZE];
            for(int i = 0; i < BearFruitControl.ROLE_SIZE; i++) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("ico_fruit_list_" + i, "mipmap", mContext.getPackageName()));
                fruitBitmaps[i] = bitmap;
            }
        }
        if (bearControl == null) {
            bearControl = new BearFruitControl(screenW, screenH, bearBitmap, fruitBitmaps);
            bearControl.setRoleListener(new BearFruitControl.RoleListener() {
                @Override
                public void touch(Role role, int score) {
                    if (callback != null) {
                        callback.score(score);
                    }
                }
            });
        }
        mCanvas.drawBitmap(bearBitmap, new Rect(0, 0, bearBitmap.getWidth(), bearBitmap.getHeight()), bearControl.getPlayerRect(), mPaint);
    }

    private void drawFruit() {
        if (bearControl == null || isStop) return;
        if (!isPause)
            bearControl.calculateRoleRect();
        for (Role role : bearControl.getRoleList()) {
            if (isStop) return;
            Bitmap bitmap = fruitBitmaps[role.getType()];
            RectF rectF = new RectF(role.getCenterX() - role.getSize().getWidth() / 2, role.getCenterY() - role.getSize().getHeight() / 2,
                    role.getCenterX() + role.getSize().getWidth() / 2, role.getCenterY() + role.getSize().getHeight() / 2);
            mCanvas.drawBitmap(bitmap, new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight()), rectF, mPaint);
        }
    }

}
