package com.mxsella.m8.ui.game;

public interface GameCallback {

    /***
     * 游戏公共逻辑
     */
    interface ICommon {
        /**
         * 主动开始游戏
         */
        void start();

        /**
         * 重置游戏状态
         */
        void reset();

        /**
         * 退出界面时主动结束与回收资源
         */
        void finish();

        /**
         * 设置是否暂停
         */
        void setPause(boolean pause);

        /**
         * 当前状态
         */
        boolean isPause();

        /**
         * 设置玩家位置
         */
        void setLocation(int location);

        /**
         * 游戏流程回调
         */
        void setCallback(IProcess processCallback);

        /**
         * 获取测试阶段语音
         */
        int getTestMedia();
    }

    /**
     * 游戏流程回调
     */
    interface IProcess {
        void init();

        void end();

        void score(int score);
    }


}
