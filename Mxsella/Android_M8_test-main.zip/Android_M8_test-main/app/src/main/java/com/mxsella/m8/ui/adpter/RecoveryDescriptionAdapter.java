package com.mxsella.m8.ui.adpter;

import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.mxsella.m8.R;

import java.util.List;

public class RecoveryDescriptionAdapter extends BaseQuickAdapter<List<String>, BaseViewHolder> {

    public RecoveryDescriptionAdapter(@Nullable List<List<String>> data) {
        super(R.layout.item_recovery_description, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, List<String> item) {
        String text = item.get(0) + item.get(1);
        SpannableString spannableString = new SpannableString(text);

        ForegroundColorSpan blackColorSpan = new ForegroundColorSpan(mContext.getResources().getColor(R.color.black));
        spannableString.setSpan(blackColorSpan, 0, text.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        ForegroundColorSpan themeColorSpan = new ForegroundColorSpan(mContext.getResources().getColor(R.color.theme_color));
        spannableString.setSpan(themeColorSpan, 0, item.get(0).length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        helper.setText(R.id.tv_recovery_description, spannableString);
    }
}
