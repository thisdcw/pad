package com.mxsella.m8.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.helper.HardwareHelper;
import com.mxsella.m8.utils.MediaHelper;

public class HardwareDialog extends Dialog {

    private final Context context;

    private EditText edtHardware;
    private Button btnConfirm;

    public HardwareDialog(@NonNull Context context) {
        super(context, R.style.Dialog);
        this.context = context;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_hardware, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        edtHardware = view.findViewById(R.id.edt_hardware);
        btnConfirm = view.findViewById(R.id.btn_confirm);

        edtHardware.setText(HardwareHelper.getVersion());
    }

    public String getHardware() {
        return edtHardware.getText().toString();
    }

    public void setConfirmClickListener(View.OnClickListener listener) {
        btnConfirm.setOnClickListener(listener);
    }
}
