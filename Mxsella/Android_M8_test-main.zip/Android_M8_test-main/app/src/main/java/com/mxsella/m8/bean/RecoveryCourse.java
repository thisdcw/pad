package com.mxsella.m8.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RecoveryCourse implements Serializable {

    private int trainId;
    private String trainName;
    private int trainDuration;
    private List<List<Integer>> hzList;
    private int finishTimes;

    public RecoveryCourse() {
    }

    public RecoveryCourse(int trainId, String trainName, int trainDuration, List<List<Integer>> hzList) {
        this.trainId = trainId;
        this.trainName = trainName;
        this.trainDuration = trainDuration;
        this.hzList = hzList;
    }

    public int getTrainId() {
        return trainId;
    }

    public void setTrainId(int trainId) {
        this.trainId = trainId;
    }

    public String getTrainName() {
        return trainName;
    }

    public void setTrainName(String trainName) {
        this.trainName = trainName;
    }

    public int getTrainDuration() {
        return trainDuration;
    }

    public void setTrainDuration(int trainDuration) {
        this.trainDuration = trainDuration;
    }

    public List<List<Integer>> getHzList() {
        return hzList;
    }

    public void setHzList(List<List<Integer>> hzList) {
        this.hzList = hzList;
    }

    public int getFinishTimes() {
        return finishTimes;
    }

    public void setFinishTimes(int finishTimes) {
        this.finishTimes = finishTimes;
    }

    @Override
    public String toString() {
        return "RecoveryCourse{" +
                "trainId=" + trainId +
                ", trainName='" + trainName + '\'' +
                ", trainDuration=" + trainDuration +
                ", hzList=" + hzList +
                ", finishTimes=" + finishTimes +
                '}';
    }
}
