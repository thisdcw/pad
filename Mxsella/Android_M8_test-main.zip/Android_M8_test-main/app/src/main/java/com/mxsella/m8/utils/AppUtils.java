package com.mxsella.m8.utils;

import android.content.Context;
import android.content.Intent;

import com.mxsella.m8.ui.login.LoginActivity;

public class AppUtils {

    private static final String TAG = "AppUtil";

    public static String getVersionName(Context context) {
        String versionName = "1.0";
        try {
            versionName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return versionName;
    }

    public static int getVersionCode(Context context) {
        int versionCode = 1;
        try {
            versionCode = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return versionCode;
    }

    /**
     * 重启APP
     */
    public static void restartApp(final Context context, final long time, final boolean killFlag) {
        new Thread(() -> {
            try {
                Thread.sleep(time);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block/**/
                e.printStackTrace();
            }
            AppManager.getAppManager().finishAllActivity();
            if (context == null)
                return;
            Intent bootIntent = new Intent(context, LoginActivity.class);
            bootIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(bootIntent);
            if (killFlag) System.exit(0);
        }).start();
    }
}
