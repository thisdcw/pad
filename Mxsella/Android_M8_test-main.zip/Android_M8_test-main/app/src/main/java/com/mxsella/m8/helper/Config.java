package com.mxsella.m8.helper;

import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.mxsella.m8.bean.User;
import com.mxsella.m8.comm.BleService;
import com.mxsella.m8.utils.AppManager;
import com.mxsella.m8.utils.AppUtils;
import com.mxsella.m8.utils.LanguageUtils;

import java.util.Locale;
import java.util.Objects;

public class Config {

    private static final String TAG = "Config";

    public static int BuildVersion = 23;
    public static final String packageName = "com.mxsella.m8";
    public static String versionName = "";
    public static int versionCode = 0;
    public static int versionBranch = 1;

    public static final String BLE_CONNECT = "com.mxsella.m8.BLE_CONNECT";
    public static final String BLE_DISCONNECT = "com.mxsella.m8.BLE_DISCONNECT";

    public static User curUser;
    public static boolean ifKilled = true;
    public static boolean ifDebug = false;
    public static boolean ifLog = false;
    public static boolean ifHttpLog = false;
    public static boolean ifJumpLowPower = false;

    // 语言
    private static final String READ_PRIVACY_POLICY = "read_privacy_policy";
    private static final String LANGUAGE = "language";
    private static final String LOGIN_USER = "login_user";
    // Ble名称
    private static final String BLE_NAME = "ble_name";
    // Ble地址
    private static final String BLE_ADDRESS = "ble_address";
    // 盆底肌评估系数
    private static final String PARAMETER_ASSESS = "parameter_assess";
    // 固件版本
    private static final String HARDWARE_VERSION = "hardware_version";

    public static SharedPreferences mainSP;

    public static void logout() {
        BleService.getInstance().disconnect();
        Config.saveLoginUser(null);
        AppUtils.restartApp(AppManager.getAppManager().currentActivity(), 0, false);
    }

    public static void save(String key, Object value) {
        mainSP.edit().putString(key, String.valueOf(value)).apply();
    }

    public static Boolean getReadPrivacyPolicy() {
        return Boolean.parseBoolean(mainSP.getString(READ_PRIVACY_POLICY, "false"));
    }

    public static void saveReadPrivacyPolicy(Boolean read) {
        save(READ_PRIVACY_POLICY, read);
    }

    public static String getLanguage(boolean auto) {
        String language = mainSP.getString(LANGUAGE, "");
        if (language.isEmpty()) {
            if (auto) {
                return LanguageUtils.AUTO;
            } else {
                String systemLanguage = LanguageUtils.getSystemLanguage().toString();
                for (String key: LanguageUtils.localeMap.keySet()) {
                    Locale locale = LanguageUtils.localeMap.get(key);
                    if (locale != null && locale.toString().equals(systemLanguage)) {
                        return key;
                    }
                }
                return LanguageUtils.DEFAULT_LANGUAGE;
            }
        } else {
            return language;
        }
    }

    public static void saveLanguage(String language) {
        save(LANGUAGE, language);
    }

    public static void removeLanguage() {
        mainSP.edit().remove(LANGUAGE).apply();
    }

    public static User getLoginUser() {
        Config.curUser = new Gson().fromJson(mainSP.getString(LOGIN_USER, ""), User.class);
        return Config.curUser;
    }

    public static void saveLoginUser(User user) {
        Config.curUser = user;
        save(LOGIN_USER, new Gson().toJson(user));
    }

    public static String getBleName() {
        return mainSP.getString(BLE_NAME, "");
    }

    public static void saveBleName(String name) {
        save(BLE_NAME, name);
    }

    public static String getBleAddress() {
        return mainSP.getString(BLE_ADDRESS, "");
    }

    public static void saveBleAddress(String address) {
        save(BLE_ADDRESS, address);
    }

    public static float getParameterAssess() {
        return Float.parseFloat(Objects.requireNonNull(mainSP.getString(PARAMETER_ASSESS, "4.0")));
    }

    public static void saveParameterAssess(float parameter) {
        save(PARAMETER_ASSESS, parameter);
    }

    public static String getHardwareVersion() {
        return mainSP.getString(HARDWARE_VERSION, "");
    }

    public static void saveHardwareVersion(String version) {
        save(HARDWARE_VERSION, version);
    }
}
