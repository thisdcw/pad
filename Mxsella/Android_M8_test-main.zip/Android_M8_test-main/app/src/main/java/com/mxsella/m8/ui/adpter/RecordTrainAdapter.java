package com.mxsella.m8.ui.adpter;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.mxsella.m8.R;
import com.mxsella.m8.bean.AssessRecord;
import com.mxsella.m8.bean.TrainRecord;
import com.mxsella.m8.helper.ResourceHelper;
import com.mxsella.m8.utils.TimeDateUtils;

import java.util.List;

public class RecordTrainAdapter extends BaseQuickAdapter<TrainRecord, BaseViewHolder> {

    public RecordTrainAdapter(@Nullable List<TrainRecord> data) {
        super(R.layout.item_record_train, data);
    }

    @Override
    protected void convert(BaseViewHolder holder, TrainRecord item) {
        holder.setText(R.id.tv_train_time, item.getTrainTime());
        holder.setText(R.id.tv_train_name, ResourceHelper.getStringByName(mContext, "train_name_" + item.getTrainId()));
        holder.setText(R.id.tv_train_duration, TimeDateUtils.getMinAndSecondBySeconds(item.getTrainDuration()));
    }
}
