package com.mxsella.m8.view.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.mxsella.m8.R;
import com.mxsella.m8.utils.DensityUtil;
import com.mxsella.m8.utils.LocalLog;

import java.util.Objects;

import me.jessyan.autosize.AutoSize;

public class BleDialog extends Dialog {

    private final Context context;
    private final String bleName;

    private TextView tvTitle, tvBle;
    private Button btnPair, btnCancel;

    public BleDialog(@NonNull Context context, String bleName) {
        super(context, R.style.Dialog);
        this.context = context;
        this.bleName = bleName;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_ble, null);
        addContentView(view, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT
                , ViewGroup.LayoutParams.WRAP_CONTENT));

        tvTitle = view.findViewById(R.id.tv_title);
        tvBle = view.findViewById(R.id.tv_ble_name);
        btnPair = view.findViewById(R.id.btn_pair);
        btnCancel = view.findViewById(R.id.btn_cancel);
        tvBle.setText(bleName);
    }

    public void setPair() {
        tvTitle.setText(context.getString(R.string.ble_pairing));
        tvTitle.setTextColor(context.getResources().getColor(R.color.theme_color));
        btnPair.setVisibility(View.GONE);
        btnCancel.setVisibility(View.GONE);
        setCanceledOnTouchOutside(false);
    }

    public void setPairClickListener(View.OnClickListener listener) {
        btnPair.setOnClickListener(listener);
    }

    public void setCancelClickListener(View.OnClickListener listener) {
        btnCancel.setOnClickListener(listener);
    }
}
