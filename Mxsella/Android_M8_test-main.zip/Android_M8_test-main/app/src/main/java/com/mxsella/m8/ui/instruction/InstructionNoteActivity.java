package com.mxsella.m8.ui.instruction;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.mxsella.m8.R;
import com.mxsella.m8.base.BaseActivity;
import com.mxsella.m8.helper.Config;
import com.mxsella.m8.ui.user.UserInfoActivity;
import com.mxsella.m8.utils.AppUtils;

import butterknife.OnClick;

public class InstructionNoteActivity extends BaseActivity {

    @Override
    public int getLayoutId() {
        return R.layout.activity_instruction_note;
    }

    public static void show(Context context) {
        context.startActivity(new Intent(context, InstructionNoteActivity.class));
    }

    @Override
    public void initView() {
        super.initView();
    }

    @Override
    protected void initEventAndData() {
        super.initEventAndData();
    }

    @OnClick(R.id.btn_return)
    public void onReturnClick() {
        super.onBackPressedSupport();
    }
}